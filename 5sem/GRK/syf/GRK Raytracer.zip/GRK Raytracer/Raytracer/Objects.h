#ifndef __OBJECTS_H
#define __OBJECTS_H

#include "Vector.h"
#include "Color.h"
class Ray;
class Vector;
class Scene;
class Material;
class Color;

/*
Klasa abstrakcyjna opisujaca obiekty 3d. Wlasciwoscia
kazdego obiektu jest jego material, okreslajacy takie rzeczy
jak kolor (tekstura), wspolczynniki odbicia i zalamania etc.

Najwazniejsza metoda jest FindInter, ktora znajduje przeciecie
promienia swiatla z danym obiektem.
*/

class Object
{
	friend class Scene;
protected:
	Color color;
public:
	Object(){;}
	Object(Color c){color = c;};
	virtual int FindInter(const Ray &r, float &t) = 0; // znajdz przeciecie
	virtual Vector FindNormal(const Vector &v) = 0; // znajdz normalna

};

/*
Kula opisana jest przez wspolrzedne srodka i promien
*/

class Sphere: public Object
{
private:
	Vector	pos; // pozycja
	float	rad; // promien
	float	rr; // kwadrat promienia (dla przyspieszenia obliczen)

public:

	Sphere() : Object(), pos(), rad(0), rr(0) {}
	Sphere(const Vector &p, float r, Color c) : Object(c), pos(p), rad(r), rr(r * r) {}
	Sphere(float x, float y, float z, float r, Color c) : Object(c), pos(x, y, z), rad(r), rr(r*r) {}

	virtual int FindInter(const Ray &r, float &t); // znajdz przeciecie
	virtual Vector FindNormal(const Vector &v); // znajdz normalna

};

/*
Plaszczyzna opisana jest przez wektor normalny oraz parametr "d",
stanowiacy uzupelnienie rownania plaszczyzny Ax + By + Cz +d = 0
*/

class Plane : public Object
{
private:
	Vector	normal; // normalna do plaszczyzny
	float	d; // parametr D rownania plaszczyzny

public:
	Plane() : Object(), normal(), d(0) {}
	Plane(const Vector &n, float r, Color c) : Object(c), normal(n), d(r) {}
	Plane(float x, float y, float z, float r, Color c) : Object(c), normal(x, y, z), d(r) {}

	virtual int FindInter(const Ray &l, float &t);
	virtual Vector FindNormal(const Vector &a);
};


#endif