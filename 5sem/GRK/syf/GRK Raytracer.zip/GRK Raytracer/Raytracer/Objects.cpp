#include "stdafx.h"
#include <math.h>
#include "objects.h"
#include "Color.h"
#include "ray.h"

/*
Metoda znajdujaca przeciecie promienia swiatla z kula.
Zwraca zero dla braku przeciecia lub 1 gdy istnieje przeciecie
*/

int Sphere::FindInter(const Ray &l, float &t)
{
	Vector tmp = l.Point() - pos;
	float a = 1;
	float b = 2 * Dot(tmp,l.Direction());
	float c = Dot(tmp,tmp)-rr;
	
	float delta = pow(b,2) - (4*a*c);
	if(delta > 0){
		float t1 = (-b-sqrt(delta))/(2*a);
		float t2 = (-b+sqrt(delta))/(2*a);
		if(t1<0 && t2<0) return 0;
		float val = min(t1,t2);
		if(val < 0) val = max(t1,t2);
		if(val<0.01) return 0;
		if(val < t){
			t = val;
			return 1;
		}
	}
	return 0;
	

}


/*
Metoda znajduje wektor normalny do kuli w danym jej punkcie
*/ 

Vector Sphere::FindNormal(const Vector &v)
{
	return Normalize(v - pos);
}

/*
Metoda znajdujaca przeciecie z plaszczyzna
- o wiele prostsza niz dla kuli, walca czy stozka
*/

int Plane::FindInter(const Ray &l, float &t)
{
	float a;
	a = Dot(normal,l.Direction());
	
	if(a==0) return 0;
	
	float b;
	b = (Dot(normal,l.Direction())) + d;
	
	float t1 = -b/a;
	if(t1<0.1) return 0;
	if(t1>0 && t1<t){
		t = t1;
		return 1;
	}else{
		return 0;
	}

}

/*
Metoda znajdujaca normalna do plaszczyzny
*/

Vector Plane::FindNormal(const Vector &a)
{
	return Normalize(normal);
}

