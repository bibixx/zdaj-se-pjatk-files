#include "stdafx.h"
#include "scene.h"
#include "ximage.h"
#include <CommCtrl.h>
/*
Metoda dodajaca element do listy
*/
extern CxImage imageDest;
/*
Konstruktor sceny ustawia szereg parametrow na watosci domyslne,
by nie trzeba bylo ich wszystkich ustawiac potem recznie
*/

Scene::Scene()
{
	strcpy (name,"");
	ambient = Color();
	campos = Vector();
	camdir = Vector(0,0,1);

	xres = yres = 200;
	roll = 0;
	aspect = 1;
	fogen = 0;
	maxdeep = 3;
	SetFOV(90);
	SetFog(0,2000,Color(0.4, 0.4, 0.4));
	lights.clear();
	objects.clear();

}


/*
Metoda liczaca natezenie mgly w danej odleglosci od obserwatora
*/

float Scene::CalcFog(float depth)
{
	float a; // tymczasowa zmienna

	a = (depth - dmin) / (dmax - dmin);
	if (a > 1) a = 1;
	if (a < 0) a = 0;
	return a;
}

/*
Metoda ustawiajaca nazwe pliku, do ktorego nastapi zapis
wygenerowanej sceny
*/

void Scene::SetFile(const char *fname)
{
	strncpy(name, fname, sizeof(name));
}

/*
Metoda ustawiajaca pozycje kamery i kierunek patrzenia
*/

void Scene::SetCam(const Vector &pos, const Vector &dir)
{
	campos = pos;
	camdir = dir;
}

/*
Metoda ustawiajaca zasieg mgly i jej kolor
*/

void Scene::SetFog(float min, float max, Color col)
{
	dmin = min;
	dmax = max;
	fog = col;
}

/*
Metoda ustawiajaca pole widzenia
*/

void Scene::SetFOV(unsigned int f)
{
	float a = FOV * PI / 180; // przeliczenie na radiany
	FOV = f;
	focus = yres / (2 * tan(a / 2));
}

/*
Metoda dodajaca obiekt do listy
Zwraca -1 w razie bledu
*/

int Scene::AddObj(Object *obj)
{
	if(obj)
		objects.push_back(obj);
	else
		return -1;
	return 0;
}

/*
Metoda dodajaca swiatlo do listy
Zwraca -1 w razie bledu
*/

int Scene::AddLight(Light *lt)
{
	if(lt)
		lights.push_back(lt);
	else
		return -1;
	return 0;
}

/*
Metoda znajdujaca przeciecie z najblizszym mozliwym obiektem
*/

Object *Scene::FindNearest(const Ray &l, float &t)
{
	Object *nearest = 0, *temp;
	int i = 0;

	t = maxray; // ograniczamy najwieksza glebokosc...

	for(int i = 0; i < objects.size(); i++)
	{
		temp = objects[i];
		if (temp->FindInter(l, t)) // szukanie przeciecia z kazdym objektem...
			nearest = temp; // FindInter zwroci wartosc niezerowa tylko jesli znajdzie blizsze przeciecie
	}
	return nearest;
}

/*
Metoda liczaca kolor w danym punkcie (pobieranym z "info").
Zmienna deep oznacza na ktorym poziomie rekurencji jestesmy,
gdyz metoda ta wywoluje siebie rekurencyjnie w przypadku odbicia
i zalamania swiatla.
*/

Color Scene::CalcColor(const ShInfo *info, int deep)
{
	Color	finalcol; // kolor koncowy
	Color	pointcolor; // kolor tymczasowy
	Light	*lt; // tymczasowe swiatlo
	Object	*obj; // tymczasowy obiekt
	ShInfo	tempinfo;
	ShInfo	*ninfo = &tempinfo; // pomocnicza tymczasowa struktura ShInfo
	int		i = 0; // licznik petli
	float	tmax, t; // parametry promienia
	float	depth = Length(info->point - campos); // odleglosc od kamery
	Ray		newray; // tymczasowy promien swiatla


	pointcolor = info->object->color; // pobranie koloru
	finalcol = ambient * pointcolor; // nalozenie swiatla tla

	for(int i = 0 ; i < lights.size(); i++) // dla kazdego swiatla...
	{
		lt = lights[i];
		Vector dir = lt->Direction(info->point); // kierunek swiatla
		float  shadow; // cien
		float  spc, temp; // tymczasowe zmienne pomocnicze

		newray = Ray(info->point, dir); // puszczamy promien z powierzchni do swiatla
		tmax = Length(lt->ReturnPos() - info->point); // dla cienia szukamy obiektow miedzy aktualnym punktem a swiatlem

		if (Length(dir) > 0)
		{
			shadow = 1; // ustawiamy cien na maksymalna wartosc
			t = tmax;
			for (int j = 0; j < objects.size(); j++)
			{
				if (objects[j]->FindInter(newray, t))
					shadow = 0;
			}

			if (shadow > 0) // jesli jest jakikolwiek cien, to zmien kolor obiektu w tym punkcie
			{
				// CIENOWANIE PHONGA
				
				float radius = Dot(dir,info->normal);
				if(radius>0){
					finalcol+=radius*lt->ReturnColor()*pointcolor;
				}

				
				// EFEKT SPECULAR
				radius = Dot(info->reflect,dir);

				if(radius>0){
					finalcol+=lt->ReturnColor() * pow(radius,8);
				}
			
			
			}
			
		}
	}

	if (deep > maxdeep)
		return finalcol; // nie zglebiamy sie dalej...


	if (fogen) // dodanie efektu mgly w razie potrzeby...
	{
		float a = CalcFog(depth);
		finalcol = a * fog + (1 - a) * finalcol;
	}

	return finalcol; // zwracamy ostateczny kolor...
}

int Scene::Trace()
{

	// szereg zmiennych uzytych w obliczeniach, nie bede ich opisywal
	// szczegolowo, gdyz mija sie to z celem...
	float t;
	float alpha, beta, gamma;
	float length = sqrt(pow(camdir[0],2) + pow(camdir[2], 2));
	float mx1, mx2, mx3, my1, my2, my3, mz1, mz2, mz3;

	Object	*obj; // tu bedzie trzymany obiekt
	ShInfo	tempinfo;
	ShInfo	*info = &tempinfo; // tu struktura okreslajaca aktualny pixel w 3d
	Ray		ray; // promien ktory puscimy z kamery
	Vector	dir, rotdir; // kierunki, w tym rotacja
	Color	col; // kolor punktu
	int x, y, hx = xres/2, hy = yres/2; // rozmiary obrazka

	// teraz szereg obliczen dla znalezienia odwzorowania plaszczyzny ekranu 
	// z 3d na 2d na podstawie parametrow ustawienia kamery...

	if (camdir[2]!=0)
		alpha = atan2(camdir[0], camdir[2]);
	else
		alpha = 0;

	beta  = -asin(camdir[1]/length);
	gamma = roll * PI / 180;

	mx1 = sin(alpha) * sin(beta) * sin (gamma) + cos(alpha) * cos(gamma);
	my1 = cos(beta) * sin(gamma);
	mz1 = sin(alpha) * cos(gamma) - cos(alpha) * sin(beta) * sin(gamma);

	mx2 = sin(alpha) * sin(beta) * cos (gamma) - cos(alpha) * sin(gamma);
	my2 = cos(beta) * cos(gamma);
	mz2 = -cos(alpha) * sin(beta) * cos(gamma) - sin(alpha) * sin(gamma);

	mx3 = -sin(alpha) * cos(beta);
	my3 = sin(beta);
	mz3 = cos(alpha) * cos(beta);

	// glowna petla ponizej liczy kazdy pixel ekranu :

	for (y = yres - 1; y >= 0; y--) // z dolu do gory, gdyz taki format ma BMP...
	{
		for (x = 0; x < xres; x++) // i z lewej do prawej...
		{
			// liczymy wspolrzedne promienia ktory zostanie wypuszczony...

			dir = Vector(aspect * (x - hx), hy - y, focus);

			rotdir[0] = mx1 * dir[0] + my1 * dir[1] + mz1 * dir[2];
			rotdir[1] = mx2 * dir[0] + my2 * dir[1] + mz2 * dir[2];
			rotdir[2] = mx3 * dir[0] + my3 * dir[1] + mz3 * dir[2];

			ray = Ray(Vector(0, 0, -focus) + campos, rotdir);

			// szukamy przeciec z obiektami:

			if ((obj = FindNearest(ray, t)) != 0)
			{
				info->object = obj;
				info->point = ray.GetPoint(t);
				info->normal = obj->FindNormal(info->point);
				info->reflect = ray.Reflect(info->normal);
				info->ray = &ray;

				col = NormalizeColor(CalcColor(info,0)); // jesli jest przeciecie, to znajdz kolor
				
			}
			else
				if (fogen)
					col = fog; // jesli nie ma przeciec, ale jest mgla, to daj kolor mgly
				else
					col = Color(); // a w przeciwnym razie czarny (0, 0, 0)

			// przeksztalcenie wektora koloru do pixela 24-bit
			// CXIMAGE
			RGBQUAD rgb;
			rgb.rgbBlue=255 * col[2];
			rgb.rgbRed=255 * col[0];
			rgb.rgbGreen=255 * col[1];
			imageDest.SetPixelColor(x, yres - y, rgb);
						

		}
		
	}
	
	return 0;
}

