#pragma once

#include "resource.h"

template <class T> class List
{
private:
	struct Element
	{
		char	name[16]; // nazwa elementu
		T		 *member; // skladnik listy
		Element	 *next; // wskaznik na nast. element
	};

	Element *head; // glowa listy

public:
	List() : head(0) {}
	~List();

	int Add(T *memb, const char *name); // dodanie elementu o zadanej nazwie
	T *GiveMemb(const char *name); // znalezienie elementu na podstawie nazwy (w razie braku zwraca null)
	T *GiveMemb(int n); // znalezienie n-tego elementu (w razie braku zwraca null)
};
