if [ `echo -n $1 | wc -c ` -gt 0 ]; then
echo nowy katalog $1;
cd $1;
fi

for i in *; do
	pwd=`pwd`;
	if [ -d $i ]; then
		sh literki.sh $pwd/$i;
	fi
	nowanazwa=`echo $i | tr '[A-Z]{1}' '[a-z]{1}'`;
	mv -f $i $nowanazwa;
	
done;

if [ `echo -n $1 | wc -c ` -gt 0 ]; then
echo opuszczam katalog;
cd ..;
fi
