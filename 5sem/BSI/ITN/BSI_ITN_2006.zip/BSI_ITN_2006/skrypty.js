var ff;



function napis(f, x) { 
        ff=f;
          f.elements[0].blur(); 
          f.elements[0].value = x;
          setTimeout("stare()", 2000); 

   }

function stare() {
	ff.elements[0].value ="Zobacz odpowiedz";
}



function print_model()
{
window.print();
} 

function okno_model(ff)
{
window.open(ff, '', 'toolbar=no,menubar=no,scrollbars=yes, resizable=yes,status=no,location=no,directories=no,top=20, left=20,fullscreen=no,height=570,width=650');
} 

function okno_model1(ff)
{
window.open(ff, '', 'toolbar=no,menubar=no,scrollbars=yes, resizable=yes,status=no,location=no,directories=no,top=5, left=5,fullscreen=no,height=685,width=1010');
} 

function okno(ff)
{
window.open(ff, '', 'toolbar=no,menubar=no,scrollbars=no, resizable=no,status=no,location=no,directories=no,top=20, left=20,fullscreen=no,height=200,width=250');
} 

function okno_szer(ff)
{
window.open(ff, '', 'toolbar=no,menubar=no,scrollbars=no, resizable=no,status=no,location=no,directories=no,top=20, left=20,fullscreen=no,height=200,width=350');
} 


function okno1(ff)
{
window.open(ff, '', 'toolbar=no,menubar=no,scrollbars=no, resizable=no,status=no,location=no,directories=no,top=20, left=20,fullscreen=no,height=250,width=650');
} 

function okno2(ff)
{
window.open(ff, '', 'toolbar=no,menubar=no,scrollbars=no, resizable=no,status=no,location=no,directories=no,top=20, left=20,fullscreen=no,height=400,width=450');
} 

function okno3(ff)
{
window.open(ff, '', 'toolbar=no,menubar=no,scrollbars=no, resizable=no,status=no,location=no,directories=no,top=20, left=20,fullscreen=no,height=550,width=450');
} 

function okno4(ff)
{
window.open(ff, '', 'toolbar=no,menubar=no,scrollbars=no, resizable=no,status=no,titlebar=0,location=no,directories=no,top=20, left=20,fullscreen=no,height=210,width=450');
} 

function okno_duze(ff)
{
window.open(ff, '', 'toolbar=no,menubar=no,scrollbars=yes, resizable=yes,status=no,location=no,directories=no,top=1, left=1,fullscreen=no,height=690,width=800');
}