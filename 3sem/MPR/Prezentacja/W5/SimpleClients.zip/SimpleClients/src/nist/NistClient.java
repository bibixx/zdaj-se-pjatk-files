package nist;

import java.io.*;
import java.net.*;


public class NistClient {
  
  public static void main(String[] args) {
    Socket socket = null;
    int port = 13;
    BufferedReader br = null;
    String[] hosts = { "time.nist.gov", "time-a.nist.gov", "time-b.nist.gov", "time-nw.nist.gov" };
    
    for (String host : hosts) {
      try {

        socket = new Socket();
        InetAddress inetadr = InetAddress.getByName(host);
        InetSocketAddress conadr = new InetSocketAddress(inetadr, port);
        
        // Po�aczenie z serwerem
        socket.connect(conadr, 200);
  
        // Pobranie strumienia wej�ciowego gniazda
        // Nak�adamy buforowanie
        br = new BufferedReader(
                              new InputStreamReader(
                               socket.getInputStream()
                               )
                            );
  

        socket.setSoTimeout(200);
        // Odczyt odpowiedzi serwera (data i czas)
        String line;
        while ((line = br.readLine()) != null) {
          System.out.println("From " + host + ": " + line);
        }
        
        break;
  
      } catch (UnknownHostException exc) {
          System.out.println("Nieznany host: " + host);
      } catch (Exception exc) {
          System.out.println("Host " + host + ", exc = " + exc);
      } finally {
        // Zamkni�cie strumienia i gniazda
          try {
            if (br != null) br.close();
            socket.close();
          } catch (IOException exc) {
            exc.printStackTrace();
          }

      }
    }
  }

}
