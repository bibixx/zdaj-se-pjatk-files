import java.text.*;
import java.util.*;

import static util.Util.*;
 
public class Daty1 {
 
  public static void main(String[] args) {

    Calendar c = Calendar.getInstance();
    Date teraz = c.getTime();

    SimpleDateFormat df = (SimpleDateFormat) DateFormat.getDateInstance();
    
    String[] pattern = {"dd-MM-yyyy",
                        "MMMM, 'dzie� 'dd ( EE ), 'roku 'yyyy GGGG",
                        "EEEE, dd MMM yyyy 'r.'" 
                       };
    for (int i=0; i<pattern.length; i++) {
      df.applyPattern(pattern[i]);
      show(pattern[i] + '\n' + df.format(teraz));
    }  

        
    for (int i=0; i<pattern.length; i++) {

      String in=ask("Wprowad� dat� wg wzorca " + pattern[i]);
      if (in == null) break;
      df.applyPattern(pattern[i]);
      Date data = df.parse(in, new ParsePosition(0)); 
      show(data);
    }  
  } 
 
}
