import static java.lang.String.format;
import static util.Util.*;

import java.util.*;


public class Format {
  
  public static void main(String[] args) {
    double d = 1.126;
    show(format("Wynik w domy�lnej lokalizacji = %f", d));
    show(format(Locale.US,"Wynik w wybranej lokalizacji = %f", d));
    StringBuilder sb = new StringBuilder();
    Formatter f = new Formatter(sb);
    f.format("Miejsca po przecinku 2: %.2f%n", d);
    Date now = Calendar.getInstance().getTime();
    f.format("Data: %tF%n", now);
    f.format("Data: %tY.%<tm.%<td%n", now);
    f.format("Data:\n%te %<tB (%<tA)%n", now);
    show(sb);
    
    // Scanner wprowadza liczby w zlokalizowanej formie
    String sn ;
    Locale loc = null;
    while ((sn = ask("Podaj liczb� rzeczysist�"))!= null) {
      if (sn.matches("[a-z][a-z]")) {
        loc = new Locale(sn);
        continue;
      }
      Scanner s = new Scanner(sn);
      if (loc != null) s.useLocale(loc);
      try {
        show("Liczba = " + s.nextDouble());
      }catch(Exception exc) {
        show(exc);
      }
    }
    
  }

}
