import java.text.*;
import java.util.*;

import static util.Util.*;



public class Sortowanie {

  public static void main(String[] args) {
    List<String> list = Arrays.asList(
        "�wiek", "cekin", "�d�b�o", "zwierz"
        );
    Collections.sort(list, Collator.getInstance(new Locale("pl")));
    show(list);
    Collections.sort(list, Collator.getInstance(new Locale("en")));
    show(list);
  }

}
