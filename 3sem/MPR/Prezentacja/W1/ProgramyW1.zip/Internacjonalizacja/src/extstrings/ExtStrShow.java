package extstrings;

import java.awt.*;
import javax.swing.*;

public class ExtStrShow extends JFrame {

  public ExtStrShow() {
    JButton b1 = new JButton(Messages.getString("txt.open")); //$NON-NLS-1$
    JButton b2 = new JButton(Messages.getString("txt.save")); //$NON-NLS-1$
    JButton b3 = new JButton(Messages.getString("txt.show")); //$NON-NLS-1$
    setTitle(Messages.getString("txt.Title")); //$NON-NLS-1$
    setLayout(new FlowLayout());
    add(b1);
    add(b2);
    add(b3);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    pack();
    setLocationRelativeTo(null);
    setVisible(true);
  }


  public static void main(String[] args) {
    new ExtStrShow();
  }

}
