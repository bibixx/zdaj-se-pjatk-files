package propbund;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.util.*;

import javax.swing.*;

@SuppressWarnings("serial")
public class ExternalStrings extends JFrame {
  
  private Font font = new Font("Dialog", Font.BOLD, 14); //$NON-NLS-1$
  private java.util.List<AbstractButton> txtChanging = new ArrayList<AbstractButton>();
  
  public ExternalStrings() {
    setLayout(new FlowLayout());
    makeButton("open"); 
    makeButton("save"); 
    makeButton("show"); 
    makeButton("english").addActionListener( //$NON-NLS-1$
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            setLocale(new Locale("en")); //$NON-NLS-1$
          }
        }
    );
    
    makeButton("polish").addActionListener( //$NON-NLS-1$
        new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            setLocale(new Locale("pl")); //$NON-NLS-1$
          }
        }
    );
        
    addPropertyChangeListener( new PropertyChangeListener() {
      public void propertyChange(PropertyChangeEvent e) {
        if (e.getPropertyName().equals("locale")) { //$NON-NLS-1$
          Locale loc = (Locale) e.getNewValue();
          Msg.refresh(loc);
          for (AbstractButton b : txtChanging) {
            String txt = Msg.getString((String) b.getClientProperty("lkey"));
            b.setText(txt);
          }
          pack();
        }
      }
      
    });
    
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    pack();
    setLocationRelativeTo(null);
    setVisible(true);
    
  }
  
  private JButton makeButton(String key, ActionListener ... al) {
    JButton b = new JButton(Msg.getString(key));
    b.putClientProperty("lkey", key);
    b.setFont(font);
    for (ActionListener listener : al) {
      b.addActionListener(listener);  
    }
    add(b);
    txtChanging.add(b);
    return b;
  }

  public static void main(String[] args) {
    new ExternalStrings();
  }

}
