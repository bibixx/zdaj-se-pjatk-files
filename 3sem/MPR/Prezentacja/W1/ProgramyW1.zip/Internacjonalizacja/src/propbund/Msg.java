package propbund;

import java.util.*;

public class Msg {

  private static final String BUNDLE_NAME = "propbund.messages"; //$NON-NLS-1$

  private static ResourceBundle RESOURCE_BUNDLE = ResourceBundle
      .getBundle(BUNDLE_NAME);
  
  public static void refresh(Locale loc) {
    RESOURCE_BUNDLE = ResourceBundle
    .getBundle(BUNDLE_NAME, loc);
  }
    
  private Msg() {
  }

  public static String getString(String key) {
    try {
      return RESOURCE_BUNDLE.getString(key);
    } catch (MissingResourceException e) {
      return '!' + key + '!';
    }
  }
}
