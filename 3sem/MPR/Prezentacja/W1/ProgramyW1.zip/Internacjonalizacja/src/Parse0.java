import java.text.*;
import java.util.*;

import static util.Util.*;

public class Parse0 {

  public static void main(String[] args) {
    NumberFormat nf = NumberFormat.getInstance();
    String in;
    while ((in = ask("Liczba?")) != null) {
      if (in.matches("[a-zA-Z]+"))
        nf = NumberFormat.getInstance(new Locale(in));
      else
        try {
          Number n = nf.parse(in);
          show("in = " + in + '\n' + n.getClass().getName() +
                    '\n' + "val = " + n);
        } catch (ParseException e) {
            show(e.toString());
        }
    }
  }
}
