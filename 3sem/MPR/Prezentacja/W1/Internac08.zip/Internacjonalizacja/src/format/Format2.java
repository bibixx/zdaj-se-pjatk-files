package format;

import java.util.*;

import javax.swing.*;

public class Format2 {

  public static void main(String[] args) {
    System.out.println("Wyr�wnany wydruk tablicy (po 2 elementy w wierszu)");
    int[] arr = { 1, 100, 200, 4000 };
    int k = 1;
    for (int i : arr) {
      System.out.printf("%5d", i);
      if (k%2 ==0) System.out.println();
      k++;
    }
    // Zastosowanie znaku < 
    System.out.println("Zaokraglenia");
    System.out.printf("%.3f %<.2f %<.1f", 1.256 );
    
    // Znak < szczeg�lnie przydatny w datach/czasie
    Calendar c = Calendar.getInstance();
    c.set(Calendar.MONTH, 1);
    System.out.printf("\nW roku %tY i miesi�cu %<tm mamy %d dni", c, c.getActualMaximum(Calendar.DATE) );
    
    // Oczywi�cie mo�emy formatowa� do String�w
    String dateNow = String.format("%td-%<tm-%<tY", System.currentTimeMillis());
    JOptionPane.showMessageDialog(null, dateNow);
  }

}
