package format;

import java.util.*;

public class Format1 {

  public static void main(String[] args) {
    double cena = 1.52;
    double ilosc = 3;
    double koszt = cena * ilosc;
    System.out.printf(Locale.ROOT, "Koszt wynosi %.2f z�", koszt);
    System.out.printf("\nData: %tF", Calendar.getInstance());
  }

}
