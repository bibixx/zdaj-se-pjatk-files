package format;

import java.util.*;
import static java.util.FormattableFlags.*;

public class Person implements Formattable{
  
  private String fname;
  private String lname;

  public Person(String fname, String lname) {
    this.fname = fname;
    this.lname = lname;
  }

  @Override
  public void formatTo(Formatter formatter, int flags, int width, int precision) {
    String txt = lname;
    if ((flags & ALTERNATE) == ALTERNATE) txt += ' ' + fname;
    String fs = "%";
    if ((flags & LEFT_JUSTIFY) == LEFT_JUSTIFY) fs += '-';
    if (width >= 0) fs += width;
    if (precision >= 0) fs += "."+precision;
    fs += ((flags & UPPERCASE) == UPPERCASE) ?  "S" : "s";
    formatter.format(fs, txt);
  }


  public static void main(String[] args) {
    Person e =  new Person("Jan", "Kowalski");
    System.out.printf("%#s\n", e);
    System.out.printf("%20s\n", e);
    System.out.printf("%#30S\n", e);
    System.out.printf("%#.10S\n", e);
  }

}
