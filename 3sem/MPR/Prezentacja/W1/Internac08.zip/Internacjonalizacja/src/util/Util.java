package util;
import java.awt.*;
import javax.swing.*;
import javax.swing.plaf.*;



public class Util {
  
  static int fsize = 20;
  static boolean opConfigured = false;
  
  public static void setOpFont(int size) {
    fsize = size;
  }
  
  static void configureOp() {
    FontUIResource font = new FontUIResource(new Font("Dialog",
                                             Font.BOLD, fsize));
    UIManager.put("OptionPane.messageFont", font);
    UIManager.put("TextField.font", font);
    opConfigured = true;
  }
  
  public static String ask(String msg) {
    if (!opConfigured) configureOp();
    return JOptionPane.showInputDialog(msg);
  }
  
  public static void show(Object o) {
    if (o==null) show("null");
    else show(o.toString());
  }
  
  public static void show(String msg) {
    if (!opConfigured) configureOp();
    JOptionPane.showMessageDialog(null, msg);
  }

}
