import java.util.*;

public class Lokalizacja_pl extends ListResourceBundle
{
	public Object[][] getContents()
	{
		return contents;
	}
	
	static final Object[][] contents = {
		{"MENU", "Menu"},
		{"DODAJ", "Dodaj ofert�"},
		{"SORTUJ", "Sortuj"},
		{"ZAPISZ", "Zapisz do XML"},
		{"WCZYTAJ", "Wczytaj"},
		{"ZAKONCZ", "Zako�cz"},	
		{"JEZYK", "Zmie� j�zyk"}
	};
}