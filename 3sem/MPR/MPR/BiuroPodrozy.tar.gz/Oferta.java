import java.util.*;
import java.io.Serializable;

public class Oferta implements Comparable{
	
	public	Date wyjazd;
	public	Date powrot;
	public  String kraj;
	public	String miejsce;
		double cena;
		String opis;
	public void setPowrot(Date powrot)		{
	this.powrot = powrot;
	}
	public Date getPowrot(){
		return powrot;
		}
		
	public void setWyjazd(Date wyjazd)		{
	this.wyjazd = wyjazd;
	}
	public Date getWyjazd(){
		return wyjazd;}
	
	public String toString(){
				return kraj+" region "+miejsce+"\nZa zl: "+cena+"\nOpis oferty:\n"+opis;
		}
		public int compareTo(Object o){
			Oferta of = (Oferta)o;
			//return (int)(cena - of.cena); //sortuje wg ceny rosnaco
			return this.kraj.compareTo(of.kraj); //a tu wg nazwy kraju
		}
	public void setKraj(String l)
	{
		kraj = l;
	}
	public String getKraj()
	{
		return kraj;
	}
	public void setMiejsce(String l)
	{
		miejsce = l;
	}
	public String getMiejsce()
	{
		return miejsce;
	}
	public void setCena(double l)
	{
		cena = l;
	}
	public double getCena()
	{
		return cena;
	}
	public void setOpis(String l)
	{
		opis = l;
	}
	
	public String getOpis()
	{
		return opis;
	}

		
}