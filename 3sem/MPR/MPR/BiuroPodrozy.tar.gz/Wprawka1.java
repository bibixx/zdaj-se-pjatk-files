import java.util.*;
import java.io.*;
import java.text.*;


public class Wprawka1
{
	
	public static Vector oferty = new Vector();
	public static Ramka ramka = new Ramka();
	static	String lokal;
	Locale lokalizacja;
	ResourceBundle tlumaczenia;
	Collator collator;
	
	public static void main(String[]args){
		try{
		
			new Wprawka1(new File("plik.txt"));
		}catch(Exception e){
			System.err.println(e);
		}
		
	}
	

	public Wprawka1(File plik) throws Exception
	{
		oferty =  WczytajPlik(plik, true);
	}
	public static Vector WczytajPlik(File plik, boolean opisy) throws Exception{
	
		Vector tmp_oferty = new Vector();
		BufferedReader r = new BufferedReader(new FileReader(plik));

		StringBuffer opis = null;
		String linia;
		
		
		lokal = r.readLine();
		System.out.println(lokal);
		
		String lok[] = lokal.split("_");
		Locale lokalizacja = new Locale(lok[0], lok[1]);
		//lokalizacja jest potrzebna do p�niejszego parsowania daty (ponizej)
		

		Oferta nowa = null;
		ramka.dopisz("", true);
		while(true)
		{
			linia = r.readLine();
			if (linia == null)
			{
				//TU TWORZY OFERTE OSTATNIA Z PLIKU
				
				nowa.opis = opisy?opis.toString():"";
				ramka.dopisz(nowa.toString(), false); //czysci pole txt
				ramka.dopisz("==============================", false); //nie czysci
				
				tmp_oferty.add(nowa);
				break;
			}
			else if(linia.length()>3 && linia.substring(0,3).equals("###")){
				if(opis!=null){
					 
					//TU TWORZY OFERTE
					
					nowa.opis = opisy?opis.toString():""; // warunek ? (operacja gdy true) : (operacja gdy false) ;
					ramka.dopisz(nowa.toString(), false);
					ramka.dopisz("==============================", false);
					
					tmp_oferty.add(nowa);
					opis = null;
					
				}
				nowa = new Oferta();
				StringTokenizer st = new StringTokenizer(linia);
				DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, lokalizacja);
				//###
				/*	int i=0;
				while(st.hasMoreTokens())
				 System.out.println(i+++". "+st.nextToken());
				*/
				
				st.nextToken();
				nowa.wyjazd = df.parse(st.nextToken());
					ramka.dopisz(nowa.wyjazd.toGMTString(), false);
				nowa.powrot = df.parse(st.nextToken());
				ramka.dopisz(nowa.powrot.toLocaleString(), false);																																		
				nowa.kraj = st.nextToken();
				nowa.miejsce = st.nextToken();
				nowa.cena = Double.parseDouble(st.nextToken());
					ramka.dopisz("Oferta do kraju: "+nowa.kraj+" region "+nowa.miejsce+" za zl: "+nowa.cena, false);
					ramka.dopisz("Opis oferty:", false);
				opis = new StringBuffer();
		
			}
			else{
				
				opis.append(linia);
				opis.append("\n");
			//	System.out.println(linia);
			
			}
			
		}
		
		r.close();
		return tmp_oferty;
	}
}