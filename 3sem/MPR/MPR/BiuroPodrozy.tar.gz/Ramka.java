import javax.swing.*;
import java.io.*;
import java.awt.event.*;
import java.util.Collections; //sortowanie
import java.util.Vector; 
import java.util.Date; 
import java.util.Locale;
import java.util.ResourceBundle;
import java.text.Collator;

import java.beans.*; //do xml Encodera/decodera
class Ramka extends JFrame  implements ActionListener{
		JMenuItem itemSortuj;
		JMenuItem itemZapisz;
		JMenuItem itemWczytaj;
		JMenuItem itemDodaj;
		JMenuItem itemJezyk;
		JMenuItem itemZakoncz;
		JFileChooser chooser = new JFileChooser();
		JTextArea poletxt = new JTextArea();
		Locale lokalizacja;
		ResourceBundle tlumaczenia;
		Collator collator;
	
	public Ramka(){
		
		String lok[] = ("en_US").split("_"); //pl_PL
		lokalizacja = new Locale(lok[0], lok[1]);
		collator = Collator.getInstance(lokalizacja);
		tlumaczenia = ResourceBundle.getBundle("Lokalizacja",lokalizacja);
		
			JMenuBar bar = new JMenuBar();
		JMenu menu = new JMenu(tlumaczenia.getString("MENU"));
		itemSortuj = new JMenuItem(tlumaczenia.getString("SORTUJ"));
		itemZapisz = new JMenuItem(tlumaczenia.getString("ZAPISZ"));
		itemWczytaj = new JMenuItem(tlumaczenia.getString("WCZYTAJ"));
		itemDodaj = new JMenuItem(tlumaczenia.getString("DODAJ"));
		itemZakoncz = new JMenuItem(tlumaczenia.getString("ZAKONCZ"));
		itemJezyk = new JMenuItem(tlumaczenia.getString("JEZYK"));
		
		itemSortuj.addActionListener(this);
		itemZapisz.addActionListener(this);
		itemWczytaj.addActionListener(this);
		itemDodaj.addActionListener(this);
		itemZakoncz.addActionListener(this);
		itemJezyk.addActionListener(this);
		menu.add(itemSortuj);
		menu.add(itemZapisz);
		menu.add(itemWczytaj);
		menu.addSeparator();
		menu.add(itemDodaj);
		menu.addSeparator();
		menu.add(itemJezyk);
		menu.addSeparator();
		menu.add(itemZakoncz);
		
		bar.add(menu);
		setJMenuBar(bar);

		JScrollPane scroll = new JScrollPane(poletxt);

		this.getContentPane().add(scroll);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(new java.awt.Dimension(800, 640));
		/* this.setBackground(new java.awt.Color.GREY); */
	
		this.setVisible(true);
	}
	public void dopisz(String napis){ //jak jeden parametr to nie wyczysci pola txt
		dopisz(napis, false);
	}
	public void dopisz(String napis, boolean czysc){
		
		if(czysc) //czysci pole tekstowe
			poletxt.setText("");
		
		poletxt.append(napis);
		poletxt.append("\n");
	}
	public void actionPerformed(ActionEvent e){
		
		dopisz("przycisk"+e.getActionCommand(), false);
		if(e.getSource()==itemSortuj){
			Collections.sort(Wprawka1.oferty);
			Oferta biezaca = null;
			System.out.println(Wprawka1.oferty);
			dopisz("++++++++++++++++++++++++++++++++++", true);
			for (int i = 0; i<Wprawka1.oferty.size(); i++){
				biezaca = (Oferta)Wprawka1.oferty.get(i);
				dopisz(biezaca.toString());	
				dopisz("++++++++++++++++++++++++++++++++++");	
			}
			biezaca = null;

		}else if(e.getSource()==itemJezyk){
			String jezyk = JOptionPane.showInputDialog(this, "Wpisz lokalizacje (np.: pl_PL)", "pl_PL");
			if(jezyk==null)
				return;
			String lok[] = jezyk.split("_");//pl_PL
			lokalizacja = new Locale(lok[0], lok[1]);
			collator = Collator.getInstance(lokalizacja);
			tlumaczenia = ResourceBundle.getBundle("Lokalizacja",lokalizacja);
				
			itemSortuj.setText(tlumaczenia.getString("SORTUJ"));
			itemZapisz.setText(tlumaczenia.getString("ZAPISZ"));
			itemWczytaj.setText(tlumaczenia.getString("WCZYTAJ"));
			itemDodaj.setText(tlumaczenia.getString("DODAJ"));
			itemZakoncz.setText(tlumaczenia.getString("ZAKONCZ"));
			itemJezyk.setText(tlumaczenia.getString("JEZYK"));
			
		}else if(e.getSource()==itemZapisz){
				zapisz();

		}else if(e.getSource()==itemWczytaj){
				wczytaj();

		}else if(e.getSource()==itemDodaj){
				dodaj();

		}
		else if(e.getSource()==itemZakoncz){
			System.exit(0);

				}	
}
public void zapisz()
	{
		System.out.println(new Date(0).toGMTString());
		System.out.println(new Date(Long.MAX_VALUE).toGMTString());
		int decyzja = chooser.showSaveDialog(this);
		if(decyzja != chooser.APPROVE_OPTION)
		{
			return;
		}
		try
		{
			XMLEncoder output = new XMLEncoder(new FileOutputStream(chooser.getSelectedFile()));
			output.writeObject(Wprawka1.oferty);
			output.close();
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(this, "Blad zapisu");				
		}
		finally{
			JOptionPane.showMessageDialog(this,"Zapisano do pliku: "+chooser.getSelectedFile().getName());	
		}
	}
		
	public void wczytaj()
	{
		int decyzja = chooser.showOpenDialog(this);
		if(decyzja != chooser.APPROVE_OPTION)
		{
			return;
		}
		try
		{
			XMLDecoder input = new XMLDecoder(new FileInputStream(chooser.getSelectedFile()));
			Vector v = (Vector)input.readObject();
			input.close();
			Oferta o;
			for(int i=0; i<v.size(); i++){
				o = (Oferta)v.get(i);
				Wprawka1.oferty.add(o);		
			}
			
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(this,"Blad odczytu");
			return;
		}
	
	}			
	public void dodaj()
	{
		int decyzja = chooser.showOpenDialog(this);
		if(decyzja != chooser.APPROVE_OPTION)
		{
			return;
		}
		try
		{
			Vector v = Wprawka1.WczytajPlik(chooser.getSelectedFile(),true);
			Oferta o;
			for(int i=0; i<v.size(); i++){
				o = (Oferta)v.get(i);
				Wprawka1.oferty.add(o);		
			}
			
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(this,"Blad odczytu");
			return;
		}
	
	}	
}