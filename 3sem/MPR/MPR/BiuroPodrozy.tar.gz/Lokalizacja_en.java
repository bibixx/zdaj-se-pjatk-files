import java.util.*;

public class Lokalizacja_en extends ListResourceBundle
{
	public Object[][] getContents()
	{
		return contents;
	}
	
	static final Object[][] contents = {
		{"MENU", "Menu"},
		{"DODAJ", "Add offer"},
		{"SORTUJ", "Sort"},
		{"ZAPISZ", "Export to XML"},
		{"WCZYTAJ", "Import"},
		{"ZAKONCZ", "Exit"},
		{"JEZYK", "Change language"}
	};
}