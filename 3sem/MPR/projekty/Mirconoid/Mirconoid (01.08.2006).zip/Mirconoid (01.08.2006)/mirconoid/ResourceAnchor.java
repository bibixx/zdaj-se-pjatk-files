package mirconoid;

import java.awt.Image;
import java.awt.Toolkit;
import java.util.Locale;
import java.util.ResourceBundle;

public class ResourceAnchor
{
	static ClassLoader				cl							= ResourceAnchor.class.getClassLoader();
	public static Image				currentUpperPanelSkin		= Toolkit.getDefaultToolkit().getImage(cl.getResource("pictures/upperPanelDefault.jpg"));
	public static Image				currentLowerPanelSkin		= Toolkit.getDefaultToolkit().getImage(cl.getResource("pictures/lowerPanelDefault.jpg"));
	public static Image				backgroundForMainMenuImage	= Toolkit.getDefaultToolkit().getImage(cl.getResource("pictures/MainMenuBackground.jpg"));
	public static Image				mirconoidImage				= Toolkit.getDefaultToolkit().getImage(cl.getResource("pictures/mirconoid.jpg"));
	public static Image				ballImage					= Toolkit.getDefaultToolkit().getImage(cl.getResource("pictures/Ball.gif"));
	public static ResourceBundle	msgsDEFAULT					= ResourceBundle.getBundle("mirconoid/PropertiesFiles/mirconoid", Locale.getDefault());

	// -------------------------------------------------
	// ResourceAnchor()
	// ------------------------------------------------
	public ResourceAnchor()
	{
	}
	// -------------------------------------------------
	// getImage()
	// ------------------------------------------------
	public static Image getImage( String path )
	{
		Image image = loadImage(path);
		return image;
	}
	// -------------------------------------------------
	// loadImage()
	// ------------------------------------------------
	public static Image loadImage( String path )
	{
		Image image = Toolkit.getDefaultToolkit().getImage(cl.getResource(path));
		return image;
	}
	// -------------------------------------------------
	// setSkin()
	// ------------------------------------------------
	public static void setSkin( String upperPanelSkin, String lowerPanelSkin )
	{
		currentUpperPanelSkin = Toolkit.getDefaultToolkit().getImage(cl.getResource(upperPanelSkin));
		currentLowerPanelSkin = Toolkit.getDefaultToolkit().getImage(cl.getResource(lowerPanelSkin));
		Gameplay.setNewSkin();
	}
}