package mirconoid;

import java.awt.BorderLayout;
import java.util.Locale;
import java.util.ResourceBundle;
import javax.swing.JOptionPane;
import mirconoid.MenuBars.GameplayMenuBar.GameplayMenuBar;
import mirconoid.MenuBars.MainMenuMenuBar.MainMenuMenuBar;

public final class Manager
{
	private static Manager								manager		= null;
	// internacionalization
	public static ResourceBundle						msgsDEFAULT	= ResourceBundle.getBundle("mirconoid/PropertiesFiles/mirconoid", Locale.getDefault());
	public static ResourceAnchor						resources;
	// media player (for audio and video)
	private static mirconoid.mediaPlayer.MediaPlayer	mediaPlayer	= new mirconoid.mediaPlayer.MediaPlayer();
	// frames
	private static Window								window;
	// menu bars
	private static MainMenuMenuBar						MMMB;
	private static GameplayMenuBar						GPMB;
	private static Gameplay								gameplay;

	// -------------------------------------------------
	// Manager()
	// -------------------------------------------------
	private Manager()
	{
		window = new Window("Mirconoid", 800, 600);
		MMMB = new MainMenuMenuBar();
		GPMB = new GameplayMenuBar();
		gameplay = new Gameplay();
	}
	// -------------------------------------------------
	// getInstance()
	// -------------------------------------------------
	public static synchronized Manager getInstance()
	{
		if (manager == null)
			manager = new Manager();
		return manager;
	}
	// -------------------------------------------------
	// resetGameplayMenuBar()
	// -------------------------------------------------
	public static void resetGameplayMenuBar()
	{
		GPMB = null;
		GPMB = new GameplayMenuBar();
		window.setMenu(GPMB);
		window.packAndShow();
	}
	// -------------------------------------------------
	// resetMainMenuBar()
	// -------------------------------------------------
	public static void resetMainMenuBar()
	{
		MMMB = null;
		MMMB = new MainMenuMenuBar();
		window.setMenu(MMMB);
		window.packAndShow();
	}
	// -------------------------------------------------
	// getMediaPlayer()
	// -------------------------------------------------
	public static mirconoid.mediaPlayer.MediaPlayer getMediaPlayer()
	{
		return mediaPlayer;
	}
	// -------------------------------------------------
	// getGameplay()
	// -------------------------------------------------
	public static Gameplay getGameplay()
	{
		return gameplay;
	}
	// -------------------------------------------------
	// getWindow()
	// -------------------------------------------------
	public static Window getWindow()
	{
		return window;
	}
	// -------------------------------------------------
	// goTo()
	// -------------------------------------------------
	public static void goTo( String choose )
	{
		if (choose.equals("MainMenu"))
		{
			window.removeAllElements();
			window.setMenu(MMMB);
			Gameplay.reset();
			window.addJPanel(gameplay);
			window.packAndShow();
			gameplay.startMainMenu();
		}
		if (choose.equals("Gameplay"))
		{
			window.removeAllElements();
			window.setMenu(MMMB);
			Gameplay.reset();
			window.addJPanel(gameplay);
			window.packAndShow();
			gameplay.start();
		}
	}
	// -------------------------------------------------
	// showHighScoresWindow()
	// -------------------------------------------------
	public static void showHighScoresWindow()
	{
		new mirconoid.windows.HighScoresWindow();
	}
	// -------------------------------------------------
	// showAboutWindow()
	// -------------------------------------------------
	public static void showAboutWindow()
	{
		Window window = new Window("About Mirconoid", 800, 600);
		window.setDefaultCloseOperation(1);
		window.setLayout(new BorderLayout());
		JPanelWithBackground panelCenter = new JPanelWithBackground("pictures/about/center.jpg");
		window.add(panelCenter, BorderLayout.CENTER);
		window.packAndShow();
	}
	// -------------------------------------------------
	// showHelpWindow()
	// -------------------------------------------------
	public static void showHelpWindow()
	{
		Window window = new Window("Mirconoid help", 800, 800);
		window.setDefaultCloseOperation(1);
		window.setLayout(new BorderLayout());
		JPanelWithBackground panelCenter = new JPanelWithBackground("pictures/help/center.jpg");
		window.add(panelCenter, BorderLayout.CENTER);
		window.packAndShow();
	}
	// -------------------------------------------------
	// showErrorMessageWhenConnectingToSQLServer()
	// -------------------------------------------------
	public static void showErrorMessageWhenConnectingToSQLServer()
	{
		JOptionPane.showMessageDialog(window, "ERROR - Server not responding", "Connection Timeout", JOptionPane.ERROR_MESSAGE);
	}
	// -------------------------------------------------
	// showWaintingMessageWhenConnectingToSQLServer()
	// -------------------------------------------------
	public static void showWaintingMessageWhenConnectingToSQLServer()
	{
		JOptionPane.showMessageDialog(window, msgsDEFAULT.getString("Patient") + "\n" + msgsDEFAULT.getString("Connect"));
	}
	// -------------------------------------------------
	// showCongratulationMessage()
	// -------------------------------------------------
	public static void showCongratulationMessage( String text )
	{
		JOptionPane.showMessageDialog(window, "\t\t" + msgsDEFAULT.getString("WellDone") + "\n\n\t" + msgsDEFAULT.getString("Level") + " " + text + " " + msgsDEFAULT.getString("Complete"), msgsDEFAULT.getString("WellDone"), JOptionPane.INFORMATION_MESSAGE);
	}
}
