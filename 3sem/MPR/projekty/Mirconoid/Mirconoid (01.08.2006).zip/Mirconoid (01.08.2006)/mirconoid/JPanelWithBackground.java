package mirconoid;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import javax.swing.JPanel;

public class JPanelWithBackground extends JPanel
{
	private Image	backgroundImage;
	private boolean	loaded;
	private int		imageWidth;
	private int		imageHeight;

	JPanelWithBackground(String imgFileName)
	{
		loadImage(imgFileName);
	}
	public void paintComponent( Graphics g )
	{
		super.paintComponent(g);
		if (backgroundImage != null && loaded)
		{
			g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
		}
	}
	private void loadImage( String imgFileName )
	{
		backgroundImage = ResourceAnchor.loadImage(imgFileName);
		MediaTracker mt = new MediaTracker(this);
		mt.addImage(backgroundImage, 1);
		try
		{
			mt.waitForID(1);
		}
		catch (InterruptedException exc)
		{
			System.err.println("ERROR: " + exc.getMessage());
		}
		imageWidth = backgroundImage.getWidth(this);
		imageHeight = backgroundImage.getHeight(this);
		if (imageWidth != -1 && imageWidth != 0 && imageHeight != -1 && imageHeight != 0)
		{
			loaded = true;
			setPreferredSize(new Dimension(imageWidth, imageHeight));
		}
		else
		{
			setPreferredSize(new Dimension(800, 600));
		}
	}
}