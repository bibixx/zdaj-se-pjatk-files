package mirconoid.ball;

import java.awt.*;
import mirconoid.*;
import mirconoid.Methods.AudioMethods;

public class Ball implements Runnable
{
	private static int			mirconoid_X_AXIS;
	private static int			mirconoid_WIDTH					= Gameplay.getmirconoidPerameters("width");
	private static int			mirconoid_HEIGHT				= Gameplay.getmirconoidPerameters("height");
	private static int			BALL_SIZE						= Gameplay.getBallSize();
	private static int			BALL_X_AXIS						= Gameplay.getBallLocation("x");
	private static int			BALL_Y_AXIS						= Gameplay.getBallLocation("y");
	private static Rectangle	collisionRectangleFormirconoid	= new Rectangle(0, 0, mirconoid_WIDTH, mirconoid_HEIGHT);	// collison
																															// rectangle
																															// for
																															// mirconoid
	private static Rectangle	collisionRectangleForBall		= new Rectangle(0, 0, BALL_SIZE, BALL_SIZE);				// collison
																															// rectangle
																															// for
																															// ball
	private static int			planeWidth						= 800;
	private static int			planeHeight						= 480;

	// ------------------------------------------------
	// runBallPhisics()
	// ------------------------------------------------
	public static void runBallPhisics()
	{
		mirconoid_X_AXIS = Gameplay.getmirconoidLocation("x");
		BALL_X_AXIS = Gameplay.getBallLocation("x");
		BALL_Y_AXIS = Gameplay.getBallLocation("y");
		checkBallCollisionWithMirconoid();
		ballMove();
	}
	// ------------------------------------------------
	// ballMove()
	// ------------------------------------------------
	public static void ballMove()
	{
		if (Gameplay.ballTrajectory_Y > 0 && BALL_Y_AXIS > 400 && BALL_Y_AXIS < 500)
		{
			Gameplay.bounced = false;
		}
		if (Gameplay.ballTrajectory_Y < 0 && BALL_Y_AXIS > 400 && BALL_Y_AXIS < 500)
		{
			Gameplay.bounced = true;
		}
		if (BALL_Y_AXIS < 0) // upper bound
		{
			AudioMethods.playBorderHit();
			Gameplay.ballTrajectory_Y = -Gameplay.ballTrajectory_Y;
		}
		if (BALL_X_AXIS < 0 || BALL_X_AXIS > planeWidth - BALL_SIZE) // left
																		// bound
																		// and
																		// right
																		// bound
		{
			AudioMethods.playBorderHit();
			Gameplay.ballTrajectory_X = -Gameplay.ballTrajectory_X;
		}
		if (BALL_Y_AXIS > planeHeight - BALL_SIZE) // ball touches ground
		{
			if (!Gameplay.liveLost)
			{
				AudioMethods.playBallLost();
				Gameplay.lives -= 1; // player looses 1 live
				Gameplay.liveLost = true;
			}
		}
		if (!Gameplay.gamePaused && !Gameplay.gamePausedByMouseExit && Gameplay.liveLost && !Gameplay.gameOver) // status
																												// after
																												// loss
		{
			Gameplay.bounced = false;
			mirconoid.Gameplay.changeBallLocation("set", 400, 260);
			Gameplay.ballTrajectory_X = 0;
			Gameplay.ballTrajectory_Y = 0;
		}
		mirconoid.Gameplay.changeBallLocation("update", Gameplay.ballTrajectory_X, Gameplay.ballTrajectory_Y);
	}
	// ------------------------------------------------
	// checkBallCollisionWithMirconoid()
	// ------------------------------------------------
	public static void checkBallCollisionWithMirconoid()
	{
		collisionRectangleFormirconoid.setLocation(mirconoid_X_AXIS, Gameplay.getPanelGameHeight() - mirconoid_HEIGHT - 5);
		collisionRectangleForBall.setLocation(BALL_X_AXIS, BALL_Y_AXIS);
		if (BALL_Y_AXIS >= 450)
		{
			if (collisionRectangleForBall.intersects(collisionRectangleFormirconoid) && !Gameplay.bounced && !Gameplay.gamePaused)
			{
				Gameplay.numberOfBounces += 1;
				AudioMethods.playMirconoidHit();
				// ====================================================================================================================
				// BALL RIGTH ( X+ Y+ )
				// ====================================================================================================================
				if (Gameplay.ballTrajectory_X > 0 && Gameplay.ballTrajectory_Y > 0) // HARD
																					// LEFT
																					// X+
																					// Y+
				{
					// ==========================
					// LEFT SIDE
					// ==========================
					/* normalny L */if (BALL_X_AXIS < mirconoid_X_AXIS + BALL_SIZE &&
					/* nieudany */BALL_X_AXIS + BALL_SIZE < mirconoid_X_AXIS + BALL_SIZE)
					{
						Gameplay.bounced = true;
						Gameplay.ballTrajectory_X = -Gameplay.ballTrajectory_X;
					}
					else
					/* normalny L */if (BALL_X_AXIS < mirconoid_X_AXIS + BALL_SIZE && BALL_X_AXIS + BALL_SIZE < mirconoid_X_AXIS + BALL_SIZE)
					{
						Gameplay.bounced = true;
						double temp = Gameplay.ballTrajectory_X;
						Gameplay.ballTrajectory_X = -Gameplay.ballTrajectory_Y;
						Gameplay.ballTrajectory_Y = -temp;
					}
					/* niepelny */if (BALL_X_AXIS < mirconoid_X_AXIS + BALL_SIZE && BALL_X_AXIS + BALL_SIZE / 2 > mirconoid_X_AXIS + BALL_SIZE)
					{
						Gameplay.bounced = true;
						double temp = Gameplay.ballTrajectory_X;
						Gameplay.ballTrajectory_X = -Gameplay.ballTrajectory_Y;
						Gameplay.ballTrajectory_Y = -temp;
					}
					// ==========================
					// RIGTH SIDE
					// ==========================
					/* normalny R */if (BALL_X_AXIS + BALL_SIZE > mirconoid_X_AXIS + mirconoid_WIDTH - BALL_SIZE && BALL_X_AXIS > mirconoid_X_AXIS + mirconoid_WIDTH - BALL_SIZE)
					{
						Gameplay.bounced = true;
						double temp = Gameplay.ballTrajectory_X;
						Gameplay.ballTrajectory_X = Gameplay.ballTrajectory_Y;
						Gameplay.ballTrajectory_Y = -temp;
					}
					/* niepelny */if (BALL_X_AXIS + BALL_SIZE / 2 > mirconoid_X_AXIS + mirconoid_WIDTH - BALL_SIZE && BALL_X_AXIS < mirconoid_X_AXIS + mirconoid_WIDTH - BALL_SIZE)
					{
						Gameplay.bounced = true;
						double temp = Gameplay.ballTrajectory_X;
						Gameplay.ballTrajectory_X = Gameplay.ballTrajectory_Y;
						Gameplay.ballTrajectory_Y = -temp;
					}
				}
				// ====================================================================================================================
				// BALL LEFT ( X- Y+ )
				// ====================================================================================================================
				if (Gameplay.ballTrajectory_X < 0 && Gameplay.ballTrajectory_Y > 0) // HARD
																					// RIGTH
																					// X-
																					// Y+
				{
					// ==========================
					// RIGTH SIDE
					// ==========================
					/* normalny R */if (BALL_X_AXIS + BALL_SIZE > mirconoid_X_AXIS + mirconoid_WIDTH - BALL_SIZE && BALL_X_AXIS > mirconoid_X_AXIS + mirconoid_WIDTH - BALL_SIZE)
					{
						Gameplay.bounced = true;
						double temp = Gameplay.ballTrajectory_X;
						Gameplay.ballTrajectory_X = Gameplay.ballTrajectory_Y;
						Gameplay.ballTrajectory_Y = temp;
					}
					/* niepelny */if (BALL_X_AXIS + BALL_SIZE / 2 > mirconoid_X_AXIS + mirconoid_WIDTH - BALL_SIZE && BALL_X_AXIS < mirconoid_X_AXIS + mirconoid_WIDTH - BALL_SIZE)
					{
						Gameplay.bounced = true;
						double temp = Gameplay.ballTrajectory_X;
						Gameplay.ballTrajectory_X = Gameplay.ballTrajectory_Y;
						Gameplay.ballTrajectory_Y = temp;
					}
					// ==========================
					// LEFT SIDE
					// ==========================
					/* normalny L */if (BALL_X_AXIS + BALL_SIZE < mirconoid_X_AXIS + BALL_SIZE && BALL_X_AXIS < mirconoid_X_AXIS + BALL_SIZE)
					{
						Gameplay.bounced = true;
						double temp = Gameplay.ballTrajectory_X;
						Gameplay.ballTrajectory_X = -Gameplay.ballTrajectory_Y;
						Gameplay.ballTrajectory_Y = temp;
					}
					/* niepelny */if (BALL_X_AXIS < mirconoid_X_AXIS + BALL_SIZE && BALL_X_AXIS + BALL_SIZE / 2 > mirconoid_X_AXIS + BALL_SIZE)
					{
						Gameplay.bounced = true;
						double temp = Gameplay.ballTrajectory_X;
						Gameplay.ballTrajectory_X = -Gameplay.ballTrajectory_Y;
						Gameplay.ballTrajectory_Y = temp;
					}
				}
				if (!Gameplay.bounced)
				{
					Gameplay.ballTrajectory_Y = -Gameplay.ballTrajectory_Y;
					Gameplay.bounced = true;
				}
			}
		}
	}
	public void run()
	{
		runBallPhisics();
	}
}