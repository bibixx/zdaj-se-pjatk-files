package mirconoid.Methods;

import mirconoid.Gameplay;
import mirconoid.Manager;

public class Methods
{
	static int	w	= Gameplay.getWindowParameters("width");
	static int	h	= Gameplay.getWindowParameters("height");

	public static void startNewGame()
	{
		if (!Gameplay.gameStarted)
		{
			System.out.println("CONSOLE INFO: startNewGame()");
			Manager.resetGameplayMenuBar();
			Gameplay.newLevel = true;
			Gameplay.gameStarted = true;
		}
	}
	public static void pauseGame()
	{
		System.out.println("CONSOLE INFO: pauseGame()");
		Gameplay.changePausedBallTrajectory("x", "set", Gameplay.ballTrajectory_X);
		Gameplay.changePausedBallTrajectory("y", "set", Gameplay.ballTrajectory_Y);
		Gameplay.changeBallTrajectory("x", "set", 0);
		Gameplay.changeBallTrajectory("y", "set", 0);
		Gameplay.gamePaused = true;
	}
	// ---------------------------------
	public static void continueGame()
	{
		// ---------------------------------
		System.out.println("CONSOLE INFO: continueGame()");
		Gameplay.ballTrajectory_X = Gameplay.pausedBallTrajectory_X;
		Gameplay.ballTrajectory_Y = Gameplay.pausedBallTrajectory_Y;
		Gameplay.gamePaused = false;
	}
	// ------------------------------------------
	public static void continueGameAfterLoss()
	{
		// ------------------------------------------
		System.out.println("CONSOLE INFO: continueGameAfterLoss()");
		int choose = (int) Math.floor(Math.random() * 2);
		int x = 5;
		if (choose == 1)
		{
			Gameplay.changeBallTrajectory("x", "set", x);
		}
		else
			Gameplay.changeBallTrajectory("x", "set", -x);
		Gameplay.changeBallTrajectory("y", "set", 4);
		Gameplay.liveLost = false;
		Gameplay.bouncedBlock = false;
		Gameplay.bounced = false;
	}
	// -----------------------------------------
	public static void pauseGameByMouseExit()
	{
		// -----------------------------------------
		System.out.println("CONSOLE INFO: pauseGameByMouseExit()");
		Gameplay.changePausedBallTrajectory("x", "set", Gameplay.ballTrajectory_X);
		Gameplay.changePausedBallTrajectory("y", "set", Gameplay.ballTrajectory_Y);
		Gameplay.changeBallTrajectory("x", "set", 0);
		Gameplay.changeBallTrajectory("y", "set", 0);
		Gameplay.gamePausedByMouseExit = true;
	}
	// ---------------------------------------------
	public static void continueGameByMouseEnter()
	{
		// ---------------------------------------------
		System.out.println("CONSOLE INFO: continueGameByMouseEnter()");
		Gameplay.ballTrajectory_X = Gameplay.pausedBallTrajectory_X;
		Gameplay.ballTrajectory_Y = Gameplay.pausedBallTrajectory_Y;
		Gameplay.gamePausedByMouseExit = false;
	}
	// -----------------------------
	public static void NewLevel()
	{
		// -----------------------------
		System.out.println("CONSOLE INFO: continueGameOnNewLevel()");
		mirconoid.Gameplay.changeBallLocation("set", 400, 260);
		Gameplay.ballTrajectory_X = 0;
		Gameplay.ballTrajectory_Y = 0;
		Gameplay.newLevel = true;
	}
	// -------------------------------------------
	public static void continueGameOnNewLevel()
	{
		// -------------------------------------------
		Gameplay.newLevel = false;
		int choose = (int) Math.floor(Math.random() * 2);
		int x = 5;
		if (choose == 1)
		{
			Gameplay.changeBallTrajectory("x", "set", x);
		}
		else
			Gameplay.changeBallTrajectory("x", "set", -x);
		Gameplay.changeBallTrajectory("y", "set", 4);
	}
	// ---------------------------------
	public static void goToMainMenu()
	{
		// ---------------------------------
		Gameplay.gameStarted = false;
		Gameplay.exit = true;
		Manager.goTo("MainMenu");
	}
	// ------------------------------------
	public static void showAboutWindow()
	{
		// ------------------------------------
		Manager.showAboutWindow();
	}
	// -----------------------------------
	public static void showHighScores()
	{
		// -----------------------------------
		Manager.showHighScoresWindow();
	}
	// -----------------------------------
	public static void showHelpWindow()
	{
		// -----------------------------------
		Manager.showHelpWindow();
	}
	// -----------------------------
	public static void quitGame()
	{
		// -----------------------------
		System.exit(0);
	}
}