package mirconoid.Methods;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;

public class AudioMethods
{
	private static InputStream			is;
	private static BufferedInputStream	bis;
	private static AudioStream			as;

	public static void playAudioStream( String path )
	{
		try
		{
			is = new FileInputStream(path);
			bis = new BufferedInputStream(is);
			as = new AudioStream(bis);
			AudioPlayer.player.start(as);
		}
		catch (IOException e)
		{
			System.err.print("AUDIO ERROR: " + e.getMessage());
		}
	}
	public static void loadAudioStream( String path )
	{
		try
		{
			is = new FileInputStream(path);
			bis = new BufferedInputStream(is);
			as = new AudioStream(bis);
			AudioPlayer.player.start(as);
			AudioPlayer.player.stop(as);
		}
		catch (IOException e)
		{
			System.err.print("AUDIO ERROR: " + e.getMessage());
		}
	}
	public static void playBallLost()
	{
		try
		{
			is = new FileInputStream("sounds/ball_lost.wav");
			bis = new BufferedInputStream(is);
			as = new AudioStream(bis);
			AudioPlayer.player.start(as);
		}
		catch (IOException e)
		{
			System.err.print("AUDIO ERROR: " + e.getMessage());
		}
	}
	public static void playBorderHit()
	{
		try
		{
			is = new FileInputStream("sounds/border_hit.wav");
			bis = new BufferedInputStream(is);
			as = new AudioStream(bis);
			AudioPlayer.player.start(as);
		}
		catch (IOException e)
		{
			System.err.print("AUDIO ERROR: " + e.getMessage());
		}
	}
	public static void playMirconoidHit()
	{
		try
		{
			is = new FileInputStream("sounds/mirconoid_hit.wav");
			bis = new BufferedInputStream(is);
			as = new AudioStream(bis);
			AudioPlayer.player.start(as);
		}
		catch (IOException e)
		{
			System.err.print("AUDIO ERROR: " + e.getMessage());
		}
	}
	public static void playBrickHit()
	{
		try
		{
			is = new FileInputStream("sounds/brick_hit.wav");
			bis = new BufferedInputStream(is);
			as = new AudioStream(bis);
			AudioPlayer.player.start(as);
		}
		catch (IOException e)
		{
			System.err.print("AUDIO ERROR: " + e.getMessage());
		}
	}
	public static void playBonusHit()
	{
		try
		{
			is = new FileInputStream("sounds/bonus.wav");
			bis = new BufferedInputStream(is);
			as = new AudioStream(bis);
			AudioPlayer.player.start(as);
		}
		catch (IOException e)
		{
			System.err.print("AUDIO ERROR: " + e.getMessage());
		}
	}
}