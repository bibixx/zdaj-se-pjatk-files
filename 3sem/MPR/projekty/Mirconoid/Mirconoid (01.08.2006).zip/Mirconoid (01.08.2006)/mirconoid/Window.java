package mirconoid;

import java.awt.Container;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import mirconoid.screen.ScreenResolution;

public class Window extends JFrame implements MouseListener
{
	private Container	container	= this.getContentPane();
	private Image		icon		= Toolkit.getDefaultToolkit().getImage("./Pictures/Icon.jpg");

	public Window(String title, int w, int h)
	{
		this.setDefaultCloseOperation(Window.EXIT_ON_CLOSE);
		this.setIconImage(icon);
		setTitle(title);
		ScreenResolution.getDefaultScreenResolution();
		setResizable(false);
		if (w != 0 && h != 0)
		{
			setSize(w, h);
			setNewLocation();
		}
		else
		{
			System.out.println("WARNING: Frame size is not Specified.");
			System.out.println("INFO: Setting frame size to default (800x600)");
			setSize(800, 600);
			setNewLocation();
		}
		this.addMouseListener(this);
	}
	public void setNewLocation()
	{
		setLocation((ScreenResolution.getDefaultScreenWidth() / 2) - (this.getWidth() / 2), (ScreenResolution.getDefaultScreenHeight() / 2) - (this.getHeight() / 2) - (ScreenResolution.getDefaultScreenHeight() / 10));
	}
	public void addJPanel( JPanel p )
	{
		System.out.println("CONSOLE INFO: JPanel added to window from " + p.getClass());
		container.add(p);
		if (p.getClass().equals("mirconoid.MainMenu"))
		{
			setNewLocation();
		}
	}
	public void setMenu( JMenuBar mb )
	{
		this.setJMenuBar(null);
		this.setJMenuBar(mb);
	}
	public void packAndShow()
	{
		this.pack();
		this.setVisible(true);
	}
	public void removeAllElements()
	{
		System.out.println("CONSOLE INFO: All elements removed from window");
		container.removeAll();
	}
	public void mouseClicked( MouseEvent arg0 )
	{
	}
	public void mouseEntered( MouseEvent arg0 )
	{
	}
	public void mouseExited( MouseEvent arg0 )
	{
	}
	public void mousePressed( MouseEvent arg0 )
	{
		this.dispose();
		this.invalidate();
	}
	public void mouseReleased( MouseEvent arg0 )
	{
	}
}