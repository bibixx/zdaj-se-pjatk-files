package mirconoid.MenuBars;

import javax.swing.ImageIcon;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.KeyStroke;

import mirconoid.Manager;

public class MenuBarsMethods 
{
	
//---------------------------------------------------------------------------------------------------------------------------------
public static JMenuItem createJMenuItem( JMenu menu, int type, String text, ImageIcon image, int acceleratorKey, String accel ) {
//---------------------------------------------------------------------------------------------------------------------------------
	JMenuItem menuItem;

	switch( type )
	{
		case 1:
		menuItem = new JRadioButtonMenuItem();
		break;

		case 2:
		menuItem = new JCheckBoxMenuItem();
		break;

		default: 
		menuItem = new JMenuItem();
		break;
	}
	menuItem.setText( text );
	if( image != null )      
	{
		menuItem.setIcon( image );
	}
	if( acceleratorKey != -1 )
	{
		if( acceleratorKey > 0 ) 
		{
			menuItem.setMnemonic( acceleratorKey );
		}
	}
	menuItem.setAccelerator(KeyStroke.getKeyStroke(accel));
	menu.add( menuItem );
return menuItem;
}	
//---------------------------------------------
public static String getName(String property) {
//---------------------------------------------
	return Manager.msgsDEFAULT.getString(property);
}
}