package mirconoid.MenuBars.MainMenuMenuBar;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.*;

import mirconoid.Manager;
import mirconoid.Methods.Methods;
import mirconoid.MenuBars.MenuBarsMethods;

//#######################################################################
public class MainMenuMenuBar extends JMenuBar implements ActionListener {
//#######################################################################
	
	Font font = new Font("SansSerif", 0 , 10);
	static String currentLanguage = "none";
//--------------------------------------------------------------------------------------------------------------- GAME MENU	
	JMenu menuGame = new JMenu( MenuBarsMethods.getName("Game") );
		JMenuItem menuItemNewGame = MenuBarsMethods.createJMenuItem( menuGame, 0, MenuBarsMethods.getName("NewGame") , null , -1 , "control N" );
//--------------------------------------------------------------------------------------------------------------- OPTIONS MENU		
	JMenu menuOptions = new JMenu( MenuBarsMethods.getName("Options") );
		JMenu menuLanguage = new JMenu( MenuBarsMethods.getName("Language") );
			JMenuItem menuItemEnglish   = MenuBarsMethods.createJMenuItem( menuLanguage, 2, MenuBarsMethods.getName("EN") , new ImageIcon( "mirconoid/MenuBars/Icons/EN.gif" ) , -1 , null );
			JMenuItem menuItemPolish    = MenuBarsMethods.createJMenuItem( menuLanguage, 2, MenuBarsMethods.getName("PL") , new ImageIcon( "mirconoid/MenuBars/Icons/PL.gif" ) , -1 , null );
			JMenuItem menuItemVitnamese = MenuBarsMethods.createJMenuItem( menuLanguage, 2, MenuBarsMethods.getName("VN") , new ImageIcon( "mirconoid/MenuBars/Icons/VN.gif" ) , -1 , null );
		JMenu menuMusic = new JMenu( MenuBarsMethods.getName("Music") );
			JMenu menuMusicVolume = new JMenu( MenuBarsMethods.getName("SetVolume") );
				JMenuItem menuItemSetVolume1 = MenuBarsMethods.createJMenuItem( menuMusicVolume, 0, MenuBarsMethods.getName("Volume1"), null, -1, null );
				JMenuItem menuItemSetVolume2 = MenuBarsMethods.createJMenuItem( menuMusicVolume, 0, MenuBarsMethods.getName("Volume2"), null, -1, null );
				JMenuItem menuItemSetVolume3 = MenuBarsMethods.createJMenuItem( menuMusicVolume, 0, MenuBarsMethods.getName("Volume3"), null, -1, null );
				JMenuItem menuItemSetVolume4 = MenuBarsMethods.createJMenuItem( menuMusicVolume, 0, MenuBarsMethods.getName("Volume4"), null, -1, null );
				JMenuItem menuItemSetVolume5 = MenuBarsMethods.createJMenuItem( menuMusicVolume, 0, MenuBarsMethods.getName("Volume5"), null, -1, null );
			JMenuItem menuItemPreviousTrack = MenuBarsMethods.createJMenuItem( menuMusic, 0, MenuBarsMethods.getName("PreviousTrack"), new ImageIcon( "mirconoid/MenuBars/Icons/Previous.jpg" ), -1, null );
	    	JMenuItem menuItemStopTrack 	= MenuBarsMethods.createJMenuItem( menuMusic, 0, MenuBarsMethods.getName("Pause")        , new ImageIcon( "mirconoid/MenuBars/Icons/Pause.jpg" ), -1, null );
	    	JMenuItem menuItemPlayTrack 	= MenuBarsMethods.createJMenuItem( menuMusic, 0, MenuBarsMethods.getName("Play")         , new ImageIcon( "mirconoid/MenuBars/Icons/Play.jpg" ), -1, null );
	    	JMenuItem menuItemNextTrack 	= MenuBarsMethods.createJMenuItem( menuMusic, 0, MenuBarsMethods.getName("NextTrack")    , new ImageIcon( "mirconoid/MenuBars/Icons/Next.jpg" ), -1, null );    	
//--------------------------------------------------------------------------------------------------------------- HIGHSCORES MENU
	JMenuItem HighScores = new JMenuItem( MenuBarsMethods.getName("HighScores") );	  		    	
//--------------------------------------------------------------------------------------------------------------- HELP MENU				
	JMenu menuHelp = new JMenu( MenuBarsMethods.getName("Info") );
		JMenuItem menuItemHelp  = MenuBarsMethods.createJMenuItem( menuHelp, 0, MenuBarsMethods.getName("Help")  , null , -1 , "control H" );
		JMenuItem menuItemAbout = MenuBarsMethods.createJMenuItem( menuHelp, 0, MenuBarsMethods.getName("About") , null , -1 , "control A" );
			
	JMenuItem quit = new JMenuItem( MenuBarsMethods.getName("Quit") );

//@@@@@@@@@@@@@@@@@@@@@@@@
public MainMenuMenuBar() {
//@@@@@@@@@@@@@@@@@@@@@@@@

//================================== SETTING FONTS	
	menuItemNewGame.setFont(font);
	menuLanguage.setFont(font);
	menuMusic.setFont(font);
	menuMusicVolume.setFont(font);
	
		menuItemPolish.setFont(font);
		menuItemEnglish.setFont(font);
		menuItemVitnamese.setFont(font);
		menuItemSetVolume1.setFont(font);
		menuItemSetVolume2.setFont(font);
		menuItemSetVolume3.setFont(font);
		menuItemSetVolume4.setFont(font);
		menuItemSetVolume5.setFont(font);
		menuItemPreviousTrack.setFont(font);
		menuItemStopTrack.setFont(font);
		menuItemPlayTrack.setFont(font);
		menuItemNextTrack.setFont(font);
		menuItemHelp.setFont(font);
		menuItemAbout.setFont(font);
	
//-------------------------------------------------------- LISTENERS
	menuItemNewGame.setActionCommand("New Game");
		menuItemPolish.setActionCommand("PL");
		menuItemEnglish.setActionCommand("EN");
		menuItemVitnamese.setActionCommand("VN");
		menuItemSetVolume1.setActionCommand("Set Volume 1");
		menuItemSetVolume2.setActionCommand("Set Volume 2");
		menuItemSetVolume3.setActionCommand("Set Volume 3");
		menuItemSetVolume4.setActionCommand("Set Volume 4");
		menuItemSetVolume5.setActionCommand("Set Volume 5");
		menuItemPreviousTrack.setActionCommand("Previous Track");
		menuItemStopTrack.setActionCommand("Stop");
		menuItemPlayTrack.setActionCommand("Play");
		menuItemNextTrack.setActionCommand("Next Track");
	menuItemHelp.setActionCommand("Help");
	menuItemAbout.setActionCommand("About");
	
	HighScores.setActionCommand("High Scores");
	quit.setActionCommand("Quit");
	
	menuItemNewGame.addActionListener(this);
		menuItemPolish.addActionListener(this);
		menuItemEnglish.addActionListener(this);
		menuItemVitnamese.addActionListener(this);
		menuItemSetVolume1.addActionListener(this);
		menuItemSetVolume2.addActionListener(this);
		menuItemSetVolume3.addActionListener(this);
		menuItemSetVolume4.addActionListener(this);
		menuItemSetVolume5.addActionListener(this);
		menuItemPreviousTrack.addActionListener(this);
		menuItemStopTrack.addActionListener(this);
		menuItemPlayTrack.addActionListener(this);
		menuItemNextTrack.addActionListener(this);
	menuItemHelp.addActionListener(this);
	menuItemAbout.addActionListener(this);
	
	HighScores.addActionListener(this);
	quit.addActionListener(this);
//-------------------------------------------------------------------
	
	if ( currentLanguage.equals("PL") ) 
	{
		menuItemEnglish.setSelected(false);
		menuItemPolish.setSelected(true);
		menuItemVitnamese.setSelected(false);
	} else if ( currentLanguage.equals("EN") )
	{
		menuItemEnglish.setSelected(true);
		menuItemPolish.setSelected(false);
		menuItemVitnamese.setSelected(false);
	} else if ( currentLanguage.equals("VN") )
	{
		menuItemEnglish.setSelected(false);
		menuItemPolish.setSelected(false);
		menuItemVitnamese.setSelected(true);
	}
	
	menuGame.setMnemonic( MenuBarsMethods.getName("Game").charAt(0) );
	menuOptions.setMnemonic( MenuBarsMethods.getName("Options").charAt(0) );
	menuHelp.setMnemonic( MenuBarsMethods.getName("Info").charAt(0) );
	quit.setAccelerator(KeyStroke.getKeyStroke("control Q"));
	
		HighScores.setPreferredSize(new Dimension(MenuBarsMethods.getName("HighScores").length()*7,10));
		HighScores.setMaximumSize(
			     new Dimension(
			    		 HighScores.getPreferredSize().width, 
			    		 HighScores.getMaximumSize().height));
		
		quit.setPreferredSize(new Dimension(MenuBarsMethods.getName("Quit").length()*18,10));
		quit.setMaximumSize(
			     new Dimension(
			    		 quit.getPreferredSize().width, 
			    		 quit.getMaximumSize().height));
	
	this.add(menuGame);
		menuGame.add(menuItemNewGame); 
	this.add(menuOptions);
		menuOptions.add(menuLanguage);		
		menuOptions.add(menuMusic);
		menuMusic.add(menuMusicVolume);
	this.add(HighScores);
	this.add(menuHelp);
		menuHelp.add(menuItemHelp);
		menuHelp.add(menuItemAbout);
	this.add(quit);
}
//******************************************
public void actionPerformed(ActionEvent e) {
//******************************************	
	if (e.getActionCommand().equals("New Game"))
	{
		Methods.startNewGame();
	}
	else if (e.getActionCommand().equals("PL"))
	{
		currentLanguage = "PL";
		Manager.msgsDEFAULT = ResourceBundle.getBundle("mirconoid/PropertiesFiles/Mirconoid_pl");
		System.out.println("LANGUAGE INFO: Polish Language enabled");
		Manager.resetMainMenuBar();
	}
	else if (e.getActionCommand().equals("EN"))
	{
		currentLanguage = "EN";
		Manager.msgsDEFAULT = ResourceBundle.getBundle("mirconoid/PropertiesFiles/Mirconoid_en");
		System.out.println("LANGUAGE INFO: English Language enabled");
		Manager.resetMainMenuBar();
	}
	else if (e.getActionCommand().equals("VN"))
	{
		currentLanguage = "VN";
		Manager.msgsDEFAULT = ResourceBundle.getBundle("mirconoid/PropertiesFiles/Mirconoid_vn");
		System.out.println("LANGUAGE INFO: Vietnamese Language enabled");
		System.out.println(ResourceBundle.getBundle("mirconoid/PropertiesFiles/Mirconoid_vn").getLocale());
		Manager.resetMainMenuBar();
	}
	else if (e.getActionCommand().equals("Set Volume 1"))
	{
		Manager.getMediaPlayer().setVolume("1");	
	}
	else if (e.getActionCommand().equals("Set Volume 2"))
	{
		Manager.getMediaPlayer().setVolume("2");	
	}
	else if (e.getActionCommand().equals("Set Volume 3"))
	{
		Manager.getMediaPlayer().setVolume("3");	
	}
	else if (e.getActionCommand().equals("Set Volume 4"))
	{
		Manager.getMediaPlayer().setVolume("4");	
	}
	else if (e.getActionCommand().equals("Set Volume 5"))
	{
		Manager.getMediaPlayer().setVolume("5");	
	}
	else if (e.getActionCommand().equals("Previous Track"))
	{
		Manager.getMediaPlayer().playPreviousTrack();	
	}
	else if (e.getActionCommand().equals("Stop"))
	{
		Manager.getMediaPlayer().stop();	
	}
	else if (e.getActionCommand().equals("Play"))
	{
		Manager.getMediaPlayer().start();	
	}
	else if (e.getActionCommand().equals("Next Track"))
	{
		Manager.getMediaPlayer().playNextTrack();	
	}
	else if (e.getActionCommand().equals("Help"))
	{
		Methods.showHelpWindow();	
	}
	else if (e.getActionCommand().equals("About"))
	{
		Methods.showAboutWindow();	
	}
	else if (e.getActionCommand().equals("High Scores"))
	{	
		Methods.showHighScores();
	}
	else if (e.getActionCommand().equals("Quit"))
	{
		Methods.quitGame();	
	}
}
}//class MainMenuMenuBar