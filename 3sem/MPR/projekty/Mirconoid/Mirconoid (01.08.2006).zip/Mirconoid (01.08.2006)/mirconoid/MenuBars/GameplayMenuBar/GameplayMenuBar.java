package mirconoid.MenuBars.GameplayMenuBar;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;
import javax.swing.*;
import mirconoid.Methods.Methods;
import mirconoid.Gameplay;
import mirconoid.Manager;
import mirconoid.ResourceAnchor;
import mirconoid.MenuBars.MenuBarsMethods;

//#######################################################################
public class GameplayMenuBar extends JMenuBar implements ActionListener {
//#######################################################################
		
	Font font = new Font("SansSerif", 0 , 10);
	boolean pause;
	static String currentLanguage = "none";
	
//--------------------------------------------------------------------------------------------------------------- GAME MENU	
	JMenu menuGame = new JMenu( MenuBarsMethods.getName("Game") );
		JMenuItem menuItemPauseGame = MenuBarsMethods.createJMenuItem( menuGame, 0, MenuBarsMethods.getName("PauseGame") , null , -1 , "P" );
		JMenuItem menuItemEndGame   = MenuBarsMethods.createJMenuItem( menuGame, 0, MenuBarsMethods.getName("MainMenu")  , null , -1 , "control M" );
//--------------------------------------------------------------------------------------------------------------- OPTIONS MENU		
	JMenu menuOptions = new JMenu( MenuBarsMethods.getName("Options") );
		JMenu menuLanguage = new JMenu( MenuBarsMethods.getName("Language") );
			JMenuItem menuItemEnglish   = MenuBarsMethods.createJMenuItem( menuLanguage, 2, MenuBarsMethods.getName("EN") , new ImageIcon( "mirconoid/MenuBars/Icons/EN.gif" ) , -1 , null );
			JMenuItem menuItemPolish    = MenuBarsMethods.createJMenuItem( menuLanguage, 2, MenuBarsMethods.getName("PL") , new ImageIcon( "mirconoid/MenuBars/Icons/PL.gif" ) , -1 , null );
			JMenuItem menuItemVitnamese = MenuBarsMethods.createJMenuItem( menuLanguage, 2, MenuBarsMethods.getName("VN") , new ImageIcon( "mirconoid/MenuBars/Icons/VN.gif" ) , -1 , null );
		JMenu menuSkins = new JMenu( "Skins" );
			JMenuItem menuItemSkin1 = MenuBarsMethods.createJMenuItem( menuSkins, 0, "Silver" , new ImageIcon( "mirconoid/MenuBars/Icons/silver.jpg" ) , -1 , null );
			JMenuItem menuItemSkin2 = MenuBarsMethods.createJMenuItem( menuSkins, 0, "Gold"   , new ImageIcon( "mirconoid/MenuBars/Icons/gold.jpg"   ) , -1 , null );
			JMenuItem menuItemSkin3 = MenuBarsMethods.createJMenuItem( menuSkins, 0, "Red"    , new ImageIcon( "mirconoid/MenuBars/Icons/red.jpg"    ) , -1 , null );
			JMenuItem menuItemSkin4 = MenuBarsMethods.createJMenuItem( menuSkins, 0, "Green"  , new ImageIcon( "mirconoid/MenuBars/Icons/green.jpg"  ) , -1 , null );
			JMenuItem menuItemSkin5 = MenuBarsMethods.createJMenuItem( menuSkins, 0, "Blue"   , new ImageIcon( "mirconoid/MenuBars/Icons/blue.jpg"   ) , -1 , null );
		JMenu menuMusic = new JMenu( MenuBarsMethods.getName("Music") );
			JMenu menuMusicVolume = new JMenu( MenuBarsMethods.getName("SetVolume") );
				JMenuItem menuItemSetVolume1 = MenuBarsMethods.createJMenuItem( menuMusicVolume, 0, MenuBarsMethods.getName("Volume1"), null, -1, null );
				JMenuItem menuItemSetVolume2 = MenuBarsMethods.createJMenuItem( menuMusicVolume, 0, MenuBarsMethods.getName("Volume2"), null, -1, null );
				JMenuItem menuItemSetVolume3 = MenuBarsMethods.createJMenuItem( menuMusicVolume, 0, MenuBarsMethods.getName("Volume3"), null, -1, null );
				JMenuItem menuItemSetVolume4 = MenuBarsMethods.createJMenuItem( menuMusicVolume, 0, MenuBarsMethods.getName("Volume4"), null, -1, null );
				JMenuItem menuItemSetVolume5 = MenuBarsMethods.createJMenuItem( menuMusicVolume, 0, MenuBarsMethods.getName("Volume5"), null, -1, null );
	    	JMenuItem menuItemPreviousTrack = MenuBarsMethods.createJMenuItem( menuMusic, 0, MenuBarsMethods.getName("PreviousTrack"), new ImageIcon( "mirconoid/MenuBars/Icons/Previous.jpg" ), -1, null );
	    	JMenuItem menuItemStopTrack 	= MenuBarsMethods.createJMenuItem( menuMusic, 0, MenuBarsMethods.getName("Pause")        , new ImageIcon( "mirconoid/MenuBars/Icons/Pause.jpg" ), -1, null );
	    	JMenuItem menuItemPlayTrack 	= MenuBarsMethods.createJMenuItem( menuMusic, 0, MenuBarsMethods.getName("Play")         , new ImageIcon( "mirconoid/MenuBars/Icons/Play.jpg" ), -1, null );
	    	JMenuItem menuItemNextTrack 	= MenuBarsMethods.createJMenuItem( menuMusic, 0, MenuBarsMethods.getName("NextTrack")    , new ImageIcon( "mirconoid/MenuBars/Icons/Next.jpg" ), -1, null );
	    	
	JMenuItem quit = new JMenuItem( MenuBarsMethods.getName("Quit") );
	
//@@@@@@@@@@@@@@@@@@@@@@@@
public GameplayMenuBar() {
//@@@@@@@@@@@@@@@@@@@@@@@@
		
//================================== SETTING FONTS
	menuItemPauseGame.setFont(font);
	menuItemEndGame.setFont(font);
	menuLanguage.setFont(font);
		menuItemPolish.setFont(font);
		menuItemEnglish.setFont(font);
		menuItemVitnamese.setFont(font);
	menuMusic.setFont(font);
		menuItemPreviousTrack.setFont(font);
		menuItemStopTrack.setFont(font);
		menuItemPlayTrack.setFont(font);
		menuItemNextTrack.setFont(font);
		menuMusicVolume.setFont(font);	
			menuItemSetVolume1.setFont(font);
			menuItemSetVolume2.setFont(font);
			menuItemSetVolume3.setFont(font);
			menuItemSetVolume4.setFont(font);
			menuItemSetVolume5.setFont(font);
	menuSkins.setFont(font);	
		menuItemSkin1.setFont(font);	
		menuItemSkin2.setFont(font);	
		menuItemSkin3.setFont(font);	
		menuItemSkin4.setFont(font);	
		menuItemSkin5.setFont(font);
			
//-------------------------------------------------------- LISTENERS
	menuItemPauseGame.setActionCommand("Pause Game");
	menuItemEndGame.setActionCommand("End Game");
		menuItemPolish.setActionCommand("PL");
		menuItemEnglish.setActionCommand("EN");
		menuItemVitnamese.setActionCommand("VN");
		menuItemPreviousTrack.setActionCommand("Previous Track");
		menuItemStopTrack.setActionCommand("Stop");
		menuItemPlayTrack.setActionCommand("Play");
		menuItemNextTrack.setActionCommand("Next Track");
		menuItemSetVolume1.setActionCommand("Set Volume 1");
		menuItemSetVolume2.setActionCommand("Set Volume 2");
		menuItemSetVolume3.setActionCommand("Set Volume 3");
		menuItemSetVolume4.setActionCommand("Set Volume 4");
		menuItemSetVolume5.setActionCommand("Set Volume 5");
		menuItemSkin1.setActionCommand("Silver");
		menuItemSkin2.setActionCommand("Gold");	
		menuItemSkin3.setActionCommand("Red");	
		menuItemSkin4.setActionCommand("Green");	
		menuItemSkin5.setActionCommand("Blue");	

	menuItemPauseGame.addActionListener(this);
	menuItemEndGame.addActionListener(this);
		menuItemPolish.addActionListener(this);
		menuItemEnglish.addActionListener(this);
		menuItemVitnamese.addActionListener(this);
		menuItemPreviousTrack.addActionListener(this);
		menuItemStopTrack.addActionListener(this);
		menuItemPlayTrack.addActionListener(this);
		menuItemNextTrack.addActionListener(this);
		menuItemSetVolume1.addActionListener(this);
		menuItemSetVolume2.addActionListener(this);
		menuItemSetVolume3.addActionListener(this);
		menuItemSetVolume4.addActionListener(this);
		menuItemSetVolume5.addActionListener(this);
		menuItemSkin1.addActionListener(this);
		menuItemSkin2.addActionListener(this);
		menuItemSkin3.addActionListener(this);	
		menuItemSkin4.addActionListener(this);
		menuItemSkin5.addActionListener(this);	

//-------------------------------------------------------------------
		
		if ( currentLanguage.equals("PL") ) 
		{
			menuItemEnglish.setSelected(false);
			menuItemPolish.setSelected(true);
			menuItemVitnamese.setSelected(false);
		} else if ( currentLanguage.equals("EN") )
		{
			menuItemEnglish.setSelected(true);
			menuItemPolish.setSelected(false);
			menuItemVitnamese.setSelected(false);
		} else if ( currentLanguage.equals("VN") )
		{
			menuItemEnglish.setSelected(false);
			menuItemPolish.setSelected(false);
			menuItemVitnamese.setSelected(true);
		}
		quit.setAccelerator(KeyStroke.getKeyStroke("control Q"));
		quit.setActionCommand("Quit");
		quit.addActionListener(this);
			
		menuGame.setMnemonic( MenuBarsMethods.getName("Game").charAt(0) );
		menuOptions.setMnemonic( MenuBarsMethods.getName("Options").charAt(0) );
		quit.setAccelerator(KeyStroke.getKeyStroke("control Q"));
				
		quit.setPreferredSize(new Dimension(MenuBarsMethods.getName("Quit").length()*18,10));
		quit.setMaximumSize(
			     new Dimension(
			    		 quit.getPreferredSize().width, 
			    		 quit.getMaximumSize().height));

	this.add(menuGame);
		menuGame.add(menuItemPauseGame); 
		menuGame.add(menuItemEndGame);
	this.add(menuOptions);
		menuOptions.add(menuLanguage);		
		menuOptions.add(menuMusic); menuMusic.add(menuMusicVolume);
		menuOptions.add(menuSkins);
	this.add(quit);
}		
//******************************************
public void actionPerformed(ActionEvent e) {
//******************************************	
	if (e.getActionCommand().equals("Pause Game"))
	{
		if (pause)
		{
			if ( Gameplay.gameStarted && Gameplay.gamePaused && !Gameplay.gameOver)
			{
				Methods.continueGame();
				pause = false;
			}
		}else 
		if ( Gameplay.gameStarted && !Gameplay.gamePaused && !Gameplay.gameOver)
		{
			Methods.pauseGame();
			pause = true;
		}

	}
	else if (e.getActionCommand().equals("End Game"))
	{
		Methods.goToMainMenu();
	}
	else if (e.getActionCommand().equals("PL"))
	{
		currentLanguage = "PL";
		Manager.msgsDEFAULT = ResourceBundle.getBundle("mirconoid/PropertiesFiles/mirconoid_pl");
		System.out.println("LANGUAGE INFO: Polish Language enabled");
		Manager.resetGameplayMenuBar();
	}
	else if (e.getActionCommand().equals("EN"))
	{
		currentLanguage = "EN";
		Manager.msgsDEFAULT = ResourceBundle.getBundle("mirconoid/PropertiesFiles/mirconoid_en");
		System.out.println("LANGUAGE INFO: English Language enabled");
		Manager.resetGameplayMenuBar();
	}
	else if (e.getActionCommand().equals("VN"))
	{
		currentLanguage = "VN";
		Manager.msgsDEFAULT = ResourceBundle.getBundle("mirconoid/PropertiesFiles/mirconoid_vn");
		System.out.println("LANGUAGE INFO: Vietnamese Language enabled");
		System.out.println(ResourceBundle.getBundle("mirconoid/PropertiesFiles/mirconoid_vn").getLocale());
		Manager.resetGameplayMenuBar();
	}
	else if (e.getActionCommand().equals("Set Volume 1"))
	{
		Manager.getMediaPlayer().setVolume("1");	
	}
	else if (e.getActionCommand().equals("Set Volume 2"))
	{
		Manager.getMediaPlayer().setVolume("2");	
	}
	else if (e.getActionCommand().equals("Set Volume 3"))
	{
		Manager.getMediaPlayer().setVolume("3");	
	}
	else if (e.getActionCommand().equals("Set Volume 4"))
	{
		Manager.getMediaPlayer().setVolume("4");	
	}
	else if (e.getActionCommand().equals("Set Volume 5"))
	{
		Manager.getMediaPlayer().setVolume("5");	
	}
	else if (e.getActionCommand().equals("Previous Track"))
	{
		Manager.getMediaPlayer().playPreviousTrack();	
	}
	else if (e.getActionCommand().equals("Stop"))
	{
		Manager.getMediaPlayer().stop();	
	}
	else if (e.getActionCommand().equals("Play"))
	{
		Manager.getMediaPlayer().start();	
	}
	else if (e.getActionCommand().equals("Next Track"))
	{
		Manager.getMediaPlayer().playNextTrack();	
	}
	else if (e.getActionCommand().equals("Quit"))
	{
		Methods.quitGame();	
	}
	else if (e.getActionCommand().equals("Silver"))
	{
		ResourceAnchor.setSkin("pictures/skins/silver/upperPanel.jpg","pictures/skins/silver/lowerPanel.jpg");
		System.out.println("SILVER");
	}
	else if (e.getActionCommand().equals("Gold"))
	{
		ResourceAnchor.setSkin("pictures/skins/gold/upperPanel.jpg","pictures/skins/gold/lowerPanel.jpg");
		System.out.println("GOLD");
	}
	else if (e.getActionCommand().equals("Red"))
	{
		ResourceAnchor.setSkin("pictures/skins/red/upperPanel.jpg","pictures/skins/red/lowerPanel.jpg");
		System.out.println("RED");
	}
	else if (e.getActionCommand().equals("Green"))
	{
		ResourceAnchor.setSkin("pictures/skins/green/upperPanel.jpg","pictures/skins/green/lowerPanel.jpg");
		System.out.println("GREEN");
	}
	else if (e.getActionCommand().equals("Blue"))
	{
		ResourceAnchor.setSkin("pictures/skins/blue/upperPanel.jpg","pictures/skins/blue/lowerPanel.jpg");
		System.out.println("BLUE");
	}
}
}//class GameplayMenuBar