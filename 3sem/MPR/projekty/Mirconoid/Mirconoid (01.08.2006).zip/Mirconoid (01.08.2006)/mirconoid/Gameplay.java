package mirconoid;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GraphicsConfiguration;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.VolatileImage;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import mirconoid.MenuBars.MenuBarsMethods;
import mirconoid.ball.Ball;
import mirconoid.levels.LevelsManager;

public class Gameplay extends JPanel implements MouseMotionListener, MouseListener, KeyListener
{
	private static JPanel			panelInformation							= new JPanel();
	private static JPanel			panelGame									= new JPanel();
	private static JPanel			panelStatus									= new JPanel();
	private static final int		w											= 800;
	private static final int		h											= 600;
	private static final int		_10PercentFrom_h							= 60;
	private static int				mirconoid_WIDTH								= 50;
	private static int				mirconoid_HEIGHT							= 10;
	private static int				mirconoid_X_AXIS							= w / 2 - mirconoid_WIDTH;
	private static int				mirconoid_Y_AXIS							= panelGame.getHeight() - (mirconoid_HEIGHT + 5);
	private static int				BALL_SIZE									= 10;
	private static int				BALL_X_AXIS									= 400;
	private static int				BALL_Y_AXIS									= 260;
	private static int				MOUSE_X_AXIS								= 0;
	private static int				MOUSE_Y_AXIS								= 0;
	public static double			ballTrajectory_X							= 0 , ballTrajectory_Y = 0;
	public static double			pausedBallTrajectory_X						= 0 , pausedBallTrajectory_Y = 0;
	static int						ballTrajectoryInformationColumnPossision	= 50;
	static int						ballPositionInformationColumnPossision		= 500;
	static int						mousePositionInformationColumnPossision		= 650;
	public static int				currentLevel								= 1;
	public static int				points										= 0;
	public static int				numberOfBounces								= 0;
	public static int				lives										= 5;
	public static boolean			bounced;
	public static boolean			bouncedBlock;
	public static boolean			gameStarted;
	public static boolean			gamePaused;
	public static boolean			gamePausedByMouseExit;
	public static boolean			gameEnded;
	public static boolean			liveLost;
	public static boolean			lastLive;
	public static boolean			gameOver;
	public static boolean			newLevel;
	public static boolean			exit;
	public static boolean			bonus;
	public static boolean			firstTime									= true;
	static Font						font										= new Font("Times New Roman", 1, 50);
	public static String			playerName;
	public static String			playerToHighScore;
	private static Image			upperPanelBackgroundForGameplay				= ResourceAnchor.currentUpperPanelSkin;
	private static Image			lowerPanelBackgroundForGameplay				= ResourceAnchor.currentLowerPanelSkin;
	private static Image			backgroundForMainMenuImage					= ResourceAnchor.backgroundForMainMenuImage;
	private static Image			mirconoidImage								= ResourceAnchor.mirconoidImage;
	private static Image			ballImage									= ResourceAnchor.ballImage;
	private static VolatileImage	vi_panelInformation;
	private static Graphics			vig_panelInformation;
	private static VolatileImage	vi_panelGame;
	private static Graphics			vig_panelGame;
	private static VolatileImage	vi_panelStatus;
	private static Graphics			vig_panelStatus;
	static int						counter										= 1;
	private static LevelsManager	levelsManager								= new LevelsManager();
	Ball							ball										= new Ball();

	public Gameplay()
	{
		this.setLayout(new BorderLayout());
		panelInformation.setPreferredSize(new Dimension(w, _10PercentFrom_h));
		panelGame.setPreferredSize(new Dimension(w, _10PercentFrom_h * 8));
		panelStatus.setPreferredSize(new Dimension(w, _10PercentFrom_h));
		this.add(panelInformation, BorderLayout.NORTH);
		this.add(panelGame, BorderLayout.CENTER);
		this.add(panelStatus, BorderLayout.SOUTH);
		this.addMouseMotionListener(this);
		this.addMouseListener(this);
		this.addKeyListener(this);
	}
	public void mouseExited( MouseEvent e )
	{
		// when mouse cursor exits area of game window, game is paused
		if (gameStarted && !gamePaused && !gamePausedByMouseExit && !gameOver)
		{
			mirconoid.Methods.Methods.pauseGameByMouseExit();
		}
	}
	public void mouseMoved( MouseEvent e )
	{
		// when game is in progress, set mirconoid position to mouse cursor
		// position
		if (gameStarted && !gamePausedByMouseExit && !gamePaused && !gameEnded)
		{
			MOUSE_X_AXIS = e.getX();
			MOUSE_Y_AXIS = e.getY();
			mirconoid_X_AXIS = e.getX() - mirconoid_WIDTH / 2;
			 if(newLevel)
			{
				BALL_X_AXIS = e.getX() - BALL_SIZE / 2;
				BALL_Y_AXIS = panelGame.getHeight()-((BALL_SIZE*2)+(BALL_SIZE/2));
			}
			if (mirconoid_X_AXIS >= w - mirconoid_WIDTH) // Right border
			{
				mirconoid_X_AXIS = w - mirconoid_WIDTH;
			}
			if (mirconoid_X_AXIS <= 1) // Left border
			{
				mirconoid_X_AXIS = 1;
			}
		}
	}
	public void mouseEntered( MouseEvent e )
	{
		// when mouse cursor enters in area of game window, game is not longer
		// paused
		if (gameStarted && !gamePaused && gamePausedByMouseExit && !gameOver)
		{
			mirconoid.Methods.Methods.continueGameByMouseEnter();
		}
	}
	public void mouseReleased( MouseEvent e )
	{
	}
	public void mousePressed( MouseEvent e )
	{
		// when player lost 1 live. Mouse must be pressed in order to continue
		// game
		if (gameStarted && !gamePausedByMouseExit && !gamePaused && liveLost && !gameOver)
		{
			mirconoid.Methods.Methods.continueGameAfterLoss();
			liveLost = false;
		}
		// when player entered to new level. Mouse must be pressed in order to
		// continue game in new level
		if (gameStarted && !gamePausedByMouseExit && !gamePaused && !gameOver && newLevel)
		{
			mirconoid.Methods.Methods.continueGameOnNewLevel();
		}
	}
	public void mouseClicked( MouseEvent e )
	{
	}
	public void mouseDragged( MouseEvent e )
	{
	}
	public void keyReleased( KeyEvent e )
	{
	}
	public void keyTyped( KeyEvent e )
	{
	}
	public void keyPressed( KeyEvent e )
	{
		int keyCode = e.getKeyCode();
		String keyString = "key code = " + keyCode + " (" + KeyEvent.getKeyText(keyCode) + ")";
		System.out.println(keyString);
	}
	private void createBackBuffer( int number )
	{
		if (number == 1)
		{
			GraphicsConfiguration a = panelInformation.getGraphicsConfiguration();
			vi_panelInformation = a.createCompatibleVolatileImage(getWidth(), getHeight());
			return;
		}
		if (number == 2)
		{
			GraphicsConfiguration b = panelGame.getGraphicsConfiguration();
			vi_panelGame = b.createCompatibleVolatileImage(getWidth(), getHeight());
			return;
		}
		if (number == 3)
		{
			GraphicsConfiguration c = panelStatus.getGraphicsConfiguration();
			vi_panelStatus = c.createCompatibleVolatileImage(getWidth(), getHeight());
			return;
		}
	}
	public void start()
	{
		Gameplay.reset();
		if (firstTime)
		{
			paintComponent(this.getGraphics());
			vi_panelInformation = panelInformation.createVolatileImage(w, h / 10);
			vig_panelInformation = vi_panelInformation.createGraphics();
			vi_panelGame = panelGame.createVolatileImage(w, _10PercentFrom_h * 8);
			vig_panelGame = vi_panelGame.createGraphics();
			vi_panelStatus = panelStatus.createVolatileImage(w, h / 10);
			vig_panelStatus = vi_panelStatus.createGraphics();
			firstTime = false;
		}
		GraphicsConfiguration gc = this.getGraphicsConfiguration();
		if (vi_panelInformation.validate(gc) == VolatileImage.IMAGE_INCOMPATIBLE)
		{
			createBackBuffer(1);
		}
		if (vi_panelGame.validate(gc) == VolatileImage.IMAGE_INCOMPATIBLE)
		{
			createBackBuffer(2);
		}
		if (vi_panelStatus.validate(gc) == VolatileImage.IMAGE_INCOMPATIBLE)
		{
			createBackBuffer(3);
		}
		while (true)
		{
			try
			{
				repaint();
				if (gameStarted && !gameOver)
				{
					if (exit)
						break;
					vi_panelInformation.validate(gc);
					vi_panelGame.validate(gc);
					vi_panelStatus.validate(gc);
					if (gameStarted)
					{
						checkStatus();
					}
				}
				Thread.sleep(5);
			}
			catch (InterruptedException e)
			{
				System.err.println("GAMEPLAY ERROR: " + e.getMessage());
				System.exit(0);
			}
		}
	}
	private void checkStatus()
	{
		if (lives == 0 && !gameOver)
		{
			lastLive = true;
		}
		if (points == 20)
		{
			bonus = true;
		}
		if (lastLive && !gameOver)
		{
			gameOver = true;
			System.out.println("< < < GAME OVER > > >");
			sendPlayerInfromationToSQL("lost", 0);
			mirconoid.Methods.Methods.goToMainMenu();
		}
	}
	public static void inputPlayerName( String choose )
	{
		if (choose.equals("lost"))
		{
			while (true)
			{
				playerName = JOptionPane.showInputDialog(panelGame, MenuBarsMethods.getName("GameOver") + "\n\n" + MenuBarsMethods.getName("TypeName") + "\n" + MenuBarsMethods.getName("NameLength"));
				if (playerName == null)
				{
					playerName = "NONAME";
					break;
				}
				if (playerName.equals(""))
				{
					playerName = "NONAME";
					break;
				}
				if (playerName.length() <= 20)
					break;
			}
		}
		else if (choose.equals("won"))
		{
			while (true)
			{
				playerName = JOptionPane.showInputDialog(panelGame, MenuBarsMethods.getName("WellDone") + "\n\n" + MenuBarsMethods.getName("TypeName") + "\n" + MenuBarsMethods.getName("NameLength"));
				if (playerName == null)
				{
					playerName = "NONAME";
					break;
				}
				if (playerName.equals(""))
				{
					playerName = "NONAME";
					break;
				}
				if (playerName.length() <= 20)
					break;
			}
		}
	}
	public static void sendPlayerInfromationToSQL( String choose, int additionalPoints )
	{
		try
		{
			points += additionalPoints;
			inputPlayerName(choose);
			Manager.showWaintingMessageWhenConnectingToSQLServer();
			Player player = new Player(playerName, numberOfBounces, lives, points);
			mirconoid.JDBC.Jdbc.sendPlayer(player);
		}
		catch (Exception e)
		{
			System.err.println("ERROR: " + e.getMessage());
		}
	}
	public void startMainMenu()
	{
		Gameplay.reset();
		if (firstTime)
		{
			paintComponent(this.getGraphics());
			vi_panelInformation = panelInformation.createVolatileImage(w, h / 10);
			vig_panelInformation = vi_panelInformation.createGraphics();
			vi_panelGame = panelGame.createVolatileImage(w, _10PercentFrom_h * 8);
			vig_panelGame = vi_panelGame.createGraphics();
			vi_panelStatus = panelStatus.createVolatileImage(w, h / 10);
			vig_panelStatus = vi_panelStatus.createGraphics();
			firstTime = false;
		}
	}
	public void paint( Graphics g )
	{
		super.paintComponent(g);
		if (!gameStarted)
		{
			g.drawImage(backgroundForMainMenuImage, 0, 0, w, h, this);
			g.dispose();
			return;
		}
		if (gameStarted)
		{
			if (!gameOver)
			{
				vig_panelStatus.drawImage(lowerPanelBackgroundForGameplay, 0, 0, w, _10PercentFrom_h, panelStatus);
				vig_panelStatus.drawRect(0, 0, w - 1, _10PercentFrom_h - 1);
				vig_panelStatus.drawString(MenuBarsMethods.getName("BallTrajectory"), ballTrajectoryInformationColumnPossision - 10, 15);
				vig_panelStatus.drawString("-------------------------------------", ballTrajectoryInformationColumnPossision - 25, 25);
				vig_panelStatus.drawString(MenuBarsMethods.getName("AxisX") + ": " + ballTrajectory_X, ballTrajectoryInformationColumnPossision + 10, 35);
				vig_panelStatus.drawString(MenuBarsMethods.getName("AxisY") + ": " + ballTrajectory_Y, ballTrajectoryInformationColumnPossision + 10, 50);
				vig_panelStatus.drawString(MenuBarsMethods.getName("Bounces") + ": " + numberOfBounces, w / 2 - 50, 15);
				vig_panelStatus.drawString(MenuBarsMethods.getName("RemainingLives") + ": " + lives, w / 2 - 50, 35);
				vig_panelStatus.drawString(MenuBarsMethods.getName("Points") + ": " + points, w / 2 - 50, 55);
				vig_panelStatus.drawString(MenuBarsMethods.getName("BallPosition"), ballPositionInformationColumnPossision - 10, 15);
				vig_panelStatus.drawString("-----------------------------", ballPositionInformationColumnPossision - 25, 25);
				vig_panelStatus.drawString(MenuBarsMethods.getName("AxisX") + ": " + BALL_X_AXIS, ballPositionInformationColumnPossision + 10, 35);
				vig_panelStatus.drawString(MenuBarsMethods.getName("AxisY") + ": " + BALL_Y_AXIS, ballPositionInformationColumnPossision + 10, 50);
				vig_panelStatus.drawString(MenuBarsMethods.getName("MousePosition"), mousePositionInformationColumnPossision - 10, 15);
				vig_panelStatus.drawString("-------------------------------------", mousePositionInformationColumnPossision - 25, 25);
				vig_panelStatus.drawString(MenuBarsMethods.getName("AxisX") + ": " + MOUSE_X_AXIS, mousePositionInformationColumnPossision + 10, 35);
				vig_panelStatus.drawString(MenuBarsMethods.getName("AxisY") + ": " + MOUSE_Y_AXIS, mousePositionInformationColumnPossision + 10, 50);
			}
			if (gameOver)
			{
				vig_panelStatus.drawImage(lowerPanelBackgroundForGameplay, 0, 0, w, _10PercentFrom_h, panelStatus);
				vig_panelStatus.drawRect(0, 0, w - 1, _10PercentFrom_h - 1);
				vig_panelStatus.drawString(MenuBarsMethods.getName("Bounces") + ": " + numberOfBounces, w / 2 - 50, 15);
				vig_panelStatus.drawString(MenuBarsMethods.getName("RemainingLives") + ": " + lives, w / 2 - 50, 35);
				vig_panelStatus.drawString(MenuBarsMethods.getName("Points") + ": " + points, w / 2 - 50, 55);
			}
			if (!liveLost && !gameOver) // normal play
			{
				vig_panelInformation.drawImage(upperPanelBackgroundForGameplay, 0, 0, w, _10PercentFrom_h, this);
				vig_panelInformation.drawRect(0, 0, w - 1, _10PercentFrom_h - 1);
			}
			if (liveLost && !gameOver) // live lost
			{
				vig_panelInformation.drawImage(upperPanelBackgroundForGameplay, 0, 0, w, _10PercentFrom_h, this);
				vig_panelInformation.drawRect(0, 0, w - 1, _10PercentFrom_h - 1);
				vig_panelInformation.setColor(Color.black);
				vig_panelInformation.drawRect(0, 0, w - 1, _10PercentFrom_h - 1);
				vig_panelInformation.setColor(Color.red);
				vig_panelInformation.setFont(font);
				vig_panelInformation.drawString(MenuBarsMethods.getName("LiveLost"), 200, 48);
				vig_panelInformation.setColor(Color.black);
			}
			if (!liveLost && newLevel) // new level
			{
				vig_panelInformation.drawImage(upperPanelBackgroundForGameplay, 0, 0, w, _10PercentFrom_h, this);
				vig_panelInformation.drawRect(0, 0, w - 1, _10PercentFrom_h - 1);
				vig_panelInformation.setColor(Color.black);
				vig_panelInformation.drawRect(0, 0, w - 1, _10PercentFrom_h - 1);
				vig_panelInformation.setColor(Color.red);
				vig_panelInformation.setFont(font);
				vig_panelInformation.drawString(MenuBarsMethods.getName("PressMouse"), 100, 48);
				vig_panelInformation.setColor(Color.black);
			}
			if (gameOver) // game over
			{
				vig_panelInformation.drawImage(upperPanelBackgroundForGameplay, 0, 0, w, _10PercentFrom_h, this);
				vig_panelInformation.drawRect(0, 0, w - 1, _10PercentFrom_h - 1);
				vig_panelInformation.setColor(Color.black);
				vig_panelInformation.drawRect(0, 0, w - 1, _10PercentFrom_h - 1);
				vig_panelInformation.setColor(Color.red);
				vig_panelInformation.setFont(font);
				vig_panelInformation.drawString(MenuBarsMethods.getName("GameOver"), 250, 48);
				vig_panelInformation.setColor(Color.black);
			}
			if (true)
			{
				switch(currentLevel)
				{
					case 1:
						levelsManager.runLevel(vig_panelGame, 1);
					case 2:
						levelsManager.runLevel(vig_panelGame, 2);
					case 3:
						levelsManager.runLevel(vig_panelGame, 3);
					case 4:
						levelsManager.runLevel(vig_panelGame, 4);
					case 5:
						levelsManager.runLevel(vig_panelGame, 5);
				}
				ball.run();
				// TO DO
				vig_panelGame.drawImage(mirconoidImage, mirconoid_X_AXIS, panelGame.getHeight() - mirconoid_HEIGHT - 5, mirconoid_WIDTH, mirconoid_HEIGHT, panelGame);
				vig_panelGame.drawImage(ballImage, BALL_X_AXIS, BALL_Y_AXIS, BALL_SIZE, BALL_SIZE, panelGame);
				if (!exit)
					g.drawImage(vi_panelInformation, 0, 0, panelInformation);
				if (!exit)
					g.drawImage(vi_panelGame, 0, 60, panelGame);
				if (!exit)
					g.drawImage(vi_panelStatus, 0, 540, panelStatus);
				g.dispose();
				return;
			}
		}
	}
	public static int getPanelGameHeight()
	{
		return panelGame.getHeight();
	}

	public static int getWindowParameters( String choose )
	{
		if (choose.equals("width"))
		{
			return w;
		}
		if (choose.equals("height"))
		{
			return h;
		}
		return -1;
	}
	public static int getBallSize()
	{
		return BALL_SIZE;
	}
	public static int getBallLocation( String xy )
	{
		if (xy.equals("x"))
		{
			return BALL_X_AXIS;
		}
		if (xy.equals("y"))
		{
			return BALL_Y_AXIS;
		}
		return -1;
	}
	public static void changeBallLocation( String choose, double x, double y )
	{
		if (choose.equals("update"))
		{
			BALL_X_AXIS += x;
			BALL_Y_AXIS += y;
		}
		if (choose.equals("set"))
		{
			BALL_X_AXIS = (int) x;
			BALL_Y_AXIS = (int) y;
		}
	}
	public static void changeBallTrajectory( String xy, String choose, double value )
	{
		if (choose.equals("update"))
		{
			if (xy.equals("x"))
			{
				ballTrajectory_X += value;
			}
			if (xy.equals("y"))
			{
				ballTrajectory_Y += value;
			}
		}
		if (choose.equals("set"))
		{
			if (xy.equals("x"))
			{
				ballTrajectory_X = value;
			}
			if (xy.equals("y"))
			{
				ballTrajectory_Y = value;
			}
		}
	}
	public static void changePausedBallTrajectory( String xy, String choose, double value )
	{
		if (choose.equals("update"))
		{
			if (xy.equals("x"))
			{
				pausedBallTrajectory_X += value;
			}
			if (xy.equals("y"))
			{
				pausedBallTrajectory_Y += value;
			}
		}
		if (choose.equals("set"))
		{
			if (xy.equals("x"))
			{
				pausedBallTrajectory_X = value;
			}
			if (xy.equals("y"))
			{
				pausedBallTrajectory_Y = value;
			}
		}
	}
	public static double getBallTrajectory( String xy )
	{
		// -------------------------------------------------
		if (xy.equals("x"))
			return ballTrajectory_X;
		if (xy.equals("y"))
			return ballTrajectory_Y;
		return -1;
	}
	public static int getmirconoidPerameters( String xy )
	{
		if (xy.equals("width"))
		{
			return mirconoid_WIDTH;
		}
		if (xy.equals("height"))
		{
			return mirconoid_HEIGHT;
		}
		return -1;
	}
	public static int getmirconoidLocation( String xy )
	{
		if (xy.equals("x"))
		{
			return mirconoid_X_AXIS;
		}
		if (xy.equals("y"))
		{
			return mirconoid_Y_AXIS;
		}
		return -1;
	}
	public static void setNewSkin()
	{
		upperPanelBackgroundForGameplay = ResourceAnchor.currentUpperPanelSkin;
		lowerPanelBackgroundForGameplay = ResourceAnchor.currentLowerPanelSkin;
	}
	public static void reset()
	{
		System.out.println("reset()");
		panelInformation.removeAll();
		panelGame.removeAll();
		panelStatus.removeAll();
		mirconoid_WIDTH = 50;
		mirconoid_HEIGHT = 10;
		mirconoid_X_AXIS = w / 2 - mirconoid_WIDTH; // default Mirkonoid X
													// posision
		mirconoid_Y_AXIS = panelGame.getHeight() - (mirconoid_HEIGHT + 5); // default
																			// Mirkonoid
																			// Y
																			// posision
		BALL_SIZE = 10; // default ball size
		BALL_X_AXIS = 400; // default ball X posision
		BALL_Y_AXIS = 260; // default ball Y posision
		MOUSE_X_AXIS = 0; // default X posision for mouse cursor
		MOUSE_Y_AXIS = 0; // default Y posision for mouse cursor
		ballTrajectory_X = 0;
		ballTrajectory_Y = 0;
		pausedBallTrajectory_X = 0;
		pausedBallTrajectory_Y = 0;
		ballTrajectoryInformationColumnPossision = 50;
		ballPositionInformationColumnPossision = 500;
		mousePositionInformationColumnPossision = 650;
		points = 0;
		numberOfBounces = 0;
		lives = 5;
		bounced = false;
		bouncedBlock = false;
		gameStarted = false;
		gamePaused = false;
		gamePausedByMouseExit = false;
		gameEnded = false;
		liveLost = false;
		lastLive = false;
		gameOver = false;
		newLevel = false;
		exit = false;
		currentLevel = 1;
		firstTime = true;
		playerName = null;
		vi_panelInformation = null;
		vig_panelInformation = null;
		vi_panelGame = null;
		vig_panelGame = null;
		vi_panelStatus = null;
		vig_panelGame = null;
	}
}