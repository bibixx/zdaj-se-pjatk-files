package mirconoid.mediaPlayer;

public class MediaPlayer extends javax.media.bean.playerbean.MediaPlayer
{
	private static String[]	tracksTable;
	private static int		currentTrack	= -1;
	private static boolean	initialized;
	private static boolean	firstTime		= true;

	// -------------------------------------------------
	// setVolume()
	// -------------------------------------------------
	public void setVolume( String text )
	{
		setVolumeLevel(text);
	}
	// -------------------------------------------------
	// playPreviousTrack()
	// -------------------------------------------------
	public void playPreviousTrack()
	{
		if (initialized)
		{
			if (currentTrack - 1 >= 0)
			{
				stop();
				setMediaLocation(tracksTable[currentTrack - 1]);
				start();
			}
			else
			{
				System.out.println("MEDIAPLAYER INFO: Playing first audio track.");
			}
		}
		else
		{
			System.err.println("MEDIAPLAYER ERROR: Player not initialized");
		}
	}
	// -------------------------------------------------
	// playNextTrack()
	// -------------------------------------------------
	public void playNextTrack()
	{
		if (initialized)
		{
			if (currentTrack + 1 < tracksTable.length)
			{
				stop();
				setMediaLocation(tracksTable[currentTrack + 1]);
				System.out.println("MEDIAPLAYER INFO: Trying to play track nr " + (currentTrack + 1) + ":   " + tracksTable[currentTrack + 1].toString());
				currentTrack += 1;
				start();
			}
			else
			{
				System.out.println("MEDIAPLAYER INFO: Playing last audio track.");
			}
		}
		else
		{
			System.err.println("MEDIAPLAYER ERROR: Player not initialized");
		}
	}
	// -------------------------------------------------
	// fillTrackTableWithDefaultTracks()
	// -------------------------------------------------
	public void fillTrackTableWithDefaultTracks()
	{
		tracksTable = null;
		tracksTable = new String[3];
		tracksTable[0] = "file:Music/BH_FD.mp3";
		tracksTable[1] = "file:Music/BH_I.mp3";
		tracksTable[2] = "file:Music/BH_N.mp3";
	}
	// -------------------------------------------------
	// initializePlayerForMusic()
	// -------------------------------------------------
	public void initializePlayerForMusic()
	{
		if (firstTime)
		{
			setPlaybackLoop(true);
			fillTrackTableWithDefaultTracks();
			int choose = (int) (Math.random() * 3);
			System.out.println(choose);
			switch(choose)
			{
				case 0:
				{
					setMediaLocation(tracksTable[0]);
				}
					break;
				case 1:
				{
					setMediaLocation(tracksTable[1]);
				}
					break;
				case 2:
				{
					setMediaLocation(tracksTable[2]);
				}
					break;
			}
			firstTime = false;
			currentTrack = 0;
		}
		try
		{
			System.out.println("MEDIAPLAYER INFO: Trying to play track nr " + (currentTrack) + ":   " + tracksTable[currentTrack].toString());
			start();
			setVolumeLevel("1");
			initialized = true;
		}
		catch (Exception e)
		{
			System.err.println("MEDIAPLAYER ERROR: " + e.getMessage());
		}
	}
	// -------------------------------------------------
	// initializePlayerForVideo()
	// -------------------------------------------------
	public void initializePlayerForVideo()
	{
		setMediaLocation("file:Video/Logo.avi");
		setVisible(true);
		setPlaybackLoop(false);
		setBounds(0, 0, 640, 480);
		setControlPanelVisible(false);
		try
		{
			start();
		}
		catch (Exception e)
		{
			System.err.println("MEDIAPLAYER ERROR: " + e.getMessage());
		}
	}
}// class mirconoidMediaPlayer
