package mirconoid.JDBC;

import java.sql.*;
import java.util.Vector;
import mirconoid.Manager;
import mirconoid.Player;

//-------------------------------------------------	
//Jdbc()	
//-------------------------------------------------
public class Jdbc
{
	private static final String		drName	= "com.mysql.jdbc.Driver";
	private static final String		url		= "jdbc:mysql://127.0.0.1/mirconoid";
	private static final String		uid		= "player";
	private static final String		pwd		= "player";
	public static Vector<Player>	players	= new Vector<Player>();
	public static int				counter	= 0;

	// -------------------------------------------------
	// sendPlayer()
	// -------------------------------------------------
	public static void sendPlayer( Player player )
	{
		Connection con;
		try
		{
			System.out.println("JDBC INFO: Sending player's score to MySQL datadase");
			Class.forName(drName);
			con = DriverManager.getConnection(url, uid, pwd);
			PreparedStatement st = con.prepareStatement("INSERT INTO mirconoid.highscores SET name=? , bounces=?, lives=?, points=?, totalPoints=?, date=?, time=? ;");
			// getting current data and time in ISO format
			java.util.Date currentDate = new java.util.Date();
			java.sql.Date date = new java.sql.Date(currentDate.getTime());
			java.sql.Time time = new java.sql.Time(currentDate.getTime());
			// setting players data and time to current
			player.setDate(date);
			player.setTime(time);
			// setting parameters in SQL querry
			st.setString(1, player.getName());
			st.setInt(2, player.getBounces());
			st.setInt(3, player.getLives());
			st.setInt(4, player.getPoints());
			st.setInt(5, player.getTotalPoints());
			st.setDate(6, player.getDate());
			st.setTime(7, player.getTime());
			st.executeUpdate();
			Statement sortTable = con.createStatement();
			sortTable.executeUpdate("ALTER TABLE mirconoid.highscores ORDER BY totalpoints DESC;");
			sortTable.close();
			con.close();
			System.out.println("JDBC INFO: Player score sent successfully to database.");
		}
		catch (SQLException exc)
		{
			Manager.showErrorMessageWhenConnectingToSQLServer();
			System.err.println("JDBC ERROR: " + exc.getMessage());
		}
		catch (ClassNotFoundException exc)
		{
			System.err.println("JDBC ERROR: " + exc.getMessage());
			System.exit(1);
		}
	}
	// -------------------------------------------------
	// Get()
	// -------------------------------------------------
	public static boolean Get()
	{
		Connection con;
		try
		{
			System.out.println("JDBC INFO: Getting inforamtion from MySQL datadase");
			Class.forName(drName);
			con = DriverManager.getConnection(url, uid, pwd);
			Statement cs = con.createStatement();
			ResultSet rs = cs.executeQuery("select * from highscores order by totalPoints desc;");
			players.clear();
			counter = 0;
			while (rs.next())
			{
				String name = rs.getString(2);
				int bounces = rs.getInt(3);
				int lives = rs.getInt(4);
				int points = rs.getInt(5);
				int totalPoints = rs.getInt(6);
				java.sql.Date date = rs.getDate(7);
				java.sql.Time time = rs.getTime(8);
				Player player = new Player();
				player.setName(name);
				player.setBounces(bounces);
				player.setLives(lives);
				player.setPoints(points);
				player.setTotalPoints(totalPoints);
				player.setDate(date);
				player.setTime(time);
				players.add(player);
				counter++;
			}
			rs.close();
			cs.close();
			con.close();
			System.out.println("JDBC INFO: High scores list successfully recieved from MySQL database.");
			return true;
		}
		catch (SQLException exc)
		{
			Manager.showErrorMessageWhenConnectingToSQLServer();
			System.err.println("JDBC ERROR: " + exc.getMessage());
			return false;
		}
		catch (ClassNotFoundException exc)
		{
			System.err.println("JDBC ERROR: " + exc.getMessage());
			return false;
		}
	}
}