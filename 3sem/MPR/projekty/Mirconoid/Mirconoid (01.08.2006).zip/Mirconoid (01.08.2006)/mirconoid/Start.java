package mirconoid;

public class Start
{
	public static void main( String[] args ) throws InterruptedException
	{
		Manager.getInstance();
		while (true)
		{
			Manager.getMediaPlayer().initializePlayerForMusic();
			Manager.goTo("Gameplay");
			break;
		}
	}
}