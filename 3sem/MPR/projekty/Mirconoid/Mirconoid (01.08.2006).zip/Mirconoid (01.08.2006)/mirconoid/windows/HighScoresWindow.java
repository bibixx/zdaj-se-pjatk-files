package mirconoid.windows;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableColumn;
import mirconoid.JDBC.Jdbc;
import mirconoid.screen.ScreenResolution;

public class HighScoresWindow extends JFrame implements MouseListener
{
	private JPanel						panel;
	private JTable						table;
	private JScrollPane					scrollPane;
	private Vector<String>				columns;
	private Vector<Vector<Comparable>>	playersData;
	private Image						icon	= Toolkit.getDefaultToolkit().getImage("./Pictures/Icon.jpg");

	public HighScoresWindow()
	{
		super("High Scores");
		setIconImage(icon);
		mirconoid.Manager.showWaintingMessageWhenConnectingToSQLServer();
		if (Jdbc.Get() == true)
		{
			this.setDefaultCloseOperation(1);
			this.panel = new JPanel();
			this.panel.setLayout(new GridLayout(1, 0));
			this.columns = new Vector<String>();
			this.columns.add("Rank");
			this.columns.add("Name");
			this.columns.add("Bounces");
			this.columns.add("Lives");
			this.columns.add("Points");
			this.columns.add("Total Points");
			this.columns.add("Date");
			this.columns.add("Time");
			if (Jdbc.counter != 0)
			{
				this.playersData = new Vector<Vector<Comparable>>();
				int counter = 1;
				for (int i = 0 ; i < Jdbc.counter ; i++)
				{
					Vector<Comparable> row = new Vector<Comparable>();
					row.add(counter);
					row.add(Jdbc.players.elementAt(i).getName());
					row.add(Jdbc.players.elementAt(i).getBounces());
					row.add(Jdbc.players.elementAt(i).getLives());
					row.add(Jdbc.players.elementAt(i).getPoints());
					row.add(Jdbc.players.elementAt(i).getTotalPoints());
					row.add(Jdbc.players.elementAt(i).getDate());
					row.add(Jdbc.players.elementAt(i).getTime());
					playersData.add(row);
					counter++;
				}
			}
			this.table = new JTable(this.playersData, this.columns);
			this.table.setEnabled(false);
			this.table.setPreferredScrollableViewportSize(new Dimension(700, 200));
			TableColumn column_0 = table.getColumnModel().getColumn(0);
			column_0.setResizable(false);
			column_0.setPreferredWidth(10);
			TableColumn column_1 = table.getColumnModel().getColumn(1);
			column_1.setResizable(false);
			column_1.setPreferredWidth(150);
			TableColumn column_2 = table.getColumnModel().getColumn(2);
			column_2.setResizable(false);
			column_2.setPreferredWidth(30);
			TableColumn column_3 = table.getColumnModel().getColumn(3);
			column_3.setResizable(false);
			column_3.setPreferredWidth(10);
			TableColumn column_4 = table.getColumnModel().getColumn(4);
			column_4.setResizable(false);
			column_4.setPreferredWidth(10);
			TableColumn column_5 = table.getColumnModel().getColumn(5);
			column_5.setResizable(false);
			column_5.setPreferredWidth(30);
			TableColumn column_6 = table.getColumnModel().getColumn(6);
			column_6.setResizable(false);
			column_6.setPreferredWidth(60);
			TableColumn column_7 = table.getColumnModel().getColumn(7);
			column_7.setResizable(false);
			column_7.setPreferredWidth(50);
			this.scrollPane = new JScrollPane(this.table);
			this.panel.add(this.scrollPane);
			this.panel.setOpaque(true);
			this.setContentPane(this.panel);
			this.setResizable(false);
			this.setLocation((ScreenResolution.getDefaultScreenWidth() / 2) - (700 / 2), (ScreenResolution.getDefaultScreenHeight() / 2) - (200 / 2) - (ScreenResolution.getDefaultScreenHeight() / 10));
			this.table.addMouseListener(this);
			this.scrollPane.addMouseListener(this);
			this.panel.addMouseListener(this);
			this.addMouseListener(this);
			this.pack();
			this.setVisible(true);
		}
		else
		{
		}
	}
	public void mouseClicked( MouseEvent arg0 )
	{
	}
	public void mouseEntered( MouseEvent arg0 )
	{
	}
	public void mouseExited( MouseEvent arg0 )
	{
	}
	public void mousePressed( MouseEvent arg0 )
	{
		this.playersData = null;
		this.columns = null;
		this.dispose();
		this.invalidate();
	}
	public void mouseReleased( MouseEvent arg0 )
	{
	}
}