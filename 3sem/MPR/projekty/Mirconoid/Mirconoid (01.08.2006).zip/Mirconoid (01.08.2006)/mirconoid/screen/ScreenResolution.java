package mirconoid.screen;

import java.awt.Dimension;
import java.awt.Toolkit;

public class ScreenResolution
{
	private static Dimension	defaultScreenDimension;
	private static int			defaultScreenWidth;
	private static int			defaultScreenHeight;
	private static boolean		isDefaultScreenDimensionSet;

	public static Dimension getDefaultScreenResolution()
	{
		if (!isDefaultScreenDimensionSet)
		{
			defaultScreenDimension = Toolkit.getDefaultToolkit().getScreenSize();
			isDefaultScreenDimensionSet = true;
		}
		return defaultScreenDimension;
	}
	public static int getDefaultScreenWidth()
	{
		if (!isDefaultScreenDimensionSet)
		{
			getDefaultScreenResolution();
		}
		defaultScreenWidth = defaultScreenDimension.width;
		return defaultScreenWidth;
	}
	public static int getDefaultScreenHeight()
	{
		if (!isDefaultScreenDimensionSet)
		{
			getDefaultScreenResolution();
		}
		defaultScreenHeight = defaultScreenDimension.height;
		return defaultScreenHeight;
	}
}