package mirconoid;

public class Player
{
	private String			name;
	private int				bounces;
	private int				lives;
	private int				points;
	private int				totalPoints;
	private java.sql.Date	date;
	private java.sql.Time	time;

	public Player()
	{
	}
	Player(String name, int bounces, int lives, int points)
	{
		this.name = name;
		this.bounces = bounces;
		this.lives = lives;
		this.points = points;
		this.totalPoints = this.points + (this.lives * 3) - (int) (this.bounces / 10);
		java.util.Date currentDate = new java.util.Date();
		java.sql.Date date = new java.sql.Date(currentDate.getTime());
		java.sql.Time time = new java.sql.Time(currentDate.getTime());
		this.date = date;
		this.time = time;
	}
	public String getName()
	{
		return name;
	}
	public void setName( String name )
	{
		this.name = name;
	}
	public int getBounces()
	{
		return bounces;
	}
	public void setBounces( int bounces )
	{
		this.bounces = bounces;
	}
	public int getLives()
	{
		return lives;
	}
	public void setLives( int lives )
	{
		this.lives = lives;
	}
	public int getPoints()
	{
		return points;
	}
	public void setPoints( int points )
	{
		this.points = points;
	}
	public int getTotalPoints()
	{
		return totalPoints;
	}
	public void setTotalPoints( int totalPoints )
	{
		this.totalPoints = totalPoints;
	}
	public java.sql.Date getDate()
	{
		return date;
	}
	public void setDate( java.sql.Date date )
	{
		this.date = date;
	}
	public java.sql.Time getTime()
	{
		return time;
	}
	public void setTime( java.sql.Time time )
	{
		this.time = time;
	}
}