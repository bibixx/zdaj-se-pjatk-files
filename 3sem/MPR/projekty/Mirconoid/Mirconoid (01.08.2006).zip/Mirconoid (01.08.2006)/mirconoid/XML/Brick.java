package mirconoid.XML;

import java.awt.Rectangle;
import java.util.Vector;

public class Brick
{
	private int					width;
	private int					height;
	private String				imageURL;
	private Vector<Rectangle>	positions	= new Vector<Rectangle>();

	// -------------------------------------------------
	// Brick()
	// -------------------------------------------------
	public Brick()
	{
	}
	Brick(int width, int height, String imageURL)
	{
		setWidth(width);
		setHeight(height);
		setImageURL(imageURL);
	}
	public int getWidth()
	{
		return width;
	}
	public void setWidth( int width )
	{
		this.width = width;
	}
	public int getHeight()
	{
		return height;
	}
	public void setHeight( int height )
	{
		this.height = height;
	}
	public String getImageURL()
	{
		return imageURL;
	}
	public void setImageURL( String imageURL )
	{
		this.imageURL = imageURL;
	}
	public Vector<Rectangle> getPositions()
	{
		return positions;
	}
	public void addPosition( int x, int y )
	{
		this.positions.add(new Rectangle(x, y));
	}
	public int getPositionX( int index )
	{
		return this.positions.elementAt(index).width;
	}
	public int getPositionY( int index )
	{
		return this.positions.elementAt(index).height;
	}
}