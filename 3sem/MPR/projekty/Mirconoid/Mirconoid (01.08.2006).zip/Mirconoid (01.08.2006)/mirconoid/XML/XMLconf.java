package mirconoid.XML;

import java.io.*;
import java.util.Vector;
import org.xml.sax.*;
import org.xml.sax.helpers.*;
import javax.xml.parsers.SAXParserFactory;
import javax.xml.parsers.SAXParser;

public class XMLconf
{
	public static String		backgroundImageURL;
	public static Vector<Brick>	bricks;
	static boolean				readingBricksData;
	static boolean				readingDataAboutNextBrick;
	static boolean				readingPositionsData;
	static boolean				readingDataAboutNextPosition;
	static int					currentPositionX;
	static int					currentPositionY;

	public static void clearTab()
	{
		for (int j = 0 ; j < SAXHandler.vector.size() ; j++)
		{
			SAXHandler.vector.clear();
		}
	}
	public static void getData( String file )
	{
		int index = 0;
		String[] xmlfile = { file };
		try
		{
			String xmlResource = "file:" + new File(xmlfile[index]).getAbsolutePath();
			SAXParserFactory spf = SAXParserFactory.newInstance();
			SAXParser sp = spf.newSAXParser();
			SAXHandler handler = new SAXHandler();
			sp.parse(xmlResource, handler);
			bricks = new Vector<Brick>();
			int bricksCounter = -1;
			int positionsCounter = -1;
			for (int j = 0 ; j < SAXHandler.vector.size() ; j++)
			{
				if ((SAXHandler.vector.elementAt(j).toString()).equals("BRICKS"))
				{
					readingBricksData = true;
					continue;
				}
				if (readingBricksData)
				{
					if ((SAXHandler.vector.elementAt(j).toString()).startsWith("BRICK"))
					{
						readingDataAboutNextBrick = true;
						bricksCounter++;
						bricks.addElement(new Brick(0, 0, null));
						continue;
					}
					else
					{
						readingDataAboutNextBrick = false;
					}
					if (!readingDataAboutNextBrick)
					{
						if ((SAXHandler.vector.elementAt(j).toString()).equals("WIDTH"))
						{
							bricks.elementAt(bricksCounter).setWidth(Integer.parseInt((String) SAXHandler.vector.elementAt(j + 1)));
							j++;
						}
						if ((SAXHandler.vector.elementAt(j).toString()).equals("HEIGHT"))
						{
							bricks.elementAt(bricksCounter).setHeight(Integer.parseInt((String) SAXHandler.vector.elementAt(j + 1)));
							j++;
						}
						if ((SAXHandler.vector.elementAt(j).toString()).equals("IMAGEURL"))
						{
							bricks.elementAt(bricksCounter).setImageURL((String) SAXHandler.vector.elementAt(j + 1));
							j++;
						}
						if ((SAXHandler.vector.elementAt(j).toString()).equals("POSITIONS"))
						{
							readingPositionsData = true;
							continue;
						}
					}
					if (readingPositionsData)
					{
						if ((SAXHandler.vector.elementAt(j).toString()).equals("POSITION"))
						{
							readingDataAboutNextPosition = true;
							positionsCounter++;
							continue;
						}
						else
						{
							readingDataAboutNextPosition = false;
						}
						if (!readingDataAboutNextPosition)
						{
							if ((SAXHandler.vector.elementAt(j).toString()).equals("X"))
							{
								currentPositionX = Integer.parseInt((String) SAXHandler.vector.elementAt(j + 1));
								j++;
							}
							if ((SAXHandler.vector.elementAt(j).toString()).equals("Y"))
							{
								currentPositionY = Integer.parseInt((String) SAXHandler.vector.elementAt(j + 1));
								bricks.elementAt(bricksCounter).addPosition(currentPositionX, currentPositionY);
								j++;
							}
						}
					}
					if ((SAXHandler.vector.elementAt(j).toString()).equals("/POSITIONS"))
					{
						readingPositionsData = false;
					}
				}
				if ((SAXHandler.vector.elementAt(j).toString()).equals("/BRICKS"))
				{
					readingBricksData = false;
				}
				if ((SAXHandler.vector.elementAt(j).toString()).equals("BACKGROUNDURL"))
				{
					backgroundImageURL = SAXHandler.vector.elementAt(j + 1).toString();
					j++;
					return;
				}
			}
		}
		catch (Exception e)
		{
			System.err.println("XML ERROR: " + e.getMessage());
		}
	}
}

class SAXHandler extends DefaultHandler
{
	public static Vector<Object>	vector	= new Vector<Object>();
	private String					currentData;

	public void startElement( String namespaceURI, String localName, String rawName, Attributes atts ) throws SAXException
	{
		vector.addElement(rawName);
	}
	public void endElement( String namespaceURI, String localName, String rawName ) throws SAXException
	{
	}
	public void ignorableWhitespace( char[] ch, int start, int end ) throws SAXException
	{
	}
	public void characters( char[] ch, int start, int length ) throws SAXException
	{
		currentData = new String(ch, start, length).trim();
		if (currentData.equals(""))
		{
			currentData = null;
		}
		else
		{
			vector.addElement(currentData);
		}
	}
}