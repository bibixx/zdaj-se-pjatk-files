package mirconoid.levels;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.util.Vector;
import mirconoid.Gameplay;
import mirconoid.Manager;
import mirconoid.ResourceAnchor;
import mirconoid.Methods.AudioMethods;
import mirconoid.XML.Brick;
import mirconoid.XML.XMLconf;

public class LevelsManager
{
	private static Vector<Brick>	bricks;
	private static int				brickBeforeLastBrickIndex	= -2;
	private static int				lastBrickIndex				= -1;
	private static int				destroyedBricksCounter;
	private static int				numberOfAllBricksInLevel;
	private static Image			Image_background;
	private static boolean			levelPrepared;
	private static int				BALL_SIZE					= Gameplay.getBallSize();
	private static int				BALL_X_AXIS;
	private static int				BALL_Y_AXIS;
	private static Rectangle		collisionRectangleBall		= new Rectangle(0, 0, BALL_SIZE, BALL_SIZE);

	public void runLevel( Graphics g, int levelNumber )
	{
		if (!levelPrepared && Gameplay.gameStarted)
		{
			System.out.print("BEFORE");
			prepareLevel(levelNumber);
		}
		if(g != null && levelNumber >= 1)
		{
			g.drawImage(Image_background, 0, 0, 800, 480, null);
			getBallInformation();
			drawBircks(g);
			checkCollision(levelNumber);
		}
		else
		{
			System.err.print("ERROR when drawing level's elements.");
			System.exit(0);
		}
	}
	public static void getBallInformation()
	{
		BALL_SIZE = Gameplay.getBallSize();
		BALL_X_AXIS = Gameplay.getBallLocation("x");
		BALL_Y_AXIS = Gameplay.getBallLocation("y");
	}
	static void drawBircks( Graphics g )
	{
		for (int i = 0 ; i < bricks.size() ; i++)
		{
			for (int k = 0 ; k < bricks.elementAt(i).getPositions().size() ; k++)
			{
				int x = (int) bricks.elementAt(i).getPositions().elementAt(k).getX();
				int y = (int) bricks.elementAt(i).getPositions().elementAt(k).getY();
				int width = (int) bricks.elementAt(i).getPositions().elementAt(k).getWidth();
				int height = (int) bricks.elementAt(i).getPositions().elementAt(k).getHeight();
				g.drawImage(ResourceAnchor.getImage(bricks.elementAt(i).getImageURL()), x, y, width, height, null);
			}
		}
	}
	static void checkCollision( int levelNumber )
	{
		if (Gameplay.bounced)
		{
			collisionRectangleBall.setLocation(BALL_X_AXIS, BALL_Y_AXIS);
			for (int i = 0 ; i < bricks.size() ; i++)
			{
				for (int k = 0 ; k < bricks.elementAt(i).getPositions().size() ; k++)
				{
					if (collisionRectangleBall.intersects(bricks.elementAt(i).getPositions().elementAt(k)))
					{
						brickBeforeLastBrickIndex = lastBrickIndex;
						if (lastBrickIndex != i)
						{
							if (checkBallCollisionWithBrick(bricks.elementAt(i).getPositions().elementAt(k), bricks.elementAt(i).getWidth(), bricks.elementAt(i).getHeight(), i, brickBeforeLastBrickIndex, lastBrickIndex))
							{
								bricks.elementAt(i).getPositions().remove(k);
								destroyedBricksCounter += 1;
								System.out.println("DESTROYED: " + destroyedBricksCounter);
								System.out.println("ALL: " + numberOfAllBricksInLevel);
								if (numberOfAllBricksInLevel == destroyedBricksCounter)
								{
									// bricks.clear();
									brickBeforeLastBrickIndex = -2;
									lastBrickIndex = -1;
									numberOfAllBricksInLevel = 0;
									destroyedBricksCounter = 0;
									numberOfAllBricksInLevel = 0;
									Image_background = null;
									Gameplay.ballTrajectory_X = 0;
									Gameplay.ballTrajectory_Y = 0;
									Manager.showCongratulationMessage("" + levelNumber);
									if (levelNumber == 5)
									{
										Gameplay.sendPlayerInfromationToSQL("won", 15);
										Manager.goTo("MainMenu");
									}
									else
									{
										mirconoid.Methods.Methods.NewLevel();
										Gameplay.currentLevel = levelNumber + 1;
										levelPrepared = false;
									}
								}
							}
						}
					}
				}
			}
		}
	}
	public static boolean checkBallCollisionWithBrick( Rectangle rec, int blockWidth, int blockHeight, int i, int blockBeforeLastBlock, int lastBlock )
	{
		getBallInformation();
		// ==========================
		// LEFT SIDE
		// ==========================
		if (BALL_Y_AXIS + BALL_SIZE - BALL_SIZE / 2 > rec.getY() && BALL_Y_AXIS - BALL_SIZE - BALL_SIZE / 2 < rec.getY() + blockHeight && BALL_X_AXIS < rec.getX())
		{
			if (Gameplay.ballTrajectory_X > 0 && Gameplay.ballTrajectory_Y > 0 && lastBlock != i)
			{
				AudioMethods.playBrickHit();
				lastBlock = i;
				Gameplay.ballTrajectory_X = -Gameplay.ballTrajectory_X;
				Gameplay.points += 1;
				return true;
			}
			if (Gameplay.ballTrajectory_X > 0 && Gameplay.ballTrajectory_Y < 0 && lastBlock != i)
			{
				AudioMethods.playBrickHit();
				lastBlock = i;
				Gameplay.ballTrajectory_X = -Gameplay.ballTrajectory_X;
				Gameplay.points += 1;
				return true;
			}
		}
		else
		// ==========================
		// RIGTH SIDE
		// ==========================
		if (BALL_Y_AXIS + BALL_SIZE - BALL_SIZE / 2 > rec.getY() && BALL_Y_AXIS - BALL_SIZE - BALL_SIZE / 2 < rec.getY() + blockHeight && BALL_X_AXIS + BALL_SIZE - BALL_SIZE / 2 > rec.getX() + blockWidth)
		{
			if (Gameplay.ballTrajectory_X < 0 && Gameplay.ballTrajectory_Y > 0 && lastBlock != i)
			{
				AudioMethods.playBrickHit();
				lastBlock = i;
				Gameplay.ballTrajectory_X = -Gameplay.ballTrajectory_X;
				Gameplay.points += 1;
				return true;
			}
			if (Gameplay.ballTrajectory_X < 0 && Gameplay.ballTrajectory_Y < 0 && lastBlock != i)
			{
				AudioMethods.playBrickHit();
				lastBlock = i;
				Gameplay.ballTrajectory_X = -Gameplay.ballTrajectory_X;
				Gameplay.points += 1;
				return true;
			}
		}
		else
		// ==========================
		// UP SIDE
		// ==========================
		if (Gameplay.ballTrajectory_Y > 0 && BALL_Y_AXIS < rec.getY() && lastBlock != i)
		{
			AudioMethods.playBrickHit();
			lastBlock = i;
			Gameplay.ballTrajectory_Y = -Gameplay.ballTrajectory_Y;
			Gameplay.points += 1;
			return true;
		}
		else
		// ==========================
		// DOWN SIDE
		// ==========================
		if (Gameplay.ballTrajectory_Y < 0 && BALL_Y_AXIS + BALL_SIZE - 1 > rec.getY() + blockHeight && lastBlock != i)
		{
			AudioMethods.playBrickHit();
			lastBlock = i;
			Gameplay.ballTrajectory_Y = -Gameplay.ballTrajectory_Y;
			Gameplay.points += 1;
			return true;
		}
		if (blockBeforeLastBlock == lastBlock)
		{
			AudioMethods.playBonusHit();
			lastBlock = i;
			Gameplay.points += 2;
			return true;
		}
		return false;
	}
	static void prepareLevel( int levelNumber )
	{
		bricks = new Vector<Brick>();
		numberOfAllBricksInLevel = 0;
		brickBeforeLastBrickIndex = -2;
		lastBrickIndex = -1;
		destroyedBricksCounter = 0;
		XMLconf.clearTab();
		XMLconf.getData("mirconoid/XML/level" + levelNumber + ".xml");
		int numberOfBricksTypes = XMLconf.bricks.size();
		for (int i = 0 ; i < numberOfBricksTypes ; i++)
		{
			Brick brick = new Brick();
			int width = (int) XMLconf.bricks.elementAt(i).getWidth();
			int height = (int) XMLconf.bricks.elementAt(i).getHeight();
			brick.setWidth(width);
			brick.setHeight(height);
			brick.setImageURL(XMLconf.bricks.elementAt(i).getImageURL());
			int numberOfPositions = XMLconf.bricks.elementAt(i).getPositions().size();
			for (int k = 0 ; k < numberOfPositions ; k++)
			{
				int x = (int) XMLconf.bricks.elementAt(i).getPositionX(k);
				int y = (int) XMLconf.bricks.elementAt(i).getPositionY(k);
				Rectangle position = new Rectangle();
				position.setLocation(x, y);
				position.setSize(width, height);
				brick.getPositions().add(position);
			}
			bricks.add(brick);
		}
		Image_background = ResourceAnchor.getImage((String) XMLconf.backgroundImageURL);
		for (int i = 0 ; i < bricks.size() ; i++)
		{
			for (int k = 0 ; k < bricks.elementAt(i).getPositions().size() ; k++)
			{
				numberOfAllBricksInLevel++;
			}
		}
		levelPrepared = true;
	}
}