public class SimpleSamples {


  public SimpleSamples() {

  }

  public static void main(String[] args) {
     new SimpleSamples();
  }


}