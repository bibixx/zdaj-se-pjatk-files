public class DbAccessException extends RuntimeException {
  public DbAccessException(String msg, Throwable cause) {
     super(msg, cause);
   }
}