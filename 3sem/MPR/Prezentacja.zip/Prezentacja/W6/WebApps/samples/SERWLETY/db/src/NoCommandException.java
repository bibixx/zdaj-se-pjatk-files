
public class NoCommandException extends RuntimeException {
  public NoCommandException() { super(); }
  public NoCommandException(String msg) { super(msg); }
}
