package zad1;

import java.sql.*;

public class Database {

	public Database(String url, TravelData travelData) {
		// TODO Auto-generated constructor stub
		try {
			Connection con = DriverManager.getConnection(url);
		} catch (SQLException e) {
			System.out.println("Nieudane połączenie z " + url);
		       System.out.println(e);
		       System.exit(1);
		}
	}

	public void create() {
		// TODO Auto-generated method stub
		
	}

	public void showGui() {
		// TODO Auto-generated method stub
		
	}
	
}
