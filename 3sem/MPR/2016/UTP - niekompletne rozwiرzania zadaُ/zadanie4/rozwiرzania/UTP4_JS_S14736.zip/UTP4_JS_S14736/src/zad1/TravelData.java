package zad1;

import java.io.*;
import java.util.*;
import javax.swing.*;

public class TravelData {
	String[] locale;
	String[] country;
	String[] departure;
	String[] arrival;
	String[] place;
	Double[] price;
	String[] currency;
	
	public TravelData(File dataDir) {
		// TODO Auto-generated constructor stub
		File[] files=dataDir.listFiles();
		int number = files.length;
		int i = 0;
		while(number>0){
			Scanner sc;
			try {
				sc = new Scanner(files[i]);
				while(sc.hasNext()){
					sc.useDelimiter("\t|\n");
					locale[i]=sc.next();
					//tu wstawić ustawienia lokalizacji
					country[i]=sc.next();
					departure[i]=sc.next();
					arrival[i]=sc.next();
					place[i]=sc.next();
					price[i]=Double.parseDouble(sc.next());
					currency[i]=sc.next();
					i++;
					number--;
				}
				sc.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println("No files in data folder: "+e);
				e.printStackTrace();
			}
		}
	}

	public List<String> getOffersDescriptionsList(String loc, String dateFormat){
		List<String> list;
		int number = locale.length;
		Locale input;
		
		Locale[] loc1 = Locale.getAvailableLocales();
	    Map map = new HashMap();
	    String kraj;

	    // Dodanie dostępnych lokalizacji do mapy
	    // klucz: nazwa kraju po poslku, wartośc - lokealizacja
	    for (int i=0; i<loc1.length; i++) {
	      String countryCode = loc1[i].getCountry();  // kod kraju
	      if (countryCode.equals("")) continue;
	      kraj =  loc1[i].getDisplayCountry();
	      map.put(kraj, loc1[i]);
	    }

	    String msg = "Podaj kraj";
	    String in = "";
	    while((kraj = JOptionPane.showInputDialog(msg)) != null ) {
	      // Pobieramy lokalizację dla podanego kraju
	      Locale savedLoc = (Locale) map.get(kraj);
	      if (savedLoc == null) continue;
	      msg = "Podaj kody języków, rozdzielone spacjami";
	      while((in = JOptionPane.showInputDialog(null, msg, in)) != null ) {
	        StringTokenizer st = new StringTokenizer(in);
	        if (st.countTokens() == 0) continue;
	        String rep = "Nazwa kraju " + kraj + ":\n";

	        // Dla kolejnych kodów języków
	        // uzyskujemy nazwę kraju w języku odpowiadającym
	        // lokalizacji związanej z kodem jęsyka
	        while(st.hasMoreTokens()) {
	          Locale lang = new Locale(st.nextToken());
	          rep += lang.getDisplayLanguage() + "   =   " +
	                 savedLoc.getDisplayCountry(lang) + "\n";
	        }
	      JOptionPane.showMessageDialog(null,rep);
	      }
	      msg = "Podaj kraj";
	    }
	    
	    
		for(int i=0;i<number;i++){
			if(locale[i].length()==2) input = new Locale (locale[i].substring(0, 1));
			else input = new Locale(locale[i].substring(0, 1), locale[i].substring(3, 4));
			
		}
		return null;
	}
}
