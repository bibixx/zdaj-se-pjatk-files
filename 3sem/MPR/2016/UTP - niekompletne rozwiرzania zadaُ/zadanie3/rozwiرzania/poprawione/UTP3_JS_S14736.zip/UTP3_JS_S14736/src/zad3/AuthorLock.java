package zad3;

public class AuthorLock extends Thread {

}
