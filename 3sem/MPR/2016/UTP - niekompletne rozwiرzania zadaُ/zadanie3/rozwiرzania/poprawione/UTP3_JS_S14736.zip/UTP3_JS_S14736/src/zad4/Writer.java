/**
 *
 *  @author Jabłoński Sławomir S14736
 *
 */

package zad4;


public class Writer extends Thread implements Runnable {
	Teksty txtArea=new Teksty();

	public Writer(Author autor) {
		txtArea.txt=new String[autor.txtArea.txt.length];
		for(int i=0;i<autor.txtArea.txt.length;i++) txtArea.txt[i]=autor.txtArea.txt[i];
	}
	public void run() {
	    String[] txt = txtArea.getTextToWrite();
	    while(txt != null) {
	      System.out.println("-> " + txt);
	      txt = txtArea.getTextToWrite();
	      }
	  }
}
