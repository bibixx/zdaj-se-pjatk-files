/**
 *
 *  @author Jabłoński Sławomir S14736
 *
 */

package zad4;


public class Author extends Thread implements Runnable  {
	Teksty txtArea = new Teksty();

	  public Author(String[] args) {
		  txtArea.txt=new String[args.length];
		  for(int i=0;i<args.length;i++) txtArea.txt[i]=args[i];
	}

	public void run() {

	    for (int i=0; i<txtArea.txt.length; i++) {
	      try {
	        sleep((int)(Math.random() * 1000));
	      } catch(InterruptedException exc) { }
	      txtArea.setTextToWrite(txtArea.txt);
	    }
	  }

}  
