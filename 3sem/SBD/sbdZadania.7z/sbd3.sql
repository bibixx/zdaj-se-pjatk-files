SET IMPLICIT_TRANSACTIONS Off -- wy��czenie automatycznego zatwierdzania
CREATE TABLE Osoba (Id INT, Nazwisko VARCHAR(50))
COMMIT
INSERT INTO Osoba VALUES (1, 'Lenkiewicz')
INSERT INTO Osoba VALUES (2, 'Kowalski')
SELECT * FROM Osoba   -- powinni�my zobaczy� dwie osoby 
ROLLBACK
SELECT * FROM Osoba   -- powinni�my zobaczy� pust� tabel�
INSERT INTO Osoba VALUES (3, 'Iksi�sjjki')
COMMIT
SELECT * FROM Osoba   -- powinni�my zobaczy� jedn� osob�
begin transaction T
	CREATE TABLE Osoba (Id INT, Nazwisko VARCHAR(50))
	INSERT INTO Osoba VALUES (1, 'Lenkiewicz')
	INSERT INTO Osoba VALUES (2, 'Kowalski')

	save tran T1

		save tran T2
			INSERT INTO Osoba VALUES (3, 'Iksi�ski')
			SELECT * FROM Osoba   -- powinni�my zobaczy� wszystko
		ROLLBACK tran T2

		save tran T3
			INSERT INTO Osoba VALUES (33, 'aaa')
			INSERT INTO Osoba VALUES (44, 'bbb')
			INSERT INTO Osoba VALUES (55, 'ccc')
			SELECT * FROM Osoba   -- powinni�my zobaczy� wszystko
		ROLLBACK tran T3

		SELECT * FROM Osoba   -- powinni�my zobaczy� wszystko

		delete from osoba;
		SELECT * FROM Osoba   -- powinni�my zobaczy� nic
	ROLLBACK tran T1

	SELECT * FROM Osoba   -- powinni�my zobaczy� nic
ROLLBACK transaction T
SELECT * FROM Osoba   -- powinni�my zobaczy� wszystko
COMMIT transaction a1

drop TABLE Osoba 