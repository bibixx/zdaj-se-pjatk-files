--	@kNz : nazwa kategorii
--	@gIm : 	imie klienta
--	@gNa :	nazwisko klienta
--	@dSt :	data od
--	@dKo :	data do
create proc rezerwuj( 
	@kNz as varchar(20), 
	@gIm as varchar(20), 
	@gNa as varchar(30), 
	@dSt as dateTime,
	@dKo as dateTime 
	)
as
	declare @kId as int
	select @kId = idKategoria from kategoria where Nazwa = @kNz
	
	if @kId is null 
		begin 
			RAISERROR('Nie znaleziono kategorii',5,1) 
		end
	else
		begin
	
		declare @gId as int
		select @gId = max(idGosc) from Gosc where imie = @gIm and nazwisko = @gNa
	
		if @gId is null
		begin	-- dodajemy goscia
			insert into Gosc([Imie],[Nazwisko],[Procent_rabatu]) values (@gIm,@gNa,0)
			select @gId = @@identity
		end
	
		declare @pId as int -- id pokoju
		select @pId = min(p.NrPokoju) from Pokoj p where idKategoria = @kId
	/*	and not exists ( -- sprawdzanie czy jest jakis wolny...
			select * from rezerwacja where 
				nrpokoju = p.nrpokoju and ( 
					@dSt between dataOd and dataDo or 
					@dKo between dataOd and dataDo  ) 
			)

		if @pId is null begin RAISERROR('Nie znaleziono pokoju',5,1) end
	*/
		INSERT INTO [dbo].[Rezerwacja]
			([DataOd],[DataDo],[IdGosc],[NrPokoju],[Zaplacona])
		VALUES
			(@dSt,@dKo,@gId,@pId,0)
	end
go
/*
-- test: zla kat.
execute rezerwuj 'zlaKategoria', '???', '???', '11-11-2011', '12-11-2011'
select top 1 * from rezerwacja order by [IdRezerwacja] desc
go
-- test: dodawania klienta/ponowna rezerwacja
--	kategorie:
--	1	Turystyczny	30.00
--	2	Standardowy	60.00
--	3	Luksusowy	120.00
--
execute rezerwuj 'Turystyczny', 'Zbigniew', 'Zielony', '11-11-2011', '22-11-2011'
select top 1 * from rezerwacja order by [IdRezerwacja] desc
go
execute rezerwuj 'Luksusowy', 'Zbigniew', 'Zielony', '11-12-2011', '22-12-2011'
select top 1 * from rezerwacja order by [IdRezerwacja] desc
go

drop proc rezerwuj
go
*/
