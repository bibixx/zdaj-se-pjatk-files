set serveroutput on;
--	Temat 11 � PL/SQL, wyzwalacze
--	1.	Utw�rz wyzwalacz, kt�ry nie pozwoli 
--	usun�� rekordu z tabeli Emp.

	CREATE OR REPLACE TRIGGER A
	BEFORE DELETE
	ON emp
	BEGIN
      RAISE_APPLICATION_ERROR (
         num=> -20107,
         msg=> 'Nie wooolno');
	END A;
/
--	2.	Utw�rz wyzwalacz, kt�ry przy wstawianiu lub modyfikowaniu 
--	danych w tabeli Emp sprawdzi czy nowe zarobki (wstawiane lub 
--	modyfikowane) s� wi�ksze ni� 1000. W przeciwnym przypadku 
--	wyzwalacz powinien zg�osi� b��d i nie dopu�ci� do wstawienia 
--	rekordu. Uwaga:  Ten sam efekt mo�na uzyska� �atwiej przy 
--	pomocy wi�z�w sp�jno�ci typu CHECK. U�yjmy wyzwalacza w celach 
--	treningowych.

	CREATE OR REPLACE TRIGGER B
	BEFORE 	INSERT OR
			UPDATE OF SAL
	ON emp
	FOR EACH ROW
	BEGIN
		if	:NEW.sal < 1000 THEN
			RAISE_APPLICATION_ERROR (
			num=> -20107,
			msg=> 'Za maa�o');
		END IF;
	END B;
/
--	3.	Utw�rz tabel� budzet:
--	
	DROP TABLE budzet;
  CREATE TABLE budzet (wartosc INT NOT NULL);
--	
--	W tabeli tej b�dzie przechowywana ��czna warto�� wynagrodzenia 
--	wszystkich pracownik�w. Tabela b�dzie zawsze zawiera�a jeden 
--	wiersz. Nale�y najpierw obliczy� pocz�tkow� warto�� zarobk�w:
--	
  INSERT INTO budzet (wartosc)
  SELECT SUM(sal) FROM emp;
  /
--	
--	Utw�rz wyzwalacz, kt�ry b�dzie pilnowa�, aby warto�� w tabeli 
--	budzet by�a zawsze aktualna, a wi�c przy wszystkich operacjach 
--	aktualizuj�cych tabel� emp (INSERT, UPDATE, DELETE), wyzwalacz 
--	b�dzie aktualizowa� wpis w tabeli bud�et
--	4.	Napisz jeden wyzwalacz, kt�ry:
--	�	Nie pozwoli usun�� pracownika, kt�rego pensja jest wi�ksza od 0.
--	�	Nie pozwoli zmieni� nazwiska pracownika.
--	�	Nie pozwoli wstawi� pracownika, kt�ry ju� istnieje 
--		(sprawdzaj�c po nazwisku).

create or replace
TRIGGER C
	BEFORE 	
      INSERT OR
			UPDATE OF ename OR
			UPDATE OF sal OR
      DELETE  
	ON emp
	FOR EACH ROW
  DECLARE
       maxc integer := 0;
	BEGIN

  CASE
    WHEN INSERTING THEN
    
      SELECT count(*) INTO maxc FROM emp where ename = :new.ename;
      if( maxc < 1 ) then
        DBMS_OUTPUT.PUT_LINE('Inserting');
        update budzet set wartosc = wartosc + :new.sal;
      else
      RAISE_APPLICATION_ERROR (
         num=> -20107,
         msg=> 'Duplikat');
      end if;
      
    WHEN UPDATING('ename') THEN
    
        RAISE_APPLICATION_ERROR (
           num=> -20107,
           msg=> 'Nie wooolno');
    
    WHEN UPDATING('sal') THEN
      update budzet set wartosc = wartosc + :new.sal - :old.sal;   
    WHEN DELETING THEN
    
      SELECT sal INTO maxc FROM emp where ename = :new.ename;
      if maxc < 1 then
        DBMS_OUTPUT.PUT_LINE('Deleting');   
      else
        RAISE_APPLICATION_ERROR (
           num=> -20107,
           msg=> 'Nie wooolno');
      end if;
      
  END CASE;

	END C;
/
/*
delete from emp where empno = 1;  -- nie wolno
/
insert into emp (empno,ename,sal) values (111,'zbignievv',10); -- za malo
/
insert into emp (empno,ename,sal) values (111,'KING',10000); -- duplikat
/
update emp set ename = 'aaa' where empno = 888; -- nie wolno
/
*/


--select wartosc from budzet;/  -- 29340
--insert into emp (empno,ename,sal) values (111,'AND�EJ',10000);/ -- ok?
select * from budzet;/  -- 39340

update emp set sal = 10000 where empno = 111; -- ok?

--	5.	Napisz wyzwalacz, kt�ry:
--	�	Nie pozwoli zmniejsza� pensji.
--	�	Nie pozwoli usuwa� pracownik�w.
/
drop TRIGGER C;
/
set serveroutput on;
create or replace
TRIGGER D
	BEFORE 	
			UPDATE OF sal OR
      DELETE  
	ON emp
	FOR EACH ROW
  BEGIN
  dbms_output.put_line ( 'Trigger D' );
    CASE
      WHEN UPDATING THEN
      dbms_output.put_line ( 'Trigger D UPD' );
        if  :old.sal > :new.sal THEN
          RAISE_APPLICATION_ERROR (
             num=> -20107,
             msg=> 'Nie wooolno');
        END IF;
      WHEN DELETING THEN
      dbms_output.put_line ( 'Trigger D DEL' );
          RAISE_APPLICATION_ERROR (
             num=> -20107,
             msg=> 'Nie wooolno');
    END CASE;

dbms_output.put_line ( 'Trigger D END' );
	END D;
/

update emp set sal = 3000 where empno = 111; -- nie wolno
delete from emp where empno = 111;

