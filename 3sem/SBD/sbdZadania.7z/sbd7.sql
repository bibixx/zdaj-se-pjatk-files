--	Temat 8 � Transact SQL, wyzwalacze
--		1.	Utw�rz wyzwalacz, kt�ry nie pozwoli usun�� rekordu z tabeli Emp.
GO
CREATE TRIGGER derp 
   ON  emp
   instead of DELETE
AS 
BEGIN
	print('nie!')
END
GO

drop TRIGGER derp 
GO
--		2.	Utw�rz wyzwalacz, kt�ry przy wstawianiu pracownika do tabeli Emp, 
--			wstawi prowizj� r�wn� 0, je�li prowizja by�a pusta. 
--			Uwaga: Zadanie da si� wykona� bez u�ycia wyzwalaczy przy pomocy DEFAULT. 
--			U�yjmy jednak wyzwalacza w celach treningowych.
GO
CREATE TRIGGER derp 
   ON  emp
   FOR INSERT
AS 
BEGIN
	update emp set COMM = 0 where empno in (select empno from inserted) and COMM is null;
END
GO

INSERT INTO [dbo].[EMP]
           ([EMPNO],[ENAME],[JOB],[MGR],[HIREDATE],[SAL],[COMM],[DEPTNO])
     VALUES(999,'Andrzej','Andrzej',null,getDate(),10,null,10)
GO

SELECT * from emp where EMPNO = 999;
delete from emp where EMPNO = 999;
drop TRIGGER derp 
GO
--		3.	Utw�rz wyzwalacz, kt�ry przy wstawianiu lub modyfikowaniu danych w tabeli Emp sprawdzi czy nowe 
--			zarobki (wstawiane lub modyfikowane) s� wi�ksze ni� 1000. W przeciwnym przypadku wyzwalacz 
--			powinien zg�osi� b��d i nie dopu�ci� do wstawienia rekordu. 
--			Uwaga:  Ten sam efekt mo�na uzyska� �atwiej przy pomocy wi�z�w sp�jno�ci typu CHECK. 
--			U�yjmy wyzwalacza w celach treningowych.
GO
CREATE TRIGGER derp
   ON emp
   instead of INSERT
--   FOR INSERT
AS 
BEGIN
	declare @sal as int;
	select @sal = min(sal) from inserted;
	
	if @sal < 1000
	begin
		declare @err as varchar(max)
		set @err = 'za ma�o p�acisz ' + cast( (select count(*) from inserted where sal < 1000) as varchar) + ' osobom' 
		RAISERROR(  @err ,5,1)
		--rollback
	end 
	
	
	insert into emp([EMPNO],[ENAME],[JOB],[MGR],[HIREDATE],[SAL],[COMM],[DEPTNO]) 
		( select [EMPNO],[ENAME],[JOB],[MGR],[HIREDATE],[SAL],[COMM],[DEPTNO] from inserted where sal > 1000 )
	
	
END
GO

INSERT INTO [dbo].[EMP]
           ([EMPNO],[ENAME],[JOB],[MGR],[HIREDATE],[SAL],[COMM],[DEPTNO])
     VALUES
           (999,'Andrzej','Andrzej',null,getDate(),1100,null,10),
           (998,'Maciej','Andrzej',null,getDate(),10,null,10)
GO

SELECT * from emp where EMPNO in (999,998);
delete from emp where EMPNO in (999,998);
drop TRIGGER derp 
GO

--		4.	Utw�rz tabel� budzet:
--	
--		CREATE TABLE budzet (wartosc INT NOT NULL)
--	
--		W tabeli tej b�dzie przechowywana ��czna warto�� wynagrodzenia wszystkich pracownik�w. 
--		Tabela b�dzie zawsze zawiera�a jeden wiersz. Nale�y najpierw obliczy� pocz�tkow� warto�� zarobk�w:
--	
--		INSERT INTO budzet (wartosc)
--		SELECT SUM(sal) FROM emp
--	
--		Utw�rz wyzwalacz, kt�ry b�dzie pilnowa�, aby warto�� w tabeli budzet by�a zawsze aktualna, 
--		a wi�c przy wszystkich operacjach aktualizuj�cych tabel� emp (INSERT, UPDATE, DELETE), 
--		wyzwalacz b�dzie aktualizowa� wpis w tabeli bud�et
go
CREATE TABLE budzet (wartosc INT NOT NULL)
INSERT INTO budzet (wartosc) SELECT SUM(sal) FROM emp

GO
CREATE TRIGGER herp 
   ON  emp
   FOR INSERT
AS 
BEGIN
	update budzet set wartosc = wartosc + ( select sum(sal) from inserted )
END
GO

INSERT INTO [dbo].[EMP]
           ([EMPNO],[ENAME],[JOB],[MGR],[HIREDATE],[SAL],[COMM],[DEPTNO])
     VALUES(999,'Andrzej','Andrzej',null,getDate(),10,null,10)
GO

CREATE TRIGGER derp 
   ON  emp
   FOR UPDATE
AS 
BEGIN

	declare k cursor for select empno,ename,sal from inserted
	declare d cursor for select empno,ename,sal from deleted
	
	declare @a int, @b varchar(11), @c int
	declare @aa int, @bb varchar(11), @cc int

	open k
	fetch next from k into @a,@b,@c

	open d
	fetch next from d into @aa,@bb,@cc

	while @@FETCH_STATUS = 0
	begin
		print( cast( @aa as varchar ) + ' ' + @bb + ' ' + cast(@cc as varchar) + ' -> '
		+ cast( @a as varchar ) + ' ' + @b + ' ' + cast(@c as varchar) +' :'+ cast((@c - @cc) as varchar) )

		update budzet set wartosc = wartosc + @cc - @c

		fetch next from k into @a,@b,@c
		fetch next from d into @aa,@bb,@cc
	end
	close k
	deallocate k

	close d
	deallocate d

END
GO

update [dbo].[EMP] set [SAL] = [SAL] + 110 where empno = 999;
GO

drop TRIGGER derp 
GO


drop TABLE budzet
go
--		5.	Napisz wyzwalacz, kt�ry nie pozwoli modyfikowa� nazw dzia��w w tabeli dept. 
--			Powinno by� jednak mo�liwe wstawianie nowych dzia��w.

CREATE TRIGGER derp 
   ON  dept
   FOR UPDATE
AS 
BEGIN
	declare @n as int
	select @n = count(*) from inserted i join deleted d on i.deptno = d.DEPTNO where i.DNAME <> d.DNAME

	if @n > 0
	begin
		RAISERROR( 'err' ,5,1)
		rollback
	end

END

update dept set dname = 'OPS2' where deptno = 111

drop TRIGGER derp 
GO


--		6.	Napisz jeden wyzwalacz, kt�ry:
--			�	Nie pozwoli usun�� pracownika, kt�rego pensja jest wi�ksza od 0.
--			�	Nie pozwoli zmieni� nazwiska pracownika.
--			�	Nie pozwoli wstawi� pracownika, kt�ry ju� istnieje (sprawdzaj�c po nazwisku).

--		7.	Napisz wyzwalacz, kt�ry:
--			�	Nie pozwoli zmniejsza� pensji.
--			�	Nie pozwoli usuwa� pracownik�w.

