-- Temat 2 � powt�rka z zapyta� SQL
-- 1.	Wypisz wszystkich klient�w hotelu w kolejno�ci alfabetycznej (sortuj�c po nazwisku i imieniu).
select * from Gosc order by nazwisko,imie;
-- 2.	Podaj bez powt�rze� wszystkie wyst�puj�ce w tabeli warto�ci rabatu posortowane malej�co.
select distinct [Procent_rabatu] from Gosc order by [Procent_rabatu] desc;
-- 3.	Wypisz wszystkie rezerwacje Ferdynanda Kiepskiego.
select *  
from Gosc g 
join [dbo].[Rezerwacja] r on r.IdGosc = g.IdGosc 
where lower(imie) = 'ferdynand' and lower(nazwisko)='kiepski';
-- 4.	Wypisz rezerwacje z 2008 roku klient�w, kt�rych nazwisko zaczyna si� na liter� �K� lub �L�. Podaj imi�, nazwisko oraz numer pokoju.
select imie,nazwisko,[NrPokoju], cast(DataOd as varchar)+ ' - ' + cast(DataDo as varchar)
from Gosc g 
join [dbo].[Rezerwacja] r on r.IdGosc = g.IdGosc 
where (nazwisko like 'k%' or nazwisko like 'l%') 
	and (r.DataOd between '2008-01-01' and '2008-12-31 23:59:59'
	or r.DataDo between '2008-01-01' and '2008-12-31 23:59:59');
-- 5.	Wypisz numery pokoi wynajmowanych przez Andrzeja Nowaka.
select r.[NrPokoju]
from Gosc g 
join [dbo].[Rezerwacja] r on r.IdGosc = g.IdGosc 
where lower(imie) = 'andrzej' and lower(nazwisko)='nowak';
-- 6.	Podaj liczb� pokoi w ka�dej kategorii.
select idKategoria, count(*) as ilosc from Pokoj group by IdKategoria;
-- 7.	Podaj dane klient�w oraz ich rezerwacji tak, aby klient zosta� wypisany nawet, je�li nigdy nie rezerwowa� pokoju.
select imie,nazwisko, cast(DataOd as varchar)+ ' - ' + cast(DataDo as varchar)
from Gosc g 
left join [dbo].[Rezerwacja] r on r.IdGosc = g.IdGosc 
-- 8.	Wypisz klient�w, kt�rzy spali w pokoju 101 i zap�acili.
select distinct imie,nazwisko
from Gosc g 
join [dbo].[Rezerwacja] r on r.IdGosc = g.IdGosc 
where r.[NrPokoju] = '101' and [Zaplacona] = 1
-- 9.	Wypisz dane w postaci: Nazwisko i imi� (w jednej kolumnie), DataOd, DataDo, NrPokoju, nazwa kategorii.
select nazwisko+' '+imie, DataOd, DataDo, NrPokoju
from Gosc g 
left join [dbo].[Rezerwacja] r on r.IdGosc = g.IdGosc 
-- 10.	Wypisz w jednym zapytaniu go�ci, 
--			kt�rzy zarezerwowali pok�j 101, maj�cych nazwisko na liter� �K� 
--			oraz tych, 
--			kt�rzy zarezerwowali pok�j 201, ale maj�cych nazwisko na liter� �P�.
select imie,nazwisko,[NrPokoju], cast(DataOd as varchar)+ ' - ' + cast(DataDo as varchar)
from Gosc g 
join [dbo].[Rezerwacja] r on r.IdGosc = g.IdGosc 
where 
	(NrPokoju = '101' and nazwisko like 'k%') 
	or
	(NrPokoju = '201' and not nazwisko like 'p%') 
-- 11.	Wypisz dane klient�w, kt�rzy nie maj� rabatu (NULL) i wynaj�li jakikolwiek pok�j.
select imie,nazwisko,[NrPokoju], cast(DataOd as varchar)+ ' - ' + cast(DataDo as varchar)
from Gosc g 
join [dbo].[Rezerwacja] r on r.IdGosc = g.IdGosc 
where g.Procent_rabatu is null
-- 12.	Wypisz dane wszystkich rezerwacji pokoi: 101, 102, 103, 104. Podaj imi�, nazwisko i dat�.
select imie,nazwisko,[NrPokoju], cast(DataOd as varchar)+ ' - ' + cast(DataDo as varchar)
from Gosc g 
join [dbo].[Rezerwacja] r on r.IdGosc = g.IdGosc 
where NrPokoju in (101, 102, 103, 104)
-- 13.	Podaj kategorie z przedzia�u cenowego <10,100>.
select * from Kategoria where cena between 9 and 101
-- 14.	Wypisz imiona i nazwiska (w jednej kolumnie) klient�w, kt�rzy zalegaj� z p�atno�ciami (pole �zaplacona� = 0). 
--		Kolumnie z danymi klienta nadaj etykiet� �d�u�nik�. 
--		Posortuj w pierwszej kolejno�ci po nazwiskach, a w drugiej po imionach.
select distinct imie+' '+nazwisko as 'd�u�nik' 
from ( select top 9999 imie,nazwisko
from Gosc g join [dbo].[Rezerwacja] r on r.IdGosc = g.IdGosc 
where r.Zaplacona is not null and r.Zaplacona = 0
order by nazwisko,imie ) as t
-- 15.	Podaj, ile jest ��cznie rezerwacji zap�aconych.
select sum( coalesce(Zaplacona,0) ) from rezerwacja
select count(*) from rezerwacja where Zaplacona = 1
-- 16.	Wypisz, ile rezerwacji zosta�o z�o�onych w 2009 roku.
select count(*) from rezerwacja 
where DataOd between '2009-01-01' and '2009-12-31 23:59:59'
-- 17.	Podaj liczb� pokoi w ka�dej kategorii.
select IdKategoria, count(*) ile from pokoj group by IdKategoria
-- 18.	Wstaw do bazy danych nowego go�cia (wymy�l dowolne dane) oraz rezerwacj� dla niego.
INSERT INTO [dbo].[Gosc] ([IdGosc],[Imie],[Nazwisko],[Procent_rabatu]) VALUES (99,'Zbig','Zielony',99)
INSERT INTO [dbo].[Rezerwacja] values (99,'2009-05-05','2009-08-05',99,101,0)
-- 19.	Zmie� dowolnie dat� zako�czenia wybranej rezerwacji.
update [dbo].[Rezerwacja] set dataDo = '2009-08-15' where IdRezerwacja = 99
-- 20.	Usu� wybran� rezerwacj�.
delete from Rezerwacja where IdRezerwacja = 99;


