-- 1.	Wypisz go�ci wraz z liczb� dokonanych przez nich rezerwacji. 
-- 		Nie wypisuj informacji o go�ciach, kt�rzy z�o�yli tylko jedn� rezerwacj�.
select imie,nazwisko,c from Gosc g, (
	select [IdGosc], count(*) as c from [dbo].[Rezerwacja] group by [IdGosc] having count(*) > 1
) as cnt 
where g.IdGosc = cnt.IdGosc;

-- 2.	Wypisz pokoje o najwi�kszej liczbie miejsc.
select * from pokoj where Liczba_miejsc >= all( select Liczba_miejsc from pokoj )
select * from pokoj where Liczba_miejsc = ( select max(Liczba_miejsc) from pokoj )

-- 3.	Dla ka�dego pokoju wypisz, kiedy by� ostatnio wynajmowany.
select NrPokoju,dataOd from rezerwacja r where dataOd > any( select dataOd from Rezerwacja where NrPokoju=r.NrPokoju )

-- 4.	Wypisz liczb� rezerwacji dla ka�dego pokoju. 
-- 		Nie wypisuj pokoi, kt�re by�y rezerwowane tylko raz oraz pokoi z kategorii �luksusowy�.
select r.nrPokoju, ( select count(*) from rezerwacja r2 where r2.NrPokoju = p.NrPokoju) as c
from Rezerwacja r, pokoj p, kategoria k
where ( r.NrPokoju = p.NrPokoju and p.idkategoria = k.IdKategoria )
and lower(k.Nazwa) <> 'luksusowy' and
( select count(*) from rezerwacja r2 where r2.NrPokoju = p.NrPokoju ) > 1

-- 5.	Podaj dane (imi�, nazwisko, numer pokoju) najnowszej rezerwacji.
select imie,nazwisko,NrPokoju from gosc g, rezerwacja r where r.IdGosc = g.IdGosc 
and r.DataOd = ( select max(dataod) from rezerwacja )
and r.DataDo = ( select max(datado) from rezerwacja )

-- 6.	Wypisz dane pokoju, kt�ry nie by� nigdy wynajmowany.
select * from pokoj where not exists( 
	select IdRezerwacja from Rezerwacja where NrPokoju = Pokoj.NrPokoju 
)

-- 7.	U�ywaj�c operatora NOT EXISTS wypisz go�ci, kt�rzy nigdy nie wynajmowali pokoju luksusowego.
select * from gosc g where not exists ( 
	select idrezerwacja from rezerwacja r, kategoria k, pokoj p 
	where r.NrPokoju = p.NrPokoju and p.idkategoria = k.idkategoria 
	and r.idgosc = g.idgosc
	and not lower(k.Nazwa) = 'luksusowy'
)

-- 8.	W jednym zapytaniu wypisz go�ci, kt�rzy wynajmowali pok�j 101 
-- 		(imi�, nazwisko, data rezerwacji) 
-- 		oraz go�ci, kt�rzy nigdy nie wynajmowali �adnego pokoju (imi�, nazwisko, �brak�).
select imie,nazwisko, coalesce( cast( r.NrPokoju as varchar) ,'brak' )  from gosc g
left join rezerwacja r on r.idgosc = g.idgosc
where r.NrPokoju = 101 or r.NrPokoju is null
/*
select imie,nazwisko from gosc g where (
	exists ( select idrezerwacja from rezerwacja r where g.idgosc = r.idgosc and r.NrPokoju = 101 )
	or
	not exists( select idrezerwacja from rezerwacja r where g.idgosc = r.idgosc )
)
*/
-- 9.	Znajd� kategori�, w kt�rej liczba pokoi jest najwi�ksza.
select k.idkategoria, count(*) 
from kategoria k, pokoj p 
where p.IdKategoria = k.idkategoria 
group by k.idkategoria
having count(*) > any( 
	select count(*) from kategoria k, pokoj p 
	where p.IdKategoria = k.idkategoria group by k.idkategoria 
)

-- 10.	Dla ka�dej kategorii podaj pok�j o najwi�kszej liczbie miejsc.
select p.NrPokoju, p.liczba_miejsc, k.nazwa 
from pokoj p, kategoria k 
where 	p.idkategoria = k.idkategoria 
	and p.Liczba_miejsc > any( 
		select Liczba_miejsc 
		from pokoj p2, kategoria k2 
		where 	k2.idkategoria = p2.IdKategoria 
		and 	k2.IdKategoria = k.IdKategoria
	)