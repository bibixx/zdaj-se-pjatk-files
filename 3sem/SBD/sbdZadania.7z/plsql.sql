PL/SQL

Blok PL/SQL:

DECLARE
	deklaracje
BEGIN
	instrukcje
EXCEPTION
	obs�uga wyj�tk�w
END;

Deklaracje zmiennych:

	Identyfikator TYP [NOT NULL] [:=wyra�enie];
	np.: nazwisko VARCHAR2(30) := �Kowalski�;

SELECT w PL/SQL:

SELECT wyra�enie1, wyra�enie2, ...
INTO zmienna1, zmienna2, ...
FROM ...

	Zapytanie musi zwraca� 1 wiersz.

Warunki:

IF warunek THEN
	instrukcje
ELSIF warunek THEN
	instrukcje
ELSE
	instrukcje
END IF;

W��czenie wy�wietlania komunikat�w:

	SET ServerOutput ON

Wy�wietlenie komunikatu:

	DBMS_OUTPUT.PUT_LINE(napis);

Wywo�anie b��du:

	Np. raise_application_error(-20500, �komunikat�);

Zmienne systemowe:

	SQL%ROWCOUNT		-	ilo�� zwr�conych wierszy
	SQL%FOUND		-	czy zapytanie zwr�ci�o wiersz
	SQLERRM			-	komunikat o b��dzie

Uruchomienie procedury:

	EXECUTE procedura (parametry)

Zmienne typu wiersza i kolumny:

zmienna emp.ename%type		- zmienna tego samego typu co ename
zmienna emp%rowtype		- zmienna typu wierszowego

Deklaracja i u�ycie kursora:

	W DECLARE:
		CURSOR nazwa IS SELECT ...
	Po BEGIN:
		OPEN nazwa;				-	otwarcie kursora
		FETCH nazwa INTO zmienna;	-	�ci�gni�cie kolejnego wiersza
		CLOSE nazwa;			-	zamkni�cie kursora

	Kursor�w u�ywamy zwykle w p�tli np.:
		LOOP
			FETCH nazwa INTO zmienna;
			EXIT WHEN nazwa%NOTFOUND;
			...
		END LOOP;

Atrybuty kursora:

	nazwa%FOUND		-	ostatnia instrukcja FETCH zwr�ci�a wiersz
	nazwa%NOTFOUND	-	ostatnia instrukcja FETCH nie zwr�ci�a wiersza
	nazwa%ROWCOUNT	-	ilo�� zwr�conych dotychczas wierszy
	nazwa%ISOPEN		-	okre�la, czy kursor jest otwarty

Procedury:

	CREATE [OR REPLACE] PROCEDURE nazwa (par [IN/OUT/INOUT] TYP, ...) AS
		deklaracje
	BEGIN
		kod procedury
	END;

Funkcje:

	CREATE [OR REPLACE] FUNCTION nazwa (par [IN/OUT/INOUT] TYP, ...)
	RETURN TYP AS
		deklaracje
	BEGIN
		kod funkcji
		RETURN wyra�enie;
	END;

Wyzwalacze:

	CREATE [OR REPLACE] TRIGGER nazwa
	{BEFORE / AFTER} specyfikacja instrukcji
	ON tabela
	[FOR EACH ROW]
	blok PL/SQL

Specyfikacje instrukcji:
	INSERT, DELETE, UPDATE
	Mo�na je ��czy� np. BEFORE INSERT OR UPDATE
Dla UPDATE mo�na okre�li� pola, kt�rych modyfikowanie spowoduje uruchomienie triggera np. UPDATE OF pole1, pole2

Odwo�anie do starej/nowej warto�ci w wyzwalaczu:

	:OLD.pole
	:NEW.pole

Zmienne logiczne okre�laj�ce, co spowodowa�o uruchomienie wyzwalacza:

	UPDATING, INSERTING, DELETING

Tworzenie sekwensji:

	CREATE SEQUENCE nazwa_sekwencji
	[INCREMENT BY k]
	[START WITH n]

Bie��ca i kolejna warto�ci sekwencji:

	nazwa_sekwencji.currval
	nazwa_sekwencji.nextval
