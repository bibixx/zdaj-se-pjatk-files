--	Temat 10 � PL/SQL � kursory

--	1.	Przy pomocy kursora przejrzyj wszystkich pracownik�w i zmodyfikuj wynagrodzenia tak, 
--		aby osoby zarabiaj�ce mniej ni� 1000 mia�y zwi�kszone wynagrodzenie o 10%, natomiast 
--		osoby zarabiaj�ce powy�ej 1500 mia�y zmniejszone wynagrodzenie o 10%. Wypisz na ekran 
--		ka�d� wprowadzon� zmian�.

set serveroutput on;

DECLARE
--	 CURSOR emp_c IS SELECT empno,ename,sal from emp;
--   emp_ename emp.ename%type;
--   emp_sal emp.sal%type;
--   emp_empno emp.empno%type;


	 CURSOR emp_c IS SELECT * from emp;
   emp_row emp%rowtype;
   
   output VARCHAR2(25);
BEGIN   
		OPEN emp_c;
		
    
		LOOP
			--FETCH emp_c INTO emp_empno,emp_ename,emp_sal;
			FETCH emp_c INTO emp_row;
			EXIT WHEN emp_c%NOTFOUND;
      
--      output := emp_ename || ':' || emp_sal;
--      dbms_output.put_line ( output );

      if emp_row.sal < 1000 then
        update emp set sal = sal * 1.1 where empno = emp_row.empno;
        output := emp_row.ename || ':' || emp_row.sal || ' -> ' || (emp_row.sal*1.1);
      elsif emp_row.sal > 1500 then
        update emp set sal = sal * 0.9 where empno = emp_row.empno;
        output := emp_row.ename || ':' || emp_row.sal || ' -> ' || (emp_row.sal*0.9);
      end if;

      
      dbms_output.put_line ( output );
		END LOOP;
    
		CLOSE emp_c;
END;

--	2.	Przer�b kod z zadania 1 na procedur� tak, aby warto�ci zarobk�w (1000 i 1500) nie 
--		by�y sta�e, tylko by�y parametrami procedury.

create or replace
PROCEDURE ADJSAL( minsal IN integer, maxsal IN integer ) AS

	 CURSOR emp_c IS SELECT * from emp;
   emp_row emp%rowtype;
   
   output VARCHAR2(25);
BEGIN   
		OPEN emp_c;
		
    
		LOOP
			FETCH emp_c INTO emp_row;
			EXIT WHEN emp_c%NOTFOUND;
      
      if emp_row.sal < minsal then
        update emp set sal = sal * 1.1 where empno = emp_row.empno;
        output := emp_row.ename || ':' || emp_row.sal || ' -> ' || (emp_row.sal*1.1);
      elsif emp_row.sal > maxsal then
        update emp set sal = sal * 0.9 where empno = emp_row.empno;
        output := emp_row.ename || ':' || emp_row.sal || ' -> ' || (emp_row.sal*0.9);
      end if;

      
      dbms_output.put_line ( output );
		END LOOP;
    
		CLOSE emp_c;

END ADJSAL;

execute adjsal( 500, 2000);

--	3.	W procedurze sprawd� �redni� warto�� zarobk�w z tabeli EMP z dzia�u okre�lonego 
--		parametrem procedury. Nast�pnie nale�y da� prowizj� (comm) tym pracownikom tego 
--		dzia�u, kt�rzy zarabiaj� poni�ej �redniej. Prowizja powinna wynosi� 5% ich 
--		miesi�cznego wynagrodzenia.

create or replace
PROCEDURE ADJCOM( deptno IN integer ) AS

	 CURSOR emp_c IS SELECT * from emp where deptno = deptno and sal < ( select avg(sal) from emp where deptno = deptno );
   emp_row emp%rowtype;
   
   output VARCHAR2(25);
BEGIN   
		OPEN emp_c;
		

		LOOP
			FETCH emp_c INTO emp_row;
			EXIT WHEN emp_c%NOTFOUND;
      
      update emp set comm = coalesce(comm,0) + 0.05 * sal where empno = emp_row.empno;
      output := emp_row.ename || ':' || coalesce(emp_row.comm,0) || ' -> ' || (  coalesce(emp_row.comm,0) + 0.05 * emp_row.sal);
      
      dbms_output.put_line ( output );
		END LOOP;
    
		CLOSE emp_c;

END ADJCOM;

execute adjcom(10);

--	4.	(bez kursora) Utw�rz tabel� Magazyn (IdPozycji, Nazwa, Ilosc) zawieraj�c� ilo�ci 
--		poszczeg�lnych towar�w w magazynie i wstaw do niej kilka przyk�adowych rekord�w.

CREATE TABLE MAG
       (IDP NUMBER(4) NOT NULL,
        PN VARCHAR2(40),
        PC NUMBER(7, 2)
        );
        
DELETE FROM MAG;        
INSERT INTO MAG VALUES (1,'GRUSZKI',2);        
INSERT INTO MAG VALUES (2,'BETONIARKI',200);        
INSERT INTO MAG VALUES (3,'KRASNALE OGRODOWE',4);        
INSERT INTO MAG VALUES (4,'POMPY DO BETONU',20);        
INSERT INTO MAG VALUES (5,'WIADRA',100);    
INSERT INTO MAG VALUES (6,'KOSTKI MAS�A',250);      
INSERT INTO MAG VALUES (7,'WORKI Z PIASKIEM',250);   

--		W bloku Transact-SQL sprawd�, kt�rego artyku�u jest najwi�cej w magazynie i zmniejsz 
--		ilo�� tego artyku�u o 5 (je�li stan jest wi�kszy lub r�wny 5, w przeciwnym wypadku 
--		zg�o� b��d).

DECLARE
	 CURSOR mag_c IS SELECT * from mag;
   mag_row mag%rowtype;
   
   maxc integer := 0;
   maxid integer := 0;
   
   output VARCHAR2(45);
BEGIN   
		OPEN mag_c;
		
		LOOP
			FETCH mag_c INTO mag_row;
			EXIT WHEN mag_c%NOTFOUND;

      if maxc < mag_row.pc then
        maxc := mag_row.pc;
        maxid := mag_row.idp;
        output := mag_row.pn;
      end if;

		END LOOP;
    
    CLOSE mag_c;
    
    if maxc > 5 then
      update mag set pc = pc - 5 where idp = maxid;
      output := output || ': ' || maxc || ' -> ' || (maxc-5);
    else
      output := 'za malo towaru: ' || output ;
    end if;
    
    dbms_output.put_line ( output );
end;

--	5.	Przer�b kod z zadania 4 na procedur�, kt�rej b�dziemy mogli poda� warto��, o kt�r� 
--		zmniejszamy stan (zamiast wpisanego �na sztywno� 5).

CREATE OR REPLACE
PROCEDURE ADJMAG
( adjVal IN NUMBER DEFAULT 5
) AS
	 CURSOR mag_c IS SELECT * from mag;
   mag_row mag%rowtype;
   
   maxc integer := 0;
   maxid integer := 0;
   
   output VARCHAR2(45);
BEGIN   
		OPEN mag_c;
		
		LOOP
			FETCH mag_c INTO mag_row;
			EXIT WHEN mag_c%NOTFOUND;

      if maxc < mag_row.pc then
        maxc := mag_row.pc;
        maxid := mag_row.idp;
        output := mag_row.pn;
      end if;

		END LOOP;
    
    CLOSE mag_c;
    
    if maxc > adjVal then
      update mag set pc = pc - adjVal where idp = maxid;
      output := output || ': ' || maxc || ' -> ' || (maxc-adjVal);
    else
      output := 'za malo towaru: ' || output ;
    end if;
    
    dbms_output.put_line ( output );
END ADJMAG;

execute ADJMAG(100);