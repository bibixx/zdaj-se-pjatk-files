-- Temat 9 � PL/SQL � podstawy
-- 1.	Napisz prosty program w PL/SQL. Zadeklaruj zmienn�, przypisz na t� zmienn� 
-- 		liczb� rekord�w w tabeli EMP i wypisz uzyskany wynik w postaci 
-- 		np. "W tabeli jest 10 os�b".
set serveroutput on;

DECLARE
	 ile integer(8);   
   output VARCHAR2(25);
BEGIN
    select count(*) into ile from emp;
    output := 'W tabeli jest ' || ile || 'osob';
	  dbms_output.put_line ( output );
END;

-- 2.	Sprawd� w bloku PL/SQL liczb� pracownik�w z tabeli EMP. Je�li liczba jest mniejsza 
-- 		ni� 16, wstaw pracownika Kowalskiego i wypisz odpowiedni komunikat. W przeciwnym 
-- 		przypadku wypisz komunikat informuj�cy o tym, �e nie wstawiono danych.

DECLARE
	 ile integer(8);   
   output VARCHAR2(25);
BEGIN
    select count(*) into ile from emp;
    
    IF ile < 16 THEN
      INSERT INTO EMP VALUES
        (888, 'KOVALSKI',  'ANALYST',   666,
        TO_DATE('1982-12-09'), 3000, NULL, 20);
        
        output := 'Dodano KOVALSKI';
    ELSE
      output := 'Nie dodano KOVALSKI';
    END IF;
        
	  dbms_output.put_line ( output );
END;

-- 3.	Napisz procedur� s�u��c� do wstawiania dzia��w do tabeli Dept. Procedura b�dzie 
-- 		pobiera� jako parametry: nr_dzia�u, nazw� i lokalizacj�. Nale�y sprawdzi�, czy 
-- 		dzia� o takiej nazwie lub lokalizacji ju� istnieje. Je�eli istnieje, to nie 
-- 		wstawiamy nowego rekordu. 

create or replace
PROCEDURE WSTAW (did IN integer, n IN VARCHAR2, l IN VARCHAR2) AS
	 ile integer(8);   
   output VARCHAR2(25);
	BEGIN
    select count(*) into ile from dept where dname = n or loc = l or deptno = did;
  
    IF ile < 1 THEN
      INSERT INTO DEPT VALUES (did, n, l);
        
        output := 'Dodano '||n;
    ELSE
      output := 'Nie Dodano '||n;
    END IF;
  
		dbms_output.put_line ( output );
	END;


  execute WSTAW(10,'aaa','aaa');
  execute WSTAW(99,'aaa','aaa');


-- 4.	Napisz procedur� s�u��c� do wstawiania pracownik�w. Jako parametry podamy: 
-- 		nr dzia�u i nazwisko. Procedura powinna sprawdzi�, czy podany dzia� 
-- 		istnieje (w przeciwnym przypadku zg�aszamy b��d) i wyliczy� pracownikowi 
-- 		pensj� r�wn� minimalnemu wynagrodzeniu w jego dziale. Procedura powinna r�wnie� 
-- 		nada� EMPNO nowemu pracownikowi obliczone jako maksymalne EMPNO w tabeli + 1.

create or replace
PROCEDURE WSTAWEMP (did IN integer, n IN VARCHAR2) AS
	ile integer(8);   
	output VARCHAR2(25);
BEGIN
	select count(*) into ile from dept where deptno = did;

	IF ile > 0 THEN
	
	INSERT INTO EMP VALUES
			(
        (select max(empno)+1 from emp), 
        n,   
        'DERP', 
        NULL,
        TO_DATE('1981-11-17'), 
        (select min(sal) from emp where deptno = did), 
        NULL, 
        did
      );
	
		output := 'Dodano '||n;
	ELSE
		output := 'Nie Dodano '||n;
	END IF;

	dbms_output.put_line ( output );
END;

execute WSTAWEMP(11,'JanGrzyb');
execute WSTAWEMP(10,'JanGrzyb');

-- 5.	Utw�rz tabel� Magazyn (IdPozycji, Nazwa, Ilosc) zawieraj�c� ilo�ci 
-- 		poszczeg�lnych towar�w w magazynie i wstaw do niej kilka przyk�adowych rekord�w.
-- 		W bloku PL/SQL sprawd�, kt�rego artyku�u jest najwi�cej w magazynie i zmniejsz 
-- 		ilo�� tego artyku�u o 5 (je�li stan jest wi�kszy lub r�wny 5, w przeciwnym wypadku zg�o� b��d).

CREATE TABLE MAG
       (IDP NUMBER(4) NOT NULL,
        PN VARCHAR2(40),
        PC NUMBER(7, 2)
        );
        
DELETE FROM MAG;        
INSERT INTO MAG VALUES (1,'GRUSZKI',2);        
INSERT INTO MAG VALUES (2,'BETONIARKI',200);        
INSERT INTO MAG VALUES (3,'KRASNALE OGRODOWE',4);        
INSERT INTO MAG VALUES (4,'POMPY DO BETONU',20);        
INSERT INTO MAG VALUES (5,'WIADRA',100);    
INSERT INTO MAG VALUES (6,'KOSTKI MAS�A',250);      
INSERT INTO MAG VALUES (7,'WORKI Z PIASKIEM',250);      

DECLARE
	 ile integer(8);   
	 mag_idp integer(8);   
   output VARCHAR2(45);
BEGIN
    select IDP, PC, PN into mag_idp,ile,output from MAG WHERE idp = ( 
      select min(idp) from mag where pc = ( 
        select max(PC) from mag 
      ) 
    );
    
    IF ile > 4 THEN
        UPDATE mag set PC = PC - 5 where IDP = mag_idp;
        
        output := output || '('||mag_idp||'): ' || ile || ' -> ' || (ile-5);
    ELSE
      output := 'Za malo towaru: '||output;
    END IF;
        
	  dbms_output.put_line ( output );
END;

select * from mag;