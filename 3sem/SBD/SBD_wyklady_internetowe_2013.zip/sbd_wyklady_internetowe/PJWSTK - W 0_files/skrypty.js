
var win = null;

function popUp(URL,x,y) {
   if (win != null)
        if (!win.closed) win.close(); 
   win = open(URL, '', "scrollbars=yes,resizable=yes,width="+x+",height="+y);
   win.focus()
}

