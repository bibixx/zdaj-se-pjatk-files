#include <stdio.h>
#include <stdlib.h>

int readLongLong(long long* num);
int readInt (int* num);
long long partition(long long* array, long long left, long long right);
void quicksort(long long* array, long long left, long long right);

int main(void)
{
    int n;
    int j, row, col;
    long long k;
    long long i;
    long long sum, sumAll, lastSum;
    long long lastRepeat, countClasses, maxClassCount, maxRepeat;
    int** matrix;
    int corners[4]; /* Used to store corners of submatrices */
    long long* subSums; /* Used to store sums of submatrices */
    
	/* COMPILES but too slow,
		correct first 5/10 tests, rest over time limit */

    /* Read in the size of matrix and the number of submatrices */
    readInt(&n);
    readLongLong(&k);
    
    /* Allocate memory for the main matrix */
    matrix = malloc(n*sizeof(int*));
    for(row = 0; row < n; row++)
        matrix[row] = malloc(n*sizeof(int));        
    /* Read in elements of matrix */
    for(row = 0; row < n; row++)
        for(col = 0; col < n; col++){
            readInt(matrix[row] + col);
        }
    /* Allocate memory for array storing sums of submatrices */
    subSums = malloc(k*sizeof(long long));

    sumAll = 0;

    /* Read in coordinates of each submatrix, sum its elements and remember result in subSums */
    for(i = 0; i < k; i++){
        for(j = 0; j < 4; j++){ /* coords of upper left and lower right corners*/
			readInt(corners+j);
        }
        sum = 0;
        for(row = corners[0]; row <= corners[2]; row++)
            for(col = corners[1]; col <= corners[3]; col++)
                sum += *(matrix[row] + col);
        subSums[i] = sum;
        sumAll += sum;
    }
    /* Sort subSums */
    quicksort(subSums, 0, k-1);
    
    /* Count number of abstraction classes (unique sums).
    Remember the largest size of an abstraction class.
    Count the number of times the largest size of an abstraction class repeats. */
    countClasses = 1; /* no of unique sums, at least 1 */
    lastSum = subSums[0]; /* last different sum seen */
    lastRepeat = 1; /* no of times last sum was repeated */
    maxClassCount = 1; /* max number of times 1 sum was repeated */
    maxRepeat = 1; /* no of sums which were repeated max times */
    for(i = 1; i < k; i++)
    {
        if(subSums[i] == lastSum) /* if sum repeats */
        {
			lastRepeat++;
            if(lastRepeat > maxClassCount){
                maxClassCount = lastRepeat;
                maxRepeat = 1;
            }
            else if(lastRepeat == maxClassCount){
                maxRepeat++;
            }
        }
        else{ /* if sum doesn't repeat, we have a new abstraction class */
            countClasses++;
            lastSum = subSums[i];
            lastRepeat = 1;
			if(maxClassCount == 1) /* no sum repeated so far */
				maxRepeat++;
        }
        
    }
    
    /* Print the results out:
    1. Number of abstraction classes
    2. Number of largest abstraction classes
    3. Average sum of a submatrix */
    printf("%lld %lld %lld", countClasses, maxRepeat, sumAll/k); 
    
    /* Free allocated memory */
    for(i = 0; i < n; i++)
        free(matrix[i]);
    free(matrix);
    free(subSums);
}

int readLongLong(long long* num)
{
    char digit;
    /* Read the first character */
    scanf("%c", &digit);
    *num = (long long)(digit - '0'); 
    /* Read in characters until encountering either EOF or a whitespace character (space or new line)*/
    while(scanf("%c", &digit)){
        if(digit == 32 || digit == 10)
            return (int)digit;
        /* Multiply number by 10 using bitwise operations: 10x = 8x + 2x */
        *num = ((*num)<<3) + ((*num)<<1);
        /*Add new digit as the least significant one*/
        *num = *num + digit - '0';
    }
    return 0;
}

int readInt(int* num)
{
    char digit;
    int negative;
    /* Read the first character, check whether it's a minus sign */
    scanf("%c", &digit);
    if(digit == 45)
    {
        negative = 1;
        scanf("%c", &digit);
    }
    else
        negative = 0;
    *num = digit - '0';
    /* Read in characters until encountering either EOF or a whitespace character (space or new line)*/
    while(scanf("%c", &digit)){
        if(digit == 32 || digit == 10){
            if(negative)
                *num = 0 - *num;
            return (int)digit;
		}
        /* Multiply number by 10 using bitwise operations: 10x = 8x + 2x */
        *num = ((*num)<<3) + ((*num)<<1);
        /*Add new digit as the least significant one*/
        *num = *num + digit - '0';
    }
    if(negative)
        *num = 0 - *num;
    return 0;
}

long long partition(long long* array, long long left, long long right)
{
    long long temp;
    long long pivot;
    /* Choose item to use for comparison */
    pivot = *(array+left);
    while(1)
    {
        while(*(array+right) > pivot)
            right--;
        while(*(array+left) < pivot)
            left++;
        if(left < right)
        {
            /* Swap items at indices left and right */
            temp = *(array+left);
            *(array+left) = *(array+right);
            *(array+right) = temp;
            left++;
            right--;
        }
        else
            return right;
    }
}

void quicksort(long long* array, long long left, long long right)
{
    long long pivot;
    if(left < right)
    {
        /* Choose the index to partition array */
        pivot = partition(array, left, right);
        /* Recursive calls for both parts of original array */
        quicksort(array, left, pivot);
        quicksort(array, pivot+1, right);
    }
}

