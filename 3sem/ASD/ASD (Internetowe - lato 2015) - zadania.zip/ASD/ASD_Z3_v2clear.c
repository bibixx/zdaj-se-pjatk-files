#include <stdio.h>
#include <stdlib.h>

char check_for_leaves(unsigned char* if_leaf, unsigned int position, unsigned int dist_from_bottom);

int main(void){
	unsigned char *tree, *if_leaf;
	unsigned int tree_size;
	unsigned char label; //label of a nod
	unsigned int position, path_len; //position of leaf in the tree
	unsigned char *largest_word;
	unsigned int word_len;
	unsigned int i, j, temp, read_in;
	unsigned char branch;

	/* Allocate initial memory to tree and if_leaf arrays */
	tree_size = 16;
	tree = (unsigned char*)malloc(tree_size*sizeof(char));
	if(tree == NULL) return 1;
	tree[0] = 3; //initial height of the tree
	if_leaf = (unsigned char*)malloc(tree_size*sizeof(char));
	if(if_leaf == NULL) return 1;
	if_leaf[0] = 3; //initial height of the tree
	for(i = 1; i < tree_size; i++){ //initialize all elements of if_leaf to 0
		if_leaf[i] = 0;	
	}

	/* Read in elements of the tree */
	while((read_in = getchar_unlocked()) != EOF){
		if(read_in >= 'a' && read_in <= 'z'){ //new label
			label = (unsigned char)read_in;
			position = 1;
			path_len = 0;
		}
		else if(read_in == 'L'){ //look for position - choose left branch
			position *= 2;
			path_len++;		
		}
		else if(read_in == 'R'){ //look for position - choose right branch
			position = 2*position + 1;
			path_len++;
		}
		else if(read_in == 10){ //end of line - save the label at the position
			if(path_len > tree[0]){ //if tree is too small, reallocate tree and if_leaf
				temp = tree_size;				
				for(i = path_len; i > tree[0]; i--)
					tree_size *= 2;	
		
				tree = realloc(tree, tree_size);
				if(tree == NULL) return 1;
				tree[0] = path_len;

				if_leaf = realloc(if_leaf, tree_size);
				if(if_leaf == NULL) return 1;
				if_leaf[0] = path_len;
				for(i = temp; i < tree_size; i++)
					if_leaf[i] = 0;
			}			
			tree[position] = label; //element put in the tree

			/* Set values in if_leaf array */
			if(path_len == tree[0]){ //if nod at lowest level of tree, it must be a leaf
				if_leaf[position] = 1;
				while(position /= 2) //'tell' higher nodes, there're not nodes anymore
					if_leaf[position] = 0;
			}
			else{ //check if there're leaves lower on the tree
				if(check_for_leaves(if_leaf, position, path_len) == 0)
					if_leaf[position] = 1;
	
				while(position /= 2) //'tell' higher nodes, there're not nodes anymore
					if_leaf[position] = 0;
			}
		}
		else if(read_in == 32){ //list of branches will follow
			continue;
		}
	}
	/* Save the element on the last line - no end of line, so not included in the loop */
	if(path_len > tree[0]){ //if tree is too small, reallocate tree and if_leaf
		temp = tree_size;				
		for(i = path_len; i > tree[0]; i--)
			tree_size *= 2;	

		tree = realloc(tree, tree_size);
		if(tree == NULL) return 1;
		tree[0] = path_len;

		if_leaf = realloc(if_leaf, tree_size);
		if(if_leaf == NULL) return 1;
		if_leaf[0] = path_len;
		for(i = temp; i < tree_size; i++)
			if_leaf[i] = 0;
	}			
	tree[position] = label; //element put in the tree

	/* Last element read in - set values in if_leaf array */
	if(path_len == tree[0]){ //if nod at lowest level of tree, it must be a leaf
		if_leaf[position] = 1;
		while(position /= 2) //'tell' higher nodes, there're not nodes anymore
			if_leaf[position] = 0;
	}
	else{ //check if there're leaves lower on the tree
		if(check_for_leaves(if_leaf, position, path_len) == 0)
			if_leaf[position] = 1;
		while(position /= 2) //'tell' higher nodes, there're not nodes anymore
			if_leaf[position] = 0;
	}

	/* Look for the lexically largest word */
	largest_word = (unsigned char*)malloc((tree[0]+2)*sizeof(char));
	
	largest_word[0] = 'a';
	word_len = 1;
	
	for(i = 1; i < tree_size; i++){ //check all if_leaf elements
		/* Start only from leafs */
		if(if_leaf[i] == 1){
			if(tree[i] > largest_word[0]){
				/* First letter of new word bigger than first letter of largest one
				- new largest word found */		
				largest_word[0] = tree[i];
				j = 1;
				position = i;
				while(position /= 2)
					largest_word[j++] = tree[position];
				word_len = j;
			}			
			else if(tree[i] == largest_word[0]){
				/* First letters identical - look for first different letter */
				j = 1;
				position = i;
				/* Compare with current largest word */
				while(j < word_len && (position /= 2) != 0){
					if(largest_word[j] > tree[position]) //current word bigger
						break;
					else if(largest_word[j] == tree[position]) //so far identical
						j++;
					else{ //largest_word[j] < tree[position] => bigger word found
						largest_word[j++] = tree[position];
						while(position /= 2)
							largest_word[j++] = tree[position];
						word_len = j;
						break;
					}
				}
				/* If current largest word is prefix for this one => bigger word found */
				if(j == word_len && position != 0 && largest_word[j-1] == tree[position]){
					while(position /= 2)
						largest_word[j++] = tree[position];
					word_len = j;
				}
			}			
		}
	}

	/* Print out the largest word */
	largest_word[word_len] = '\0';
	printf("%s", largest_word);

	/* Free allocated memory */
	free(tree);
	free(if_leaf);
	free(largest_word);

	return 0;
}

char check_for_leaves(unsigned char* if_leaf, unsigned int position, unsigned int path_len){
	char left, right;
	
	/* First check if current element is not a leaf itself */	
	if(if_leaf[position])
		return 1;

	/* Current is not a leaf, look at its branches */
	if(path_len == if_leaf[0]-1){
		left = if_leaf[2*position];
		right = if_leaf[2*position+1];
	}
	else{
		left = check_for_leaves(if_leaf, 2*position, path_len+1);
		right = check_for_leaves(if_leaf, 2*position+1, path_len+1);
	}

	return (left | right);
}
