#include <stdio.h>
#include <stdlib.h>

int read_int (int* num);
int partition(long long* array, int left, int right);
void quicksort(long long* array, int left, int right);

int main(void)
{
    int n, k; // Size of matrix and number of submatrices
    int element;
    int i, j, row, col;
    long long sum, sum_all, last_sum;
    int last_repeat, count_classes, max_class_count, max_repeat;
    long long** matrix; // Subsums' matrix
    int corners[4]; // Used to temporarily store 2 corners (x,y) of each submatrix
    long long* sub_sums; // Used to store sums of submatrices
    
	/* WORK IN PROGRESS */

    /* Read in the size of matrix and the number of submatrices */
    read_int(&n);
    read_int(&k);
    
    /* Allocate memory for the subsums' matrix */
    matrix = malloc(n*sizeof(long long*));
    for(row = 0; row < n; row++)
        matrix[row] = malloc(n*sizeof(long long));
     
	/* Allocate memory for array storing sums of submatrices */
    sub_sums = malloc(k*sizeof(long long));
   
    /* Read in elements of oryginal matrix, calculate partial sums and put them into matrix*/
	//printf("Matrix of partial sums:\n");    
	for(row = 0; row < n; row++){
        for(col = 0; col < n; col++){
			matrix[row][col] = 0;
			if(row == 0){
				if(col != 0)
					matrix[row][col] += matrix[row][col-1];
			}
			else if(col == 0){
				if(row != 0)
					matrix[row][col] += matrix[row-1][col];
			}
			else{
				matrix[row][col] += matrix[row][col-1] + matrix[row-1][col];
				matrix[row][col] -= matrix[row-1][col-1];
			}
			read_int(&element);
			matrix[row][col] += element;
			//printf("%lld ", matrix[row][col]);
        }
		//printf("\n");
	}

    sum_all = 0;

    /* Read in coordinates of each submatrix, calculate sum of its elements and remember result in sub_sums */
    for(i = 0; i < k; i++){
        for(j = 0; j < 4; j++){ /* coords of upper left and lower right corners*/
			read_int(corners+j);
        }
        sum = matrix[corners[2]][corners[3]];
		if(corners[0] != 0) //subtract the rectangle between y axis and submatrix' area
			sum -= matrix[corners[0]-1][corners[3]];
		if(corners[1] != 0) //subtract the rectangle between x axis and submatrix' area
			sum -= matrix[corners[2]][corners[1]-1];
		if(corners[0] != 0 && corners[1] != 0) //add the doubly subtracted part
			sum += matrix[corners[0]-1][corners[1]-1];
    	
        sub_sums[i] = sum;
        sum_all += sum;
    }
    /* Sort sub_sums */
    quicksort(sub_sums, 0, k-1);
    
    /* Count number of abstraction classes (unique sums).
    Remember the largest size of an abstraction class.
    Count the number of times the largest size of an abstraction class repeats. */
    count_classes = 1; /* no of unique sums, at least 1 */
    last_sum = sub_sums[0]; /* last unique sum seen */
    last_repeat = 1; /* no of times last sum was repeated */
    max_class_count = 1; /* max number of times 1 sum was repeated */
    max_repeat = 1; /* no of sums which were repeated max times */
    for(i = 1; i < k; i++)
    {
		printf("Current submatrix sum: %lld\n", sub_sums[i]);
        if(sub_sums[i] == last_sum) /* if sum repeats */
        {
			last_repeat++;
            if(last_repeat > max_class_count){
                max_class_count = last_repeat;
                max_repeat = 1;
				printf("New max-sized abstraction class, max_class_count = %d\n", max_class_count);
            }
            else if(last_repeat == max_class_count){
                max_repeat++;
				printf("New member of this max-sized abstraction class\n");
            }
        }
        else{ /* if sum doesn't repeat, we have a new abstraction class */
            count_classes++;
            last_sum = sub_sums[i];
            last_repeat = 1;
			if(max_class_count == 1){ /* no sum repeated so far */
				max_repeat++;
				printf("Another single element abstraction class\n");
			}
        }
        
    }
    
    /* Print the results out:
    1. Number of abstraction classes
    2. Number of largest abstraction classes
    3. Average sum of a submatrix */
    printf("%d %d %lld", count_classes, max_repeat, sum_all/k); 
    
    /* Free allocated memory */
    for(i = 0; i < n; i++)
        free(matrix[i]);
    free(matrix);
    free(sub_sums);
}

inline int read_int(int* num){
	int digit, negative;

	/* Read the first character */
	digit = getchar_unlocked();
	if(digit == 45){ //check if first character is a minus
		negative = 1;
		digit = getchar_unlocked();
	}
	else
		negative = 0;
	*num = digit - '0';
	/* Read in characters until encountering either EOF or a whitespace character (space or new line)*/
	while((digit = getchar_unlocked()) != EOF){
		if(digit == 32 || digit == 10){
			if(negative)
				*num = 0 - *num;
			return digit;
		}
		/* Multiply number by 10 using bitwise operations: 10x = 8x + 2x */
		*num = ((*num)<<3) + ((*num)<<1);
		/* Add new digit as the least significant one */
		*num = *num + digit - '0';
	}
	if(negative)
    	*num = 0 - *num;
	return 0;
}

int partition(long long* array, int left, int right)
{
    long long temp;
    long long pivot;
    /* Choose item to use for comparison */
    pivot = *(array+left);
    while(1)
    {
        while(*(array+right) > pivot)
            right--;
        while(*(array+left) < pivot)
            left++;
        if(left < right)
        {
            /* Swap items at indices left and right */
            temp = *(array+left);
            *(array+left) = *(array+right);
            *(array+right) = temp;
            left++;
            right--;
        }
        else
            return right;
    }
}

void quicksort(long long* array, int left, int right)
{
    int pivot;
    if(left < right)
    {
        /* Choose the index to partition array */
        pivot = partition(array, left, right);
        /* Recursive calls for both parts of original array */
        quicksort(array, left, pivot);
        quicksort(array, pivot+1, right);
    }
}

