#include <stdio.h>
#include <stdlib.h>

int readInt(unsigned int*);

int main(void) {
	unsigned int current, last;
	unsigned int max_len, current_len;
	unsigned long long max_sum, current_sum;
	unsigned int count_repeats, more_to_read;
	int current_subseq;
	
	max_len = 0; max_sum = 0;
	current_subseq = 0;
	count_repeats = 1;
	more_to_read = 1;
	
	/* Read in the first number */
	more_to_read = readInt(&last);
	current_len = 1;
	current_sum = last;
	
	if(!more_to_read){
		printf("1 %llu", current_sum);
		return 0;
	}

	/* Read and process all the other numbers */
	while(1){
		more_to_read = readInt(&current);		
		
		/* Constant sequence so far - only until it becomes increasing or decreasing for the first time */
		if(current_subseq == 0){
			if(current > last){ /* From now on it's an increasing sequence */
				current_subseq = 1;
				count_repeats = 1;
			}
			else if(current < last){ /* From now on it's a decreasing sequence */
				current_subseq = -1;
				count_repeats = 1;
			}
			else
				count_repeats++;
		
			current_len++;
			current_sum += current;
		}
		
		/* Increasing sequence */
		else if(current_subseq == 1){
			if(current >= last){
				current_len++;
				current_sum += current;

				if(current == last)
					count_repeats++;
				else
					count_repeats = 1;
			}
			else{ /* Current and last element form new decreasing sequence */
				current_subseq = -1;

				if(current_len > max_len){ /* Compare finished sequence with the so far longest one */
					max_len = current_len;
					max_sum = current_sum;
				}
				current_len = count_repeats + 1;
				current_sum = current;

				while(count_repeats >= 1){
					current_sum += last;
					count_repeats--;
				}
				count_repeats = 1;
			}
		}
		/* Decreasing sequence */
		else if(current_subseq == -1){
			if(current <= last){
				current_len++;
				current_sum += current;

				if(current == last)
					count_repeats++;
				else
					count_repeats = 1;
			}
			else{ /* Current and last element form new increasing sequence */
				current_subseq = 1;

				if(current_len > max_len){ /* Compare finished sequence with the so far longest one */
					max_len = current_len;
					max_sum = current_sum;
				}
				current_len = count_repeats + 1;
				current_sum = current;
				while(count_repeats >= 1){
					current_sum += last;
					count_repeats--;
				}
				count_repeats = 1;
			}
		}

		last = current;

		if(!more_to_read){

			if(current_len > max_len){
				max_len = current_len;
				max_sum = current_sum;
			}

			break;
		}
	}
	
	/* Print out the results */
	printf("%u %llu", max_len, max_sum);
	return 0;
}

inline int readInt(unsigned int* num)
{
    int digit;
    /* Read the first character */
    digit = getchar_unlocked();	
    *num = digit - '0';
    /* Read in characters until encountering either EOF or a whitespace character (space or new line)*/
    while((digit = getchar_unlocked()) != EOF){
        if(digit == 32 || digit == 10)
            return digit;
        /* Multiply number by 10 using bitwise operations: 10x = 8x + 2x */
        *num = ((*num)<<3) + ((*num)<<1);
        /* Add new digit as the least significant one */
        *num = *num + digit - '0';
    }
    return 0;
}

