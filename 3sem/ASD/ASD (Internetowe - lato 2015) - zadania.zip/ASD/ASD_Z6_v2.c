#include <stdio.h>
#include <stdlib.h>

inline int read_int(unsigned int*);

unsigned int partition(unsigned int* array, unsigned int left, unsigned int right);
void quicksort(unsigned int* array, unsigned int left, unsigned int right);

inline unsigned int is_sum_odd (unsigned int*);
unsigned int* multiset_union (unsigned int* first, unsigned int* second, unsigned int m, unsigned int* count_0s);
void sum_all_count_unique(unsigned int* set, unsigned long long* sum, unsigned int* count);

int main(void){
	unsigned int n, m, k;
	unsigned int i, j, length, second, third;
	unsigned int** sets; /* [n] Remembers pointers to all multisets */
	unsigned int *sorted; /* [n] Remembers if set sorted */
	unsigned int *result;
	unsigned int odd_sum; /* 0 if result's sum even, 1 - if odd */ 
	unsigned int count_unique, count_0s;
	unsigned long long sum_all;
	
	/* WORKING SOLUTION - 49 points
	8/11 OK, 3 over time limit */
	
	/* Count 0s in result - k loop may end early */

	/* Read in:
	n - number of multisets (sets with repeating elements),
	m - max number of elements of a single multisets' union,
	k - number of iterations of multisets' union */
	read_int(&n);
	read_int(&m);
	read_int(&k);
	
	/* Allocate memory for 'sets' and 'sorted' arrays */
	sets = (unsigned int**)malloc(n * sizeof(unsigned int*));
	sorted = (unsigned int*)malloc(n * sizeof(unsigned int));
	
	/* Read in n multisets' elements, allocate memory.
	Remember no. elements in i-th multiset in set[i][0] */
	for(i = 0; i < n; i++){
		read_int(&length);
		sets[i] = (unsigned int*)malloc((length+1) * sizeof(unsigned int));
		sets[i][0] = length;
		for(j = 1; j <= length; j++){
			read_int(sets[i] + j);
		}
		sorted[i] = 0;
	}
	
	/* Initially set up 'result' to be an empty multiset of size m */
	result = (unsigned int*)malloc((m+1)*sizeof(unsigned int));
	result[0] = 0;
	odd_sum = 0;
	count_0s = 0;
	
	/* Perform k iterations of multisets' union */
	for(i = 0; i < k; i++){
		read_int(&second);
		read_int(&third);
		if(is_sum_odd(result)){
		/* If the sum of 'result' elements is odd, union with 'third' set */
			if(sorted[third] == 0){
				quicksort(sets[third], 1, sets[third][0]);
				sorted[third] = 1;
			}
			result = multiset_union(result, sets[third], m, &count_0s);
		}
		else{
		/* If the sum of 'result' elements is even, union with 'second' set */
			if(sorted[second] == 0){
				quicksort(sets[second], 1, sets[second][0]);
				sorted[second] = 1;
			}
			result = multiset_union(result, sets[second], m, &count_0s);
		}
		if(count_0s == m) /* Result contains only 0s - it won't change anymore */
			break;
	}
	/* Sum all elements of 'result' and count no. unique elements */
	sum_all_count_unique(result, &sum_all, &count_unique);
	
	printf("%llu %u", sum_all, count_unique);
	
	/* Free allocated memory */
	free(result);
	for(i = 0; i < n; i++)
		free(sets[i]);
	free(sets);
	free(sorted);
	
	return 0;
}

inline int read_int(unsigned int* num)
{
    int digit;
    /* Read the first character */
    digit = getchar_unlocked();	
    *num = digit - '0';
    /* Read in characters until encountering either EOF or a whitespace character (space or new line)*/
    while((digit = getchar_unlocked()) != EOF){
        if(digit == 32 || digit == 10)
            return digit;
        /* Multiply number by 10 using bitwise operations: 10x = 8x + 2x */
        *num = ((*num)<<3) + ((*num)<<1);
        /* Add new digit as the least significant one */
        *num = *num + digit - '0';
    }
    return 0;
}

/* QUICKSORT */
unsigned int partition(unsigned int* array, unsigned int left, unsigned int right)
{
    unsigned int temp;
    unsigned int pivot;
    /* Choose item to use for comparison */
    pivot = *(array+left);
    while(1)
    {
        while(*(array+right) > pivot)
            right--;
        while(*(array+left) < pivot)
            left++;
        if(left < right)
        {
            /* Swap items at indices left and right */
            temp = *(array+left);
            *(array+left) = *(array+right);
            *(array+right) = temp;
            left++;
            right--;
        }
        else
            return right;
    }
}

void quicksort(unsigned int* array, unsigned int left, unsigned int right)
{
    unsigned int pivot;
    if(left < right)
    {
        /* Choose the index to partition array */
        pivot = partition(array, left, right);
        /* Recursive calls for both parts of original array */
        quicksort(array, left, pivot);
        quicksort(array, pivot+1, right);
    }
}

/* MULTISET OPERATIONS */
inline unsigned int is_sum_odd (unsigned int* set)
{
	unsigned int sum, i, size;
	sum = 0;
	size = *(set);
	for(i = 1; i <= size; i++)
		sum ^= (*(set+i))&1;
	return sum;
}

unsigned int* multiset_union (unsigned int* first, unsigned int* second, unsigned int m, unsigned int* count_0s)
{
	unsigned int size, size_first, size_second, i, j, k;
	unsigned int* set_union;
	
	size_first = first[0];
	size_second = second[0];
	
	if(size_first + size_second < m)
		size = size_first + size_second;
	else
		size = m;
		
	set_union = (unsigned int*)malloc((size+1)*sizeof(unsigned int));
	set_union[0] = size;

	(*count_0s) = 0;
	k = 1; i = j = 1;
	while (k <= size){
		if(i <= size_first && j <= size_second){
			if(first[i] <= second[j]){
				set_union[k] = first[i++];
			}
			else{
				set_union[k] = second[j++];
			}
		}
		else if(i <= size_first){
			set_union[k] = first[i++];
		}
		else{
			set_union[k] = second[j++];
		}
		/* Check if added 0 */
		if(set_union[k++] == 0)
			(*count_0s)++;
	}
	free(first);
	return set_union;
}
void sum_all_count_unique(unsigned int* set, unsigned long long* sum, unsigned int* count){
	unsigned int i, size, last_counted, current;
	*sum = 0;
	*count = 1;
	size = *set;
	last_counted = *(set+1);
	
	for(i = 1; i <= size; i++){
		current = *(set+i);
		*sum += current;
		if(current != last_counted){
			(*count)++;
			last_counted = current;
		}
	}
}

