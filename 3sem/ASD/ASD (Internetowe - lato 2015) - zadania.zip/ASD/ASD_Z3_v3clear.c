#include <stdio.h>
#include <stdlib.h>

struct node{
	unsigned char label;
	struct node *parent, *left, *right;
};

void find_largest_word(struct node*, unsigned char*, unsigned int*);
void free_tree(struct node *root);

int main(void){
	struct node *root, *current;
	unsigned int tree_size, path_len;
	unsigned char label; //label of a nod
	unsigned char *largest_word;
	unsigned int word_len;
	unsigned int read_in;

	/*** Working solution
		 Uses structs to hold tree elements with links up and down the tree ***/


	/* Allocate root node element, set all links to null */
	root = (struct node*)malloc(sizeof(struct node));
	root->parent = root->left = root->right = NULL;
	tree_size = 1;

	/* Read in elements of the tree */
	while((read_in = getchar_unlocked()) != EOF){
		if(read_in >= 'a' && read_in <= 'z'){ //new label
			label = (unsigned char)read_in;
			current = root;
			path_len = 1;
		}
		else if(read_in == 32){ //list of branches will follow
			continue;
		}
		else if(read_in == 'L'){ //look for position - choose left branch
			if(current->left == NULL){ //if branch doesn't exist, create new one
					current->left = (struct node*)malloc(sizeof(struct node));
					current->left->left = current->left->right = NULL;
					current->left->parent = current;
			}
			current = current->left;
			path_len++;
		}
		else if(read_in == 'R'){ //look for position - choose right branch
			if(current->right == NULL){ //if branch doesn't exist, create new one
					current->right = (struct node*)malloc(sizeof(struct node));
					current->right->left = current->right->right = NULL;
					current->right->parent = current;
			}
			current = current->right;
			path_len++;
		}
		else if(read_in == 10){ //end of line - save the label at the current node
			current->label = label;
			if(path_len > tree_size)
				tree_size = path_len;
		}
	}
	/* Save the element on the last line - no end of line, so not included in the loop */
	current->label = label;
	if(path_len > tree_size)
		tree_size = path_len;	
	
	/* Look for the lexically largest word */
	largest_word = (unsigned char*)malloc((tree_size+1)*sizeof(char));
	
	largest_word[0] = 'a';
	word_len = 1;
	
	find_largest_word(root, largest_word, &word_len);

	/* Print out the largest word */
	largest_word[word_len] = '\0';
	printf("%s", largest_word);

	/* Free allocated memory */
	free(largest_word);
	free_tree(root);

	return 0;
}

void find_largest_word(struct node *current, unsigned char* largest_word, unsigned int  *word_len){
	unsigned int i;

	if(current->left != NULL) //check left subtree
		find_largest_word(current->left, largest_word, word_len);
	if(current->right != NULL) //check right subtree
		find_largest_word(current->right, largest_word, word_len);
	/* No left or right links => current is a leaf */
	else if(current->left == NULL){
		/* Completely new largest word */
		if(current->label > largest_word[0]){
			largest_word[0] = current->label;
			*word_len = 1;
			while((current = current->parent) != NULL){
				largest_word[(*word_len)++] = current->label;
			}
		}
		/* New largest word has a common beginning part with the old one */
		else if(current->label == largest_word[0]){
			i = 1;			
			while(i < *word_len && (current = current->parent) != NULL){
				if(current->label == largest_word[i]) //identical so far
					i++;
				/* Found place where current path gets bigger than largest word */
				else if(current->label > largest_word[i]){
					*word_len = i;					
					largest_word[(*word_len)++] = current->label;
					/* Replace rest of largest word with current path to root */
					while((current = current->parent) != NULL)
						largest_word[(*word_len)++] = current->label;
					break;
				}
				else //Current path smaller than largest word - path no longer viable
					break;
			}
			/* Largest word is a prefix for the current path */
			if(i == *word_len && current->label == largest_word[i-1]){				
				while((current = current->parent) != NULL)
					largest_word[(*word_len)++] = current->label;
			}
		}
	}
} 

void free_tree(struct node *root){
	if(root->left != NULL)	
		free_tree(root->left);
	if(root->right != NULL)
		free_tree(root->right);
	free(root);
}

