#include <stdio.h>
#include <stdlib.h>


struct candHQ {
	int index;
	int countA;
	int countB;
};

int readInt(int*);

void election (int* area, int* hqA, int* hqB, struct candHQ** countHQ, int k, int* toVisit, int iterId, int* winnerA, int* winnerB);

void heapConstruct(struct candHQ** array, unsigned int k, unsigned int maxHeap);
void downHeapMax(struct candHQ** array, unsigned int k, unsigned int i);
void downHeapMin(struct candHQ** array, unsigned int k, unsigned int i);
void findMinRecursive(struct candHQ** array, unsigned int k, unsigned int i, int* currentMin, int* minIndex);

int partition(int* array, unsigned int left, unsigned int right);
void quicksort(int* array, unsigned int left, unsigned int right);
void countInPlace(int* array, unsigned int n);

int main(void)
{
	unsigned int n, k, i, j;
	int index1, index2;
	unsigned int** areas; /* Represents in memory communities' graph */
	unsigned int countNeighbours;
	unsigned int* area;
	int *hqA, *hqB; /* [n] Remembers who has hq where */
	int *toVisit; /* [n] Remembers status of an area */
	unsigned int countVisited, iterId;
	struct candHQ** countHQ;
	int winnerA, winnerB;
	int* changes; /* An array of changes to HQ locations */
	unsigned int changesCount; 
	
	/* COMPILES 8/11 correct - 60 points
		2 tests - segmentation error,
		1 test - over time limit*/

	/* READ DATA */
	/* Read in no communities and allocate memory for the graph and toVisit */
	readInt(&n);
	areas = (unsigned int**)malloc(n * sizeof(unsigned int*));
	toVisit = (int*)malloc(n * sizeof(int));
	for (i = 0; i < n; i++){
		/* Areas[i] is an array of at most n neighbours' indices.
		areas[i][0] holds the actual number of neighbours,
		which is the areas[i][j] j-index of last neighbour */
		areas[i] = (unsigned int*)malloc(n * sizeof(unsigned int));
		areas[i][0] = 0;
		toVisit[i] = -1;
	}
	
	/* Read in communities' graph until encountering -1 */
	while(readInt(&index1) != 45)
	{
		readInt(&index2);
		areas[index1][0]++;
		areas[index1][areas[index1][0]] = index2;
		areas[index2][0]++;
		areas[index2][areas[index2][0]] = index1;
	}
	readInt(&index2); /* Read and ignore the other -1 */
	
	/* Read in no candidates and allocate memory for hqA & hqB*/
	readInt(&k);
	hqA = (int*)malloc(n * sizeof(int));
	hqB = (int*)malloc(n * sizeof(int));
	
	/* Initialize hqA with -1 */
	for(i = 0; i < n; i++)
		hqA[i] = -1;	
	/* Read in candidates headquaters' initial localization to hqA */
	for(i = 0; i < k; i++){
		readInt(&index1);
		hqA[index1] = i;
	}	
	
	/* Corner case k = n */
	if(k == n){
		countInPlace(hqA, n);
		for(i = 0; i < k; i++)
			printf("%d %d\n", hqA[i], hqA[i]);
		return 0;
	}
	
	/* Copy hqA into hqB */
	for(i = 0; i < n; i++){
		hqB[i] = hqA[i];
	}
	
	/* Mark neighbours of initial HQs as part of next-to-visit */
	/* toVisit[n] has now possible values:
	-1: not checked,
	0: visited,
	1: next-to-visit, */
	
	for(i = 0; i < n; i++){
		if(hqA[i] != -1){
			toVisit[i] = 0;
			area = areas[i];
			for(j = 1; j <= area[0]; j++){
				if(toVisit[area[j]] < 0){
					toVisit[area[j]] = 1;
				}
			}
		}	
	}
	
	/* Allocate memory for countHQ, once is enough since its size doesn't change */
	countHQ = (struct candHQ**)malloc(k * sizeof(struct candHQ*));
	for(i = 0; i < k; i++)
		countHQ[i] = (struct candHQ*)malloc(sizeof(struct candHQ));
	
	/* Allocate memory to changes */
	changes = (int*)malloc(3*(n-k) * sizeof(int));
			
	/* ELECTIONS */
	countVisited = k;
	iterId = 1;
	
	while(countVisited < n){
		changesCount = 0;
		for(i = 0; i < n; i++){
			if(toVisit[i] != iterId) continue;
			
			election(areas[i], hqA, hqB, countHQ, k, toVisit, iterId, &winnerA, &winnerB);
			toVisit[i] = 0; /* Mark area as visited */
			countVisited++;
			/*printf("Area %d, winnerA: %d, winnerB: %d\n", i, winnerA, winnerB);*/
			
			changes[changesCount] = i;
			changes[changesCount+1] = winnerA;
			changes[changesCount+2] = winnerB;
			changesCount += 3;
			/*printf("Winners: %d %d\n", winnerA, winnerB);*/
		}
		/* Copy changes into hqA and hqB */
		for(i = 0; i <= changesCount-3; i += 3){
			hqA[changes[i]] = changes[i+1];
			hqB[changes[i]] = changes[i+2];
		}
		
		/* Change iteration id */
		iterId++;
	}
	
	/* Sort hqA and hqB */
	quicksort(hqA, 0, n-1);
	quicksort(hqB, 0, n-1);
	
	/* Count duplicates in hqA and hqB in place */
	countInPlace(hqA, n);
	countInPlace(hqB, n);
	
	/* Print the results */
	for(i = 0; i < k; i++)
	{
		printf("%d %d\n", hqA[i], hqB[i]);
	}
	
	/* Free allocated memory */
	for(i = 0; i < n; i++)
		free(areas[i]);
	free(areas);
	free(toVisit);
	free(hqA);
	free(hqB);
	free(changes);
	for(i = 0; i < k; i++)
		free(countHQ[i]);
	free(countHQ);	
	return 0;
}

inline int readInt(int* num)
{
    int digit;
    /* Read the first character */
    digit = getchar();
    /* If the first character is a minus sign, set num to -1 and return */
    if(digit == 45){
    	*num = -1;
    	getchar(); /* Remove 1 & whitespace from stdin */
    	getchar();
    	return 45;
    }   	
    *num = digit - '0';
    /* Read in characters until encountering either EOF or a whitespace character (space or new line)*/
    while((digit = getchar()) != EOF){
        if(digit == 32 || digit == 10)
            return digit;
        /* Multiply number by 10 using bitwise operations: 10x = 8x + 2x */
        *num = ((*num)<<3) + ((*num)<<1);
        /* Add new digit as the least significant one */
        *num = *num + digit - '0';
    }
    return 0;
}

/* ELECTION */
void election (int* area, int* hqA, int* hqB, struct candHQ** countHQ, int k, int* toVisit, int iterId, int* winnerA, int* winnerB)
{
	unsigned int i, neighbours;
	int currentMin, minIndex;
	
	/* countHQ remembers no HQs of each candidate in the neighbouring areas */
	for(i = 0; i < k; i++){
		(*(countHQ+i))->index = i;
		(*(countHQ+i))->countA = 0;
		(*(countHQ+i))->countB = 0;
	}
	
	iterId++;
	neighbours = *(area);
	
	/* Iterate over all neighbouring areas */
	for(i = 1; i <= neighbours; i++)
	{
		/* If the area has a HQ, increase appropriate count */
		if(hqA[area[i]] != -1){
			(countHQ[hqA[area[i]]]->countA)++;
			(countHQ[hqB[area[i]]]->countB)++; 
		}
		if(toVisit[area[i]] < 0){
			toVisit[area[i]] =iterId;
		}
	}
	
	/* Max-Heapify countHQ based on countB value and then lower index */
	heapConstruct(countHQ, k, 1);	
	/* Highest countB with lowest index is the first element of the heap */
	*winnerB = countHQ[0]->index;
	
	/* Set maximum possible value for currentMin to use in comparisons */
	currentMin = countHQ[0]->countB;	
	/* Min-Heapify countHQ based on countA value and then higher index */
	heapConstruct(countHQ, k, 0);
	
	/* Find min of heap that is > 0 and has the highest index.
	Set initial index = -1 */	
	minIndex = -1;
	findMinRecursive(countHQ, k, 1, &currentMin, &minIndex);
	*winnerA = minIndex;
}

/* MAX-HEAP */
inline void heapConstruct(struct candHQ** array, unsigned int k, unsigned int maxHeap)
{
	unsigned int i;
	i = (k>>1);
	if(maxHeap){
		while(i > 0){
			downHeapMax(array, k, i);
			i--;
		}
	}
	else{
		while(i > 0){
			downHeapMin(array, k, i);
			i--;
		}
	}
}

void downHeapMax(struct candHQ** array, unsigned int k, unsigned int i)
{
	unsigned int j;
	struct candHQ* v;
	
	/* i,j from 1 to k */
	v = *(array + i-1);
	
	while(i <= (k>>1)){
		j = 2*i;
		/* Choose larger child based on countB and if equal, choose smaller index*/
		if(j < k){
			if((*(array + j-1))->countB < (*(array + j))->countB)
				j++;
			else if((*(array + j-1))->countB == (*(array + j))->countB &&
			(*(array + j-1))->index > (*(array + j))->index)
				j++;
		}
		/* If parent's countB is larger than children' end loop */
		if(v->countB > (*(array + j-1))->countB)
			break;
		/* If parent's countB is equal to larger child's but parent's index is smaller end loop */
		if(v->countB == (*(array+j-1))->countB &&
		v->index < (*(array+j-1))->index)
			break;
		
		/* Else put child in the place of parent */
		*(array + i-1) = *(array + j-1);
		
		/* Go one level lower on the tree */
		i = j;
	}
	*(array + i-1) = v;
}

void downHeapMin(struct candHQ** array, unsigned int k, unsigned int i)
{
	unsigned int j;
	struct candHQ* v;
	
	/* i,j from 1 to k */
	v = *(array + i-1);
	
	while(i <= k/2){
		j = (i<<1);
		/* Choose smaller child based on countA and if equal, choose larger index*/
		if(j < k){
			if((*(array + j-1))->countA > (*(array + j))->countA)
				j++;
			else if((*(array + j-1))->countA == (*(array + j))->countA &&
			(*(array + j-1))->index < (*(array + j))->index)
				j++;
		}
		/* If parent's countA is smaller than children' end loop */
		if(v->countA < (*(array + j-1))->countA)
			break;
		/* If parent's countA is equal to larger child's but parent's index is larger end loop */
		if(v->countA == (*(array+j-1))->countA &&
		v->index > (*(array+j-1))->index)
			break;
		
		/* Else put child in the place of parent */
		*(array + i-1) = *(array + j-1);
		
		/* Go one level lower on the tree */
		i = j;
	}
	*(array + i-1) = v;
}

void findMinRecursive(struct candHQ** array, unsigned int k, unsigned int i, int* currentMin, int* minIndex)
{
	/* If countA of current node = 0, do the recursive calls */
	if((*(array+i-1))->countA == 0){
		if((i<<1) <= k)
			findMinRecursive(array, k, i<<1, currentMin, minIndex);
		if(((i<<1)|1) <= k)
			findMinRecursive(array, k, (i<<1)|1, currentMin, minIndex);
	}
	/* Take any action only if count is at most equal to current min and greater than 0 */
	else if((*(array+i-1))->countA <= *currentMin){
		/* If either count < min or count = min while index > min  */
		if((*(array+i-1))->countA < *currentMin){
			*currentMin = (*(array+i-1))->countA;
			*minIndex = (*(array+i-1))->index;
		}
		if((*(array+i-1))->countA == *currentMin && (*(array+i-1))->index > *minIndex){
			*minIndex = (*(array+i-1))->index;
		}
	}
}

/* QUICKSORT */
int partition(int* array, unsigned int left, unsigned int right)
{
    unsigned int temp;
    unsigned int pivot;
    /* Choose item to use for comparison */
    pivot = *(array+left);
    while(1)
    {
        while(*(array+right) > pivot)
            right--;
        while(*(array+left) < pivot)
            left++;
        if(left < right)
        {
            /* Swap items at indices left and right */
            temp = *(array+left);
            *(array+left) = *(array+right);
            *(array+right) = temp;
            left++;
            right--;
        }
        else
            return right;
    }
}

void quicksort(int* array, unsigned int left, unsigned int right)
{
    unsigned int pivot;
    if(left < right)
    {
        /* Choose the index to partition array */
        pivot = partition(array, left, right);
        /* Recursive calls for both parts of original array */
        quicksort(array, left, pivot);
        quicksort(array, pivot+1, right);
    }
}


/* Count number of repetitions */
void countInPlace(int* array, unsigned int n)
{
	int latestCand, countLatest;
	unsigned int i;
	latestCand = *(array); /* i.e. 0 */
	countLatest = 1;
	
	/* Since array is already sorted, the values stored in it start from 0 */
	for(i = 1; i < n; i++){
		if(*(array+i) == latestCand)
			countLatest++;
		else{
			*(array+latestCand) = countLatest;
			latestCand = *(array+i);
			countLatest = 1;
		}
	}
	/* Last candidate's index and count aren't yet saved,
	because we always saved the previous one, not the one we looked at. */
	if(latestCand >= n)
		printf("We somehow got a candidate with id >= n!\n");
	else
		*(array+latestCand) = countLatest;
}
