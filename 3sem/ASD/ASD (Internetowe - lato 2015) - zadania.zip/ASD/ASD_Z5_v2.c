#include <stdio.h>
#include <stdlib.h>

struct election_cand {
	unsigned int id;
	unsigned int count;
	struct election_cand *next;
};

struct area {
	unsigned int id;
	unsigned int election_status; //0 - no elections yet, 1 - in progress, 2 - done
	struct neighbour *neighbours; 
	struct election_cand *candidatesA, *candidatesB;
};

struct neighbour {
	unsigned int id;
	struct neighbour *next;
};

int read_int(unsigned int*);

void add_candidate_to_area(unsigned int cand_idA, unsigned int cand_idB, unsigned int area_id);

unsigned int partition(unsigned int* array, unsigned int left, unsigned int right);
void quicksort(unsigned int* array, unsigned int left, unsigned int right);
void count_in_place(int* array, unsigned int n);

int main(void){
	unsigned int n, k, i, j; //n - number of areas, k - number of candidates
	int index1, index2;
	unsigned int *hqA, *hqB; //[n] candidates who won elections in areas 0...n
	unsigned int count_finished;
	struct area *areas; //nodes of communities' graph
	struct area *temp_area;
	struct neighbour *temp_neighbour, *new_neighbour;

	/* IN PROGRESS
	Using multiple structs */
	
	/* READ DATA */
	/* Read in no communities and allocate memory for the graph */
	read_int(&n);
	areas = (struct area*)malloc(n * sizeof(struct area));
	for(i = 0; i < n; i++){
		areas[i].id = i;
		areas[i].election_status = 0;
		areas[i].neighbours = NULL;
		areas[i].candidatesA = NULL;
		areas[i].candidatesB = NULL;
	}
	
	/* Read in communities' graph until encountering -1 */
	while(read_int(&index1) != 45)
	{
		read_int(&index2);
		/* Add index2 as neighbour to index1 */
		if(areas[index1].neighbours == NULL){ //if first neighbour
			new_neighbour = malloc(sizeof(struct neighbour));
			new_neighbour->id = index2;
			new_neighbour->next = NULL;
			areas[index1].neighbours = new_neighbour;
		}else{
			temp_neighbour = areas[index1].neighbours;
			new_neighbour = malloc(sizeof(struct neighbour));
			new_neighbour->id = index2;
			new_neighbour->next = temp_neighbour;
			areas[index1].neighbours = new_neighbour;
		}
		/* Add index1 as neighbour to index2 */
		if(areas[index2].neighbours == NULL){ //if first neighbour
			new_neighbour = malloc(sizeof(struct neighbour));
			new_neighbour->id = index1;
			new_neighbour->next = NULL;
			areas[index2].neighbours = new_neighbour;
		}else{
			temp_neighbour = areas[index2].neighbours;
			new_neighbour = malloc(sizeof(struct neighbour));
			new_neighbour->id = index1;
			new_neighbour->next = temp_neighbour;
			areas[index2].neighbours = new_neighbour;
		}
	}
	read_int(&index2); /* Read and ignore the other -1 */
	
	/* Read in no candidates */
	read_int(&k);

	/* Corner case k = 1, only 1 candidate - wins all */
	printf("%d %d\n", n, n);

	/* Allocate memory for hqA & hqB */
	hqA = (unsigned int*)malloc(n * sizeof(unsigned int));
	hqB = (unsigned int*)malloc(n * sizeof(unsigned int));
	
	/* Initialize hqA with k (no candidate has that id */
	for(i = 0; i < n; i++)
		hqA[i] = k;	
	/* Read in candidates headquaters' initial localizations to hqA and set their election status to 'done' */
	for(i = 0; i < k; i++){
		read_int(&index1);
		hqA[index1] = i;
		areas[index1].election_status = 2;
	}	
	
	/* Corner case k = n, no more elections possible */
	if(k == n){
		count_in_place(hqA, n);
		for(i = 0; i < k; i++)
			printf("%d %d\n", hqA[i], hqA[i]);
		return 0;
	}
	
	/* Copy hqA into hqB */
	for(i = 0; i < n; i++){
		hqB[i] = hqA[i];
	}

	/* ELECTIONS */
	count_finished = k;

	while(count_finished < n){
		/* Step 1: visit neighbours of hqs to become candidates */
		for(i = 0; i < n; i++){
			if(areas[i].election_status == 2){
				temp_neighbour = areas[i].neighbours;
				while(temp_neighbour != NULL){
				}
			}
		}
	}
}

inline int read_int(unsigned int* num)
{
    int digit;
    /* Read the first character */
    digit = getchar();
    /* If the first character is a minus sign, return 45 */
    if(digit == 45){ /* -1 */
    	getchar(); /* Remove 1 & whitespace from stdin */
    	getchar();
    	return 45;
    }   	
    *num = digit - '0';
    /* Read in characters until encountering either EOF or a whitespace character (space or new line)*/
    while((digit = getchar()) != EOF){
        if(digit == 32 || digit == 10)
            return digit;
        /* Multiply number by 10 using bitwise operations: 10x = 8x + 2x */
        *num = ((*num)<<3) + ((*num)<<1);
        /* Add new digit as the least significant one */
        *num = *num + digit - '0';
    }
    return 0;
}

void add_candidate_to_area(unsigned int cand_idA, unsigned int cand_idB, struct area *loc){
	struct election_cand *new_cand, *temp_cand;

}

/* QUICKSORT */
unsigned int partition(unsigned int* array, unsigned int left, unsigned int right)
{
    unsigned int temp;
    unsigned int pivot;
    /* Choose item to use for comparison */
    pivot = *(array+left);
    while(1)
    {
        while(*(array+right) > pivot)
            right--;
        while(*(array+left) < pivot)
            left++;
        if(left < right)
        {
            /* Swap items at indices left and right */
            temp = *(array+left);
            *(array+left) = *(array+right);
            *(array+right) = temp;
            left++;
            right--;
        }
        else
            return right;
    }
}

void quicksort(unsigned int* array, unsigned int left, unsigned int right)
{
    unsigned int pivot;
    if(left < right)
    {
        /* Choose the index to partition array */
        pivot = partition(array, left, right);
        /* Recursive calls for both parts of original array */
        quicksort(array, left, pivot);
        quicksort(array, pivot+1, right);
    }
}


/* Count number of repetitions */
void count_in_place(int* array, unsigned int n)
{
	unsigned int latest_cand, count_latest;
	unsigned int i;
	latest_cand = *(array); /* i.e. 0 */
	count_latest = 1;
	
	/* Since array is already sorted, the values stored in it start from 0 */
	for(i = 1; i < n; i++){
		if(*(array+i) == latest_cand)
			count_latest++;
		else{
			*(array+latest_cand) = count_latest;
			latest_cand = *(array+i);
			count_latest = 1;
		}
	}
	/* Last candidate's index and count aren't yet saved,
	because we always saved the previous one, not the one we looked at. */
	if(latest_cand >= n)
		printf("We somehow got a candidate with id >= n!\n");
	else
		*(array+latest_cand) = count_latest;
}
