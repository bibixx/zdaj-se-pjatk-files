#include <stdio.h>
#include <stdlib.h>

struct area {
	unsigned int id;
	unsigned int election_status; //0 - no elections yet, 1 - done
	struct neighbour *neighbours;
	struct area *next; //used in context of election_areas list 
};

struct neighbour {
	unsigned int id;
	struct neighbour *next;
};

int read_int(unsigned int*);

unsigned int partition(unsigned int* array, unsigned int left, unsigned int right);
void quicksort(unsigned int* array, unsigned int left, unsigned int right);
void count_in_place(int* array, unsigned int n);

void free_neighbours(struct area *areas, unsigned int n);

int main(void){
	unsigned int n, k, i, j; //n - number of areas, k - number of candidates
	int index1, index2;
	unsigned int *hqA, *hqB; //[n] candidates who won elections in areas 0...n
	unsigned int *candidatesA, *candidatesB; //[n] scores of candidates in current area
	unsigned int max_count, min_count, winnerA, winnerB;
	struct area *areas; //[n] nodes of communities' graph
	struct area *election_areas; //list of areas without elections finished
	struct area *current_area, *previous_area, *temp_area;
	struct neighbour *temp_neighbour, *new_neighbour;
	unsigned int* changes; // An array of changes to HQ locations
	unsigned int changes_count, elections_count;

	/* IN PROGRESS
	Using multiple structs, but candidatesA and candidatesB arrays outside of structs */
	
	/* READ DATA */
	/* Read in no communities and allocate memory for the graph */
	read_int(&n);
	areas = (struct area*)malloc(n * sizeof(struct area));
	for(i = 0; i < n; i++){
		areas[i].id = i;
		areas[i].election_status = 0;
		areas[i].neighbours = NULL;
	}
	
	/* Read in communities' graph until encountering -1 */
	while(read_int(&index1) != 45)
	{
		read_int(&index2);
		/* Add index2 as neighbour to index1 */
		if(areas[index1].neighbours == NULL){ //if first neighbour
			new_neighbour = malloc(sizeof(struct neighbour));
			new_neighbour->id = index2;
			new_neighbour->next = NULL;
			areas[index1].neighbours = new_neighbour;
		}else{
			temp_neighbour = areas[index1].neighbours;
			new_neighbour = malloc(sizeof(struct neighbour));
			new_neighbour->id = index2;
			new_neighbour->next = temp_neighbour;
			areas[index1].neighbours = new_neighbour;
		}
		/* Add index1 as neighbour to index2 */
		if(areas[index2].neighbours == NULL){ //if first neighbour
			new_neighbour = malloc(sizeof(struct neighbour));
			new_neighbour->id = index1;
			new_neighbour->next = NULL;
			areas[index2].neighbours = new_neighbour;
		}else{
			temp_neighbour = areas[index2].neighbours;
			new_neighbour = malloc(sizeof(struct neighbour));
			new_neighbour->id = index1;
			new_neighbour->next = temp_neighbour;
			areas[index2].neighbours = new_neighbour;
		}
	}
	read_int(&index2); /* Read and ignore the other -1 */
	
	/* Read in no candidates */
	read_int(&k);

	/* Corner case k = 1, only 1 candidate - wins all */
	printf("%d %d\n", n, n);

	/* Allocate memory for hqA & hqB */
	hqA = (unsigned int*)malloc(n * sizeof(unsigned int));
	hqB = (unsigned int*)malloc(n * sizeof(unsigned int));
	
	/* Initialize hqA with k (no candidate has that id) */
	for(i = 0; i < n; i++)
		hqA[i] = k;	
	/* Read in candidates headquaters' initial localizations to hqA and set their election status to 'done' */
	for(i = 0; i < k; i++){
		read_int(&index1);
		hqA[index1] = i;
		areas[index1].election_status = 1;
	}	
	
	/* Corner case k = n, no more elections possible */
	if(k == n){
		count_in_place(hqA, n);
		for(i = 0; i < k; i++)
			printf("%d %d\n", hqA[i], hqA[i]);
		return 0;
	}
	
	/* Copy hqA into hqB */
	for(i = 0; i < n; i++){
		hqB[i] = hqA[i];
	}

	/* ELECTIONS */
	elections_count = k;

	/* Create initial list of areas where elections have yet to happen */
	election_areas = NULL;
	for(i = 0; i < n; i++){
		if(areas[i].election_status == 0){
			if(election_areas == NULL){
				election_areas = areas+i;
			} else {
				temp_area = election_areas;
				election_areas = areas+i;
				areas[i].next = temp_area;
			}
		}
	}

	/* Allocate memory for candidates' results holders */
	candidatesA = malloc(k*sizeof(unsigned int));
	candidatesB = malloc(k*sizeof(unsigned int));

	/* Allocate memory for changes to hq locations */
	changes = (unsigned int*)malloc(3*(n-k) * sizeof(unsigned int));

	while(election_areas != NULL && elections_count != n){
		changes_count = 0;
		current_area = election_areas;
		previous_area = NULL;
		/* Visit each area in election_areas */
		while(current_area != NULL){
			/* Step 1: visit neighbours to find candidates if elections possible */
			if(current_area->election_status == 0){ //if elections didn't already happen here
				temp_neighbour = current_area->neighbours;
				for(i = 0; i < k; i++) //zero counts for candidates
					candidatesA[i] = candidatesB[i] = 0;
				if(temp_neighbour != NULL) current_area->election_status = 1;
				while(temp_neighbour != NULL){
					if(hqA[temp_neighbour->id] != k){
						candidatesA[hqA[temp_neighbour->id]]++;
						candidatesB[hqB[temp_neighbour->id]]++;
					}
					temp_neighbour = temp_neighbour->next;
				}
				if(current_area->election_status){
					/* Look for min element in candidatesA and max in candidatesB */
					min_count = candidatesA[0];
					winnerA = 0;
					max_count = candidatesB[0];
					winnerB = 0;
					for(i = 1; i < k; i++){
						if(min_count == 0 && candidatesA[i] != 0){ //first non-zero count candidate
							min_count = candidatesA[i];
							winnerA = i;
						}
						else if(candidatesA[i] < min_count){ //lower count found
							min_count = candidatesA[i];
							winnerA = i;
						}
						else if(candidatesA[i] == min_count){ //same count, larger index found
							winnerA = i;
						}
						if(candidatesB[i] > max_count){ //larger count found
							max_count = candidatesB[i];
							winnerB = i;
						}
					}
					/* Remember results for current_area in changes */
					changes[changes_count] = current_area->id;
					changes[changes_count+1] = winnerA;
					changes[changes_count+2] = winnerB;
					changes_count += 3;

					elections_count++;
				}
			}
			/* Get next area to try elections and remove current from list if elections happened */
			/*if(current_area->election_status == 1){
				if(elections_areas == current_area)
					elections_areas = current_area->next;
				else{
					previous_area->next = current_area->next;
				}
			}
			previous_area = current_area;*/
			current_area = current_area->next;
		}
		/* Copy changes into hqA and hqB */
		for(i = 0; i <= changes_count-3; i += 3){
			hqA[changes[i]] = changes[i+1];
			hqB[changes[i]] = changes[i+2];
		}
	}

	/* Sort hqA and hqB */
	quicksort(hqA, 0, n-1);
	quicksort(hqB, 0, n-1);
	
	/* Count duplicates in hqA and hqB in place */
	count_in_place(hqA, n);
	count_in_place(hqB, n);
	
	/* Print the results */
	for(i = 0; i < k; i++)
	{
		printf("%u %u\n", hqA[i], hqB[i]);
	}

	/* Free memory */
	free_neighbours(areas, n);
	free(areas);
	free(hqA);
	free(hqB);
	free(candidatesA);
	free(candidatesB);
	free(changes);
}

inline int read_int(unsigned int* num)
{
    int digit;
    /* Read the first character */
    digit = getchar();
    /* If the first character is a minus sign, return 45 */
    if(digit == 45){ /* -1 */
    	getchar(); /* Remove 1 & whitespace from stdin */
    	getchar();
    	return 45;
    }   	
    *num = digit - '0';
    /* Read in characters until encountering either EOF or a whitespace character (space or new line)*/
    while((digit = getchar()) != EOF){
        if(digit == 32 || digit == 10)
            return digit;
        /* Multiply number by 10 using bitwise operations: 10x = 8x + 2x */
        *num = ((*num)<<3) + ((*num)<<1);
        /* Add new digit as the least significant one */
        *num = *num + digit - '0';
    }
    return 0;
}

/* QUICKSORT */
unsigned int partition(unsigned int* array, unsigned int left, unsigned int right)
{
    unsigned int temp;
    unsigned int pivot;
    /* Choose item to use for comparison */
    pivot = *(array+left);
    while(1)
    {
        while(*(array+right) > pivot)
            right--;
        while(*(array+left) < pivot)
            left++;
        if(left < right)
        {
            /* Swap items at indices left and right */
            temp = *(array+left);
            *(array+left) = *(array+right);
            *(array+right) = temp;
            left++;
            right--;
        }
        else
            return right;
    }
}

void quicksort(unsigned int* array, unsigned int left, unsigned int right)
{
    unsigned int pivot;
    if(left < right)
    {
        /* Choose the index to partition array */
        pivot = partition(array, left, right);
        /* Recursive calls for both parts of original array */
        quicksort(array, left, pivot);
        quicksort(array, pivot+1, right);
    }
}


/* Count number of repetitions */
void count_in_place(int* array, unsigned int n)
{
	unsigned int latest_cand, count_latest;
	unsigned int i;
	latest_cand = *(array); /* i.e. 0 */
	count_latest = 1;
	
	/* Since array is already sorted, the values stored in it start from 0 */
	for(i = 1; i < n; i++){
		if(*(array+i) == latest_cand)
			count_latest++;
		else{
			*(array+latest_cand) = count_latest;
			latest_cand = *(array+i);
			count_latest = 1;
		}
	}
	/* Last candidate's index and count aren't yet saved,
	because we always saved the previous one, not the one we looked at. */
	if(latest_cand >= n)
		printf("We somehow got a candidate with id >= n!\n");
	else
		*(array+latest_cand) = count_latest;
}

void free_neighbours(struct area *areas, unsigned int n){
	struct area current_area;
	struct neighbour *temp_neighbour, *current_neighbour;
	unsigned int i;

	for(i = 0; i < n; i++){
		current_area = areas[i];
		current_neighbour = current_area.neighbours;
		while(current_neighbour != NULL){
			temp_neighbour = current_neighbour;
			current_neighbour = current_neighbour->next;
			free(temp_neighbour);
		}
	}
}
