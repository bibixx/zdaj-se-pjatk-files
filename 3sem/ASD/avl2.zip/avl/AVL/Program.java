
/*
Dariusz Czechowicz s2020 g227
AVL TREE

I based on information form book
"Algorytmy i struktury danych"
by L. Banachowski

but I found the short info about rotation, strange and unsufficient,
so I had to create my own version,
which is more complexed..... but works.


*/

package jbPack; 

import javax.swing.*;
import java.awt.*;

import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.text.*;

import java.awt.geom.*;
import java.awt.image.*;
import java.awt.font.*;
import java.net.*;
import java.util.zip.*;
import java.lang.reflect.*;
import java.applet.*;

import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.tree.*;
import java.beans.*;



public
class Program
    extends Context {
        
    public static void main(String[] args)
    {
        new Program();       
		
		
    }    

// ====== pod-aplikacja" ================================= //

public
class ContentPane 
    extends Content {
	
    public ContentPane()
    {
//	RepaintManager.currentManager(this).setDoubleBufferingEnabled(false);
    }
	public Graphics pDC;
	
    public void initPane()
    {
		Graphics pDC= getGraphics();
    }
    
    public void initFocus()
    {
    }
    
    public void paintComponent(Graphics gDC)
    {
        super.paintComponent(gDC);
		
		int w=getWidth();
		int h=getHeight();	
		
		
		AVLtree nr=new AVLtree();

//		for(int i=0; i<40;i++)
//			nr.insert((int)(Math.random()*99));

		nr.insert(8);

		nr.insert(4);
		nr.insert(2);
		nr.insert(1);
		nr.insert(3);
		nr.insert(6);
		nr.insert(5);
		nr.insert(7);
		
		nr.insert(12);
		
		nr.insert(10);
		nr.insert(9);
		nr.insert(11);
		nr.insert(14);
		nr.insert(13);
		nr.insert(15);
		
		nr.delete(4);
			
		nr.draw(gDC);
//		nr.draw2(gDC);
			
    }
}
							
// ====================================================== //

}

class Stock // used in ratation and counting bf
{
	Item pHead;
	public Stock()
	{
		pHead=null;
	}
	public void push(TreeNode node)
	{
		if(pHead==null)
			pHead=new Item(node);
		else
		{
			Item x =new Item(node);
			x.next=pHead;
			pHead=x;
		}
	}
	public TreeNode front()
	{
		return pHead.node;
	}
	public void pop()
	{
		if(pHead!=null)
			pHead=pHead.next;
	}
}
class Item //used in Stock
{
	TreeNode node;
	Item next;
	public Item(TreeNode n)
	{
		node=n;
		next=null;
	}
}

class TreeNode // Nodes in AVLtree
{
	public TreeNode left,
			    right;
	public	int key, 
			    bf; //diffrence between height of left and right subtree

	public TreeNode(int x)
	{
		left=null;
		right=null;
		key=x;
		bf=0;
	}
	TreeNode getleft()
	{
		return left;
	}
	TreeNode getright()
	{
		return right;
	}
}
class AVLtree // AVL tree
{
	TreeNode head; // root of tree
	TreeNode y; // entered in search, used in insert
				// consist  of Treenode (retured by searched) father 
	int num=0; // number of inserted objects
	Stock stock; // used in rotation
	Stock stock2; // copy used in counting bf
	int rot=0; //used in rotation
				// shows which rotation has just been made
				// 0-no, 1-single, 2-double
	TreeNode rot2; //used in rotation
				// TreeNode which must be assigned a new father
	AVLtree()
	{
		head=null;
		y=null;	
		stock=new Stock();
		stock2=new Stock();
	}			
	TreeNode search(int par) //checks if parameter is in node
							 //if no returs place where a par. can be placed
	{
		TreeNode x = head;
		y=null;
		stock=new Stock();
		stock2=new Stock();
		while(x!=null && par!=x.key)
		{
			y=x;
			stock.push(y);
			stock2.push(y);
			
			if(par<x.key)
				x=x.getleft();
			else
				x=x.getright();
		}
		return x;
	}
	void insert(int par) // inserts parameter into AVLTree
	{
		Loop:
		while (true)
		{
			if (search(par)==null)
			{
				TreeNode x=new TreeNode(par);
				if (y==null)
					head=x;
				else
					if(par<y.key)
						y.left=x;
					else
						y.right=x;
				// ---------- counting bf ------------ //
				TreeNode t1=x;
				TreeNode t2=null;
				
				while (stock2.pHead!=null)
				{
					t2=stock2.front();
					if (t2.left==t1)
					{
						if (t2.bf<0 || t2.bf==1)
						{
							t2.bf++;
							break;
						}
						else 
						{
							t2.bf++;
						}
					}
					
					else
					{
						if (t2.bf>0 || t2.bf==-1)
						{
							t2.bf--;
							break;	
						}
						else
						{
							t2.bf--;
						}
					}
					t1=t2;		
					stock2.pop();
				}
		
				// --------- end of bf count --------- //
									
				num++; //increases displayed number of elements in TreeNode	

	          // --------------   rotation ------------ //
				if (stock.pHead==null)
					break Loop;
				
				TreeNode t=x;
				TreeNode z=stock.front();
				stock.pop();
				while (stock.pHead!=null)
				{
					y=stock.front();
					if (rot==1 || rot==2)
					{
						
						if(y.left==z)
							y.left=rot2;
						else
							y.right=rot2;
						rot=0;	
					}
					
					stock.pop();
					switch (y.bf)
					{
					
						case 2:
							{
								if(z.bf==1)
									sngRot(y,z);
								else
								{
									dblRot(y,z,t);
								}
								break;
							}
						case -2:
							{
								if(z.bf==-1)
									sngRot(y,z);
								else
								{
									dblRot(y,z,t);
								}
							break;
							}
					}		

					t=z;
					z=y;														
				}
				if (rot==1 || rot==2)
				{
					head=rot2;
					rot=0;
				}
				break Loop;	
	          // -------- end of rotation ------------ //
			}
			break Loop;
		}				
	}
		public void sngRot(TreeNode y, TreeNode z) //Single rotation
		{
			if (y.bf==2 && z.bf==1)
			{
				y.left=z.right;
				z.right=y;
			}
			else
			{
				if (y.bf==-2 && z.bf==-1)
				{
					y.right=z.left;
					z.left=y;
				}
				else
				{
					System.out.println("error1");
				}
				
			}
			z.bf=0;
			y.bf=0;	
			rot=1;	
			rot2=z;
	}
	public void dblRot(TreeNode y, TreeNode z, TreeNode t) //Double rotation
	{
		if (y.bf==2 && z.bf==-1)
		{
			y.left=t.right;
			z.right=t.left;
			t.left=z;
			t.right=y;
			if (t.bf==-1)
			{
				z.bf=1;
				y.bf=0;
			}
			else
			{
				if (t.bf==1)
				{
					z.bf=0;
					y.bf=-1;
				}
				else
				{
					z.bf=0;
					y.bf=0;
				}
			}
			t.bf=0;
	
		}
		else
		{
			if (y.bf==-2 && z.bf==1)
			{
				y.right=t.left;
				z.left=t.right;
				t.right=z;
				t.left=y;
				if (t.bf==-1)
				{
					z.bf=0;
					y.bf=1;
				}
				else
				{ 
					if (t.bf==1)
					{
						z.bf=-1;
						y.bf=0;
					}
					else
					{
						z.bf=0;
						y.bf=0;
					}
				}
			t.bf=0;
			}
			else
			{
				System.out.println("error2");
			}
		}
		rot=2;
		rot2=t;

	}			
	void delete(int par) //this ver. doesn't change bf
	{
		TreeNode x,z,t;
		x=search(par);
		if (x!=null)
		{
			if (x.left==null || x.right==null)
			{
				if(x.left==null && x.right==null)
					z=null;
				else
					if (x.left==null)
						z=x.right;
					else
						z=x.left;
				if(y==null)
					head=z;
				else
					if(x==y.left)
						y.left=z;
					else
						y.right=z;
			}	
			else
			{
				z=x.left;
				if(z.right==null)
					x.left=z.left;
				else
				{
					do
					{
						t=z;
						z=z.right;
					}
					while(z.right!=null);
					t.right=z.left;
				}
				x.key=z.key;
				
			}
			
		}
		
	}
	
	void show() // prints sorted elements of tree
	{
		if(head!=null)
			show(head);
	}
	void show(TreeNode var)
	{
		if(var.left!=null)
			show(var.left);
//		System.out.println(var.key);
		if(var.right!=null)
			show(var.right);
	}	
		
	void draw(Graphics gDC) //displays tree with bf
	{
		if (head!=null)
			{
			int x=300,
				y=70,
				size=130;
				
			Font font = new Font("Arial", Font.BOLD, size/2+7);
			String s="number of objects="+num;
			gDC.drawString(s,50,50);
			
			gDC.setFont(font);
			s="("+head.bf+") "+head.key;
			FontMetrics mtx = gDC.getFontMetrics();
			gDC.drawString(s,x-mtx.stringWidth(s)/2,y+mtx.getAscent());	
			if (head.left!=null)
			{
				gDC.drawLine(x,y+mtx.getAscent()+mtx.getDescent(),x-size,y+mtx.getAscent()+size/2);
				draw(gDC,head.left,x-size,y+mtx.getAscent()+size/2,size/2);
			}
			if (head.right!=null)
			{
				gDC.drawLine(x,y+mtx.getAscent()+mtx.getDescent(),x+size,y+mtx.getAscent()+size/2);
				draw(gDC,head.right,x+size,y+mtx.getAscent()+size/2, size/2);	
			}
		}
	}
	void draw(Graphics gDC, TreeNode par,int x, int y, int size)
	{
		Font font = new Font("Arial", Font.BOLD, size/2+7);
		gDC.setFont(font);
		String s="("+par.bf+") "+par.key;
		FontMetrics mtx = gDC.getFontMetrics();
		gDC.drawString(s,x-mtx.stringWidth(s)/2,y+mtx.getAscent());	
		if (par.left!=null)
		{
			gDC.drawLine(x,y+mtx.getAscent()+mtx.getDescent(),x-size,y+mtx.getAscent()+size/2);
			draw(gDC,par.left,x-size,y+mtx.getAscent()+size/2,size/2);
		}
		if (par.right!=null)
		{
			gDC.drawLine(x,y+mtx.getAscent()+mtx.getDescent(),x+size,y+mtx.getAscent()+size/2);
			draw(gDC,par.right,x+size,y+mtx.getAscent()+size/2,size/2);	
		}
	
	
	
	}
	void draw2(Graphics gDC) //displays tree 
	{
		if (head!=null)
			{
			int x=300,
				y=0,
				size=120;
				
			Font font = new Font("Arial", Font.BOLD, size);
			String s="number of objects="+num;
			gDC.drawString(s,50,50);
			
			gDC.setFont(font);
			s=""+head.key;
			FontMetrics mtx = gDC.getFontMetrics();
			gDC.drawString(s,x-mtx.stringWidth(s)/2,y+mtx.getAscent());	
			if (head.left!=null)
			{
				gDC.drawLine(x,y+mtx.getAscent(),x-size,y+mtx.getAscent()+size/2);
				draw2(gDC,head.left,x-size,y+mtx.getAscent()+size/2,size/2);
			}
			if (head.right!=null)
			{
				gDC.drawLine(x,y+mtx.getAscent(),x+size,y+mtx.getAscent()+size/2);
				draw2(gDC,head.right,x+size,y+mtx.getAscent()+size/2,size/2);	
			}
		}
	}
	void draw2(Graphics gDC, TreeNode par,int x, int y, int size)
	{
		Font font = new Font("Arial", Font.BOLD, size);
		gDC.setFont(font);
		String s="";
		s+=par.key;
		FontMetrics mtx = gDC.getFontMetrics();
		gDC.drawString(s,x-mtx.stringWidth(s)/2,y+mtx.getAscent());	
		if (par.left!=null)
		{
			gDC.drawLine(x,y+mtx.getAscent(),x-size,y+mtx.getAscent()+size/2);
			draw2(gDC,par.left,x-size,y+mtx.getAscent()+size/2,size/2);
		}
		if (par.right!=null)
		{
			gDC.drawLine(x,y+mtx.getAscent(),x+size,y+mtx.getAscent()+size/2);
			draw2(gDC,par.right,x+size,y+mtx.getAscent()+size/2,size/2);	
		}
	
	
	
	}
	
}