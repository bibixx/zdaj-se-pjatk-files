// Szkielet aplikacji kontekstowej

package jbPack; 

import javax.swing.*;
import java.awt.*;

import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.text.*;

import java.awt.geom.*;
import java.awt.image.*;
import java.awt.font.*;
import java.net.*;
import java.util.zip.*;
import java.lang.reflect.*;
import java.applet.*;

import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.tree.*;
import java.beans.*;

public
class Program
    extends Context {
        
    public static void main(String[] args)
    {
        new Program();       
    }    

// ====== pod-aplikacja" ================================= //

public
class ContentPane 
    extends Content {
    
    public ContentPane()
    {
    }

    public void initPane()
    {
    }
    
    public void initFocus()
    {
    }
    
    public void paintComponent(Graphics gDC)
    {
        super.paintComponent(gDC);
    }
}

// ====================================================== //

}
