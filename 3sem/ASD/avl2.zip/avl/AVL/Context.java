// Klasy Context i Content
//              2000.07.01

package jbPack;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public
class Context
    extends JFrame {
            
    private static final 
        String caption = "Swing Application";  // tytu�        
    public static final 
        int width = 600, height = 500;        // rozmiary
    public static final 
        Point location = new Point(150, 150); // po�o�enie    
    private String lookAndFeel =              // wygl�d
        UIManager.getSystemLookAndFeelClassName();    
//      UIManager.getCrossPlatformLookAndFeelClassName();
// "com.sun.java.swing.plaf.windows.WindowsLookAndFeel"; // Win32
// "com.sun.java.swing.plaf.motif.MotifLookAndFeel";     // Unix
// "com.sun.java.swing.plaf.mac.MacLookAndFeel";         // MacOS
          
    private Program.ContentPane contentPane;
    
    public Context()
    {
            // okre�lenie napisu na pasku tytu�owym
        setTitle(caption);
        
           // uniemo�liwienie zmiany rozmiar�w okna
        setResizable(false);

            // okre�lenie wygl�du aplikacji
        try {
            UIManager.setLookAndFeel(lookAndFeel);
        }
        catch(Exception e) {
        }        
        
            // utworzenie odno�nika do pulpitu               
        contentPane = (Program.ContentPane)
                      ((Program)this).new ContentPane();

            // wymiana domy�lnego pulpitu na w�asny
        setContentPane(contentPane);

            // okre�lenie po�o�enia okna 
        setLocation(location);    
        
            // okre�lenie rozmiar�w pulpitu            
        JComponent jContent = (JComponent)contentPane;
        jContent.setPreferredSize(
            new Dimension(width, height)
        );
        
            // okre�lenie koloru t�a okna i pulpitu
        setBackground(Color.white);                
        contentPane.setBackground(Color.white);
                
            // obs�uga p-tr�j-klikni�cia         
        contentPane.addMouseListener(
            new MouseAdapter() {
                public void 
                mouseReleased(MouseEvent evt)
                {
                    if (evt.isPopupTrigger() && 
                        evt.getClickCount() == 3) {
                        String data =
                            JOptionPane.showInputDialog(
                                "Enter data"
                            );
                        if(data != null)
                            Context.this.sendData(data);
                    }
                }
            }
        );        

            // obs�uga zamkni�cia okna            
        addWindowListener(
            new WindowAdapter() {
                public void
                windowClosing(WindowEvent evt)
                {
                    System.exit(0);
                }
            }
        );   
        
            // upakowanie okna
        pack();
        
            // wywo�anie funkcji initPane
        contentPane.initPane();

            // wy�wietlenie okna
        show();
   
            // naczelne wymaganie Swinga
        SwingUtilities.invokeLater(
            new Runnable() {
                public void run()
                {            
                        // nastawienie celownika na pulpit
                    contentPane.requestFocus();       

                        // wywo�anie funkcji initFocus
                    contentPane.initFocus();        
                }
            }
        );
    }   
    
    // =========== klasa Content
    
    class Content 
        extends JPanel {

        public Content()
        {        
                // okre�lenie sposobu buforowania 
            RepaintManager.currentManager(contentPane).
                setDoubleBufferingEnabled(true);
        }        
                  
        public void initPane()
        {
        }
    
        public void initFocus()
        {        
        }
           
        public void dataEntered()
        {
            beep();
        }  
    
        public void dataEntered(int data)
        {
            dataEntered("" + data);
        }
               
        public void dataEntered(String data)
        {
            beep();
        }    
    
        public void dataEntered(int[] data) 
        {
            if(data.length == 1)
                dataEntered(data[0]);
            else {
                int count = data.length;
                String[] strings = new String [count];
                for(int i = 0; i < count ; i++)
                    strings[i] = "" + data[i];
                dataEntered(strings);
            }
        }
    
        public void dataEntered(String[] data)
        {        
            String string = "";
            int count = data.length;
            for(int i = 0; i < count ; i++)
                string += data[i] + ' ';
            dataEntered(string);
        }   
    
        protected String console = "";      
    
        public void print(String string)
        {
            if(string == null)
                console = "";
            System.out.print(string);
            console += string;
        }
        
        public void println(Object object)
        {
            print(object + "\n");
        }
            
        public void println(long value)
        {
            println("" + value);
        }
        
        public void println(boolean value)
        {
            println("" + value);
        }
        
        public void println()
        {
            println("");
        }    

        public String getData(String value)
        {    
            return (String)JOptionPane.
                   showInputDialog(
                       null, "Enter string", 
                       "Input dialog", 
                       JOptionPane.PLAIN_MESSAGE, 
                       null, null, value
                   );
        }
    
        public String getData()
        {
            return getData("");
        }
    
        public void showResult(String string)
        {
            JOptionPane.showMessageDialog(null, string);
        }
    
        public void showConsole()
        {
            showResult(console);
        }
    
        public void beep()
        {
            Toolkit.getDefaultToolkit().beep();
        }       
    
        public void sleep(int timeMillis)
        {
            try {
                Thread.sleep(timeMillis);
            }
            catch(InterruptedException e) {}
        }
    }

    // =========== analiza i wys�anie danych =========== //
    
    public String[] strings;
    public int[]    numbers;
    public String   string;    
    public boolean  isNumeric;
    
    public String[] parseData(String data)
    {
        data = data.trim();    
        if(data.equals(""))
            return new String[0];
        StringTokenizer tokens = 
            new StringTokenizer(data);
        int count = tokens.countTokens(), i = 0;
        isNumeric = true;        
        strings = new String[count];
        numbers = new int[count];
        while(tokens.hasMoreElements()) {
           String token = tokens.nextToken();
           strings[i] = token;
           try {
               numbers[i++] = Integer.parseInt(token);
           }
           catch(NumberFormatException e) {
               isNumeric = false;
           }           
        }
        return strings;
    }        
        
    public final void sendData(String data)
    {
        string = data.trim();        
        if(parseData(string).length == 0)
            contentPane.dataEntered();
        else if(isNumeric)
            contentPane.dataEntered(numbers);
        else
            contentPane.dataEntered(strings);
    }    
}
