import java.awt.*;
import java.awt.event.*;
import java.applet.*;
//import AVLTree;

public class AVLTreeDemo extends Applet {
    AVLTreeNodeCanvas canvas;

    public void init() {
		setLayout (new BorderLayout ());
		canvas = new AVLTreeNodeCanvas(500, 500);
		add ("Center", canvas);
    }

    public void destroy() {
        remove(canvas);
    }

    public void processEvent(AWTEvent e) {
        if (e.getID() == Event.WINDOW_DESTROY) {
            System.exit(0);
        }
    }

    public static void main(String args[]) {
		Frame f = new Frame("AVLTree Demonstration");
		AVLTreeDemo treeDemo = new AVLTreeDemo();

		treeDemo.init();

		f.add("Center", treeDemo);
		f.setSize(500, 500);
		f.show();
    }

    public String getAppletInfo() {
        return "A demonstration of an AVLTree.";
    }
}

class AVLTreeNodeCanvas extends Panel implements ActionListener {
    TextField userInput = new TextField ("", 15);
    Label messageLabel = new Label ("Enter a number and add it onto the tree");
	AVLTree tree = new AVLTree ();
	int m_iWidth, m_iHeight;

    public AVLTreeNodeCanvas(int iWidth, int iHeight) {
		Button b;

		add(messageLabel);
		add(userInput); 

		b = new Button("Add");
		b.addActionListener(this);
		add(b);

		m_iWidth = iWidth;
		m_iHeight = iHeight;
    }

    public void paint(Graphics g) {
		FontMetrics fm = g.getFontMetrics ();
		int iHeight;
		iHeight = fm.getHeight () + fm.getLeading();
		if (tree != null)
			tree.Draw (g, m_iWidth / 2, 0, m_iWidth, 1, 66, 2 * iHeight);
    }

    public void actionPerformed(ActionEvent ev) {
		String label = ev.getActionCommand();

		if (label.equals("Add")) {
			try {
				tree.Insert(Integer.parseInt (userInput.getText ()));
			} catch (NumberFormatException e) {
				messageLabel.setText ("Enter a NUMBER and add it onto the tree");
			}
		}

		repaint ();
    }
}

class TreeException extends RuntimeException {
	public TreeException (String s) {
		super (s);
	}

	public TreeException () {
		super ();
	}
}

class AVLNode {
	int m_iElement;
	int m_iBalance;

	static final int LEFTHIGH = 0;
	static final int BALANCED = 1;
	static final int RIGHTHIGH = 2;

	AVLNode m_Left;
	AVLNode m_Right;

	AVLNode(int iElement) {
		m_iElement = iElement;
		m_iBalance = BALANCED;

		m_Left = null;
		m_Right = null;
	}
	
	Point Draw(Graphics g, int parentx, int left, int iTotWidth, int iDepth, int iHeight, int iSep) {
		Point pos = new Point (parentx + (left * (iTotWidth / iDepth) / 2), iHeight);
		Point posl, posr;

		iDepth *= 2;

		if (m_Left != null) {
			posl = m_Left.Draw (g, pos.x, -1, iTotWidth, iDepth, iHeight + iSep, iSep);
			g.drawLine (pos.x, pos.y, posl.x, posl.y);
		}

		if (m_Right != null) {
			posr = m_Right.Draw (g, pos.x, 1, iTotWidth, iDepth, iHeight + iSep, iSep);
			g.drawLine (pos.x, pos.y, posr.x, posr.y);
		}

		g.drawString ("" + m_iElement, pos.x, pos.y);

		return pos;
	}
}

class AVLTree {
	private AVLNode m_Root;
	private boolean m_bTaller;

	AVLTree()
	{
		m_Root = null;
		m_bTaller = false;
	}

	void Insert(int iElement)
	{
		m_Root = Insert (m_Root, iElement);
	}

	AVLNode Insert(AVLNode Tree, int iElement)
	{
		if (Tree == null) {
			Tree = new AVLNode (iElement);
			m_bTaller = true;
		} else if (iElement < Tree.m_iElement) {
			Tree.m_Left = Insert (Tree.m_Left, iElement);
			if (m_bTaller) {
				switch (Tree.m_iBalance) {
				case AVLNode.LEFTHIGH:
					try {
						Tree = LeftBalance (Tree);
					} catch (TreeException e) {
					}
				break;
				case AVLNode.BALANCED:
					Tree.m_iBalance = AVLNode.LEFTHIGH;
					break;
				case AVLNode.RIGHTHIGH:
					Tree.m_iBalance = AVLNode.BALANCED;
					m_bTaller = false;
					break;
				}
			}
		} else if (iElement > Tree.m_iElement){
			Tree.m_Right = Insert (Tree.m_Right, iElement);
			if (m_bTaller) {
				switch (Tree.m_iBalance) {
				case AVLNode.RIGHTHIGH:
					try {
						Tree = RightBalance (Tree);
					} catch (TreeException e) {
					}
					break;
				case AVLNode.BALANCED:
					Tree.m_iBalance = AVLNode.RIGHTHIGH;
					break;
				case AVLNode.LEFTHIGH:
					Tree.m_iBalance = AVLNode.BALANCED;
					m_bTaller = false;
					break;
				}
			}
		}
		return Tree;
	}

	AVLNode LeftBalance(AVLNode Tree)
	{
		AVLNode LeftSub = Tree.m_Left, RightSub;
	
		switch (LeftSub.m_iBalance) {
		case AVLNode.LEFTHIGH:
			Tree.m_iBalance = LeftSub.m_iBalance = AVLNode.BALANCED;
			Tree = RotateRight (Tree);
			m_bTaller = false;
			break;
		case AVLNode.BALANCED:
			throw new TreeException ("AVL Tree Error: tree already balanced.");
		case AVLNode.RIGHTHIGH:
			RightSub = LeftSub.m_Right;
			switch (RightSub.m_iBalance) {
			case AVLNode.LEFTHIGH:
				Tree.m_iBalance = AVLNode.RIGHTHIGH;
				LeftSub.m_iBalance = AVLNode.BALANCED;
				break;
			case AVLNode.BALANCED:
				Tree.m_iBalance = LeftSub.m_iBalance = AVLNode.BALANCED;
				break;
			case AVLNode.RIGHTHIGH:
				Tree.m_iBalance = AVLNode.BALANCED;
				LeftSub.m_iBalance = AVLNode.LEFTHIGH;
				break;
			}
			RightSub.m_iBalance = AVLNode.BALANCED;
			Tree.m_Left = RotateLeft (LeftSub);
			Tree = RotateRight (Tree);
			m_bTaller = false;
		}
		return Tree;
	}

	AVLNode RightBalance(AVLNode Tree)
	{
		AVLNode RightSub = Tree.m_Right, LeftSub;
	
		switch (RightSub.m_iBalance) {
		case AVLNode.RIGHTHIGH:
			Tree.m_iBalance = RightSub.m_iBalance = AVLNode.BALANCED;
			Tree = RotateLeft (Tree);
			m_bTaller = false;
			break;
		case AVLNode.BALANCED:
			throw new TreeException ("AVL Tree Error: tree already balanced.");
		case AVLNode.LEFTHIGH:
			LeftSub = RightSub.m_Right;
			switch (LeftSub.m_iBalance) {
			case AVLNode.RIGHTHIGH:
				Tree.m_iBalance = AVLNode.LEFTHIGH;
				RightSub.m_iBalance = AVLNode.BALANCED;
				break;
			case AVLNode.BALANCED:
				Tree.m_iBalance = RightSub.m_iBalance = AVLNode.BALANCED;
				break;
			case AVLNode.LEFTHIGH:
				Tree.m_iBalance = AVLNode.BALANCED;
				RightSub.m_iBalance = AVLNode.RIGHTHIGH;
				break;
			}
			LeftSub.m_iBalance = AVLNode.BALANCED;
			Tree.m_Right = RotateRight (RightSub);
			Tree = RotateLeft (Tree);
			m_bTaller = false;
		}
		return Tree;
	}

	AVLNode RotateLeft(AVLNode Tree)
	{
		AVLNode NewTree = Tree.m_Right;
		Tree.m_Right = NewTree.m_Left;
		NewTree.m_Left = Tree;
		return NewTree;
	}

	AVLNode RotateRight(AVLNode Tree)
	{
		AVLNode NewTree = Tree.m_Left;
		Tree.m_Left = NewTree.m_Right;
		NewTree.m_Right = Tree;
		return NewTree;
	}

	void Draw(Graphics g, int parentx, int left, int iTotWidth, int iDepth, int iHeight, int iSep)
	{
		if (m_Root != null)
			m_Root.Draw (g, parentx, left, iTotWidth, iDepth, iHeight, iSep);
	}
	
}