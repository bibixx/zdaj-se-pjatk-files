import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.io.*;

import java.net.*;
import java.text.*; 

public 
class QuickSort
{

	int [] tab;
	
	long start;
	long stop;
//	start = System.currentTimeMillis();		
	public static void main(String[] args)
	{	
		new QuickSort();
	
	}
	public  QuickSort()
	{	
		Tablica(100);
		int j;
	}

	public int partition(int [] a,int l, int p)
	{
	   	int b = 0,
			x = a[p], 
		    i = l,
			j = p;
		while (true)
		{
			while (a[j] > x) 
			{
				j--;
			}
			while (a[i] < x)
			{
				i++;
			}
			if (i < j)	
			{
				b = a[i];
				a[i] = a[j];
				a[j] = b;
			}
			else
			{
				b = a[0];
				a[0] = a[j];
				a[j] = b;
				return a[j];
				
			}
		}		
	}

	public void Tablica(int p)
	{
		tab = new int[p];
		for (int a = 0; a < p; a++)	{
			tab[a] = (int)(Math.random() * 100);
		}
				
	}
		
	
}
