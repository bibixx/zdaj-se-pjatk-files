import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.io.*;

import java.net.*;
import java.text.*; 

public 
class InsertionSort
{

	int [] tab;
	long start;
	long stop;
		
	public static void main(String[] args)
	{	
		new InsertionSort();
	}

	public InsertionSort()
	{
		int obr1 = 0,
			obr2 = 0,
			i    = 0,
			j    = 0,
			x    = 0;
		Tablica(10000);
		
		start = System.currentTimeMillis();		
		for( i = 0; i < tab.length; i++)
		{
			obr1++;
			j = i;
			x = tab[i];
			while ( (j > 0) && (tab[j - 1] > x) ) {
				tab[j] = tab[j - 1];
				j--;
				obr2++;
			}
			tab[j] = x;
		}
		stop = System.currentTimeMillis();
		
		System.out.print("Tablica: ");
		for ( int a = 0; a < tab.length; a++)
		{
			System.out.print(tab[a] + " ");
		}
		
		System.out.println();
		System.out.println("Obroty: " + (obr1 + obr2));
		System.out.println("Czas: " + (stop - start));
				
	}
			
	public void Tablica(int p)
	{
		tab = new int[p];
		for (int a = 0; a < p; a++)	{
			tab[a] = (int)(Math.random() * 100);
		}
				
	}
}
	