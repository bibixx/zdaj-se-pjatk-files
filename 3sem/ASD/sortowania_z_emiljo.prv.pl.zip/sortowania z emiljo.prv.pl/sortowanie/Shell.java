import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.io.*;

import java.net.*;
import java.text.*; 

public 
class Shell
{

	int [] tab;
	int [] qwe;
	long start;
	long stop;
	int obr = 0;
	public static void main(String[] args)
	{	
		new Shell();
	}
	
	public Shell()
	{
		start = System.currentTimeMillis();		
		Tablica(5000);
		InShell(10);
		stop = System.currentTimeMillis();		
		System.out.println("Elementow: " + tab.length);
		System.out.println("Obrotow: " + obr);
		System.out.println("Czas: " + (stop - start));
	}
	
	
	public void InShell(int h)
	{
		int x = 0;
		if (h > 0) 
		{
			qwe = new int[tab.length / h];
			
			for (int j = 0; j < h ; j++)
			{
				obr++;
				x = j;		
				for(int i = 0; i < qwe.length; i++)
				{
					qwe[i] = tab[j];
					j = j + h;
				
				}
				InsertionSort(qwe);
				j = x;
				for(int i = 0; i < qwe.length; i++)
				{
					tab[j] = qwe[i];
					j = j + h;
				
				}
				j = x;
				
			}
					
			InShell(h / 2);
		
		}
		
	}
	
	public void InsertionSort(int [] abc)
	{
		int i    = 0,
			j    = 0,
			x    = 0;

		for( i = 0; i < abc.length; i++)
		{
			j = i;
			x = abc[i];
			while ( (j > 0) && (abc[j - 1] > x) ) {
				abc[j] = abc[j - 1];
				j--;
			}
			abc[j] = x;
		}
	
	}
			
	public void Tablica(int p)
	{
		tab = new int[p];
		for (int a = 0; a < p; a++)	{
			tab[a] = (int)(Math.random() * 100);
		}
				
	}

}