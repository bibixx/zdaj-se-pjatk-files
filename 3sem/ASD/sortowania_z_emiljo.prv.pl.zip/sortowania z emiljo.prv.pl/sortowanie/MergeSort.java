import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.io.*;

import java.net.*;
import java.text.*; 


public 
class MergeSort
{

	int [] tab;
	long start;
	long stop;
	start = System.currentTimeMillis();				
	public static void main(String[] args)
	{	
		new MergeSort();
	}

	public MergeSort()
	{
	
	}
 
	public void Scal(int le, int sr, int pr, IntCiag c){ 
		int i = le; 
		int j = sr+1; 
		int k = -1; 
		int[] b = new int[pr-le+1]; 
		
		while ((i <= sr) && (j <= pr) ){ 
			k++; 
			
			if (c.ciag[i] <= c.ciag[j]){ 
				i++; 
			} else { 
				b[k] = c.ciag[j]; 
				j++; 
			} 
		}
		 
		if (i <= sr){ 
			for (j = pr; j > le+k; j--){ 
				c.ciag[j] = c.ciag[sr]; 
			sr--; 
			} 
		} 
		for (i = 0; i <= k; i++) 
		c.ciag[le+i] = b[i]; 
	}
	 
	public void SortujRek(int le, int pr, IntCiag c){ 
		int sr = (le+pr)/2; 
		if (le < sr) 
		
		SortujRek(le,sr,c); 
		if ((sr+1) < pr) 
		SortujRek(sr+1,pr,c); 
		Scal(le,sr,pr,c); 
	}
	 
	public void Sortuj(IntCiag c){ 
		if (c.ciag.length >= 2) 
			SortujRek(0,c.ciag.length-1,c); 
		} 
	
	public void Tablica(int p)
	{
		tab = new int[p];
		for (int a = 0; a < p; a++)	{
			tab[a] = (int)(Math.random() * 100);
		}
				
	}
}

//public 
class IntCiag{ 
	int[] ciag; 
	
	public IntCiag(int dl){ 
		ciag = new int[dl]; 
	}
} 