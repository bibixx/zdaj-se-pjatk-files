# include <stdio.h>
# include <conio.h>


void countsort( long [], long );
 int Wejscie  ( long [], int  );
void Wyswietl ( long [], int  );

/*------------MAIN-----------------------*/
void main()
{	const N=100;
	const Z=10000;
	int n=10;
	long tab[N];
	n = Wejscie(tab, N);	// Wejscie + Ilosc danych

	Wyswietl(tab,n);
	countsort(tab,n);
	Wyswietl(tab,n);
	scanf("%d", n);
}
/*------------WEJSCIE--------------------*/
Wejscie(long tab[], int N)
{	printf("Use: 'Space Bar'(Next Value), 'Back Del', 'Enter'\n");
	printf("	\n");
	
	printf("\nENTER VALUES (Up to 10000 and %d values)\n",N);
	int zn,pot=1,i=0;
	long licz=0;
	
	while( zn !=13 ){
		zn=getch();
		if( zn>47 && zn<58 ){
			licz = (licz*10) + (zn-48);
			printf("\r%ld", licz);
		}
		if (zn == 8 ){ licz = int(licz/10);printf("%c", 8);}
		if( zn ==32 || zn==13 ){
			printf("  Element Nr %d", i);
			tab[i]=licz; i++ ;licz=0 ;printf("\n");
		}
	}
	printf("\n");
	return i;
}
/*------------WYSWIETL-------------------*/
void Wyswietl( long tab[], int n )
{
	printf("TABLICA WARTOSCI:\n");
	for(int k=0;k<n;k++) printf(" %d", k);
	printf("\n");
	for(k=0;k<n;k++) printf(" %d",tab[k]);
	printf("\n");

}



/*------------COUNTSORT------------------*/
void countsort( long tab[], long n)
{
	long i=0, p, max=0;
	long temp [100];
	long count[10000]={0};
	char jak='m', zn;
	
	printf("\nWybierz jak mam sortowac? (Klawisz 'c', 'ENTER' )\n");
	printf("\r   Tabela bedzie sortowana MALEJACO");
	while( zn !=13 ){
		zn=getch();
		if(zn==99 || zn==67){
			if(jak=='r'){ jak='m'; printf("\r   Tabela bedzie sortowana MALEJACO");}
			else if (jak=='m'){ jak='r'; printf("\r   Tabela bedzie sortowana ROSNACO ");}
		}
	} printf("\n");
	
	   //Analiza Tablicy------
	while( tab[i]<= tab[i+1] && (i<n) ) i++;
	if(i==n-1) printf("\nTABLICA BYLA JUZ POSORTOWANA (rosnaco lub malejaco)\n");
	for(i=0;i<n;i++) if(tab[i]>max) max=tab[i];
	printf("Maximum w tej tablicy wynosi %ld \n", max );
	   //---------------------
	for(i=0;i<n;i++) temp[i]=tab[i]; //KOPIOWANIE WARTOSCI do temp-a
		
	for(i=0;i<n;i++) count[ tab[i] ]++; //ZLICZANIE ELEMENTOW
	
	if(jak=='r')   for(i=1;i<max+1;i++) count[i] += count[i-1];		     //SUMOWANIE ROSNACO
	else		   for(i=max;i>=0;i--) count[i-1] =count[i-1]+ count[i]; //SUMOWANIE MALEJACO
		
	for(i=n-1;i>=0;i--){
		p=tab[i];
		count[p]--;
		temp[ count[p] ] = p;
	}
	
	for(i=0;i<n;i++) { tab[i]=temp[i];  }     //KOPIOWANIE DO TABLICY Z POWROTEM
	
	printf("\nTablica zostala posortowana\n"); 
}














