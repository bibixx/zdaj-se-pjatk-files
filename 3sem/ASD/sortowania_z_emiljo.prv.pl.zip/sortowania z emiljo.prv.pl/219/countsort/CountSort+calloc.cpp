# include <stdio.h>
# include <conio.h>		//getch()
# include <stdlib.h >	//calloc
# include <time.h>		//clock()
# include <iostream.h>	//cout

void ZNS			( int	 , char []  );		/*Zamien 'int' na 'char[11]'*/ 
void countsort		( long [], long 	);		/*sortowanie malejace i rosnace*/
 int Wejscie		( long [], int 		);		/*Pojedyncze wejscie wartosci w 'Tab[]'*/
 int RozmiarTab		( int				);		/*Wejscie rozmiaru 'Tab[n]'*/
void GeneLos		( long [], int 		);		/*Generowanie liczb od 0 do 32727*/
void Wyswietl		( long [], int		);
void Zmierzenie		( clock_t, clock_t, clock_t, int	);	/*Zapisanie wynikow testow 
															/*				do pliku.txt  */
/*------------MAIN-----------------------*/							
void main()
{	
	int n=0,zn=0;

	n=RozmiarTab( n );
	printf("\nalokacja pamieci...");
	long *tab;
	tab =  (long*) calloc(n, sizeof(long));
	printf("zakonczona\n");
	
	printf("\nCzy komputer ma  wygenerowac losowo integery od 0 do 32727 ? (Klawisz 't','n')\n");
	while( zn!=84 && zn!=116 && zn!=78 && zn!=110 ){
		zn=getch();
		if(zn==84 || zn==116) GeneLos(tab,n);
		if(zn==78 || zn==110) n=Wejscie(tab,n);// Wejscie + Ilosc danych wypelnionych
	}
	
	//Wyswietl(tab,n);
	countsort(tab,n);

	zn=0;
	printf("\nCzy chcesz wyswietlic tablice posortowana? (Klawisz 't','n')\n");
	while( zn!=84 && zn!=116 && zn!=78 && zn!=110 ){
		zn=getch();
		if(zn==84 || zn==116) Wyswietl(tab,n);
	}
	
	scanf("%n", &n);
}
/*------------WEJSCIE--------------------*/
Wejscie(long tab[], int n)
{	
	int zn,i=0;
	printf("\nUse: 'Space Bar'(Next Value), 'Back Del', 'Enter'\n");
	
	printf("ENTER VALUES ( do %d wartosci)\n",n);
	i=0; zn=0;
	long licz=0;
	
	while( zn !=13 && i<n ){
		zn=getch();
		if( zn>47 && zn<58 ){
			licz = (licz*10) + (zn-48);
			printf("\r%ld", licz);
		}
		if (zn == 8 ){
			licz = int(licz/10);
			if (n<3) n=2;
			printf("\r%ld        ", licz);
		}
		if( zn ==32 || zn==13 ){
			printf("\r%ld  Element Nr %d",licz ,i);
			tab[i]=licz; i++ ;licz=0 ;printf("\n");
		}
		
	}
	printf("\n");
	return i;
}
/*------------RozmiarTab------------------*/
int RozmiarTab	( int n  )
{
	int zn;
	printf("\r Podaj Rozmiar Tablicy ( n elementowa ): 2" );
	
	while( ( zn=getch() ) != 13 ){
		if (zn>47 && zn<58){
			n=(n * 10) + (zn-48);
			if(n<0) zn=8;
			printf("\r Podaj Rozmiar Tablicy ( n elementowa ): %d", n );

		}
		if (zn==8) { n=0;printf("\r Podaj Rozmiar Tablicy ( n elementowa ): 2          " );}
	}
	if(n<3) {n=2;printf("\n Rozmiar Tablicy zostal zmieniony na %d\n", n );}
	
	
	return n;
}

/*------------GeneLos--------------------*/
void GeneLos( long tab[], int n)
{
	printf("generowanie liczb losowych...");
	for(int k=0;k<n;k++)tab[k]=rand();
	printf("zakonczone.\n");
}
/*------------WYSWIETL--------------------*/
void Wyswietl( long tab[], int n )
{
	printf("TABLICA WARTOSCI:\n");
	//for(int k=0;k<n;k++) printf(" %d", k);
	printf("\n");
	for(int k=0;k<n;k++) printf(" %d",tab[k]);
	printf("\n");
}
/*------------COUNTSORT------------------*/
void countsort( long tab[], long n)
{	clock_t start,end ,sorting;	
	long i=0, p, max=0;
	
	printf("alokacja pamieci...");
	long *temp;
	temp = (long*) calloc(n, sizeof( long ));
	printf("zakonczona\n");
		
	char jak=' ', zn;
	
	printf("\nWybierz tryb sortowania? (Klawisz 'c')\n");
	while( zn !=13 || (zn==13 && jak==' ')) {
		zn=getch();
		if(zn==99 || zn==67){
			if(jak=='r' || jak==' '){ jak='m'; printf("\r   Tabela bedzie sortowana MALEJACO");}
			else if (jak=='m'){ jak='r'; printf("\r   Tabela bedzie sortowana ROSNACO ");}
		}
	} printf("\n");
	
		//----Analiza Tablicy------
	start=clock();
	printf("analyza tablicy...");
	
	while( tab[i]<= tab[i+1] && (i<n) ) i++;
	if(i==n-1){	printf("\nTABLICA JEST JUZ POSORTOWANA ROSNACO");
		if(jak=='r') goto END;
		printf("\nanalyza...");
	}
	i=0;
	while( tab[i] >= tab[i+1] && (i<n-1) ) i++;
	if(i==n-1){	printf("\nTABLICA JEST JUZ POSORTOWANA MALEJACO");
		if(jak=='m') goto END;
		printf("\nanalyza...");
	}
				/*MAKSYMUM*/
	for(i=0;i<n;i++) if(tab[i]>max) max=tab[i];
	
	printf("zakonczona\n");
	printf("Maximum w tej tablicy wynosi %ld \n", max );
		//-------------------------
	printf("alokacja pamieci...");
	long *count;
	count = (long*) calloc(max+1, sizeof( long ));
	printf("zakonczona\n");
	   
	printf("SORTOWANIE...");
	sorting=clock();
	for(i=0;i<n;i++) temp[i]=tab[i]; //KOPIOWANIE WARTOSCI do temp-a
		
	for(i=0;i<n;i++) count[ tab[i] ]++; //ZLICZANIE ELEMENTOW
		
	if(jak=='r'){ for(i=1;i<max+1;i++) count[i] += count[i-1]; }//SUMOWANIE ROSNACO
	else for(i=max;i>=0;i--) count[i-1] =count[i-1]+ count[i]; //SUMOWANIE MALEJACO
		
	for(i=n-1;i>=0;i--){
		p=tab[i];
		count[p]--;
		temp[ count[p] ] = p;
	}
	for(i=0;i<n;i++) { tab[i]=temp[i];  }
	printf("ZAKONCZONE.\n");
END:
	end=clock();
	Zmierzenie( start, end, sorting, n );
}
/*------------Zmierzenie------------------*/
void Zmierzenie( clock_t start, clock_t end, clock_t sorting, int n )
{
	cout << endl << "Czas="<< end-start << endl;
	char temp[13]="          ";
	FILE *f;

	double end2	 =(double) end		/ CLK_TCK;
	double start2	 =(double) start		/ CLK_TCK;
	double sorting2=(double) sorting	/ CLK_TCK;


	f=fopen("DATA.txt","a");
	fputs("\n",f);
	fputs("-------------------------- -----------\n",f);
	fputs( "Rozmiar Tablicy:               ",f);ZNS(n,temp);fputs(temp,f);
	fputs("\nFunkcja CountSort :            ",f);fprintf(f,"%f",(end2-start2));
	fputs("\n _Analyza + Alokacja count-a:  ",f);fprintf(f,"%f",(end2-start2-(end2-sorting2)));
	fputs("\n _Czas sortowania :	       ",f); fprintf(f,"%f",(end2-sorting2));
	//if(end-start>0){ fputs(" -> ",f);ZNS(int((end2-sorting2)*100/(end2-start2)),temp);fputs(temp,f);fputs("%",f);}
	//if(end-start>0){fputs("\nRozmiar Danych    ",f);
	//fputs("\n dzielony przez Czas Wykonania:",f);ZNS(int(n/(end-start)/10 -35),temp);fputs(temp,f);}
	
	fclose(f);
	printf("\nWyniki testu zostaly dodane do pliku DATA.txt\n");
}
/*------------ZNS-------------------------*/
void ZNS( int x, char temp[])
{
	int k=0;
	for(int i=11;i>=0;i--) temp[i]=' ';/*zerownia stringu*/
	i=11;
	do{
		temp[i] = 48+( x - (int(x/10)*10));
		x=x/10;i--;
		k++;if(k==3 && x>0) {k=0;temp[i]=',';i--; }
	}while (x>0);
	
}
