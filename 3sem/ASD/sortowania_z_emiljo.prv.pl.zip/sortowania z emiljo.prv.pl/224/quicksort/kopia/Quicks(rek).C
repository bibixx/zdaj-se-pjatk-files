#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#define Max1 6000

void Quicksort(long *a,int l,int r,int *li);
void run(long *t,int Max);
long *los();
int main(void)
{
    long t[Max1];
    long r;
    int i,x,w;      // i - ile razy uzylo funkcji QuickSort
    
    printf("Podaj ilosc elemento do posortowania: ");
	scanf("%d",&x);
	
	do{
    printf("Wybierz typ danych do sortowania:\n1 - Losowe\n2 - Posortowane rosnaco\n3 - Posortowane malejaco\n");
    scanf("%d",&w);
	}
    while((w!=1)&&(w!=2)&&(w!=3));
    if(w==1){
        for(i=0;i<x;i++){
            r=rand();
            t[i]=r;
        }
        run(t,x);
    }            
    if(w==2){
        for(i=0;i<x;i++)
            t[i]=i;
        run(t,x);
    }

    if(w==3){
        for(i=x-1;i<=0;i--)
            t[i]=i;
        run(t,x);
    }
  
    return 0;

}

void Quicksort(long *a,int l,int r,int *li)
{
    int i,j;
    long v,x;
    li[0]++;
    v=a[l];
    i=l;
    j=r+1;
    do{
        do
        i++;
        while((i<=r)&&(a[i]<v));
        do
        j--;
        while(a[j]>v);
        if(i<j){
            x=a[i];
            a[i]=a[j];
            a[j]=x;
        }
    }while(i<j);
    a[l]=a[j];
    a[j]=v;
    
    if(j-1>l)
    Quicksort(a,l,j-1,li);
    if(r>j+1)
    Quicksort(a,j+1,r,li);
    
}
void run(long *t,int Max)
{
    FILE *fw;
    int li[1]={0};
    double temp;
    clock_t start,end;  
    
	start = clock();        //poczatek mierzenia czasu
    Quicksort(t,0,Max,li);
    end = clock();          //koniec mierzenia czasu
     
	temp = (double)(end - start)/CLK_TCK;      //z time.h-dzielimy dla uzyskania wyniku w sekundach
    
	printf("Sortowanie dla %d liczb.\n",Max);
    printf("Czas wykonania funkcji QuicSort = %f s\n",temp);
    printf("Funkcja QuickSort zostala uzyta: %d razy.\n\n",li[0]);
     
    if ((fw = fopen("\\test.txt","w+"))==NULL) // zapis do pliku (w katalogu g��wnym bie��cego dysku)
        printf("Nie mozna otworzyc pliku\n");
    
    fprintf(fw,"Sortowanie dla %d liczb.\n",Max);
    fprintf(fw,"Czas wykonania funkcji QuicSort = %f s\n",temp);
    fprintf(fw,"Funkcja QuickSort zostala uzyta: %d razy.\n\n",li[0]);
}
   



