// Program sortujacy tablice zapisana w pliku
// Autorzy: Julita Mazik, Slawomir Brys
// Grupa: 229

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>

//=================================================================================================
// DEKLARACJE FUNKCJI
//=================================================================================================

void downheap(long *tab, int k, int n);
long deletemax(long *tab, int *n);
void construct(long *tab, int n);
void HeapSort(long *tab, int n);

long szukaj(FILE *file);
void laduj(FILE *file, long *tab);
void zapisz(FILE *file, long *tab, long count);
void kopiec();
void sort();

long fly_kopiec;
long fly = 0;

clock_t start, end;

//=================================================================================================
// FUNKCJA GLOWNA
//=================================================================================================

int main(int argc, char *argv[])
{
	long *tab, count;
    FILE *file;

    if(argc < 2) {
        printf("Muszisz podac nazwe pliku do posortowania\n");
        return 0;
    }

    file = fopen(argv[1], "r+");

    if(!file) {
        printf("Blad odczytu pliku!!!\n");
        return 0;
    }
    
    count = szukaj(file);
    tab = (long*)calloc(count+1,sizeof(long));
    laduj(file, tab);

    printf("Tablica ma %ld elementow.\n", count);
    fly_kopiec = count;
    
    printf("Sortowanie...  \n");

    start = clock();
	HeapSort(tab, count);
	end = clock();

    zapisz(file, tab, count);

    fclose(file);
    if(!file) {
        printf("Blad zapisu do pliku!!!\n");
        return 0;
    }
    
    printf("\nZakonczone pomyslnie w czasie %.3f sekund\n\n", (double)(end-start)/1000);

    return 0;
}

//=================================================================================================
// DEFINICJA FUNKCJI
//=================================================================================================

long szukaj(FILE *file)
{
    char chr;
    long count = 0;
    while(chr != EOF) {
        chr = fgetc(file);
        if(chr == 10)
            count++;
    }
      
    rewind(file);
    return count;
}

//=================================================================================================
// DEFINICJA FUNKCJI
//=================================================================================================

void zapisz(FILE *file, long *tab, long count)
{
    int i;
    for(i=1; i<=count; i++)
        fprintf( file,"%d\n", tab[i] );
   
    rewind(file);
}

//=================================================================================================
// DEFINICJA FUNKCJI
//=================================================================================================

void laduj(FILE *file, long *tab)
{
    char chr;
    int i = 1;
    long pos = 1;

    while(chr != EOF) {
        chr = fgetc(file);
        if(isdigit(chr)) {
            tab[pos] = tab[pos] * 10 + (chr - '0');
            i *= 10;
        }
        else {
            i = 1;
            pos++;
        }
    }
      
    rewind(file);
}

//=================================================================================================
// DEFINICJE FUNKCJI 
//=================================================================================================

void kopiec(void)
{
    fly++;
    printf("\b\b\b\b%ld%%", ((fly*100)/(fly_kopiec/2)) > 100 ? 100 : ((fly*100)/(fly_kopiec/2)));

}

//=================================================================================================
// DEFINICJE FUNKCJI 
//=================================================================================================

void sort(void)
{
    fly++;
    printf("\b\b\b\b%ld%%", ((fly*100)/fly_kopiec) > 100 ? 100 : ((fly*100)/fly_kopiec));

}

//=================================================================================================
// DEFINICJE FUNKCJI HeapSort
//=================================================================================================

void downheap(long *tab, int k, int n)
{
	int l;
	long v;

	v = tab[k];
	l = 2*k;
	while(l <= n) {
		if ((l < n) && (tab[l] < tab[l+1]))
			l = l + 1;
		if (v < tab[l]) {
			tab[k] = tab[l];
			k = l;
			l = 2*l;
		}
		else
			l = n + 1;
	}
	tab[k] = v;
}

long deletemax(long *tab, int *n)
{
	long v;

	v = tab[1];
	if(*n > 1) {
		tab[1] = tab[*n];
		(*n)--;
		downheap(tab,1,*n);
	}
	else *n = 0;

	return v;
}

void construct(long *tab, int n)
{
	int i;

    for(i = n/2; i > 0; i--) {
        kopiec();
		downheap(tab,i,n);
    }

}

void HeapSort(long *tab, int n)
{
	long v;
	int i;
    printf("Tworzenie kopca:\n");
	construct(tab,n);
    fly = 1;
    printf("\nSortowanie elementow:\n");
	for(i = n; i > 1; )
	{
        sort();
		v = tab[i];
		tab[i+1] = deletemax(tab,&i);
	}
}
