// Program sortujacy tablice zapisana w pliku
// Autorzy: Julita Mazik, Slawomir Brys
// Grupa: 229

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//=================================================================================================
// DEKLARACJE FUNKCJI
//=================================================================================================

void downheap(FILE *file, int k, int n);
long deletemax(FILE *file, int *n);
void construct(FILE *file, int n);
void HeapSort(FILE *file, int n);

long szukaj(FILE *file);
long czytaj(FILE *file, long num);
void zapisz(FILE *file, long num, long val);
void kopiec();
void sort();

long fly_kopiec;
long fly = 0;

clock_t start, end;

//=================================================================================================
// FUNKCJA GLOWNA
//=================================================================================================

int main(int argc, char *argv[])
{
    long count;
    FILE *file;

    if(argc < 2) {
        printf("Muszisz podac nazwe pliku do posortowania\n");
        return 0;
    }

    file = fopen(argv[1], "r+");

    if(!file) {
        printf("Blad odczytu pliku!!!\n");
        return 0;
    }
    
    count = szukaj(file);
    printf("Tablica ma %ld elementow.\n", count);
    fly_kopiec = count;
    
    printf("Sortowanie...  \n");

    start = clock();
	HeapSort(file, count);
	end = clock();

    fclose(file);
    if(!file) {
        printf("Blad zapisu do pliku!!!\n");
        return 0;
    }
    
    printf("\nZakonczone pomyslnie w czasie %.3f sekund\n\n", (double)(end-start)/1000);

   	return 0;
}

//=================================================================================================
// DEFINICJA FUNKCJI
//=================================================================================================

long szukaj(FILE *file)
{
    char chr;
    long count = 0;
    while(chr != EOF) {
        chr = fgetc(file);
        count++;
    }
    count--;
    count /= 10;
    rewind(file);
    return count;
}

//=================================================================================================
// DEFINICJA FUNKCJI
//=================================================================================================

long czytaj(FILE *file, long num)
{
    char temp[11] = {0};
    long k;

    fseek(file, num*10 - 10, SEEK_SET);
    fread(temp, 10, 1, file);
    k = atoi(temp);
    
    return k;
}

//=================================================================================================
// DEFINICJA FUNKCJI
//=================================================================================================

void zapisz(FILE *file, long num, long val)
{
    char temp[11] = {"0000000000"};
    int i = 1;
    int k = 0;
        
    while(val) {
        temp[10-k-1] = (val % 10) + '0';
        k++;
        val /= 10;
    }
    fseek(file, num*10 - 10, SEEK_SET);
    fwrite(temp, 10, 1, file);
    rewind(file);
}

//=================================================================================================
// DEFINICJE FUNKCJI 
//=================================================================================================

void kopiec(void)
{
    fly++;
    printf("\b\b\b\b%ld%%", ((fly*100)/(fly_kopiec/2)) > 100 ? 100 : ((fly*100)/(fly_kopiec/2)));

}

//=================================================================================================
// DEFINICJE FUNKCJI 
//=================================================================================================

void sort(void)
{
    fly++;
    printf("\b\b\b\b%ld%%", ((fly*100)/fly_kopiec) > 100 ? 100 : ((fly*100)/fly_kopiec));

}

//=================================================================================================
// DEFINICJE FUNKCJI HeapSort
//=================================================================================================

void downheap(FILE *file, int k, int n)
{
	int l;
	long v;
    
    v = czytaj(file, k);
	l = 2*k;
	while(l <= n) {
        if ((l < n) && (czytaj(file, l)) < (czytaj(file, l+1)))
			l = l + 1;
        if (v < czytaj(file, l)) {
            zapisz(file, k, czytaj(file, l));
            k = l;
			l = 2*l;
		}
		else
			l = n + 1;
	}
    zapisz(file, k, v);
}

long deletemax(FILE *file, int *n)
{
	long v;
	
    v = czytaj(file, 1);
	if(*n > 1) {
        zapisz(file, 1, czytaj(file, *n));
		(*n)--;
		downheap(file,1,*n);
	}
	else *n = 0;

	return v;
}

void construct(FILE *file, int n)
{
	int i;

    for(i = n/2; i > 0; i--) {
        kopiec();
		downheap(file,i,n);
    }

}

void HeapSort(FILE *file, int n)
{
	long v;
	int i;
    printf("Tworzenie kopca:\n");
	construct(file,n);
    fly = 1;
    printf("\nSortowanie elementow:\n");
	for(i = n; i > 1; )
	{
        sort();
        v = czytaj(file, i);
        zapisz(file, i+1, deletemax(file, &i));
	}
}
