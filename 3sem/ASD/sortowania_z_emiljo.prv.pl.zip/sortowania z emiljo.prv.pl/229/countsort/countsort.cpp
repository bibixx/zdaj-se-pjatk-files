#include<stdio.h>
#include<stdlib.h>
void Countsort(int *a,int m,int n)
{
	int i,j,p;
	int *t,*count;
	t=(int*)malloc(n*4);
	count=(int*)malloc(m*4);
	for(j=0;j<m;j++)
		count[j]=0;
	for(i=0;i<n;i++)
		count[a[i]]++;
	//count[j]=liczba wystapien j w a
	for(j=1;j<m;j++)
		count[j]+=count[j-1];
	//count[j]=liczba wystapien element�w <=j
	for(i=n-1;i>=0;i--){
		p=a[i];
		count[p]--;
		t[count[p]]=p;
	}
	for(i=0;i<n;i++)
		a[i]=t[i];
	free(t);
	free(count);
}

main()
{
	int n,m,i;
	int *a;
	printf("Podaj ilosc elementow tablicy\n");
	scanf("%d",&n);
	a=(int*)malloc(n*4);
	printf("Wpisz liczby do twojej tablicy");
	m=n;
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
   Countsort(a,m,n);
   for(i=0;i<n;i++)
	   printf("a[i]=%d\n",a[i]);
   return 0;
}