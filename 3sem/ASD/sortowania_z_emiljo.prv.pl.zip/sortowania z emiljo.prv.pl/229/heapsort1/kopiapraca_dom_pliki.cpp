// Nazwa programu: praca_dom_pliki
// Przeznaczenie: 
// Autor: Julita Mazik
// Grupa: 229

#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])  //ilosc argumentow i wska�niki do tych arg.
{
	FILE *fpi, *fpo;
	char tab[256];
	
	if (argc != 3)
	{
		printf ("Blad\n");
		return 1;
	}



	fpi = fopen (argv[1], "r");
	fpo = fopen (argv[2], "w");

	if(fpi == NULL || fpo == NULL)
	{
		printf("Blad otwarcia plikow.\n");
		return 1;
	}

	while (! feof (fpi))
	{
		fgets (tab, 256, fpi );
		if (! feof (fpi))  
			if(strlen(tab) > 3)
			{
				printf(tab);
				fputs (tab, fpo);
			}
	}

	
	fclose (fpi);
	fclose (fpo);

	return 0;
}
