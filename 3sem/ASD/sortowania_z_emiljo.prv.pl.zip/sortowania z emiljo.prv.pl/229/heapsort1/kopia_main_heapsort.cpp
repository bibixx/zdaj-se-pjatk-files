#include <stdio.h>
#include <stdlib.h>

void upheap(long *tab, int k);
void insert(long x, long *tab, int *n);
void downheap(long *tab, int k, int n);
long deletemax(long *tab, int *n);
void construct(long *tab, int n);
void HeapSort(long *tab, int n);
void show(long *tab, int n);

int main(int arg_il, char *arg_tab[])
{
	long tab[10]={0, 12, 5, 7, 3, 6, 20, 45, 3, 0};

	printf("Przed posortowanie: \n");
	show(tab,10);

	HeapSort(tab,10);
	
	printf("Po posortowanie: \n");
	show(tab,10);

	return 0;
}

void show(long *tab, int n)
{
	int i;
	for(i=0; i<n; i++)
		printf("%ld ", tab[i]);
	printf("\n");

	getchar();
}


void upheap(long *tab, int k)
{
	int l;
	long v;

	v = tab[k];
	l = k/2;
	while ((l != 0) && (tab[l] < v)) {
		tab[k] = tab[l];
		k = l;
		l /= 2;
	}
	tab[k] = v;
}

void insert(long x, long *tab, int *n)
{
	(*n)++;
	tab[*n] = x;
	upheap(tab, *n);
}

void downheap(long *tab, int k, int n)
{
	int l;
	long v;

	v = tab[k];
	l = 2*k;
	while(l <= n) {
		if ((l < n) && (tab[l] < tab[l+1]))
			l = l + 1;
		if (v < tab[l]) {
			tab[k] = tab[l];
			k = l;
			l = 2*l;
		}
		else
			l = n + 1;
	}
	tab[k] = v;
}

long deletemax(long *tab, int *n)
{
	long v;

	v = tab[1];
	if(*n > 1) {
		tab[1] = tab[*n];
		(*n)--;
		downheap(tab,1,*n);
	}
	else *n = 0;

	return v;
}

void construct(long *tab, int n)
{
	int i;

	for(i = n/2; i > 0; i--)
		downheap(tab,i,n);

}

void HeapSort(long *tab, int n)
{
	long v;
	int i;
	construct(tab,n);
	for(i = n; i > 1; )
	{
		v = tab[i];
		tab[i+1] = deletemax(tab,&i);
	}
}
