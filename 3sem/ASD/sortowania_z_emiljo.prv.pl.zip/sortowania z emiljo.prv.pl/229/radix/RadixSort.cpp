/*	
	Program testujacy algorytmy sortujace:
	RadixSort i QuickSort
	Grupa: 229
	Autorzy: Michal Czerniawski, Pawel Ciszewski
	Data powstania: 9.4.2000
*/

#include<stdlib.h>
#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<time.h>

#define LICZBA_POWTORZEN 10
#define ILE_LICZB  100000

void wypelnijTab(int *tab);
void qsort(int v[], int left, int right);
void swap(int v[], int i, int j);
void RadixSort(int *a, int *A, int n);
void kopiujTab(int *tab1, int *tab2, int n);
void test1(int *, int *, int);
void test2(int *, int *, int);
int test(FILE *stream);
long filesize(FILE *stream);
int bits(int x, int k, int j);

int licznik = 0; 
long CzasSortowania, CzasKopiowania;
clock_t start, stop;
time_t t;

void main( int argc, char *argv[] )
{

	int i = 0;
	int tab[ILE_LICZB] = {0}, tab2[ILE_LICZB] = {0};
	char nazwa[15], nazwa2[15];
	FILE *wej, *wyj, *wyj2;
	
	if(argc==1)
	{
		char klawisz[2], z;
		int wybor;
				
		printf("\n<<MENU>>\n");
		printf("1 - wygeneruj tablice %d liczb i zapisz ja do pliku", 
			ILE_LICZB);
		printf("\n2 - pobierz dane z mojego pliku\n");
		do{
		printf("twoj wybor: "); scanf("%s%c", &klawisz, &z);
		wybor = atoi(klawisz);
		}while((wybor != 1) && (wybor != 2));
		
		switch(wybor){
		
		case 1:	
			printf("\nPodaj nazwe pliku do ktorego mam zapisac tablice > ");
			gets(nazwa);
			if((wej = fopen(nazwa, "w+"))==NULL){
				printf("\nNie moge otworzyc pliku \"%s\" !\n", nazwa);
				exit(1);
			}
			wypelnijTab(tab);
			for (i = 0; i<ILE_LICZB; i++)
				fprintf(wej, "%d ", tab[i]);
			break;

		case 2:
			printf("\nPodaj nazwe pliku zrodlowego > ");
			gets(nazwa);
			if((wej = fopen(nazwa, "r"))==NULL){
				printf("\nNie moge otworzyc pliku \"%s\" !\n", nazwa);
				exit(1);
			}
			printf("\nCzytam dane do sortowania\n");
			printf("Test danych w pliku \"%s\": ", nazwa);
			
			if(!test(wej)){
				printf("\rTest danych w pliku \"%s\": ", nazwa);
				printf("zly format danych! wywolaj pomoc /?\n");
				fclose(wej);
				exit(1);
			}
			printf("\rTest danych w pliku \"%s\": OK \n\n", nazwa);
			rewind(wej);
			break;

		default: 
			printf("\nNieznany klawisz\n");
			break;
		}

		printf("\nPodaj nazwe pliku wynikowego dla QuickSorta > ");
		
		gets(nazwa);
		
		if(( wyj = fopen(nazwa, "w"))==NULL){
			printf("\nNie moge otworzyc pliku \"%s\" !\n", nazwa);
			exit(1);
		}
		printf("\nPodaj nazwe pliku wynikowego dla RadixSorta > ");

		gets(nazwa2);
		
		if(( wyj2 = fopen(nazwa2, "w"))==NULL){
			printf("\nNie moge otworzyc pliku \"%s\" !\n", nazwa2);
			exit(1);
		}
		
		printf("\nWpisywanie do tablicy liczb do posortowania\n");

		if(wybor==2){
			rewind(wej);
			i = 0;
			while(!feof(wej)){
				if(fscanf(wej, "%d ", &tab[i]) != 1)
					printf("\nWystapil blad czytania danych ! \n");
				i++;
				licznik++;
			}
		}
		else licznik = ILE_LICZB;
			
		const int n = licznik;
		
		//testowanie Qsorta
		
		test1(tab, tab2, n);

		double czas1 = (double)
			(CzasSortowania - CzasKopiowania) / LICZBA_POWTORZEN;
		
		for (i = 0; i<licznik; i++)
			fprintf(wyj, "%d ", tab2[i]);

		printf("\n\nZapisano liczby w pliku \"%s\"\n", nazwa);
		printf("Rozmiar pliku \"%s\" wynosi: \
			      %ld bajtow", nazwa, filesize(wyj));
		rewind(wej);
		licznik = 0;
		i = 0;
		
		while(!feof(wej)){
			if(fscanf(wej, "%d ", &tab[i]) != 1)
				printf("\nWystapil blad czytania danych ! \n");
			i++;
			licznik++;
		}
		const m = licznik;
		CzasSortowania = CzasKopiowania = 0;
		
		test2(tab2, tab, m);

		double czas2 = (double)
			(CzasSortowania - CzasKopiowania) / LICZBA_POWTORZEN;
		
		for (i = 0; i<licznik; i++)
			fprintf(wyj2, "%d ", tab2[i]);

		printf("\n\nZapisano liczby w pliku \"%s\"\n", nazwa2);
		printf("Rozmiar pliku \"%s\" wynosi: \
			      %ld bajtow", nazwa, filesize(wyj2));
		
		printf("\n\nCzas jednego sortowania QuickSorta wynosi: ");
		printf("%.5lf jednostek\n", czas1);
		
		printf("\nCzas jednego sortowania RadixSorta wynosi: ");
		printf("%.5lf jednostek\n", czas2);
		
		// zamkniecie wszystkich otwartych plikow
		if (fclose(wyj) != 0 || fclose(wyj2) != 0 || fclose(wej) != 0)
			printf("wystapil blad podczas zamykania plikow!");
	
		getch();
		
		return;

	}
	else if(argc==2)
	{
		if( (!strcmp(argv[1], "/h")) || (!strcmp(argv[1], "/?")))
		{
			printf("\n<<POMOC>>\n\n");
			printf("Program wczytuje liczby calkowite z pliku ");
			printf("uzytkownika,\na nastepnie");
			printf(" sortuje te liczby algorytmem QuickSort oraz ");
			printf("RadixSort.\n");
			printf("Wyniki sortowan sa zamieszczane w odzielnych ");
			printf("plikach \npodanych przez uzytkownika. ");
			printf("Program podaje rowniez czasy sortowan.\n");
			printf("Program moze byc wywolany z argumentami:\n");
			printf("\t* '/?' lub '/h' = pomoc"); 
			printf("\n\t* 'nazwa pliku zrodlowego'\n");
			printf("Plik zrodlowy powinien zawierac tylko liczby ");
			printf("calkowite\n w przeciwnym wypadku tester danych");
			printf(" wykryje blad.\n");
			getch();
			exit(1);
		}
		
		if((wej = fopen(argv[1], "r"))==NULL){
			printf("\nNie moge otworzyc pliku \"%s\" !\n", argv[1]);
			exit(1);
		}
		printf("\nCzytam dane do sortowania\n");
		printf("Test danych w pliku \"%s\": ", argv[1]);
			
		if(!test(wej)){
			printf("\rTest danych w pliku \"%s\": ", argv[1]);
			printf("zly format danych! wywolaj pomoc /?\n");
			fclose(wej);
			exit(1);
		}
		printf("\rTest danych w pliku \"%s\": OK \n\n", argv[1]);
		rewind(wej);

		printf("\nPodaj nazwe pliku wynikowego dla QuickSorta > ");
		
		gets(nazwa);
		
		if(( wyj = fopen(nazwa, "w"))==NULL){
			printf("\nNie moge otworzyc pliku \"%s\" !\n", nazwa);
			exit(1);
		}
		printf("\nPodaj nazwe pliku wynikowego dla RadixSorta > ");

		gets(nazwa2);
		
		if(( wyj2 = fopen(nazwa2, "w"))==NULL){
			printf("\nNie moge otworzyc pliku \"%s\" !\n", nazwa2);
			exit(1);
		}
		
		printf("\nWpisywanie do tablicy liczb do posortowania\n");
		rewind(wej);
		i = 0;
		while(!feof(wej)){
			if(fscanf(wej, "%d ", &tab[i]) != 1)
				printf("\nWystapil blad czytania danych ! \n");
			i++;
			licznik++;
		} 
			
		const int n = licznik;
		
		//testowanie Qsorta
		
		test1(tab, tab2, n);

		double czas1 = (double)
			(CzasSortowania - CzasKopiowania) / LICZBA_POWTORZEN;
		
		for (i = 0; i<licznik; i++)
			fprintf(wyj, "%d ", tab2[i]);

		printf("\n\nZapisano liczby w pliku \"%s\"\n", nazwa);
		printf("Rozmiar pliku \"%s\" wynosi: \
			      %ld bajtow", nazwa, filesize(wyj));
		rewind(wej);
		licznik = 0;
		i = 0;
		
		while(!feof(wej)){
			if(fscanf(wej, "%d ", &tab[i]) != 1)
				printf("\nWystapil blad czytania danych ! \n");
			i++;
			licznik++;
		}
		const m = licznik;
		CzasSortowania = CzasKopiowania = 0;
		
		//testowanie Radixa
		
		test2(tab2, tab, m);

		double czas2 = (double)
			(CzasSortowania - CzasKopiowania) / LICZBA_POWTORZEN;
		
		for (i = 0; i<licznik; i++)
			fprintf(wyj2, "%d ", tab2[i]);

		printf("\n\nZapisano liczby w pliku \"%s\"\n", nazwa2);
		printf("Rozmiar pliku \"%s\" wynosi: \
			      %ld bajtow", nazwa, filesize(wyj2));
		
		printf("\n\nCzas jednego sortowania QuickSorta wynosi: ");
		printf("%.5lf jednostek\n", czas1);
		
		printf("\nCzas jednego sortowania RadixSorta wynosi: ");
		printf("%.5lf jednostek\n", czas2);
		
		// zamkniecie wszystkich otwartych plikow
		if (fclose(wyj) != 0 || fclose(wyj2) != 0 || fclose(wej) != 0)
			printf("wystapil blad podczas zamykania plikow!");
	
		getch();
		
		return;
	}
	else 
	{
		printf("\nZa duzo argumentow! Wywolaj pomoc /?");
		printf("\n\n");
		exit(1);
	}

	return;
}



void qsort(int v[], int left, int right)
{
	int i, last;
	void swap(int v[], int i, int j);

	if(left >= right) return; // nic nie rob jesli dwa el

	swap(v, left, (left + right)/2);
	last = left;
	
	for(i = left + 1; i <= right; i++)
		if(v[i] < v[left])
			swap(v, ++last, i);
	swap(v, left, last);
	qsort(v, left, last - 1);
	qsort(v, last + 1, right);
}


void RadixSort(int *a, int *A, int n)
{
	#define Byte 8

	int b = Byte*sizeof(int);
	int e = 2,
		m = 1 << e;  

	int *t;
	
	int *count=new int [m];

	int i, j, pass, nofpasses, key;

	t = A;

	nofpasses = b/e;
	if(b == (nofpasses*e))
		nofpasses--;
	
	for(pass = 0; pass <= nofpasses; pass++){
		
		for(j = 0; j < m; j++)
			count[j] = 0;

		for(i = 0; i < n; i++){
			key = bits(a[i], pass*e, e);
			count[key]++;
		}
		
		for(j = 1; j < m; j++)
			count[j] += count[j-1];

		for(i = n - 1; i >= 0; i--){
			key = bits(a[i], pass*e, e);
			count[key]--;
			t[count[key]] = a[i];
		}
		
		for(i = 0; i < n; i++)
			a[i] = t[i];
	}
}

void swap(int v[], int i, int j)
{
	int temp;
	temp = v[i];
	v[i] = v[j];
	v[j] = temp;
	return;
}

int bits(int x, int k, int j)
{
	return (x >> k) % (1 << j);
}

//test danych nie uwzglednia notacji naukowej -12.321e12

int test(FILE *stream)   
{
	int c;
	
	while(!feof(stream))
	{
		c = fgetc(stream);
			
		if(c >= '0'&& c <= '9');
		else if(c==' ' || c=='\n' || c=='\t' || c==EOF);
		else if(c=='-'){
			c = fgetc(stream);
			if(c < '0' || c > '9') return 0;
			else continue;
		}
		else return 0;
	}
	
	return 1;    
} 

void kopiujTab(int *tab1, int *tab2, int n)
{
	for(int i = 0; i < n; i++) tab1[i] = tab2[i];
	return;
}

long filesize(FILE *stream) 
{ 
   long curpos, length; 

   curpos = ftell(stream);     /* zapami�tanie aktualnej pozycji */ 
   fseek(stream, 0L, SEEK_END); /* przewini�cie o 0 bajtow od ko�ca */ 
   length = ftell(stream);     /* odczytanie pozycji po przewini�ciu*/ 
   fseek(stream, curpos, SEEK_SET); /* przewini�cie na star� pozycj� */ 
   return length; 
} 

void test1(int *tab, int *tab2, int n){
	
	printf("\nTeraz %d razy sortuje QuickSortem ", LICZBA_POWTORZEN);	
	printf("kopiujac te same dane\n%6d sortowanie", LICZBA_POWTORZEN);

		start = clock();
		
		for(int i = 1; i<=LICZBA_POWTORZEN; i++)
		{
			qsort(tab, 0, n - 1);
			kopiujTab(tab2, tab, n);
			printf("\r%6d", i);
		}
		stop = clock();
		
		CzasSortowania = stop - start;

		// mierzenie czasu kopiowania

		printf("\n\nTeraz mierze czas kopiowan\n%6d kopiowanie", LICZBA_POWTORZEN);

		start = clock();
		
		for(i = 1; i <= LICZBA_POWTORZEN; i++){
			kopiujTab(tab2, tab, n);
			printf("\r%6d", i);
		}
		stop = clock();

		CzasKopiowania = stop - start;
		
		return;
}

void test2(int *tab, int *tab2, int n){
	
	printf("\n\nTeraz %d razy sortuje RadixSortem kopiujac ", 
		LICZBA_POWTORZEN);
	printf("te same dane\n%6d sortowanie",
	  LICZBA_POWTORZEN);

		start = clock();
		
		for(int i = 1; i<=LICZBA_POWTORZEN; i++)
		{
			RadixSort(tab, tab2, n);
			kopiujTab(tab2, tab, n);
			printf("\r%6d", i);
		}
		stop = clock();
		
		CzasSortowania = stop - start;

		// mierzenie czasu kopiowania

		printf("\n\nTeraz mierze czas kopiowan\n");
		printf("%6d kopiowanie", LICZBA_POWTORZEN);

		start = clock();
		
		for(i = 1; i <= LICZBA_POWTORZEN; i++){
			kopiujTab(tab2, tab, n);
			printf("\r%6d", i);
		}
		stop = clock();

		CzasKopiowania = stop - start;
		
		return;
}

void wypelnijTab(int *tab)
{
	srand((unsigned) time(&t));
	for(int i=0, j=10; i<ILE_LICZB; i++, j+=10*i)
		 tab[i] = rand() % j;
	return;
}

