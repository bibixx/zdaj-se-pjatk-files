#include <stdio.h>
#include <conio.h>
#include <malloc.h>

void QuickSort(long *a, int l, int r);

main()
{
	long *tablica;
	int dl, w, p=0;

	printf("Ile liczb chcesz sortowac ==> ");
	scanf("%d", &dl);

	tablica = malloc( dl * sizeof(long));
	printf("\n\nPodaj %d liczb calkowitych : \n\n", dl);

	for(w=0; w<dl; w++)
    	scanf("%d", &tablica[w]);

	QuickSort(tablica,p,dl-1);

    printf("\n\nOto liczby po posortowaniu : \n\n");

	for(w=0; w<dl; w++)
		printf("%d ", tablica[w]);

	printf("\n\n");

	getch();

    return 0;
}

void QuickSort(long *a, int l, int r)
{
	int i,j;
	long v,x;

    v=a[l];
	i=l;
	j=r+1;

	do {
		do
			i++;
		while((i<=r) && (a[i] <v));
		do
			j--;
		while(a[j]>v);

        if(i<j) {
			x=a[i];
			a[i]=a[j];
			a[j]=x;
		}
	}
	while(i<j);

    a[l]=a[j];
	a[j]=v;

	if(j-1>l)
		QuickSort(a,l,j-1);
	if(r>j+1)
		QuickSort(a,j+1,r);
}