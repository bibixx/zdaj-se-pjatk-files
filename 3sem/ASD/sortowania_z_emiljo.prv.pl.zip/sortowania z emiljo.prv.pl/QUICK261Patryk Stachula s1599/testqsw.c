#include <time.h>
#include <stdio.h>
#include <dos.h>
#include <conio.h>
#include <stdlib.h>

// program pokazuje jak okreslic czas pracy algorytmu w czesciach sekundy
// uzywa w tym celu funkcji clock() podajacej czas od uruchomienia komputera
// w tiksach zegara.
void qusort(int tab[], int lewy, int prawy);
void wypelnij( int tab[]);

              int main(void)
{
    int tablica[1000];
	clock_t start, end;
	double dtime;
	unsigned long i;
    clrscr();
    wypelnij(tablica);
	start = clock();

	//testowany algorytm

 for(i=0;i<1000;i++){
qusort(tablica, 0, 999);
                         }


	//

	end = clock();
	dtime = (double)(end-start)/CLK_TCK; //przelicza roznice na sekundy


	printf( "Czas dzialania dla 1000 powtorzen: %.4f sec\n", dtime );

	return 0;
}
void qusort(int tab[], int lewy, int prawy)
{
int i, ost;
void zmien(int tab[], int i, int j);
if (lewy>=prawy)
return;
zmien(tab, lewy, (lewy+prawy)/2);
ost=lewy;
for(i=lewy+1;i<=prawy;i++)
if(tab[i]<tab[lewy])
zmien(tab,++ost,i);
zmien(tab,lewy,ost);
qusort(tab,lewy,ost-1);
qusort(tab,ost+1,prawy);
                      }

void zmien(int tab[], int i, int j)
{
int bufor;

bufor=tab[i];
tab[i]=tab[j];
tab[j]=bufor;
}
void wypelnij(int tab[]){
int i;
for(i=0;i<1000;i++){
tab[i]=rand() /1000;
}                    }