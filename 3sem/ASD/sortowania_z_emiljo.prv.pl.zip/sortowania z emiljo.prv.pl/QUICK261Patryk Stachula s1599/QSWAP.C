Algorytm QUICK SORT.

Jeden z najcz�cieju�uwanych algorytm�w sortowania.
Uznawany za najszybszy dla losowych danych wej�ciowych.
Oparty jest na zasadzie dziel i zwyci�aj.
Dane wej�ciowe s� dzielone na dwie cz�ci przez element dziel�cy,
w przypadku poni�szego algorytmu jest to element 



#include <stdio.h>
#include <conio.h>
void qsort( int tab[], int lewy, int prawy);

main(){

int o;
int tablica[10]={3,10,8,7,9,1,4,2,5,6};
clrscr();
qsort(tablica, 0, 9);

for(o=0;o<10;o++){
printf("%d; ",tablica[o]);
}

return 0;
}


void qsort( int tab[], int lewy, int prawy)
{
int i, ost;
void zmien(int tab[], int i, int j);
if (lewy>=prawy)
return;
zmien(tab, lewy, (lewy+prawy)/2);
ost=lewy;
for(i=lewy+1;i<=prawy;i++)
if(tab[i]<tab[lewy])
zmien(tab,++ost,i);
zmien(tab,lewy,ost);
qsort(tab,lewy,ost-1);
qsort(tab,ost+1,prawy);
                      }

void zmien(int tab[], int i, int j)
{
int bufor;

bufor=tab[i];
tab[i]=tab[j];
tab[j]=bufor;
}