// Sorting Test

#include <stdio.h>
#include <stdlib.h>
#include <time.h>


#define MAX_LEN 100000

char fname[80];
int len = 0;


void gen(void);
void insertion(int *tab,int n);
void qsort(int *tab, int left, int right);
void selection(int *tab, int n);
void bubble(int *tab, int n);
void change(int *a, int *b);
void shellsort(int *tab, int l, int r);
void partition (int c[], int left, int right, int tab[]);
void msorting (int c[], int N);
void merging (int c[], int left, int middle, int right, int b[]);



main ()
{	int i;
	clock_t start, end;
	double dtime;
	FILE *f1;
	char buff[MAX_LEN];
	int temp[MAX_LEN];
	printf("This program tests various types of sorting arrays\n");
	gen();
	printf("Please wait...\nMain Program loads\n");
		
	if ((f1 = fopen(fname, "r+")) == NULL)
	
	{	printf("Cannot open file\n");
		exit(1);
	}
	
		// Selection
		i=0;
		rewind(f1);
		while (fgets(buff, len, f1) != NULL) {
			temp[i] = atoi(buff);
			i++;
		}
			start = clock();
				selection(temp,len);
			end = clock();
			dtime = (double) (end - start)/CLK_TCK;
			printf("1.SelectionSort = %.3f sec\n", dtime);

	// Insertion
			i=0;
			rewind(f1);
			while (fgets(buff, len, f1) != NULL) {
			temp[i] = atoi(buff);
			i++;
		}
			start = clock();
				insertion(temp,len);
			end = clock();
			dtime = (double) (end - start)/CLK_TCK;
			printf("2.InsertionSort = %.3f sec\n", dtime); 
	//Bubble
			i=0;
			rewind(f1);
			while (fgets(buff, len, f1) != NULL) {
			temp[i] = atoi(buff);
			i++;
		}
				start = clock();
					bubble(temp, len);
				end = clock();
				dtime = (double) (end - start)/CLK_TCK;
				printf("3.BubbleSort = %.3f sec\n", dtime);	
	//Shellsort
				i=0;
			rewind(f1);
			while (fgets(buff, len, f1) != NULL) {
			temp[i] = atoi(buff);
			i++;
		}
				start = clock();
					shellsort(temp,0 ,len-1);
				end = clock();
				dtime = (double) (end - start)/CLK_TCK;
				printf("4.ShellSort = %.3f sec\n", dtime);
	//MergeSort
			i=0;
			rewind(f1);
			while (fgets(buff, len, f1) != NULL) {
			temp[i] = atoi(buff);
			i++;
		}
				start = clock();
					msorting(temp,len);
				end = clock();
				dtime = (double) (end - start)/CLK_TCK;
				printf("5.MergeSort = %.3f sec\n", dtime);
	// Quick
			i=0;
			rewind(f1);
			while (fgets(buff, len, f1) != NULL) {
			temp[i] = atoi(buff);
			i++;
		}
			start = clock();
				qsort(temp,0,len-1);
			end = clock();
			dtime = (double) (end - start)/CLK_TCK;
			printf("6.QuickSort = %.3f sec\n", dtime); 

	

return 0;

}

void gen(void)
{
	FILE *f;
	int i;
	char choice;
	

	printf("File generator: \n");
	printf("Enter type of sequence: r - random, d - decreasing, i - increasing: \n");
	scanf("%c", &choice);
	printf("How many elements: ");
	scanf("%d", &len);
	printf("Enter name of file: ");
	scanf("%s", &fname);
	
	if ((f = fopen(fname, "wt")) == NULL)
	{	printf(" Cannot create file.\n");
		exit(1);
	}


	switch (choice)
	{
	case 'r':
			for (i = 0;i < len;i++)
				fprintf(f, "%d\n", rand());
				break;
	case 'd':
			for (i = 0;i < len ;i++ )
				fprintf(f,"%d\n", i );
				break;
	case 'i':
			for (i = len-1;i >=0; i--)
				fprintf(f,"%d\n",i);
				break;
	default: printf("You pressed the wrong button!");
	}

	fclose (f);
	printf("Done.\n");
	}
			
		
void selection(int *tab, int n)
{	int j,i,i_max,max;
	for (j = n-1; j >0; j--)
	{	max = tab[0];
	i_max= 0;
	for (i=1; i <= j; i++)
		if (tab[i] >max) 
		{	max = tab[i];
			i_max =i;
		}	
		tab[i_max]= tab[j];
		tab[j]= max;
	}
}

void insertion(int *tab,int n)
{	int v,j;
	for (int i=1; i <n;i++)
	{
		v = tab[i];
		for (j = i; (j > 0) && (tab[j-1] > v); j--)
			tab[j] = tab[j-1];
		tab[j]= v;
	}
}

void qsort(int *tab, int left, int right)
{
	if (left < right)
	{
		int m =left;
		for (int i = left +1; i < right; i++)
			if (tab[i] < tab[left])
				change (&tab[++m], &tab[i]);
		change(&tab[left], &tab[m]);
		qsort(tab, left, m-1);
		qsort(tab, m+1, right);
	}
}

void bubble(int *tab, int n)
{
	for (int i =1; i < n; i++)
		for (int j = n-1; j > i; j--)
			if (tab[j]< tab[j-1])
				change(&tab[j-1], &tab[j]);
}

void change(int *a, int *b)
{
	int z;
	z = *b;
	*b = *a;
	*a = z;
}
		   
void shellsort (int *tab, int l, int r)
	{int h;
	int i;
	for (h = 1;h <= (r-l)/9;h=(3*h+1));
		for (;h > 0;h /= 3)
			for (i = l + h;i <= r;i++)
			{ int j = i;
			  int v = tab[i];
			  while (j >= l + h && v < tab[j-h])
			  {  tab[j] = tab[j-h];
			  j -= h;
			  tab[j] = v; }
	      	  }
   }
	
void msorting (int c[], int N)
{
int tab[MAX_LEN];

if (N>1)
    partition (c, 0, N-1, tab);
}
    
void merging (int c[], int left, int middle, int right, int b[])
{
int i,j,k;
i = left;
j = middle +1;
k = left -1;

while (( i <= middle ) && (j <= right)) {
k++;
if (c[i] <= c[j]) { 
b[k] = c [i];
i++;
}
else {
b[k] = c[j];
j++;
}
}

if ( i <=  middle)
for (j = right; j > k; j--)
c[j] = c[middle--];

for (i = left; i <= k; i++)
c[i] = b[i];
}

void partition (int c[], int left, int right, int tab[])
{
int middle;
middle = (left + right) /2;
if (left < middle)
partition (c, left, middle, tab);
if ((middle + 1) < right )
partition (c, middle+1, right, tab);

merging(c, left, middle, right, tab);
}


