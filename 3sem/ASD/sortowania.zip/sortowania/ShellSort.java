
package sort;

public
class ShellSort 
extends SortUtils {

	public static void main(String[] args) 
	{
		new ShellSort();
	}

	void ShellSort(int[] data) 
    {
    	int i, j, tmp, h_cnt, h, k;
        int[] increments = new int[20];	// tablica zawieraj�ca kolejne przyrosty 
        

        for (h = 1, i = 0 ; h < data.length ; i++) { // obliczenie przyrost�w
        	increments[i] = h;                       // wg wzoru Knutha
            h = 3*h + 1;                             // h[i] = 3*h[i-1] + 1
        }
        for (i-- ; i >= 0 ; i--) {					 // wyb�r przyrostu dla kolejnych
        	h = increments[i];                       // przebieg�w sortowania
            
            for (h_cnt = h ; h_cnt < 2*h ; h_cnt++) {	// Insertion Sort
            	for(j=h_cnt; j < data.length ; ) {
                	tmp = data[j];
                    k=j;
                    while (k-h>=0 && tmp <data[k-h]) {
                    	data[k]=data[k-h];
                        k-=h;
                    }
                    data[k]=tmp;
                    j+=h;
            	}
            }
        }                     
    }
    
	public ShellSort() 
    {
    	int[] tab = new int[20];
        GenTab(tab,30);
        ShowTab(tab);
        
        ShellSort(tab);
        ShowTab(tab);
    }
}