
package sort;

public 
class SortUtils {

	public static void main(String[] args) 
	{

	}

	public void GenTab(int[] tab, int zakres) 
    // funkcja zape�nia tablic� tab losowymi danymi z przedzia�u <-zakres;zakres>
    {
    	for ( int i = 0; i < tab.length ; i++) {
        	int number = (int)(Math.random()*zakres);
            
            if (Math.random() > 0.5)
            	tab[i] = number;
            else
            	tab[i] = -number;  
    	}  

    }

	public void ShowTab(int[] tab) 
    // funkcja wypisuje tablic�, je�li ma ona mniej ni� 26 element�w 
    {
    	if (tab.length <= 25) {
	        System.out.print("[ ");
	        for (int i = 0; i < tab.length ; i++)
	        	System.out.print(tab[i] + " ");
	    	
	        System.out.print("]");
	    	System.out.println();
    	}
    }
    
    public long Timer() 
    {
    	return System.currentTimeMillis();
    }
}