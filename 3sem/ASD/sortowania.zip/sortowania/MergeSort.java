
package sort;

public
class MergeSort
extends SortUtils {

	public static void main(String[] args) 
    {
    	new MergeSort();
    }
    
    private void Scal(int le, int sr, int pr, int[] tab){ 
		int i = le; 
		int j = sr+1; 
		int k = -1; 
		int[] b = new int[pr-le+1]; 
		while ((i <= sr) && (j <= pr) ){ 
			k++; 
			if (tab[i] <= tab[j]){ 
				b[k] = tab[i]; 
			i++; 
		} 
		else { 
			b[k] = tab[j]; 
			j++; 
		} 
		} 
		if (i <= sr){ 
		for (j = pr; j > le+k; j--){ 
			tab[j] = tab[sr]; 
		sr--; 
		} 
		} 
		for (i = 0; i <= k; i++) 
			tab[le+i] = b[i]; 
	} 
	private void SortujRek(int le, int pr, int[] tab){ 
		int sr = (le+pr)/2; 
		if (le < sr) 
			SortujRek(le,sr,tab); 
		if ((sr+1) < pr) 
			SortujRek(sr+1,pr,tab); 
		Scal(le,sr,pr,tab); 
	} 
	public void Sortuj(int[] tab){ 
		if (tab.length >= 2) 
			SortujRek(0,tab.length-1,tab); 
	} 

	public MergeSort() 
    {
    
    }

} 