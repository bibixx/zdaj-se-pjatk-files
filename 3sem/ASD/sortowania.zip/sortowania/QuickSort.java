
package sort;

public
class QuickSort 
extends SortUtils {

	public static void main(String[] args) 
    {
    	new QuickSort();
    }
    
    private void QuickSort(int l, int r, int[] tab) 
    {
    	int i, j, v, x;
        
        v = tab[l];
        i = l;
        j = r + 1;
        
        do {
        	do
            	i++;
                while ((i <= r) && tab[i] < v);
            do
            	j--;
        	while (tab[j] > v);
            if (i < j){
            	x = tab[i]; tab[i] = tab[j]; tab[j] = x;
            }
        }
        while (i < j);
        tab[l] = tab[j]; tab[j] = v;   
        
        if (j - 1 > l)
        	QuickSort(l, j-1, tab);
        if (r > j+1)
        	QuickSort(j+1, r, tab);                             
    
    }
    
    public void Sortuj(int[] tab) 
    {
    	if (tab.length >= 2)
        	QuickSort(0, tab.length - 1, tab);
    
    }
    
    public QuickSort() 
    {
    	int[] tab = new int[2000];
        
        GenTab(tab, 100);
        ShowTab(tab);
        long start = Timer();
        Sortuj(tab);
        long stop = Timer();
        System.out.println("Czas wykonywania: " + (stop - start) + "ms");
        ShowTab(tab);
    }
    
}
    
