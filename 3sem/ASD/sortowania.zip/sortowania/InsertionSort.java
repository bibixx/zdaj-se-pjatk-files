
package sort;

public 
class InsertionSort 
extends SortUtils {

	public static void main(String[] args) 
    {
    	new InsertionSort();
    }
    
    public void InsertionSort(int[] tab) 
    {
    	int j = 0, x = 0;
        
        for (int i = 1; i < tab.length ; i++) {		
       		j = i;
	        x = tab[i];
	            
	        while (j > 0 && x < tab[j - 1]) {
	           	tab[j] = tab[j - 1];
	            j--;
	        }    
	        tab[j] = x;     
	                
	    }
    }
	public InsertionSort() 
    {
    	int[] tab = new int[2000];
        
        GenTab(tab, 100);
        ShowTab(tab);
        long start = Timer();
        InsertionSort(tab);
        long stop = Timer();
        System.out.println("Czas wykonywania: " + (stop - start) + "ms");
        ShowTab(tab);
    }
    
}											