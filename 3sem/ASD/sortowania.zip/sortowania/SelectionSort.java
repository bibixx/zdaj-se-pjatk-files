
package sort;

public 
class SelectionSort 
extends SortUtils {

	public static void main(String[] args) 
    {
    	new SelectionSort();
    }
    
    public void SelectionSort(int[] tab) 
    {
    	int min = 0, x = 0;
        
        for (int i = 0; i < tab.length ; i++) {
        	min = i;
        	
            for (int j = i + 1; j < tab.length ; j++)
            	if (tab[j] < tab[min])   
        			min = j;
        	
            x = tab[min];
            tab[min] = tab[i];
            tab[i] = x;
            
        }
    
    }
    
	public SelectionSort() 
    {
    	int[] tab = new int[20];
        
        GenTab(tab, 100);
        ShowTab(tab);
        SelectionSort(tab);
        ShowTab(tab);
    }
    
}
