function help(x)
{
     window.open(x, '', 'width=700,height=250,menubar=no,location=no,scrollbars=no,dependent=yes')
}
