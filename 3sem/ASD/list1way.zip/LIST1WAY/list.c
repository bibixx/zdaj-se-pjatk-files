//************************* LISTA DYNAMICZNA *********************************
// Lista jednokierunkowa, ze wskaznikami do glowy i ogona

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "list.h"

//***************************************************************************
TLIST *First = NULL;  //wskaznik do pierwszego elementu listy (glowy)
TLIST *Last  = NULL;  //wskaznik do ostatniego elementu listy (ogona)
// wskazniki sa inicjowane NULL-ami (czyli wskazaniem pustym) zwykle == 0
// dzieki temu wiem czy dodajac nowy element (w fun Add) bedzie to,
// bierwszy element listy
//*****************************************************************************
TLIST *FindByNo( int );
TLIST *FindByName( char * );
TLIST *FindPrev( TLIST * );
int Add( int no, char *name );
int Del( TLIST *pt );
void PrintfList( void );

// UWAGA! skrot pt uzywany w nazwach pomocniczych wskaznikow
// pochodzi od slowa pointer
// 
//*****************************************************************************
//*****************************************************************************
//                           LISTA DYNAMICZNA
//*****************************************************************************
//*****************************************************************************
//odszukanie elementu listy po numerze
//zwraca wskaznik do elementu listy lub NULL jesli nie znalazl takiego
TLIST *FindByNo( int no )
{
	TLIST *Destpt;  //pomocniczy wskaznik

	Destpt = First; //zaczynam szukac od glowy

	//szukam az znajde wskaznik na nast element == NULL (koniec listy)
	//lub jesli numer lelementu zgodzi sie z zadanym numerem (no)
	while(  Destpt != NULL && Destpt->no != no )
		Destpt = Destpt->next;  //przechodze na nast. element listy wskaznikiem pomocniczym

	return Destpt;  //zwracam wskaznik do elementu ktory posiada zadany no (numer)
	//lub NULL jesli doszedlem do konca listy i nie znalazlem numeru
}
//*****************************************************************************
//odszukanie elementu listy po nazwie
//zwraca wskaznik do elementu listy lub NULL jesli nie znalazl takiego
TLIST *FindByName( char *name )
{
	TLIST *Destpt;

	//zabezpieczenie!
	if ( name == NULL ) //jesli nazwy nie ma to nie szukam jej
		return NULL;

	Destpt = First;

	//strcmp porownuje stringi zwraca 0 jesli sa identyczne
	while(  Destpt != NULL && strcmp( Destpt->name, name ) )
		Destpt = Destpt->next;

	return Destpt;
}
//*****************************************************************************
//odszukanie poprzedniego (wzgledem podanego poprzez wskaznik pt) elementu listy 
//zwraca wskaznik do elementu listy lub NULL jesli nie znalazl poprzedniego
TLIST *FindPrev( TLIST *pt )
{
	TLIST *Destpt;

	//zabezpieczenie!
	if ( pt == NULL )//jeli podano wskaznik pusty do elem listy to nie szukam
		return NULL;

	Destpt = First; //zaczynam szukac od glowy
	//szukam az znajde wskaznik na nast element == NULL (koniec listy)
	//lub jesli chwilowy element listy wskazuje (next-em) na zadany element
	//czyli jest poprzednim elem. zadanego
	while( Destpt != NULL && Destpt->next != pt )
		Destpt = Destpt->next;

	//zwracam wskaznik na poprzedni element zadanego
	return Destpt;
}
//***************************************************************************
//dodanie nowego elementu do listy
//zwraca YES jesli sukces w przeciwnym przypadku NO
int Add( int no, char *name )
{
	TLIST *Destpt;

	if ( name == NULL )
		return NO;

	Destpt = calloc( 1, sizeof( TLIST ) );  //to samo co malloc( sizeof(TLIST) )
	if ( Destpt == NULL ) //brak wolnej pamieci
		return NO;

	Destpt->no = no; //podstawiam numer elementu
	strcpy( Destpt->name, name ); //kopjuje nazwe elementu

	if ( First == NULL )
		First = Destpt;  //dodalismy pierwszy element do listy
		//wsk First nie bedzie juz zmieniany chyba, ze usuniemy wszystkie elementy listy

	if ( Last != NULL )
		Last->next = Destpt;
		//ostati element listy wskazuje teraz na nowo dodany 

	Last = Destpt; //ostatnim elem. listy staje sie nowo dodany
	Destpt->next = NULL;//zawsze nowo dodany element wskazuje na NULL 
	//bo nie ma nastepnego elementu (jest ostatni na liscie)

	return YES; //udana operacja dodania elementu
}
//***************************************************************************
//skasowanie elementu
//zwraca YES jesli sukces w przeciwnym przypadku NO
int Del( TLIST *pt )
{
	TLIST *prvpt;  //poprzedni element listy

	if ( pt == NULL )
		return NO;

	if ( pt == First && pt == Last )  //jesli jest tylko jeden element listy
	{
		First = NULL;  //obydwa glowne wskazniki staja sie NULL-ami
		Last = NULL;   //co znaczy ze lista jest pusta
	}
	else
	{
		if ( pt == First ) //jesli kasujemy pierwszy elem.listy (glowe)
			First = pt->next; //to musimy ustawic wskaznik do glowy aby wskazywal na drugi element
		else
		{
			prvpt = FindPrev( pt ); //odszukuje wskaznik do poprzedniego elemenu
			if ( prvpt != NULL )  //jesli poprzedni element istnieje
			{
				if ( pt == Last )  //jesli kasuje ostatni element listy
					Last = prvpt;  //zmieniam wskaznik Last (bo wskazuje zawsze do ostatniego)
				prvpt->next = pt->next; //przepinam wskazniki aby ominac kasowany element
			}
			else return NO;
		}
	}
	free( pt ); //zwalniam wypiety element
	return YES;
}
//*****************************************************************************
//wyswietlenie listy
void PrintfList( void )
{
	int i = 0;
	TLIST *pt;

	pt = First;
	printf( "----------------------------- LIST -------------------------------\n");
	while( pt != NULL )
	{
		printf( "(%d) no=%3d name=%s\n", i++,  pt->no, pt->name );
		pt = pt->next;
	}
	printf( "--------------------------------------------------------------------\n");
}
//*****************************************************************************
//przykladowe uzycie funkcji
void main( void )
{
	char sbuf[255];
	int i;
	TLIST *pt;

	PrintfList();  //wyswietla pusta jeszcze liste

	//dodaje 5 elementow do listy
	for ( i=0; i<5; i++ )
	{
		//w tablicy sbuf tworze string (nazwe elementu) "element+numer"
		sprintf( sbuf, "element%d", i );
		//dodaje nowy element (o numerze i, nazwie w sbuf) do listy
		Add( i, sbuf );
	}
	PrintfList();  //wyswietla 5 elementow listy


	pt = FindByName( "element3" ); //odszukuje element o nazwie "element3)
	Del( pt );  //kasuje ten element podajac wskaznik do niego (pt)

	pt = FindByNo( 1 ); //odszukuje element o numerze 1
	Del( pt );  //kasuje ten element podajac wskaznik do niego (pt)

	PrintfList();  //wyswietla elementy listy 0, 2, 4
	//pozostale zostaly kasowane
}
//*****************************************************************************
//                              !!! CIEKAWOSTKA !!!
//*****************************************************************************
//w tych przykladach przejscie calej listy bylo realizowane petla while tak:
/*
	TLIST *Destpt;  //pomocniczy wskaznik

	Destpt = First; //zaczynam szukac od glowy
	//szukam az znajde wskaznik na nast element == NULL (koniec listy)
	while ( Destpt != NULL )
		Destpt = Destpt->next;

  //------------ MOZNA TO ZROBIC INACZEJ MOZE NAWET BARDZO ELEGANCKO ----------
	
	for ( Destpt=First; Destpt!=NULL; Destpt=Destpt->next)
*/
//*****************************************************************************
//*****************************************************************************
