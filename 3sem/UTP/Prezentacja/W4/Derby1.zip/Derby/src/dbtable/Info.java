package dbtable;

// Matainformacje dot. typ�w i tablic
// Autor: Krzysztof Barteczko

import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Info extends JFrame implements ActionListener {

 JTable tab = new JTable();
 JList list;
 DatabaseMetaData dm;
 Connection con;
 
 Info(String url, String driverName )  {
    Container cp = getContentPane();
    JPanel ctl = new JPanel();
    JButton b = new JButton("Typy");
    b.addActionListener(this);
    ctl.add(b);
    b = new JButton("Tablice");
    b.addActionListener(this);
    ctl.add(b);
    JScrollPane sp = new JScrollPane(tab);
    cp.add(sp, "Center");
    cp.add(ctl, "South");
 
   try {
     Class.forName(driverName);
     con = DriverManager.getConnection(url);
     dm = con.getMetaData();
     System.out.println("User: " + dm.getUserName());
   } catch (Exception exc)  { 
     System.out.println(exc.getMessage()); 
     System.exit(1);
   }
   setDefaultCloseOperation(3);
   pack();
   show();
 }
   
 public void actionPerformed(ActionEvent e)  {
   String cmd = e.getActionCommand();
   
  try  {
   if (cmd.equals("Tablice")) {
      String[] usertables = null;
      ResultSet rs = dm.getTables(null,null,null,usertables);
      tab.setModel(new DbTable(con, "", rs, false));
      pack();
   }
   else if (cmd.equals("Typy")) {
      ResultSet rs = dm.getTypeInfo();
      tab.setModel(new DbTable(con, "", rs, false));
      pack();
   }
  } catch (Exception ex) {
     System.out.println("cos tu");
     System.err.println(ex);
    }
    
 }    


public static void main(String[] args)  {
   new Info("jdbc:derby://localhost/ksidb", "org.apache.derby.jdbc.ClientDriver");
 }


}