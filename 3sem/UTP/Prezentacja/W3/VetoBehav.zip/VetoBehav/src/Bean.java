import java.beans.*;
import java.io.*;



public class Bean implements Serializable {

  private static final long serialVersionUID = -9205446094407397854L;
  
  private transient VetoableChangeSupport veto = new VetoableChangeSupport(this);
  private String text;

  public Bean() {
  }

  
  public String getText() {
    return text;
  }

  
  public void setText(String newText) throws PropertyVetoException {
    veto.fireVetoableChange("text", text, newText);
    text = newText;
  }
  
  public void addVetoableChangeListener( VetoableChangeListener lis) {
    veto.addVetoableChangeListener(lis);
  }
  
  public void removeVetoableChangeListener( VetoableChangeListener lis) {
    veto.removeVetoableChangeListener(lis);
  }

}
