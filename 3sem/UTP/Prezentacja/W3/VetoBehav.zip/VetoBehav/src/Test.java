import java.beans.*;



class Validator implements VetoableChangeListener {

  public void vetoableChange(PropertyChangeEvent e) throws PropertyVetoException {
    String newText = (String) e.getNewValue();
    if (newText.length() == 2) throw new PropertyVetoException("Not valid text", e);
  }
}

public class Test {

  public static void main(String[] args) {
    Bean bean = new Bean();
    bean.addVetoableChangeListener(new Validator());
    try {
      bean.setText("Ok");
      System.out.println(bean.getText());
    } catch (PropertyVetoException e) {
      e.printStackTrace();
    }
    

  }

}
