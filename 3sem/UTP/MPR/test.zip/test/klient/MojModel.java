package klient;

import java.util.Vector;
import java.util.Date;
import javax.swing.table.*;
import javax.swing.JOptionPane;

  public class MojModel extends AbstractTableModel{
        protected Vector dane = new Vector();
        
		private Vector naglowki;
		private boolean zmiana;
		public MojModel(){
			this.dane = dane;
			this.zmiana = zmiana;
			naglowki = new Vector();

			naglowki.add("ID");
			naglowki.add("KRAJ");
			naglowki.add("WYJAZD");
			naglowki.add("POWROT");
			naglowki.add("MIEJSCE");
			naglowki.add("PORA ROKU");
			naglowki.add("CENA");
			
			Oferta temp;
	       	
	       	for(int i=0; i<dane.size(); i++){
	    		temp = (Oferta)dane.get(i);
	    		setValueAt(new Integer(temp.getId()), i, 0);
	    		setValueAt(temp.getKraj(), i, 1);
	    		setValueAt(temp.getWyjazd().toGMTString(), i, 2);
	    		setValueAt(temp.getPowrot().toGMTString(), i, 3);
	    		setValueAt(temp.getMiejsce(), i, 4);
	    		setValueAt(temp.getSezon(), i, 5);
	    		setValueAt(new Double(temp.getCena()), i, 6);
	    	}
		}
		
		public void dodajNowy(){
			dane.add(new Oferta());
		//	System.out.println("dodaje nowy i mam "+dane.size());
			this.fireTableRowsInserted(dane.size(), dane.size());
		}public void dodajNowy(Oferta o){
			dane.add(o);
			//System.out.println("dodaje nowy i mam "+dane.size());
			this.fireTableRowsInserted(dane.size(), dane.size());
		}
		public void usun(int index){
			if(index<0||index>=dane.size())
				return;
			dane.remove(index);
			//System.out.println("usuwam i mam "+dane.size());
			this.fireTableRowsDeleted(index, dane.size());
		}
        public int getColumnCount() {
            return naglowki.size();
        }
      
        public int getRowCount() {
            return dane.size();
        }
        public String getColumnName(int numer){
            return ""+naglowki.get(numer);
        }
        public Object getValueAt(int row, int col){
            Oferta o = (Oferta)dane.get(row);
            if(col==0){
            	return new Integer(o.getId());
            }else if(col==1){
            	return o.getKraj();
            }else if(col==2){
            	return o.getWyjazd();
            }else if(col==3){
            	return o.getPowrot();
            }else if(col==4){
            	return o.getMiejsce();
            }else if(col==5){
            	return o.getSezon();
            }else if(col==6){
            	return new Double(o.getCena());
            }else
            	return null;
        }
     ///   public Class getColumnClass(int c) {
     //       return getValueAt(0, c).getClass();
     //   }
        public boolean isCellEditable(int row, int col) {
                if(col==0)
                	return false;
                else
                	return true;
            
        }
        public void setValueAt(Object value, int row, int col){
        	 Oferta o = (Oferta)dane.get(row);
            if(col==0){
            	o.setId(new Integer(""+value).intValue());
            }else if(col==1){
            	o.setKraj(""+value);
            }else if(col==2){
            	Date temp = o.getWyjazd();
            	try{
            		o.setWyjazd(""+value);
            	}catch(Exception ex){
								JOptionPane.showMessageDialog(null, "Z�Y FORMAT DATY");
								o.setWyjazd(temp);	
				}
            }else if(col==3){
            	Date temp = o.getPowrot();
            	try{
            		o.setPowrot(""+value);
            	}catch(Exception ex){
								JOptionPane.showMessageDialog(null, "ZLY FORMAT DATY");
								o.setPowrot(temp);	
				}
            }else if(col==4){
            	o.setMiejsce(""+value);
            }else if(col==5){
            	o.setSezon(""+value);
            }else if(col==6){
            	o.setCena(new Double(""+value).doubleValue());
            }
			
            fireTableCellUpdated(row, col);
        }
    }