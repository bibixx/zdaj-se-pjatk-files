package klient;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import javax.swing.table.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.io.*;
import java.beans.*;
import java.text.*;

public class BiuroPodrozyZad1 extends JFrame implements ActionListener

{
	public static void main(String[] args)
	{
		BiuroPodrozyZad1 b = new BiuroPodrozyZad1();
		Toolkit tools = Toolkit.getDefaultToolkit();
		Dimension rozmiar = tools.getScreenSize();
		int x = rozmiar.width;
		int y = rozmiar.height;
		
		b.setBounds(0,0,x,y);
		b.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		b.show();
	}
	
	
	JButton polacz;
	JButton select;
	JButton dodaj;
	JButton update;
	JButton usun;
	JTextField adres;
	JTextField port;
		JMenuItem itemSortuj;
		JMenuItem itemZapisz;
		JMenuItem itemWczytaj;
		JMenuItem itemZakoncz;
	
	Klient klient;
	JDialog dialog;
	Locale lokacja;
	ResourceBundle zlokalizowaneZasoby;
	JTable tabela;
	MojModel model;
	JFileChooser chooser = new JFileChooser();
	Collator collator;
	Comparator comp = new Comparator()
	{
		public int compare(Object o1, Object o2)
		{
			Oferta of1 = (Oferta)o1;
			Oferta of2 = (Oferta)o2;
			int wynik = collator.compare(of1.kraj,of2.kraj);
			return wynik;
		}
	};
	
	public BiuroPodrozyZad1()
	{
		
		dialog = new JDialog(this, true);
		JButton hideButton = new JButton("OK");
		hideButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				dialog.hide();
			}
		});
		dialog.getContentPane().add(hideButton, BorderLayout.SOUTH);
		
		JRadioButton rEng = new JRadioButton("English");
		JRadioButton rPol = new JRadioButton("Polski");
		JRadioButton rDeu = new JRadioButton("Deutsch");
		rPol.setSelected(true);
		ButtonGroup group = new ButtonGroup();
		group.add(rEng);
		group.add(rPol);
		group.add(rDeu);
		
		JPanel radioPanel = new JPanel();
		radioPanel.add(rEng);
		radioPanel.add(rPol);
		radioPanel.add(rDeu);
		
		dialog.getContentPane().add(radioPanel);
		
		dialog.pack();
		dialog.show();
		
		if(rEng.isSelected())
		{
			lokacja = new Locale("en","EN");
		}
		else if(rPol.isSelected())
		{
			lokacja = new Locale("pl","PL");
		}
		else if(rDeu.isSelected())
		{
			lokacja = new Locale("de","DE");
		}
		
		collator = Collator.getInstance(lokacja);
		zlokalizowaneZasoby = ResourceBundle.getBundle("Zasoby",lokacja);
		
		setTitle(zlokalizowaneZasoby.getString("BIURO PODROZY"));
		model= new MojModel();
		tabela = new JTable(model)
		{
			public String getToolTipText(MouseEvent e)
			{
				int row = rowAtPoint(e.getPoint());
				Oferta o = (Oferta)model.dane.get(row);
				return o.opis;
			}
		};
		tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		
		dodaj = new JButton(zlokalizowaneZasoby.getString("NOWA OFERTA"));
		usun = new JButton(zlokalizowaneZasoby.getString("USUN ZAZNACZONY"));
		update = new JButton(zlokalizowaneZasoby.getString("AKTUALIZUJ ZAZNACZONY"));
		update.addActionListener(this);
		usun.addActionListener(this);
		dodaj.addActionListener(this);
		JPanel tabelaPanel = new JPanel();
		tabelaPanel.setLayout(new BorderLayout());
		JScrollPane scroll = new JScrollPane(tabela);
		tabelaPanel.add(scroll);
		
		JMenuBar bar = new JMenuBar();
		JMenu menu = new JMenu(zlokalizowaneZasoby.getString("MENU"));
		itemSortuj = new JMenuItem(zlokalizowaneZasoby.getString("SORTUJ"));
		itemZapisz = new JMenuItem(zlokalizowaneZasoby.getString("ZAPISZ"));
		itemWczytaj = new JMenuItem(zlokalizowaneZasoby.getString("WCZYTAJ"));
		itemZakoncz = new JMenuItem(zlokalizowaneZasoby.getString("ZAKONCZ"));
		
		itemSortuj.addActionListener(this);
		itemZapisz.addActionListener(this);
		itemWczytaj.addActionListener(this);
		itemZakoncz.addActionListener(this);
		
		JPanel panelPolaczenia = new JPanel();
		polacz = new JButton(zlokalizowaneZasoby.getString("POLACZ"));
		polacz.addActionListener(this);
		select = new JButton(zlokalizowaneZasoby.getString("SYNCH"));
		select.addActionListener(this);
		adres = new JTextField("localhost");
		port = new JTextField("4444");
		panelPolaczenia.add(new JLabel(zlokalizowaneZasoby.getString("ADRES")));
		panelPolaczenia.add(adres);
		panelPolaczenia.add(new JLabel(zlokalizowaneZasoby.getString("PORT")));
		panelPolaczenia.add(port);
		panelPolaczenia.add(polacz);
		panelPolaczenia.add(select);
		panelPolaczenia.add(dodaj);
		panelPolaczenia.add(usun);
		panelPolaczenia.add(update);
		
		menu.add(itemSortuj);
		menu.add(itemZapisz);
		menu.add(itemWczytaj);
		menu.addSeparator();
		menu.add(itemZakoncz);
		
		bar.add(menu);
		setJMenuBar(bar);
		
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(panelPolaczenia, BorderLayout.NORTH);
		getContentPane().add(tabelaPanel, BorderLayout.CENTER);
	//	getContentPane().add(panel_dol, BorderLayout.SOUTH); 
	
	}
	public void rozlacz(boolean info){
		try{

		klient.gniazdo.close();
		klient = null;
		polacz.setLabel(zlokalizowaneZasoby.getString("POLACZ"));
		if(info)
	    JOptionPane.showMessageDialog(this,zlokalizowaneZasoby.getString("NASTAPILO ROZLACZENIE"));
		}catch(IOException e){}
	}
		public void actionPerformed(ActionEvent e){
				if(e.getSource()==itemSortuj){
					Collections.sort(model.dane, comp);
					model.fireTableRowsUpdated(0, model.dane.size());
				//	odswiezTabele();
	
				}else if(e.getSource()==itemZapisz){
						zapisz();
	
				}else if(e.getSource()==itemWczytaj){
						wczytaj();
	
				}else if(e.getSource()==itemZakoncz){
					System.exit(0);
	
				}else if(e.getSource()==select){
					if(klient==null){
							JOptionPane.showMessageDialog(this,zlokalizowaneZasoby.getString("NIE POLACZONY"));
							return;
					}
					model.dane.removeAllElements();
					model.fireTableRowsDeleted(0, model.dane.size());
					klient.WyslijPytanie(Klient.PROT_GET_ALL);//sciaga do tabeli wszystkie rekordy z tabeli oferty
	
				}else if(e.getSource()==polacz){
					if(klient!=null){
							this.rozlacz(false);
							polacz.setLabel(zlokalizowaneZasoby.getString("POLACZ"));
							return;
					}
					if(adres.getText().equals("")){
						JOptionPane.showMessageDialog(this,zlokalizowaneZasoby.getString("PUSTE POLE ADRESU"));
					return;
					}
						
					if(port.getText().equals("")){
						JOptionPane.showMessageDialog(this,zlokalizowaneZasoby.getString("PUSTE POLE PORTU"));
					return;
					}
					
					int temp;
					try{
						temp = Integer.parseInt(port.getText());
					}catch(NumberFormatException ex){
						JOptionPane.showMessageDialog(this,zlokalizowaneZasoby.getString("NIE JEST LICZBA"));
						return;
					}
					
					klient = new Klient(adres.getText(), temp, this);
					if(klient!=null){
						polacz.setLabel(zlokalizowaneZasoby.getString("ROZLACZ"));
					}
					
	
				}else if(e.getSource() == dodaj){
					if(klient==null){
							JOptionPane.showMessageDialog(this,zlokalizowaneZasoby.getString("NIE POLACZONY"));
							return;
						}
					  double cena=0;
						 try{
						 	String temp = JOptionPane.showInputDialog(null, zlokalizowaneZasoby.getString("CENA"));
						 	if(temp==null){
							JOptionPane.showMessageDialog(null, zlokalizowaneZasoby.getString("CANCEL"));
        					return;
							}
	          				cena = Double.parseDouble(temp);
	          			}catch(NumberFormatException evt){
        					JOptionPane.showMessageDialog(null, zlokalizowaneZasoby.getString("NIE JEST LICZBA"));
        					return;
       					}
						String kraj = JOptionPane.showInputDialog(null, zlokalizowaneZasoby.getString("KRAJ"));
						if(kraj==null){
							JOptionPane.showMessageDialog(null,  zlokalizowaneZasoby.getString("CANCEL"));
        					return;
						}
        				String miejsce  = JOptionPane.showInputDialog(null, zlokalizowaneZasoby.getString("MIEJSCE"));
						if(miejsce==null){
							JOptionPane.showMessageDialog(null,  zlokalizowaneZasoby.getString("CANCEL"));
        					return;
						}
						String sezon  = JOptionPane.showInputDialog(null, zlokalizowaneZasoby.getString("SEZON"));
						if(sezon==null){
							JOptionPane.showMessageDialog(null,  zlokalizowaneZasoby.getString("CANCEL"));
        					return;
						}
						String opis  = JOptionPane.showInputDialog(null, zlokalizowaneZasoby.getString("OPIS"));
						if(opis==null){
							JOptionPane.showMessageDialog(null,  zlokalizowaneZasoby.getString("CANCEL"));
        					return;
						}
						Oferta o = new Oferta();
						try{
						o.setWyjazd(JOptionPane.showInputDialog(null, zlokalizowaneZasoby.getString("DATAW"),  "01.01.2005"));
						}catch(Exception ex){
								JOptionPane.showMessageDialog(null,  zlokalizowaneZasoby.getString("ZLY FORMAT"));
								o.setWyjazd(new Date(System.currentTimeMillis()));	
						}
						try{
						o.setPowrot(JOptionPane.showInputDialog(null, zlokalizowaneZasoby.getString("DATAP"), "01.01.2005"));
						}catch(Exception ex){
								JOptionPane.showMessageDialog(null, zlokalizowaneZasoby.getString("ZLY FORMAT"));
								o.setWyjazd(new Date(System.currentTimeMillis()));	
						}
						
						o.setCena(cena);
						o.setKraj(kraj);
						o.setMiejsce(miejsce);
						o.setSezon(sezon);
						o.setOpis(opis);
						
						klient.dodajDoBazy(o);
					//	model.dodajNowy(o);
				
				}
				else if(e.getSource() == usun){
					int temp = tabela.getSelectedRow();
					if(temp==-1)
						return;
					if(klient==null){
							JOptionPane.showMessageDialog(this,zlokalizowaneZasoby.getString("NIE POLACZONY"));
							return;
					}
					klient.usun((Oferta)model.dane.get(temp));
			 		
			 	}
			 	else if(e.getSource() == update){
			 			int temp = tabela.getSelectedRow();
					if(temp==-1)
						return;

					if(klient==null){
							JOptionPane.showMessageDialog(this,zlokalizowaneZasoby.getString("NIE POLACZONY"));
							return;
						}
					klient.update((Oferta)model.dane.get(temp));
			 	}		
	}
	public void dodajOferte(StringBuffer s){
		Oferta o =null;
		try{
		
			File f = new File("obiekt.tmp"); //tworzy plik tymczasowy
			System.out.println("PRZERABIAM NA OBIEKT "+f.getAbsolutePath());
			FileWriter fw1 = new FileWriter(f);
        	BufferedWriter bw1 = new BufferedWriter(fw1);
        	bw1.write(s.toString());//zapisuje ten bufor
			bw1.close();
			
			XMLDecoder input = new XMLDecoder(new FileInputStream(f));//odczytuje z pliku
			o = (Oferta)input.readObject();//przerabia na obiekt
			input.close();
			
		//	f.delete();//usuwa plik tymczasowy
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(this,zlokalizowaneZasoby.getString("BLAD ODCZYTU"));
		}
		
		Oferta temp=null;
			for(int i = 0; i <model.dane.size(); i++)//sprawdzam czy mam tak� oferte
			{
				temp = (Oferta)model.dane.get(i);
				if(o.getId() == temp.getId()) //mam
				{
					model.dane.remove(i); //usuwam star� wartosc
					model.dane.add(i, o); //wstawiam nowa
					model.fireTableRowsUpdated(i, i);//odsweirzam tabele
					return;
				}
			}
			model.dodajNowy(o);	//petla przeleciala, wiec chyba nie znalazl tej oferty. dodaje
		
	}public void usunOferte(String napis){
		int numer = -1;
		try{
			numer = Integer.parseInt(napis.substring(2, napis.length()));
		}
		catch(NumberFormatException e){return;}
		if(numer==-1)//nie zmienil sie wiec nie wykonalo sie to co na gorze
			return;
		Oferta temp=null;
			for(int i = 0; i <model.dane.size(); i++){//sprawdzam czy mam tak� oferte
				temp = (Oferta)model.dane.get(i);
				if(numer == temp.getId()){ //mam taki numer
					model.usun(i); //usuwam
					return;
				}
			}
	}
	public void zapisz()
	{
		int decyzja = chooser.showSaveDialog(this);
		if(decyzja != chooser.APPROVE_OPTION)
		{
			return;
		}
		try
		{
			XMLEncoder output = new XMLEncoder(new FileOutputStream(chooser.getSelectedFile()));
			output.writeObject(model.dane);
			output.close();
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(this,zlokalizowaneZasoby.getString("BLAD ZAPISU"));				
		}
	}
		
	public void wczytaj()
	{
		int decyzja = chooser.showOpenDialog(this);
		if(decyzja != chooser.APPROVE_OPTION)
		{
			return;
		}
		try
		{
			XMLDecoder input = new XMLDecoder(new FileInputStream(chooser.getSelectedFile()));
			Vector v = (Vector)input.readObject();
			input.close();
			Oferta o;
			for(int i=0; i<v.size(); i++){
				o = (Oferta)v.get(i);
				if(model.dane.contains(o)){
					System.out.println("JUZ TO MAM");
				}else
					model.dodajNowy(o);		
			}
			
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(this,zlokalizowaneZasoby.getString("BLAD ODCZYTU"));
		}
	}	
}
