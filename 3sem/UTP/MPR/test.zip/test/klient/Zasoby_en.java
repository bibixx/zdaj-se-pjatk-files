package klient;

import java.util.*;

public class Zasoby_en extends ListResourceBundle
{
	public Object[][] getContents()
	{
		return contents;
	}
	
	static final Object[][] contents = {
		//dialog
		{"OK", "OK"},
		//pasek tytulowy i menu
		{"BIURO PODROZY", "Travel agency"},
		{"MENU", "Menu"},
		{"DODAJ OFERTE", "Add offer"},
		{"SORTUJ", "Sort"},
		{"ZAPISZ", "Save"},
		{"WCZYTAJ", "Open"},
		{"ZAKONCZ", "Close"},
		//tabela
		{"ID", "Id"},
		{"KRAJ", "Country"},
		{"WYJAZD", "Leave"},
		{"POWROT", "Return"},
		{"MIEJSCE", "Place"},
		{"PORA ROKU", "Season"},
		{"CENA", "Price"},
		//-uwagi
		{"TA OFERTA JUZ JEST DODANA", "This offer is already in database"},
		{"BLAD ODCZYTU", "Error"},
		{"BLAD ZAPISU", "Error"},
		{"PLIK JEST NIEPRAWIDLOWY", "File is not good"},
		//przyciski 
		{"NOWA OFERTA", "new offer"},
		{"USUN ZAZNACZONY", "delete selected"},
		{"AKTUALIZUJ ZAZNACZONY", "update selected"},
		{"POLACZ", "connect"},
		{"ROZLACZ", "disconnect"},
		{"SYNCH", "synchronize table"},
		{"ADRES", "address"},
		{"PORT", "port number"},
		//dialogi
		
		{"NASTAPILO ROZLACZENIE", "disconnected from database server"},
		{"NIE POLACZONY", "not connected"},
		{"PUSTE POLE ADRESU", "empty address text field"},
		{"PUSTE POLE PORTU", "empty port text field"},
		{"NIE JEST LICZBA", "not a number"},
		{"ZLY FORMAT", "wrong date format"},
		{"CANCEL", "cancelled"},
		{"CENA", "define price"},
		{"KRAJ", "enter destination"},
		{"MIEJSCE", "place"},
		{"SEZON", "year costam"},
		{"OPIS", "enter something about the offer"},
		{"DATAW", "enter departue date in DD.MM.YYYY format"},
		{"DATAP", "enter arrival date in DD.MM.YYYY format"},
		
		//***************************** stale z plikow
		// - miejsca
		{"gory", "mountains"},
		{"mountains", "mountains"},
		{"berge", "mountains"},
		
		{"morze", "sea"},
		{"sea", "sea"},
		{"meer", "sea"},
		
		{"jeziora", "lakes"},
		{"lakes", "lakes"},
		{"seen", "lakes"},
		
		//-pory roku
		{"wiosna", "spring"},
		{"spring", "spring"},
		{"fruhling", "spring"},
		
		{"lato", "summer"},
		{"summer", "summer"},
		{"sommer", "summer"},
		
		{"jesien", "autumn"},
		{"autumn", "autumn"},
		{"herbst", "autumn"},
		
		{"zima", "winter"},
		{"winter", "winter"},
		{"winter", "winter"},
		
		//-kraje europejskie
		{"Albania", "Albania"},
		{"Albania", "Albania"},
		{"Albanien", "Albania"},
		
		{"Belgia", "Belgium"},
		{"Belgium", "Belgium"},
		{"Belgien", "Belgium"},
		
		{"Bulgaria", "Bulgaria"},
		{"Bulgaria", "Bulgaria"},
		{"Bulgarien", "Bulgaria"},
		
		{"Dania", "Denmark"},
		{"Denmark", "Denmark"},
		{"Danemark", "Denmark"},
		
		{"Niemcy", "Germany"},
		{"Germany", "Germany"},
		{"Deutschland", "Germany"},
		
		{"Estonia", "Estonia"},
		{"Estonia", "Estonia"},
		{"Estland", "Estonia"},
		
		{"Finlandia", "Finland"},
		{"Finland", "Finland"},
		{"Finnland", "Finland"},
		
		{"Francja", "France"},
		{"France", "France"},
		{"Frankreich", "France"},
		
		{"Grecja", "Greece"},
		{"Greece", "Greece"},
		{"Griechenland", "Greece"},
		
		{"Anglia", "England"},
		{"England", "England"},
		{"England", "England"},
		
		{"Szkocja", "Scotland"},
		{"Scotland", "Scotland"},
		{"Schottland", "Scotland"},
		
		{"Chorwacja", "Craotia"},
		{"Craotia", "Craotia"},
		{"Kroatien", "Craotia"},
		
		{"Wlochy", "Italy"},
		{"Italy", "Italy"},
		{"Italien", "Italy"},
		
		{"Monako", "Monaco"},
		{"Monaco", "Monaco"},
		{"Monaco", "Monaco"},
		
		{"Holandia", "Holland"},
		{"Holland", "Holland"},
		{"Niederlande", "Holland"},
		
		{"Austria", "Austria"},
		{"Austria", "Austria"},
		{"Osterreich", "Austria"},
		
		{"Polska", "Poland"},
		{"Poland", "Poland"},
		{"Polen", "Poland"},
		
		{"Portugalia", "Portugal"},
		{"Portugal", "Portugal"},
		{"Portugal", "Portugal"},
		
		{"Rosja", "Russia"},
		{"Russia", "Russia"},
		{"Russland", "Russia"},
		
		{"Szwecja", "Sweden"},
		{"Sweden", "Sweden"},
		{"Schweden", "Sweden"},
		
		{"Szwajcaria", "Switzerland"},
		{"Switzerland", "Switzerland"},
		{"Schweiz", "Switzerland"},
		
		{"Slowacja", "Slovakia"},
		{"Slovakia", "Slovakia"},
		{"Slowakei", "Slovakia"},
		
		{"Turcja", "Turkey"},
		{"Turkey", "Turkey"},
		{"Turkei", "Turkey"},
		
		{"Wegry", "Hungary"},
		{"Hungary", "Hungary"},
		{"Ungarn", "Hungary"},
		
		//- kraje poza-europejskie
		
		{"Argentyna", "Argentina"},
		{"Argentina", "Argentina"},
		{"Argentina", "Argentina"},
		
		{"Australia", "Australia"},
		{"Australia", "Australia"},
		{"Australien", "Australia"},
		
		{"Brazylia", "Brazil"},
		{"Brazil", "Brazil"},
		{"Brazil", "Brazil"},
		
		{"Chiny", "China"},
		{"China", "China"},
		{"China", "China"},
		
		{"Egipt", "Egypt"},
		{"Egypt", "Egypt"},
		{"Egypt", "Egypt"},
		
		{"Indie", "India"},
		{"India", "India"},
		{"Indien", "India"},
		
		{"Indonezja", "Indonesja"},
		{"Indonesja", "Indonesja"},
		{"Indonezjen", "Indonesja"},
		
		{"Japonia", "Japan"},
		{"Japan", "Japan"},
		{"Japan", "Japan"},
		
		{"Kanada", "Canada"},
		{"Canada", "Canada"},
		{"Kanada", "Canada"},
		
		{"Meksyk", "Mexico"},
		{"Mexico", "Mexico"},
		{"Mexiko", "Mexico"},
		
		{"Nigeria", "Nigeria"},
		{"Nigeria", "Nigeria"},
		{"Nigeria", "Nigeria"},
		
		{"USA", "USA"},
		{"USA", "USA"},
		{"USA", "USA"},
		
		{"Tunezja", "Tunisia"},
		{"Tunisia", "Tunisia"},
		{"Tunesien", "Tunisia"},
		
		{"Wenezuela", "Venezuela"},
		{"Venezuela", "Venezuela"},
		{"Venezuela", "Venezuela"},
		
		
	};
	
}