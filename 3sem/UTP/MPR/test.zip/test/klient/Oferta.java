package klient;

import java.util.*;
import java.io.*;
import java.text.*;


public class Oferta
{
		int id;
		Date wyjazd;
		Date powrot;
		String kraj;
		String miejsce;
		String sezon;
		double cena;
		String opis = "";
	
	public void setId(int l)
	{
		id = l;
	}
	public int getId()
	{
		return id;
	}
	
	public void setWyjazd(Date l)
	{
		wyjazd = l;
	}
	public void setWyjazd(String napis) throws Exception
	{
		String linia = "pl_PL";
		String lok[] = linia.split("_");
		Locale lokalizacja = new Locale(lok[0], lok[1]);
		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, lokalizacja);
		wyjazd = df.parse(napis);
	}
	public Date getWyjazd()
	{
		return wyjazd;
	}
	
	public void setPowrot(Date l)
	{
		powrot = l;
	}
	public void setPowrot(String napis) throws Exception
	{
		String linia = "pl_PL";
		String lok[] = linia.split("_");
		Locale lokalizacja = new Locale(lok[0], lok[1]);
		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, lokalizacja);
		powrot = df.parse(napis);
	}
	public Date getPowrot()
	{
		return powrot;
	}
	public void setKraj(String l)
	{
		kraj = l;
	}
	public String getKraj()
	{
		return kraj;
	}
	public void setMiejsce(String l)
	{
		miejsce = l;
	}
	public String getMiejsce()
	{
		return miejsce;
	}
	public void setSezon(String l)
	{
		sezon = l;
	}
	public String getSezon()
	{
		return sezon;
	}
	public void setCena(double l)
	{
		cena = l;
	}
	public double getCena()
	{
		return cena;
	}
	public void setOpis(String l)
	{
		opis = l;
	}
	
	public String getOpis()
	{
		return opis;
	}
		public Oferta(){
		this.wyjazd = new Date(System.currentTimeMillis());
		this.powrot = new Date(System.currentTimeMillis());
		}
	
	public Oferta(File zrodlo) throws Exception
	{
		BufferedReader r = new BufferedReader(new FileReader(zrodlo));
		
		String linia = r.readLine();
		String lok[] = linia.split("_");
		Locale lokalizacja = new Locale(lok[0], lok[1]);
		
		linia = r.readLine();
		id = Integer.parseInt(linia);
		
		linia = r.readLine();
		StringTokenizer st = new StringTokenizer(linia);
		st.nextToken();
		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, lokalizacja);
		wyjazd = df.parse(st.nextToken());
		powrot = df.parse(st.nextToken());
		kraj = st.nextToken();
		miejsce = st.nextToken();
		sezon = st.nextToken();
		cena = Double.parseDouble(st.nextToken());
		
		while(true)
		{
			linia = r.readLine();
			if (linia == null)
			{
				break;
			}
			opis += linia + "\r\n";
		}
		
		r.close();
	}
}
