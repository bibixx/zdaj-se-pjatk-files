package klient;

import java.util.*;

public class Zasoby_de extends ListResourceBundle
{
	public Object[][] getContents()
	{
		return contents;
	}
	
	static final Object[][] contents = {
		//dialog
		{"OK", "OK"},
		//pasek tytulowy i menu
		{"BIURO PODROZY", "Raise-Fremdenverkehrs Buro"},
		{"MENU", "Menu"},
		{"DODAJ OFERTE", "Addierst Angebot"},
		{"SORTUJ", "Sort"},
		{"ZAPISZ", "Aufschreibst"},
		{"WCZYTAJ", "Ablests"},
		{"ZAKONCZ", "Beendst"},
		//tabela
		{"ID", "Id"},
		{"KRAJ", "Land"},
		{"WYJAZD", "Ausreise"},
		{"POWROT", "Ruckkehr"},
		{"MIEJSCE", "Platz"},
		{"PORA ROKU", "Jahreszeit"},
		{"CENA", "Preis"},
		//-uwagi
		{"TA OFERTA JUZ JEST DODANA", "Dass Angebot ist in Datenbank"},
		{"BLAD ODCZYTU", "Fehler"},
		{"BLAD ZAPISU", "Fehler"},
		{"PLIK JEST NIEPRAWIDLOWY", "File ist nicht gut"},
		//przyciski 
		{"NOWA OFERTA", "new offer"},
		{"USUN ZAZNACZONY", "delete selected"},
		{"AKTUALIZUJ ZAZNACZONY", "update selected"},
		{"POLACZ", "connect"},
		{"ROZLACZ", "disconnect"},
		{"SYNCH", "synchronize table"},
		{"ADRES", "address"},
		{"PORT", "port number"},
		//dialogi
		
		{"NASTAPILO ROZLACZENIE", "disconnected from database server"},
		{"NIE POLACZONY", "not connected"},
		{"PUSTE POLE ADRESU", "empty address text field"},
		{"PUSTE POLE PORTU", "empty port text field"},
		{"NIE JEST LICZBA", "not a number"},
		{"ZLY FORMAT", "wrong date format"},
		{"CANCEL", "cancelled"},
		{"CENA", "define price"},
		{"KRAJ", "enter destination"},
		{"MIEJSCE", "place"},
		{"SEZON", "year costam"},
		{"OPIS", "enter something about the offer"},
		{"DATAW", "enter departue date in DD.MM.YYYY format"},
		{"DATAP", "enter arrival date in DD.MM.YYYY format"},
		
		//***************************** stale z plikow
		// - miejsca
		{"gory", "berge"},
		{"mountains", "berge"},
		{"berge", "berge"},
		
		{"morze", "meer"},
		{"sea", "meer"},
		{"meer", "meer"},
		
		{"jeziora", "seen"},
		{"lakes", "seen"},
		{"seen", "seen"},
		
		//-pory roku
		{"wiosna", "fruhling"},
		{"spring", "fruhling"},
		{"fruhling", "fruhling"},
		
		{"lato", "sommer"},
		{"summer", "sommer"},
		{"sommer", "sommer"},
		
		{"jesien", "herbst"},
		{"autumn", "herbst"},
		{"herbst", "herbst"},
		
		{"zima", "winter"},
		{"winter", "winter"},
		{"winter", "winter"},
		
		//-kraje europejskie
		{"Albania", "Albanien"},
		{"Albania", "Albanien"},
		{"Albanien", "Albanien"},
		
		{"Belgia", "Belgien"},
		{"Belgium", "Belgien"},
		{"Belgien", "Belgien"},
		
		{"Bulgaria", "Bulgarien"},
		{"Bulgaria", "Bulgarien"},
		{"Bulgarien", "Bulgarien"},
		
		{"Dania", "Danemark"},
		{"Denmark", "Danemark"},
		{"Danemark", "Danemark"},
		
		{"Niemcy", "Deutschland"},
		{"Germany", "Deutschland"},
		{"Deutschland", "Deutschland"},
		
		{"Estonia", "Estland"},
		{"Estonia", "Estland"},
		{"Estland", "Estland"},
		
		{"Finlandia", "Finnland"},
		{"Finland", "Finnland"},
		{"Finnland", "Finnland"},
		
		{"Francja", "Frankreich"},
		{"France", "Frankreich"},
		{"Frankreich", "Frankreich"},
		
		{"Grecja", "Griechenland"},
		{"Greece", "Griechenland"},
		{"Griechenland", "Griechenland"},
		
		{"Anglia", "England"},
		{"England", "England"},
		{"England", "England"},
		
		{"Szkocja", "Schottland"},
		{"Scotland", "Schottland"},
		{"Schottland", "Schottland"},
		
		{"Chorwacja", "Kroatien"},
		{"Craotia", "Kroatien"},
		{"Kroatien", "Kroatien"},
		
		{"Wlochy", "Italien"},
		{"Italy", "Italien"},
		{"Italien", "Italien"},
		
		{"Monako", "Monaco"},
		{"Monaco", "Monaco"},
		{"Monaco", "Monaco"},
		
		{"Holandia", "Niederlande"},
		{"Holland", "Niederlande"},
		{"Niederlande", "Niederlande"},
		
		{"Austria", "Osterreich"},
		{"Austria", "Osterreich"},
		{"Osterreich", "Osterreich"},
		
		{"Polska", "Polen"},
		{"Poland", "Polen"},
		{"Polen", "Polen"},
		
		{"Portugalia", "Portugal"},
		{"Portugal", "Portugal"},
		{"Portugal", "Portugal"},
		
		{"Rosja", "Russland"},
		{"Russia", "Russland"},
		{"Russland", "Russland"},
		
		{"Szwecja", "Schweden"},
		{"Sweden", "Schweden"},
		{"Schweden", "Schweden"},
		
		{"Szwajcaria", "Schweiz"},
		{"Switzerland", "Schweiz"},
		{"Schweiz", "Schweiz"},
		
		{"Slowacja", "Slowakei"},
		{"Slovakia", "Slowakei"},
		{"Slowakei", "Slowakei"},
		
		{"Turcja", "Turkei"},
		{"Turkey", "Turkei"},
		{"Turkei", "Turkei"},
		
		{"Wegry", "Ungarn"},
		{"Hungary", "Ungarn"},
		{"Ungarn", "Ungarn"},
		
		//- kraje poza-europejskie
		
		{"Argentyna", "Argentina"},
		{"Argentina", "Argentina"},
		{"Argentina", "Argentina"},
		
		{"Australia", "Australien"},
		{"Australia", "Australien"},
		{"Australien", "Australien"},
		
		{"Brazylia", "Brazil"},
		{"Brazil", "Brazil"},
		{"Brazil", "Brazil"},
		
		{"Chiny", "China"},
		{"China", "China"},
		{"China", "China"},
		
		{"Egipt", "Egypt"},
		{"Egypt", "Egypt"},
		{"Egypt", "Egypt"},
		
		{"Indie", "Indien"},
		{"India", "Indien"},
		{"Indien", "Indien"},
		
		{"Indonezja", "Indonezjen"},
		{"Indonesja", "Indonezjen"},
		{"Indonezjen", "Indonezjen"},
		
		{"Japonia", "Japan"},
		{"Japan", "Japan"},
		{"Japan", "Japan"},
		
		{"Kanada", "Kanada"},
		{"Canada", "Kanada"},
		{"Kanada", "Kanada"},
		
		{"Meksyk", "Mexiko"},
		{"Mexico", "Mexiko"},
		{"Mexiko", "Mexiko"},
		
		{"Nigeria", "Nigeria"},
		{"Nigeria", "Nigeria"},
		{"Nigeria", "Nigeria"},
		
		{"USA", "USA"},
		{"USA", "USA"},
		{"USA", "USA"},
		
		{"Tunezja", "Tunesien"},
		{"Tunisia", "Tunesien"},
		{"Tunesien", "Tunesien"},
		
		{"Wenezuela", "Venezuela"},
		{"Venezuela", "Venezuela"},
		{"Venezuela", "Venezuela"},
		
		
	};
	
}