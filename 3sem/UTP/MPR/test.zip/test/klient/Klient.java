package klient;

import java.io.*;
import java.net.*;
public class Klient 
{		
public static final String PROT_GET_ALL = "><";
public static final String PROT_INSERT = "++";
public static final String PROT_REMOVE = "--";
public static final String PROT_UPDATE = ">>";
public static final String PROT_OBJ_POCZATEK = ">OF_P";
public static final String PROT_OBJ_KONIEC = ">OF_K";

		BiuroPodrozyZad1 gui;
		protected Socket gniazdo = null;
		private PrintWriter pw = null;
		private BufferedReader br = null;
		private Odczyt o;
		// nazwaHosta okre�la host na kt�rym uruchomiono 
		// aplikacj� serwera; poniewa� program klienta i serwera 
		// uruchomiono na tym samym komputerze warto�ci� tej 
		// zmiennej jest 'localhost'  deklaracja postaci:
		// String nazwaHosta = "coral.put.poznan.pl";
		// oznacza, �e aplikacj� serwera uruchomiono na ho�cie
		// coral.put.poznan.pl 
		private String nazwaHosta = "localhost"; 
		private int nrPortu = 3535;
	public Klient(String nazwaHosta, int nrPortu, BiuroPodrozyZad1 z){
		this.gui = z;
		this.nazwaHosta = nazwaHosta;
		this.nrPortu = nrPortu;
		try
		{
			gniazdo = new Socket(nazwaHosta, nrPortu);
			pw = new PrintWriter(gniazdo.getOutputStream());
			br = new BufferedReader(new InputStreamReader(gniazdo.getInputStream()));
			o = new Odczyt();
            o.start();
		}
		catch (UnknownHostException e) 
		{ System.err.println("Host: "+ nazwaHosta +" nieznany"); }
		catch (IOException e) 
		{System.err.println("Blad operacji I/O dla: "+nazwaHosta);}
		
	}
	public void WyslijPytanie(String pytanie){
		if (gniazdo== null || pw == null || br == null)
			return;
		//	System.out.println(pytanie);
			pw.print(pytanie);
			pw.print('\n');
			pw.flush();
	}
	public void dodajDoBazy(Oferta o){
		//insert into oferty(of_kraj, of_wyjazd, of_powrot, of_miejsce, of_sezon, of_cena, of_opis) Values ('polska', '2003-05-30', '2003-06-14','morze', 'lato', 1400, 'super wycieczka normalnie');
		WyslijPytanie(this.PROT_INSERT+"insert into oferty (of_kraj, of_wyjazd, of_powrot, of_miejsce, of_sezon, of_cena, of_opis) Values ('"+
			o.getKraj()+"', '"+o.getWyjazd().toGMTString()+"', '"+o.getPowrot().toGMTString()+"','"+o.getMiejsce()+"', '"+o.getSezon()+"', "+o.getCena()+", '"+o.getOpis()+"');"
		);
	}
	public void usun(Oferta o){
		WyslijPytanie(this.PROT_REMOVE+"delete from oferty where of_id='"+o.getId()+"';");
		
	}
	public void update(Oferta o){
	
		WyslijPytanie(this.PROT_UPDATE+"update oferty set of_kraj='"+o.getKraj()+"', of_wyjazd='"+o.getWyjazd().toGMTString()+"', of_powrot='"+o.getPowrot().toGMTString()+
		"', of_miejsce='"+o.getMiejsce()+"', of_sezon='"+o.getSezon()+"', of_cena="+o.getCena()+", of_opis='"+o.getOpis()+"' where of_id='"+o.getId()+"';"
		);
	}
	 class Odczyt extends Thread{
        
        private char znak;
        private boolean dziala=true;
        private StringBuffer komunikat = new StringBuffer();
        
        public Odczyt(){
        	System.out.println("tworze klase odczytu");

        }
        public void run(){//tu rdze� odczytu najwa�niejsza p�tla w Sesji
			String odp;
			StringBuffer buf = new StringBuffer(50);
			try{
				while ((odp = br.readLine()) != null){
					if(odp.equals(Klient.PROT_OBJ_POCZATEK)){//poczatek obiektu OFERTA POCZATEK
						buf.delete(0, buf.length());
						System.out.println("PRZYSZEDL POCZATEK OBIEKTU");
					}
					else if(odp.equals(Klient.PROT_OBJ_KONIEC)){ //koniec obiektu OFERTA KONIEC
						System.out.println("PRZYSZEDL KONIEC OBIEKTU");
						gui.dodajOferte(buf);
					}else if(odp.substring(0,2).equals(Klient.PROT_REMOVE)){ //koniec obiektu OFERTA KONIEC
						System.out.println("USUNIETO REKORD");
						gui.usunOferte(odp);
					}else{
						System.out.println(odp);
						buf.append(odp);
						}
				}
           }catch(IOException e){
                    System.out.println("\n===========================\nP�tla odczytu przerwana");
                    System.err.println(e+"\n===========================\n");
                    gui.rozlacz(true);
           }
        }
            
    }
}

