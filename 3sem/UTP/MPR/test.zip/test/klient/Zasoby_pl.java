package klient;

import java.util.*;

public class Zasoby_pl extends ListResourceBundle
{
	public Object[][] getContents()
	{
		return contents;
	}
	
	static final Object[][] contents = {
		//dialog
		{"OK", "OK"},
		//pasek tytulowy i menu
		{"BIURO PODROZY", "Biuro podrozy"},
		{"MENU", "Menu"},
		{"DODAJ OFERTE", "Dodaj oferte"},
		{"SORTUJ", "Sortuj"},
		{"ZAPISZ", "Zapisz"},
		{"WCZYTAJ", "Wczytaj"},
		{"ZAKONCZ", "Zakoncz"},
		//tabela
		{"ID", "Id"},
		{"KRAJ", "Kraj"},
		{"WYJAZD", "Wyjazd"},
		{"POWROT", "Powrot"},
		{"MIEJSCE", "Miejsce"},
		{"PORA ROKU", "Pora roku"},
		{"CENA", "Cena"},
		//-uwagi
		{"TA OFERTA JUZ JEST DODANA", "Ta oferta juz jest dodana"},
		{"BLAD ODCZYTU", "Blad odczytu"},
		{"BLAD ZAPISU", "Blad zapisu"},
		{"PLIK JEST NIEPRAWIDLOWY", "Plik jest nieprawidlowy"},
		//przyciski 
		{"NOWA OFERTA", "nowa oferta"},
		{"USUN ZAZNACZONY", "usu� zaznaczon�"},
		{"AKTUALIZUJ ZAZNACZONY", "aktualizuj zaznaczon�"},
		{"POLACZ", "po��cz"},
		{"ROZLACZ", "roz��cz"},
		{"SYNCH", "synchronizuj tabel�"},
		{"ADRES", "adres"},
		{"PORT", "numer portu"},
		//dialogi
		
		{"NASTAPILO ROZLACZENIE", "nast�pi�o roz��czenie"},
		{"NIE POLACZONY", "nie pod��czony"},
		{"PUSTE POLE ADRESU", "puste pole adresu"},
		{"PUSTE POLE PORTU", "puste pole portu"},
		{"NIE JEST LICZBA", "wpisana warto�� nie jest liczb�"},
		{"ZLY FORMAT", "z�y format daty"},
		{"CANCEL", "anulowano dzia�anie"},
		{"CENA", "zdefiniuj cen�"},
		{"KRAJ", "wpisz cel podr�y"},
		{"MIEJSCE", "miejsce"},
		{"SEZON", "pora roku"},
		{"OPIS", "dodatkowe informacje o ofercie"},
		{"DATAW", "wprowad� dat� wyjazdu w formacie DD.MM.YYYY"},
		{"DATAP", "wprowad� dat� powrotu w formacie DD.MM.YYYY"},
		
		//***************************** stale z plikow
		// - miejsca
		{"gory", "gory"},
		{"mountains", "gory"},
		{"berge", "gory"},
		
		{"morze", "morze"},
		{"sea", "morze"},
		{"meer", "morze"},
		
		{"jeziora", "jeziora"},
		{"lakes", "jeziora"},
		{"seen", "jeziora"},
		
		//-pory roku
		{"wiosna", "wiosna"},
		{"spring", "wiosna"},
		{"fruhling", "wiosna"},
		
		{"lato", "lato"},
		{"summer", "lato"},
		{"sommer", "lato"},
		
		{"jesien", "jesien"},
		{"autumn", "jesien"},
		{"herbst", "jesien"},
		
		{"zima", "zima"},
		{"winter", "zima"},
		{"winter", "zima"},
		
		//-kraje europejskie
		{"Albania", "Albania"},
		{"Albania", "Albania"},
		{"Albanien", "Albania"},
		
		{"Belgia", "Belgia"},
		{"Belgium", "Belgia"},
		{"Belgien", "Belgia"},
		
		{"Bulgaria", "Bulgaria"},
		{"Bulgaria", "Bulgaria"},
		{"Bulgarien", "Bulgaria"},
		
		{"Dania", "Dania"},
		{"Denmark", "Dania"},
		{"Danemark", "Dania"},
		
		{"Niemcy", "Niemcy"},
		{"Germany", "Niemcy"},
		{"Deutschland", "Niemcy"},
		
		{"Estonia", "Estonia"},
		{"Estonia", "Estonia"},
		{"Estland", "Estonia"},
		
		{"Finlandia", "Finlandia"},
		{"Finland", "Finlandia"},
		{"Finnland", "Finlandia"},
		
		{"Francja", "Francja"},
		{"France", "Francja"},
		{"Frankreich", "Francja"},
		
		{"Grecja", "Grecja"},
		{"Greece", "Grecja"},
		{"Griechenland", "Grecja"},
		
		{"Anglia", "Anglia"},
		{"England", "Anglia"},
		{"England", "Anglia"},
		
		{"Szkocja", "Szkocja"},
		{"Scotland", "Szkocja"},
		{"Schottland", "Szkocja"},
		
		{"Chorwacja", "Chorwacja"},
		{"Craotia", "Chorwacja"},
		{"Kroatien", "Chorwacja"},
		
		{"Wlochy", "Wlochy"},
		{"Italy", "Wlochy"},
		{"Italien", "Wlochy"},
		
		{"Monako", "Monako"},
		{"Monaco", "Manako"},
		{"Monaco", "Monako"},
		
		{"Holandia", "Holandia"},
		{"Holland", "Holandia"},
		{"Niederlande", "Holandia"},
		
		{"Austria", "Austria"},
		{"Austria", "Austria"},
		{"Osterreich", "Austria"},
		
		{"Polska", "Polska"},
		{"Poland", "Polska"},
		{"Polen", "Polska"},
		
		{"Portugalia", "Portugalia"},
		{"Portugal", "Portugalia"},
		{"Portugal", "Portugalia"},
		
		{"Rosja", "Rosja"},
		{"Russia", "Rosja"},
		{"Russland", "Rosja"},
		
		{"Szwecja", "Szwecja"},
		{"Sweden", "Szwecja"},
		{"Schweden", "Szwecja"},
		
		{"Szwajcaria", "Szwajcaria"},
		{"Switzerland", "Szwajcaria"},
		{"Schweiz", "Szwajcaria"},
		
		{"Slowacja", "Slowacja"},
		{"Slovakia", "Slowacja"},
		{"Slowakei", "Slowacja"},
		
		{"Turcja", "Turcja"},
		{"Turkey", "Turcja"},
		{"Turkei", "Turcja"},
		
		{"Wegry", "Wegry"},
		{"Hungary", "Wegry"},
		{"Ungarn", "Wegry"},
		
		//- kraje poza-europejskie
		
		{"Argentyna", "Argentyna"},
		{"Argentina", "Argentyna"},
		{"Argentina", "Argentyna"},
		
		{"Australia", "Australia"},
		{"Australia", "Australia"},
		{"Australien", "Australia"},
		
		{"Brazylia", "Brazylia"},
		{"Brazil", "Brazylia"},
		{"Brazil", "Brazylia"},
		
		{"Chiny", "Chiny"},
		{"China", "Chiny"},
		{"China", "Chiny"},
		
		{"Egipt", "Egipt"},
		{"Egypt", "Egipt"},
		{"Egypt", "Egipt"},
		
		{"Indie", "India"},
		{"India", "Indie"},
		{"Indien", "Indie"},
		
		{"Indonezja", "Indonezja"},
		{"Indonesja", "Indonezja"},
		{"Indonezjen", "Indonezja"},
		
		{"Japonia", "Japonia"},
		{"Japan", "Japonia"},
		{"Japan", "Japonia"},
		
		{"Kanada", "Kanada"},
		{"Canada", "Kanada"},
		{"Kanada", "Kanada"},
		
		{"Meksyk", "Meksyk"},
		{"Mexico", "Meksyk"},
		{"Mexiko", "Meksyk"},
		
		{"Nigeria", "Nigeria"},
		{"Nigeria", "Nigeria"},
		{"Nigeria", "Nigeria"},
		
		{"USA", "USA"},
		{"USA", "USA"},
		{"USA", "USA"},
		
		{"Tunezja", "Tunezja"},
		{"Tunisia", "Tunezja"},
		{"Tunesien", "Tunezja"},
		
		{"Wenezuela", "Wenezuela"},
		{"Venezuela", "Wenezuela"},
		{"Venezuela", "Wenezuela"},
		
		
	};
	
}