/**
 *
 *  @author Jabłoński Sławomir S14736
 *
 */

package zad2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CustomersPurchaseSortFind {
public static List<Purchase> list; 
	
	public void readFile(String fname) throws FileNotFoundException {
		Scanner sc = new Scanner(new File(fname));
		String id_klienta;
		String nazwisko;
		String nazwa;
		float cena;
		float ilosc;
		String temp;
		list=new ArrayList<Purchase>();
		while(sc.hasNext()){
			sc.useDelimiter(";|\n");
			id_klienta = sc.next();
			nazwisko = sc.next();
			nazwa=sc.next();
			cena= Float.parseFloat(sc.next());
			temp = sc.next();
			ilosc= Float.parseFloat(temp.substring(0));
			list.add(new Purchase(id_klienta, nazwisko, nazwa, cena, ilosc));
		}
		sc.close();
	}

	public void showSortedBy(String string) {
		List<Purchase> sortedList=new ArrayList<Purchase>(list);
		if(string == "Nazwiska") {
			sortedList.sort(new NameComparator());
			System.out.println("Nazwiska");
			for(int i=0;i<sortedList.size();i++){
				sortedList.get(i).print();
			}
		}
		else if (string == "Koszty") {
			sortedList.sort(new CostComparator());
			System.out.println("\nKoszty");
			for(int i=0;i<sortedList.size();i++){
				sortedList.get(i).printKoszt();
			}
		}
	}

	public void showPurchaseFor(String id) {
		System.out.println("\nKlient "+id);
		for(int i=0;i<list.size();i++){
			if(list.get(i).id_klienta.equals(id)){
				list.get(i).print();
			}
		}
	}
}
