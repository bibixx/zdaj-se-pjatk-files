package zad2;

import java.util.Comparator;

public class NameComparator implements Comparator<Purchase> {

	@Override
	public int compare(Purchase o1, Purchase o2) {
		if(o1.nazwisko.compareTo(o2.nazwisko)==0){
			return o1.id_klienta.compareTo(o2.id_klienta);
		}
		else{
			return o1.nazwisko.compareTo(o2.nazwisko);
		}
	}
}
