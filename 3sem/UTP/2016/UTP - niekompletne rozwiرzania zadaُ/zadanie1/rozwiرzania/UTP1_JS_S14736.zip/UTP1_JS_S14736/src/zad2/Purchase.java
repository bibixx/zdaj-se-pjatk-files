/**
 *
 *  @author Jabłoński Sławomir S14736
 *
 */

package zad2;


public class Purchase {
	public String id_klienta;
	public String nazwisko;
	public String nazwa;
	public float cena;
	public float ilosc;
	public float koszt;
	
	public Purchase(String id, String nazwisko, String nazwa, float cena, float ilosc) {
		this.id_klienta = id;
		this.nazwisko = nazwisko;
		this.nazwa = nazwa;
		this.cena = cena;
		this.ilosc = ilosc;
		this.koszt = ilosc * cena;
	}
	
	public void print () {
		System.out.println(id_klienta + ";" + nazwisko + ";" + nazwa + ";" + cena + ";" + ilosc);
	}
	
	public void printKoszt () {
		System.out.println(id_klienta + ";" + nazwisko + ";" + nazwa + ";" + cena + ";" + ilosc 
				+ " koszt:(" + koszt + ")");
	}

}
