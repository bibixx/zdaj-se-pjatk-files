/**
 *
 *  @author Jabłoński Sławomir S14736
 *
 */

package zad1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Anagrams {

	
	public List<String> list;
	public List<List<String>> sortedList;
	
	public Anagrams(String allWords) throws FileNotFoundException {
		list = new ArrayList<String>();
		sortedList= new ArrayList<List<String>>();
		Scanner sc = new Scanner(new File(allWords));
		
		while(sc.hasNext()) {
			list.add(sc.next());
		}
		sc.close();
	}
	
	List<List<String>> getSortedByAnQty() {
		List<List<String>> listOfLists = new ArrayList<List<String>>();
		List<String> temp = new ArrayList<String>();
		List<String> listCpy = new ArrayList<String>(list); 
		
		for(String wordToCompare : list) { // przebiegamy przez allwords.txt
			if(listCpy.contains(wordToCompare)) {
				temp.add(wordToCompare);
				for (int i = list.indexOf(wordToCompare)+1; i<list.size();i++) {
					if(wordToCompare.length() == list.get(i).length() 
							&& checkAns(wordToCompare, list.get(i))) {
						temp.add(list.get(i));
						listCpy.remove(list.get(i));
					}				
				}
				listOfLists.add(new ArrayList<String>(temp));
				temp.clear();
			}
		}
		listOfLists.sort(new ListComparator());
		sortedList= new ArrayList<List<String>>(listOfLists);
		return listOfLists;
	};
	
	boolean checkAns(String str1, String str2) {
		for (int j=0;j<str1.length();j++) {
			if(!str2.contains(Character.toString(str1.charAt(j))) ) {
				return false;
			}
		}
		return true;
		
	}
	
	
	String getAnagramsFor(String word){
		String result=word+": ";
		for(int i=0;i<sortedList.size();i++){
			for(int j=0;j<sortedList.get(i).size();j++){
				if((sortedList.get(i)).get(j).equals(word)){
					(sortedList.get(i)).remove(word);
					result+=sortedList.get(i);
				}
			}
		}
		if(result == word+": "){
			result+="null";
		}
		return result;
	}
}  
