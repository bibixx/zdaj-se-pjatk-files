/**
 *
 *  @author Jabłoński Sławomir S14736
 *
 */

package zad4;


public class Author implements Runnable {
}  
