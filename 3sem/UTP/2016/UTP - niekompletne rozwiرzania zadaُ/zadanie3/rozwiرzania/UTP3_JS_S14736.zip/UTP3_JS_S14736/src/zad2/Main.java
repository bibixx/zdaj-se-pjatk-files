/**
 *
 *  @author Jabłoński Sławomir S14736
 *
 */
//Zad. 2. FTSERV (max. punktów 4)
//Napisać w sposób właściwy prosty przykładowy  serwer wielowątkowy TCP/IP (na gniazdach).
//Obsługę zleceń zrealizowac w postaci FutureTask. Zadbać o możliwość przerywania obsługi w każdym momencie.
package zad2;


public class Main {

  public static void main(String[] args) {
	  MultiThreadedServer server = new MultiThreadedServer(9000);
	  System.out.println("Starting Server");
	  new Thread(server).start();
	  System.out.println("Server started.");
	  try {
	      Thread.sleep(20 * 1000);
	  } catch (InterruptedException e) {
	      e.printStackTrace();
	  }
	  System.out.println("Stopping Server");
	  server.stop();
  }
}
