package zad3;

public class WriterSync extends Thread {
	Teksty txtArea;

	  public WriterSync(Teksty t) {
	    txtArea=t;
	  }

	  public void run() {
	    String txt = txtArea.getTextToWrite();
	    while(txt != null) {
	      System.out.println("-> " + txt);
	      txt = txtArea.getTextToWrite();
	      }
	  }
}
