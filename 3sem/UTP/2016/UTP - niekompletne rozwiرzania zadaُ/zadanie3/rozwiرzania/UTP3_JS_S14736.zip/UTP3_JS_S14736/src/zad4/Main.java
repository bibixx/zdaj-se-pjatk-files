/**
 *
 *  @author Jabłoński Sławomir S14736
 *
 */
//Zad. 4. KOORD (max. punktów 10)
//Napisać program Author-Writer z wykładu przy użyciu blokujących kolejek.
//Jako argumenty program otrzymuje napisy, które co sekundę ma generować Author.
//Writer ma je wypisywać na konsoli.
package zad4;


public class Main {
  public static void main(String[] args) {
    Author autor = new Author(args);
    new Thread(autor).start();
    new Thread(new Writer(autor)).start();
  }
}
