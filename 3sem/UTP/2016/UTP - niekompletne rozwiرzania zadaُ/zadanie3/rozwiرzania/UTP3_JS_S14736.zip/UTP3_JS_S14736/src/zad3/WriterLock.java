package zad3;

public class WriterLock extends Thread {

}
