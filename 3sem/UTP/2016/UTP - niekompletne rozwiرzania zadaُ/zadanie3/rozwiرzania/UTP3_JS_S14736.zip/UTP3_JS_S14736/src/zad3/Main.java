/**
 *
 *  @author Jabłoński Sławomir S14736
 *
 */
//Zad. 3. RWLOCKS (max. punktów 5)
//Pokazać zastosowanie read/write locków i porównać ich efektywność w stosunku do zwykłej synchronizacji.
package zad3;


public class Main {

  public static void main(String[] args) {
	  Teksty t = new Teksty();
	     Thread t1 = new AuthorSync(t);
	     Thread t2 = new WriterSync(t);
	     t1.start();
	     t2.start();
  }
}
