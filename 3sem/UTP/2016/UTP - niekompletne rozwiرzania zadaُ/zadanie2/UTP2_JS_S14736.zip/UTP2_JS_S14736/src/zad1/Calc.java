/**
 *
 *  @author Jabłoński Sławomir S14736
 *
 */

package zad1;


public class Calc {
}  
