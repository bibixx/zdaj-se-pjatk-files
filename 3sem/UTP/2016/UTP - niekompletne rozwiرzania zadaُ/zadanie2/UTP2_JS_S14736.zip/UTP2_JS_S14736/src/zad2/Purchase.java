/**
 *
 *  @author Jabłoński Sławomir S14736
 *
 */

package zad2;


public class Purchase {
}  
