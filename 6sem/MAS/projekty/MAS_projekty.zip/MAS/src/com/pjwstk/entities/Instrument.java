package com.pjwstk.entities;

import com.pjwstk.entities.utils.ExtensionHandle;
import com.pjwstk.mp02.AssociationHandle;

public abstract class Instrument extends AssociationHandle {
	private String name;
	//atrybut opcjonalny
	private String tone = null;
	
	protected Instrument(String name){
		super();
		this.name = name;
	}
	
	protected Instrument(String name, String tone){
		super();
		this.name = name;
		this.tone = tone;
	}
	
	public String showInstrumentProperties(){
		return "name:"+name+(tone==null?"":", tone: "+tone);
	}
	
	@Override
	public String toString() {
		return "["+super.toString()+"]"+showInstrumentProperties();
	}
}
