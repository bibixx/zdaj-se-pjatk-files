package com.pjwstk.entities;

import java.util.HashSet;
import java.util.Set;

import com.pjwstk.entities.utils.ExtensionHandle;
import com.pjwstk.mp02.AssociationHandle;

public class Person extends AssociationHandle{

	private Integer id_person;
	private String name;
	private String surname;
	//atrybut powtarzalny
	private Set<Phone> phones;
	
	//TODO Temporary id generator [change with JPA annotations+Hibernate]
	private static Integer id = 0;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public Set<Phone> getPhones() {
		return phones;
	}

	public void setPhones(Set<Phone> phones) {
		this.phones = phones;
	}
	
	

	public Person(String name, String surname,Set<Phone> phones) {
		super();
		this.id_person = id++;
		this.name = name;
		this.surname = surname;
		this.phones = phones;
	}
	
	public Person(String name, String surname,Phone phone) {
		super();
		this.id_person = id++;
		this.name = name;
		this.surname = surname;
		this.phones = new HashSet<Phone>();
		this.phones.add(phone);
	}
	
	@Override
	public String toString() {
		return "["+super.toString()+"]name:"+this.name+", surname:"
				+this.surname+", phones:"+this.phones;
	}
}
