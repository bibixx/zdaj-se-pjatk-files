package com.pjwstk.mp04;

import java.util.HashSet;
import java.util.Set;

public class SoundTechnicianMP04 {
	private Integer uniqueID;
	private Double basicSalary;
	private static final Double minSalary = new Double(600);
	private static Integer ID = 0;
	
	public SoundTechnicianMP04(Double basicSalary) {
		this.uniqueID = ID++;
		this.setBasicSalary(basicSalary);
	}

	public Integer getUniqueID() {
		return uniqueID;
	}

	public Double getBasicSalary() {
		return basicSalary;
	}

	//OGRANICZENIE ATRYBUTU
	public void setBasicSalary(Double basicSalary) {
		if(basicSalary>minSalary)
			this.basicSalary = basicSalary;
		else
			this.basicSalary = minSalary;
	}
	
	@Override
	public String toString() {
		return "["+super.toString()+"]uniqueID:"+this.uniqueID
				+", basicSalary:"+this.basicSalary;
	}
}
