package com.pjwstk.entities.instruments;

import com.pjwstk.entities.Instrument;

public class Membranophone extends Instrument {
	private String membraneShape;
	
	public Membranophone(String name, String membraneShape) {
		super(name);
		this.membraneShape=membraneShape;
	}
	
	public Membranophone(String name, String tone, String membraneShape) {
		super(name,tone);
		this.membraneShape=membraneShape;
	}
	
	//metoda przeslonieta
	@Override
	public String showInstrumentProperties() {
		return super.showInstrumentProperties()+", membraneShape:"+membraneShape;
	}
}
