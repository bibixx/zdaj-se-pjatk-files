package com.pjwstk.mp03;

import java.util.Calendar;
import java.util.Date;

import com.pjwstk.entities.Phone;

public class EmployeeD extends PersonD{

	//atrybut z�o�ony
	protected Date employmentDate;
	
	public EmployeeD(String name,String surname,Phone phone,Gender gender) {
		super(name,surname,phone,gender);
		this.employmentDate = Calendar.getInstance().getTime();
	}
	
	public EmployeeD(PersonD person) {
		super(person);
		this.employmentDate = Calendar.getInstance().getTime();
	}
	
	@Override
	public String toString() {
		return "["+super.toString()+"]employmentDate:"+employmentDate;
	}
}
