package com.pjwstk.entities;

import java.util.Calendar;
import java.util.Date;

import com.pjwstk.mp02.AssociationHandle;


public class Employee extends AssociationHandle{

	//atrybut z�o�ony
	protected Date employmentDate;
	
	public Employee() {
		this.employmentDate = Calendar.getInstance().getTime();
	}
	
	@Override
	public String toString() {
		return "["+super.toString()+"]employmentDate:"+employmentDate;
	}
}
