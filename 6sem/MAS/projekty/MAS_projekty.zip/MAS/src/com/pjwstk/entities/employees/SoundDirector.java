package com.pjwstk.entities.employees;

import com.pjwstk.entities.Employee;
import com.pjwstk.entities.Phone;

public class SoundDirector extends Employee{
	public SoundDirector() {
	}
}
