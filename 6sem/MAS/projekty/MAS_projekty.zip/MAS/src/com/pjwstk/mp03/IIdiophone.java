package com.pjwstk.mp03;

public interface IIdiophone {
	public String getVibraShape();
	public void setVibraShape(String vibraShape);
	public String toString();
}
