package com.pjwstk.entities;

import java.util.List;

import com.pjwstk.mp02.AssociationHandle;
import com.pjwstk.mp02.Reservation;


public class Client extends AssociationHandle{
	
	public Client() {
	}
	
	
}
