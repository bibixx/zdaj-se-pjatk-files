package com.pjwstk.mp03;

import com.pjwstk.mp02.AssociationHandle;

public abstract class Gender extends AssociationHandle {
	protected Gender() {
		super();
	}
}
