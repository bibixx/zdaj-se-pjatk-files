package com.pjwstk.entities.instruments;

import com.pjwstk.entities.Instrument;
import com.pjwstk.mp03.IIdiophone;

public class Idiophone extends Instrument implements IIdiophone {

	private String vibraShape;
	
	public Idiophone(String name, String vibraShape) {
		super(name);
		this.vibraShape = vibraShape;
	}
	
	public Idiophone(String name,String tone,String vibraShape){
		super(name,tone);
		this.vibraShape = vibraShape;
	}
	
	public String getVibraShape(){
		return this.vibraShape;
	}
	
	public void setVibraShape(String vibraShape){
		this.vibraShape=vibraShape;
	}
	
	//metoda przeslonieta
	@Override
	public String showInstrumentProperties() {
		return super.showInstrumentProperties()+", vibraShape:"+vibraShape;
	}
}
