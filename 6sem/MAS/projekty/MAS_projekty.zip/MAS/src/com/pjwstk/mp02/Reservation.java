package com.pjwstk.mp02;

import java.sql.Date;

import com.pjwstk.entities.Client;
import com.pjwstk.entities.utils.ExtensionHandle;

public class Reservation extends AssociationHandle {
	//Asocjacja binarna (1-*)
	private Client person;
	private Date date_from;
	private Date date_to;
}
