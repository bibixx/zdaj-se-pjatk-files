package com.pjwstk;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.EnumSet;

import com.pjwstk.entities.Instrument;
import com.pjwstk.entities.MusicianProduction;
import com.pjwstk.entities.Person;
import com.pjwstk.entities.Phone;
import com.pjwstk.entities.Production;
import com.pjwstk.entities.clients.Musician;
import com.pjwstk.entities.employees.SoundDirector;
import com.pjwstk.entities.employees.SoundTechnician;
import com.pjwstk.entities.instruments.Electrophone;
import com.pjwstk.entities.instruments.Idiophone;
import com.pjwstk.entities.instruments.Membranophone;
import com.pjwstk.entities.utils.ExtensionHandle;
import com.pjwstk.mp03.ClientD;
import com.pjwstk.mp03.ElectroIdiophone;
import com.pjwstk.mp03.EmployeeD;
import com.pjwstk.mp03.Female;
import com.pjwstk.mp03.Gender;
import com.pjwstk.mp03.Male;
import com.pjwstk.mp03.PersonD;
import com.pjwstk.mp03.PersonO;
import com.pjwstk.mp04.SoundTechnicianMP04;

public class Main {
	
	
	/** MP 04
	 * 
	 */
	
	public static void main(String[] args){
		//OGRANICZENIE ATRYBUTU + UNIQUE
		SoundTechnicianMP04 soundTech = new SoundTechnicianMP04(405.5);
		SoundTechnicianMP04 soundTech2 = new SoundTechnicianMP04(780.0);
		
		//PO WPISANIU WARTOSCI MNIEJSZEJ NIZ MINIMALNA PRZYJMUJEMY WARTOSC MINIMALNA
		System.out.println(soundTech);
		System.out.println(soundTech2);
		
		
		
	}
	
	/** 
	 * MP 03
	 * 
	 
	
	public static void main(String[] args){
		//Przyklad klasy abstrakcyjnej = Instrument
		Instrument instr = new Idiophone("Balafon","WoodenCube");
		Instrument instr2 = new Membranophone("Membranofon", "Membrana nr.2");
		
		//Polimorficzne wo�anie metody
		System.out.println(instr.showInstrumentProperties());
		System.out.println(instr2.showInstrumentProperties());
		
		//Overlapping
		//Czyli zamiana na kompozycje + enumy
		EnumSet<PersonO.PersonType> type = EnumSet.noneOf(PersonO.PersonType.class);
		type.add(PersonO.PersonType.CLIENT);
		Gender gender = new Male("cywil");
		PersonO client = new PersonO("Jan", "Kowalski", new Phone((long)800123123),type,gender);
		
		System.out.println(client);
		
		EnumSet<PersonO.PersonType> type2 = EnumSet.noneOf(PersonO.PersonType.class);
		type2.add(PersonO.PersonType.EMPLOYEE);
		Gender gender1 = new Female("rozwodka");
		PersonO employee = new PersonO("Zosia", "Kowalska", new Phone((long)800123123), type2,gender1);
		
		System.out.println(employee);
		
		EnumSet<PersonO.PersonType> type3 = EnumSet.noneOf(PersonO.PersonType.class);
		type3.add(PersonO.PersonType.EMPLOYEE);
		type3.add(PersonO.PersonType.CLIENT);
		Gender gender2 = new Female("w zwiazku");
		PersonO mixed = new PersonO("Dorota", "Rabczewska", new Phone((long)800123123), type3,gender2);
		
		System.out.println(mixed);
		
		//Wielodziedziczenie, czyli interfejsik:)
		Idiophone idiophone = new Idiophone("NR.1 Idiophone", "vibraShape");
		ElectroIdiophone mutant = new ElectroIdiophone("Mutant", "mild", idiophone);
		
		System.out.println(mutant);
		
		//Wieloaspektowe, dodanie p�ci do PersonO
		//W efekcie kompozycja z Gender (stosunek 1-1)
		EnumSet<PersonO.PersonType> typeX = EnumSet.noneOf(PersonO.PersonType.class);
		type.add(PersonO.PersonType.CLIENT);
		Gender genderX = new Male("cywil");
		PersonO clientX = new PersonO("Jan", "Kowalski", new Phone((long)800123123),type,genderX);
		
		//Dynamiczne
		//Sprytne kopiowanie
		PersonD clie = new ClientD("Zosia","Samosia",new Phone((long)123),new Female("singielka"));
		System.out.println(clie);
		PersonD emplo = new EmployeeD(clie);
		System.out.println(emplo);
		
	}
	
	*/
	
	/** 
	 * MP 02
	 * 
	
	public static void main(String[] args){
		Person osoba1 = new Person("Jan", "Kowalski", new Phone("123456789"));
		Person osoba2 = new Person("Joanna", "Brodzik", new Phone("080012345"));
		Musician muzyk1 = new Musician();
		Musician muzyk2 = new Musician();
		MusicianProduction muzyk1gaza = new MusicianProduction((long)120);
		MusicianProduction muzyk2gaza = new MusicianProduction((long)50);
		Production utwor1 = new Production((long)53,"Utwor nr.1");
		Production utwor2 = new Production((long)153,"Utwor nr.2");
		
		//Asocjacja binarna (*-*)
		muzyk1.addAssociation("wykonuje", "uczestnicy", utwor1);
		muzyk1.addAssociation("wykonuje", "uczestnicy", utwor2);
		muzyk2.addAssociation("wykonuje", "uczestnicy", utwor2);
		
		//Asocjacja z atrybutem [wynagrodzenie] 
		//Jednoczesnie asocjacja n-arna
		//- czyli podmianka na asocjacje z klasa posredniczaca
		muzyk1.addAssociation("zarobek", "cena", muzyk1gaza);
		muzyk2.addAssociation("zarobek", "cena", muzyk2gaza);
		utwor2.addAssociation("cena", "zarobek", muzyk1gaza);
		utwor2.addAssociation("cena", "zarobek", muzyk2gaza);
		
		utwor1.printAssociations();
		utwor2.printAssociations();
		muzyk1.printAssociations();
		muzyk2.printAssociations();
		
		//Czyszczenie asocjacji binarnych
		muzyk1.removeAssociation("wykonuje", "uczestnicy", utwor1);
		muzyk1.removeAssociation("wykonuje", "uczestnicy", utwor2);
		muzyk2.removeAssociation("wykonuje", "uczestnicy", utwor2);
		
		//Asocjacja kwalifikowana (kwalifikator = skrot nazwy utworu)
		muzyk1.addAssociation("wykonuje", "uczestnicy", utwor1, "U1");
		muzyk1.addAssociation("wykonuje", "uczestnicy", utwor2, "U2");
		muzyk2.addAssociation("wykonuje", "uczestnicy", utwor2, "U2");
		
		System.out.println(muzyk1.associatedObject("wykonuje", "U1"));
		System.out.println(muzyk1.associatedObject("wykonuje", "U2"));
		System.out.println(muzyk2.associatedObject("wykonuje", "U2"));
		
		//Kompozycja
		osoba1.addPart("musician", "parent", muzyk1);
		osoba2.addPart("musician", "parent", muzyk2);
		
		utwor1.printAssociations();
		utwor2.printAssociations();
		muzyk1.printAssociations();
		muzyk2.printAssociations();
		
	}
	
	 */
	
/**
 * MP 01
	public static void main(String[] args) {
		
		//Phone <- przeciarzenie metody setPhone
		Phone pho = new Phone((long)10101023);
		
		//Person <- atrybut powtarzalny
		SoundDirector sd = new SoundDirector("Zosia","Kowalska",
							new Phone((long)987123654));
		
		//Employee <- atrybut z�o�ony Date
		//SoundTechnician <- atrybut pochodny + atrybut klasowy
		//					 + metoda klasowa
		SoundTechnician st = new SoundTechnician("Jan","Kowalski",
								new Phone((long)123456789));
		SoundTechnician st2 = new SoundTechnician("Kuba","Kowalski",
				new Phone((long)123456789));
		System.out.println("NAJBARDZIEJ DOSWIADCZONY TECHNIK:");
		System.out.println(st.getMostExperiencedTechican()+"\n");
		//Instrument <- atrybut opcjonalny
		//Idiophone <- przesloniecie metody z Instrument
		Idiophone idp = new Idiophone("Balafon","WoodenCube");
		
		//Ekstensja w ExtensionHandler
		
		//trwalosc ekstensji
		File output = new File("ekstensja.bin");
		try {
			output.createNewFile();
			for(Class<?> cls:ExtensionHandler.getContent().keySet())
				for(Object obj:ExtensionHandler.getContent().get(cls))
					System.out.println("\t"+obj);
			System.out.println("Zapis ekstensji do pliku:"+output.getName());
			ExtensionHandler.saveExtensionHandler(
					new ObjectOutputStream(new FileOutputStream(output)));
			System.out.println("Odczyt ekstensji z pliku:"+output.getName());
			ExtensionHandler.loadExtensionHandler(
					new ObjectInputStream(new FileInputStream(output)));
			for(Class<?> cls:ExtensionHandler.getContent().keySet())
				for(Object obj:ExtensionHandler.getContent().get(cls))
					System.out.println("\t"+obj);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		 
	}
**/
}
