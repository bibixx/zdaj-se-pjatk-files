package com.pjwstk.mp03;

import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;

import com.pjwstk.entities.Client;
import com.pjwstk.entities.Employee;
import com.pjwstk.entities.Phone;
import com.pjwstk.entities.clients.Musician;
import com.pjwstk.entities.utils.ExtensionHandle;
import com.pjwstk.mp02.AssociationHandle;

public class PersonO extends AssociationHandle{

	private Integer id_person;
	private String name;
	private String surname;
	//atrybut powtarzalny
	private Set<Phone> phones;
	private EnumSet<PersonType> type;
	
	//TODO Temporary id generator [change with JPA annotations+Hibernate]
	private static Integer id = 0;
	
	private static final String parrent = "generalization";
	private static final String client = "expandToClient";
	private static final String employee = "expandToEmployee";
	
	private static final String genderMA = "gender";
	private static final String multiaspect = "multiaspect"; 

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public Set<Phone> getPhones() {
		return phones;
	}

	public void setPhones(Set<Phone> phones) {
		this.phones = phones;
	}
	
	

	public PersonO(String name, String surname,Set<Phone> phones,EnumSet<PersonType> types,Gender gender) {
		super();
		this.id_person = id++;
		this.name = name;
		this.surname = surname;
		this.phones = phones;
		this.type = types;
		for(PersonType pType: this.type)
			switch(pType){
				case CLIENT:{
					Client cli = new Client();
					this.addAssociation(client, parrent, cli);
				}break;
				case EMPLOYEE:{
					Employee emp = new Employee();
					this.addAssociation(employee, parrent, emp);
				}break;
				default: break;
			}
		this.addAssociation(genderMA, multiaspect, gender);
	}
	
	public PersonO(String name, String surname,Phone phone,EnumSet<PersonType> types,Gender gender) {
		super();
		this.id_person = id++;
		this.name = name;
		this.surname = surname;
		this.phones = new HashSet<Phone>();
		this.phones.add(phone);
		this.type = types;
		for(PersonType pType: this.type)
			switch(pType){
				case CLIENT:{
					Client cli = new Client();
					this.addAssociation(client, parrent, cli);
				}break;
				case EMPLOYEE:{
					Employee emp = new Employee();
					this.addAssociation(employee, parrent, emp);
				}break;
				default: break;
			}
		this.addAssociation(genderMA, multiaspect, gender);
	}
	
	@Override
	public String toString() {
		String expan = new String();
		for(PersonType pType: this.type)
			switch(pType){
				case CLIENT:expan+="+"+this.getAssociation(client).toString();break;
				case EMPLOYEE:expan+="+"+this.getAssociation(employee).toString();break;
				default: break;
			}
		
		return "["+super.toString()+" expandedTo:"+type+"]name:"+this.name+", surname:"
				+this.surname+", gender:"+this.getAssociation(genderMA)+", phones:"+this.phones+expan;
	}
	
	public enum PersonType{CLIENT,EMPLOYEE};
}
