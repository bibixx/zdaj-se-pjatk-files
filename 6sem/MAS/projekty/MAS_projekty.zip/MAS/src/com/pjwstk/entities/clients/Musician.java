package com.pjwstk.entities.clients;

import com.pjwstk.entities.Client;
import com.pjwstk.entities.Phone;

public class Musician extends Client{
	
	public Musician() {
	}
	
	@Override
	public String toString() {
		return "["+super.toString()+"]";
	}
}
