package com.pjwstk.entities.employees;

import java.util.Calendar;
import java.util.Date;

import com.pjwstk.entities.Employee;
import com.pjwstk.entities.Phone;

public class SoundTechnician extends Employee {
	
	//atrybut pochodny
	private Integer workedHours;

	//atrybut klasowy
	private Integer minimalSalary = 600;
	
	public SoundTechnician() {
	}
	
	public Integer getWorkedHours(){
		workedHours = Calendar.getInstance().getTime().compareTo(this.employmentDate);
		return workedHours/3600;
	}
	
	//metoda klasowa
	public SoundTechnician getMostExperiencedTechican(){
		SoundTechnician ret = null;
		for(Object obj:this.getClassExtension())
		{
			SoundTechnician st = (SoundTechnician) obj; 
			if(ret==null||ret.getWorkedHours()<st.getWorkedHours())
				ret = st;
		}
		return ret;
	}
	
	@Override
	public String toString() {
		return "["+super.toString()+"]wokredHours:"+getWorkedHours();
	}
}
