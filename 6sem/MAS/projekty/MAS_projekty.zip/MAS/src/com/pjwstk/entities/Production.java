package com.pjwstk.entities;

import com.pjwstk.mp02.AssociationHandle;

public class Production extends AssociationHandle {
	private String name;
	private Long durationInSeconds;
	
	public Production(Long duration, String name) {
		super();
		this.durationInSeconds=duration;
		this.name = name;
	}
	
	@Override
	public String toString() {
		return "["+super.toString()+"]nazwa:"+this.name+", czas_trwania:"+this.durationInSeconds;
	}
}
