package com.pjwstk.mp03;

public class Male extends Gender {
	private String militaryStatus;
	
	public Male(String militaryStatus) {
		super();
		this.militaryStatus = militaryStatus;
	}
	
	@Override
	public String toString() {
		return "["+super.toString()+"]militaryStatus:"+this.militaryStatus;
	}
}
