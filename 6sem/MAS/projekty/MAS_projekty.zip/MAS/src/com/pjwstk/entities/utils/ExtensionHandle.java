package com.pjwstk.entities.utils;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Hashtable;
import java.util.Vector;

public class ExtensionHandle implements Serializable{

	private static final long serialVersionUID = -5171910431807216802L;

	//atrybut klasowy
	private static Hashtable<Class<?>,Vector<Object>> extensions = 
		new Hashtable<Class<?>, Vector<Object>>(); 
	
	protected ExtensionHandle() {
		Class<?> cls = this.getClass();
		Vector<Object> extension = new Vector<Object>();
		
		if(extensions.containsKey(cls))
			extensions.get(cls).add(this);
		else
		{
			extension.add(this);
			extensions.put(cls,extension);
		}
	}
	
	public Vector<Object> getClassExtension(){
		if(ExtensionHandle.extensions.containsKey(this.getClass()))
			return ExtensionHandle.extensions.get(this.getClass());
		return null;
	}
	
	public static Hashtable<Class<?>, Vector<Object>> getContent(){
		return ExtensionHandle.extensions;
	}
	
	public static void saveExtensionHandler(ObjectOutputStream oos){
		try {
			oos.writeObject(extensions);
		} catch (IOException e) {e.printStackTrace();}
	}
	
	public static void loadExtensionHandler(ObjectInputStream ois){
		try {
			extensions = (Hashtable<Class<?>, Vector<Object>>)ois.readObject();
		} catch (IOException e) {e.printStackTrace();} 
		  catch (ClassNotFoundException e) {e.printStackTrace();}
	}
	
}
