package com.pjwstk.entities;

import com.pjwstk.entities.utils.ExtensionHandle;
import com.pjwstk.mp02.AssociationHandle;

public class Phone extends AssociationHandle {
	
	private String phone;
	
	public Phone(String phone) {
		super();
		if(phone.matches("[0-9]+"))
			this.phone = phone;
		else
			this.phone = null;
	}
	
	public Phone(Long phone){
		this.phone = Long.toString(phone);
	}
	
	public void setPhone(String phone){
		if(phone.matches("[0-9]+"))
			this.phone = phone;
		else
			this.phone = null;
	}
	
	//metoda przeciarzona
	public void setPhone(Long phone){
		this.phone = Long.toString(phone);
	}
	
	@Override
	public String toString() {
		return "["+super.toString()+"]phone:"+this.phone;
	}
}
