package com.pjwstk.mp03;

import com.pjwstk.entities.Phone;

public class ClientD extends PersonD {
	public ClientD(String name,String surname,Phone phone,Gender gender) {
		super(name,surname,phone,gender);
	}
	
	public ClientD(PersonD person) {
		super(person);
	}
}
