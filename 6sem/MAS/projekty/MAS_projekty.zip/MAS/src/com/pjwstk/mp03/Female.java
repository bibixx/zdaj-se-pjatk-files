package com.pjwstk.mp03;

public class Female extends Gender {
	private String relationshipStatus;
	
	public Female(String relationshipStatus) {
		super();
		this.relationshipStatus = relationshipStatus;
	}
	
	@Override
	public String toString() {
		return "["+super.toString()+"]relationshipStatus:"+this.relationshipStatus;
	}
}
