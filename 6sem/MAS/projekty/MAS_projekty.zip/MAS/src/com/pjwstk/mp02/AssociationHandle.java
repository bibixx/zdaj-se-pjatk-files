package com.pjwstk.mp02;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import com.pjwstk.entities.utils.ExtensionHandle;
import com.pjwstk.mp03.ClientD;
import com.pjwstk.mp03.PersonD;

public class AssociationHandle extends ExtensionHandle implements Serializable{

	private Hashtable<String, HashMap<Object, AssociationHandle>> associations =
		new Hashtable<String, HashMap<Object,AssociationHandle>>();
	
	private static HashSet<AssociationHandle> allParts = 
		new HashSet<AssociationHandle>();
	
	public AssociationHandle() {
		super();
	}
	
	private void addAssociation(String roleFrom, String roleTo, AssociationHandle objectTo, Object qualifier, int counter){
		HashMap<Object, AssociationHandle> objectAssociations = null;
		
		if(counter <1)
			return;
		
		if(associations.containsKey(roleFrom))
			objectAssociations = associations.get(roleFrom);
		else
		{
			objectAssociations = new HashMap<Object, AssociationHandle>();
			associations.put(roleFrom, objectAssociations);
		}
		
		if(!objectAssociations.containsKey(qualifier))
		{
			objectAssociations.put(qualifier, objectTo);
			objectTo.addAssociation(roleTo, roleFrom, this, this, counter-1);
		}
		
	}
	
	public void addAssociation(String roleFrom, String roleTo, AssociationHandle objectTo,Object qualifier){
		addAssociation(roleFrom, roleTo, objectTo, qualifier, 2);
		
	}
	
	public void addAssociation(String roleFrom, String roleTo, AssociationHandle objectTo){
		addAssociation(roleFrom, roleTo, objectTo, objectTo);
	}
	
	public void removeAssociation(String roleTo, AssociationHandle objectTo,Object qualifier){
		for(Entry<String,HashMap<Object, AssociationHandle>> objectAssociations:associations.entrySet())
		{
				this.removeAssociation(objectAssociations.getKey(),roleTo,objectTo,qualifier);
				objectTo.removeAssociation(roleTo, objectAssociations.getKey(), this, this);
		}
	}
	
	public void removeAssociation(String roleTo, AssociationHandle objectTo){
		removeAssociation(roleTo, objectTo, objectTo);
	}
	
	public void removeAssociation(String roleTo){
		for(Entry<String,HashMap<Object, AssociationHandle>> objectAssociations:associations.entrySet())
			for(AssociationHandle asso:objectAssociations.getValue().values())
			{
				this.removeAssociation(objectAssociations.getKey(),roleTo,asso,asso);
				asso.removeAssociation(roleTo, objectAssociations.getKey(), this, this);
			}
	}
	
	public void removeAssociation(String roleFrom, String roleTo, AssociationHandle objectTo, Object qualifier){
		HashMap<Object, AssociationHandle> objectAssociations = null;
		
		if(associations.containsKey(roleFrom))
			objectAssociations = associations.get(roleFrom);
		else
			return;
		
		if(objectAssociations.containsKey(qualifier))
		{
			objectAssociations.remove(objectTo);
			objectTo.removeAssociation(roleTo, roleFrom, this, this);
		}
	}
	
	public void removeAssociation(String roleFrom, String roleTo, AssociationHandle objectTo){
		removeAssociation(roleFrom, roleTo, objectTo, objectTo);
	}
	
	public void addPart(String roleFrom, String roleTo, AssociationHandle objectPart){
		if(allParts.contains(objectPart))
			{System.out.println("Ten obiekt juz istnieje!");return;}
		addAssociation(roleFrom, roleTo, objectPart);
		allParts.add(objectPart);
	}
	
	public List<AssociationHandle> getAssociation(String role){
		HashMap<Object, AssociationHandle> associationRoles;
		
		if(!associations.containsKey(role))
			{System.out.println("Brak asocjacji dla podanej roli!");return null;}
		
		associationRoles = associations.get(role);
		return new ArrayList<AssociationHandle>(associationRoles.values());
	}
	
	public void printAssociation(String role){
		HashMap<Object, AssociationHandle> associationRoles;
		
		if(!associations.containsKey(role))
			{System.out.println("Brak asocjacji dla podanej roli!");return;}
		
		associationRoles = associations.get(role);
		
		System.out.println(this+" powiazania w roli \""+role+"\":");
		for(Object obj:associationRoles.values())
			System.out.println("\t"+obj);
	}
	
	public void printAssociations(){
		for(Entry<String,HashMap<Object, AssociationHandle>> roles: associations.entrySet())
		{
			System.out.println(this+" powiazania w roli \""+roles.getKey()+"\":");
			for(Object obj:roles.getValue().values())
				System.out.println("\t"+obj);
		}
	}
	
	public AssociationHandle associatedObject(String role,Object qualifier){
		HashMap<Object, AssociationHandle> associationRoles;
		
		if(!associations.containsKey(role))
			{System.out.println("Brak asocjacji dla podanej roli!");return null;}
		
		associationRoles = associations.get(role);
		
		if(!associationRoles.containsKey(qualifier))
			{System.out.println("Brak asocjacji z podanym kwalifikatorem!");return null;}
		
		return associationRoles.get(qualifier);
	}
}
