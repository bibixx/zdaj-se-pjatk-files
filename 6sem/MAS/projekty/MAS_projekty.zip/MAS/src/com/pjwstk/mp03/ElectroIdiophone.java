package com.pjwstk.mp03;

import com.pjwstk.entities.instruments.Electrophone;
import com.pjwstk.entities.instruments.Idiophone;

public class ElectroIdiophone extends Electrophone implements IIdiophone {
	IIdiophone idiophone;
	
	public ElectroIdiophone(String name, String tone,IIdiophone idiophone) {
		super(name,tone);
		this.idiophone=idiophone;
	}

	@Override
	public String getVibraShape() {
		return this.idiophone.getVibraShape();
	}

	@Override
	public void setVibraShape(String vibraShape) {
		this.idiophone.setVibraShape(vibraShape);
	}
	
	@Override
	public String toString() {
		return "["+super.toString()+",with:"+idiophone.toString()+"]";
	}
}
