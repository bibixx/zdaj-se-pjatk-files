package com.pjwstk.entities;

import com.pjwstk.mp02.AssociationHandle;

public class MusicianProduction extends AssociationHandle {
	private Long productionPrice;
	
	public MusicianProduction(Long productionPrice) {
		super();
		this.productionPrice = productionPrice;
	}
	
	@Override
	public String toString() {
		return "["+super.toString()+"]cena:"+this.productionPrice;
	}
}
