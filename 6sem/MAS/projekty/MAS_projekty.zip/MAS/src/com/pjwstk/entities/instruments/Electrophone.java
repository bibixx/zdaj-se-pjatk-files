package com.pjwstk.entities.instruments;

import com.pjwstk.entities.Instrument;

public class Electrophone extends Instrument {

	public Electrophone(String name) {
		super(name);
	}

	public Electrophone(String name,String tone) {
		super(name, tone);
	}
	
	@Override
	public String showInstrumentProperties() {
		return super.showInstrumentProperties();
	}
}
