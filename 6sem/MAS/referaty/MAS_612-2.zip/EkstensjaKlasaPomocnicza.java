/* MAS 2004, Micha� Ma�ecki, Micha� Walkowski
 * Ekstensja - Dodawanie klasy pomocniczej.
 */

import java.util.Vector;
import java.util.Iterator;

public class EkstensjaKlasaPomocnicza {
	public static void main(String[] args) {
		System.out.println("Ekstensja z klasa pomocnicza.\n");
		
		/* Tworzenie klasy pomocniczej zarzadzajacej naszymi obiektami
		 */		
		WszystkieNaszeKlasy wnk = new WszystkieNaszeKlasy();
		
		NaszaKlasa obiekt1 = new NaszaKlasa("Pierwszy");
		NaszaKlasa obiekt2 = new NaszaKlasa("Kolejny");
		NaszaKlasa obiekt3 = new NaszaKlasa("Piekniejszy");
		NaszaKlasa obiekt4 = new NaszaKlasa("Najmadrzejszy");
		NaszaKlasa obiekt5 = new NaszaKlasa("Znudzony");
		
		wnk.add(obiekt1);
		wnk.add(obiekt2);
		wnk.add(obiekt3);
		wnk.add(obiekt4);
		wnk.add(obiekt5);		
		
		NaszaKlasa obiekt6 = new NaszaKlasa("Dodawany nietypowo", wnk);
		
		System.out.println(" --- \n");
		
		System.out.println(
			obiekt1.dajZawartosc()
		);
		
		System.out.println(
			wnk.dajCalaZgromadzonaWiedza()
		);		
	}
}

class WszystkieNaszeKlasy {
	private Vector zarzadca;
	
	public WszystkieNaszeKlasy() {
		this.zarzadca = new Vector();
		
		System.out.println("Zarzadca gotowy.\n");
	}
	
	/* Dodanie obiektu do kolekcji
	 */
	public boolean add(NaszaKlasa nk) {
		return this.zarzadca.add(nk);
	}
	
	/* Usuwanie obiektu z kolekcji
	 */
	public boolean remove(NaszaKlasa nk) {
		return this.zarzadca.remove(nk);
	}	
	
	/* Przykladowa metoda operujaca na kolekcji
	 */
	public String dajCalaZgromadzonaWiedza() {
		String wiedza = "";
		
		Iterator i = this.zarzadca.iterator();		
		while(i.hasNext()) {
			NaszaKlasa tmp = (NaszaKlasa)i.next();
			wiedza += tmp.dajZawartosc();
		}		
		
		return wiedza;
	}	
}

class NaszaKlasa {	
	public String zawartoscNaszejKlasy;
	
	public NaszaKlasa(String s) {		
		
		/* Dodanie przykladowej informacji przechowywanej 
		 * przez nasza przykladowa klase
		 */
		this.zawartoscNaszejKlasy = s;		
	}
	
	public NaszaKlasa(String s, WszystkieNaszeKlasy zarzadca) {		
		
		/* Dodanie przykladowej informacji przechowywanej 
		 * przez nasza przykladowa klase
		 */
		this.zawartoscNaszejKlasy = s;
		
		zarzadca.add(this);
	}
	
	/* Przykladowa metoda obslugujaca obiekt
	 */
	public String dajZawartosc() {
		return this.zawartoscNaszejKlasy;
	}	
}