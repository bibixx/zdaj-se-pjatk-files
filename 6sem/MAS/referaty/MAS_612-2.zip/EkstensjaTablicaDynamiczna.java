/* MAS 2004, Micha� Ma�ecki, Micha� Walkowski
 * Ekstensja realizowana za pomoca tablicy obiektow,
 * ktorej rozmiar mozna zwiekszyc w trakcie wykonywania programu.
 */
 
public class EkstensjaTablicaDynamiczna {
	public static void main(String[] args) {
		System.out.println("Ekstensja klasy jako tablica obiektow alokowana dynamicznie.\n");
		
		NaszaKlasa obiekt1 = new NaszaKlasa("Pierwszy");
		NaszaKlasa obiekt2 = new NaszaKlasa("Kolejny");
		NaszaKlasa obiekt3 = new NaszaKlasa("Piekniejszy");
		NaszaKlasa obiekt4 = new NaszaKlasa("Najmadrzejszy");
		NaszaKlasa obiekt5 = new NaszaKlasa("Znudzony");
		NaszaKlasa obiekt6 = new NaszaKlasa("Ten ktory mial sie nie zmiescic w ekstensji");
		
		System.out.println(" --- \n");
		
		System.out.println(
			obiekt1.dajZawartosc()
		);
		
		System.out.println(
			NaszaKlasa.dajCalaZgromadzonaWiedza()
		);
	}
}

class NaszaKlasa {
	private static NaszaKlasa ekstensja[];
	private static int iloscObiektowEkstensji;
	
	public String zawartoscNaszejKlasy;
	
	public NaszaKlasa(String s) {
		
		/* Sprawdzenie czy nie jest to pierwsze wystapienie
		 * obiektu i nie tzreba inicjalizowac klasy, ktora 
		 * przechowuje nam wszystkie obiekty.
		 */
		if(NaszaKlasa.ekstensja==null) {
			NaszaKlasa.ekstensja = new NaszaKlasa[5];
			NaszaKlasa.iloscObiektowEkstensji = 0;
		}
		
		/* Dodanie przykladowej informacji przechowywanej 
		 * przez nasza przykladowa klase
		 */
		this.zawartoscNaszejKlasy = s;		
		
		/* Obsluga przepelnienia tablicy
		 */
		if(NaszaKlasa.iloscObiektowEkstensji>=NaszaKlasa.ekstensja.length) {		
			System.out.println(" (!) Powiekszenie tablicy.");
			
			NaszaKlasa.powiekszTabliceEkstensji();
		}
		
		/* Dodanie nowo stworzonego obiektu do ekstensji
		 */
		NaszaKlasa.ekstensja[NaszaKlasa.iloscObiektowEkstensji] = this;
		NaszaKlasa.iloscObiektowEkstensji++;
	}
	
	/* Przykladowa metoda obslugujaca obiekt
	 */
	public String dajZawartosc() {
		return this.zawartoscNaszejKlasy;
	}
	
	/* Przykladowa metoda obslugujaca ekstensje
	 */
	public static String dajCalaZgromadzonaWiedza() {
		if (NaszaKlasa.ekstensja==null) return null;
		
		String wiedza = "";
		
		for(int i=0; i<NaszaKlasa.iloscObiektowEkstensji; i++) {
			wiedza += NaszaKlasa.ekstensja[i].dajZawartosc();
		}
		
		return wiedza;
	}
	
	/* Powieksza dwa razy tablice obiektow wykorzystywanej jako ekstensja
	 */
	private static void powiekszTabliceEkstensji() {
		NaszaKlasa[] powiekszona = new NaszaKlasa[NaszaKlasa.ekstensja.length*2];
		
		System.arraycopy(
			NaszaKlasa.ekstensja,
			0,
			powiekszona,
			0,
			NaszaKlasa.ekstensja.length
		);
		
		NaszaKlasa.ekstensja = powiekszona;
	}
}