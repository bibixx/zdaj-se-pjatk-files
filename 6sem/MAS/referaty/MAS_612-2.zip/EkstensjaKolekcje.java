/* MAS 2004, Micha� Ma�ecki, Micha� Walkowski
 * Ekstensja realizowana za pomoca kolekcji.
 */

import java.util.Vector;
import java.util.Iterator;

public class EkstensjaKolekcje {
	public static void main(String[] args) {
		System.out.println("Ekstensja klasy jako kolekcja.\n");
		
		NaszaKlasa obiekt1 = new NaszaKlasa("Pierwszy");
		NaszaKlasa obiekt2 = new NaszaKlasa("Kolejny");
		NaszaKlasa obiekt3 = new NaszaKlasa("Piekniejszy");
		NaszaKlasa obiekt4 = new NaszaKlasa("Najmadrzejszy");
		NaszaKlasa obiekt5 = new NaszaKlasa("Znudzony");
		NaszaKlasa obiekt6 = new NaszaKlasa("Ten ktory kiedys sie nie miescil");
		
		System.out.println(" --- \n");
		
		System.out.println(
			obiekt1.dajZawartosc()
		);
		
		System.out.println(
			NaszaKlasa.dajCalaZgromadzonaWiedza()
		);
	}
}

class NaszaKlasa {
	private static Vector ekstensja;
	
	public String zawartoscNaszejKlasy;
	
	public NaszaKlasa(String s) {
		
		/* Sprawdzenie czy nie jest to pierwsze wystapienie
		 * obiektu i nie tzreba inicjalizowac klasy, ktora 
		 * przechowuje nam wszystkie obiekty.
		 */
		if(NaszaKlasa.ekstensja==null) {
			NaszaKlasa.ekstensja = new Vector();
		}
		
		/* Dodanie przykladowej informacji przechowywanej 
		 * przez nasza przykladowa klase
		 */
		this.zawartoscNaszejKlasy = s;
		
		// Tutaj kiedys trzeba bylo uwazac na przepelnienie tablic.	
		
		/* Dodanie nowo stworzonego obiektu do ekstensji
		 */
		NaszaKlasa.ekstensja.add(this);		
	}
	
	/* Przykladowa metoda obslugujaca obiekt
	 */
	public String dajZawartosc() {
		return this.zawartoscNaszejKlasy;
	}
	
	/* Przykladowa metoda obslugujaca ekstensje
	 */
	public static String dajCalaZgromadzonaWiedza() {
		if (NaszaKlasa.ekstensja==null) return null;
		
		String wiedza = "";
		
		Iterator i = NaszaKlasa.ekstensja.iterator();		
		while(i.hasNext()) {
			NaszaKlasa tmp = (NaszaKlasa)i.next();
			wiedza += tmp.dajZawartosc();
		}		
		
		return wiedza;
	}	
}