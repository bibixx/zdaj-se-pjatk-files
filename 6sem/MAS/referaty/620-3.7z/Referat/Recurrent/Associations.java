import java.util.*;

class Pracownik{
  String nazwisko;
  Pracownik szef = null;
  Vector podwladni = new Vector();
  public Pracownik(String nazwisko, Pracownik szef){
    this.nazwisko = nazwisko;
    this.szef = szef;
  }
  public void dodajPodwladnego(Pracownik pr){
    podwladni.add(pr);
  }
  
  public void wyswietlPodwladnych(Pracownik person, String prefix) {
  	System.out.println(prefix + person.nazwisko);

	  	ListIterator iter = person.podwladni.listIterator();
			while (iter.hasNext()) {
				wyswietlPodwladnych((Pracownik)iter.next(), prefix + "   ");
			}	
  }
}

public class Associations {
	public static void main(String [] args) {

		//tworzymy szefa firmy
		Pracownik szef = new Pracownik("Szef", null);
		
		//tworzymy podwladnych
		Pracownik podwladny = new Pracownik("Kierownik1", szef);
		szef.dodajPodwladnego(podwladny);
		
		szef.dodajPodwladnego(new Pracownik("Kierownik2", szef));
		szef.dodajPodwladnego(new Pracownik("Kierownik3", szef));
		
		//i jego podwladnych
	    podwladny.dodajPodwladnego(new Pracownik("Pracownik1", podwladny));
	    podwladny.dodajPodwladnego(new Pracownik("Pracownik2", podwladny));
	    podwladny.dodajPodwladnego(new Pracownik("Pracownik3", podwladny));
		
		//Wypisz wszystkich podwladnych
		szef.wyswietlPodwladnych(szef, "");
		
	}
}