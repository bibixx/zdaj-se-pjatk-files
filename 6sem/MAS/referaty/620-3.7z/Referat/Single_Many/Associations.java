class Osoba{
  	String imie;
  	Firma pracodawca;
  	
  	public Osoba(String im){
    	imie = im;
    	pracodawca = null;
  	}
  	
  	public void zatrudnij(Firma f){
    	pracodawca = f;
  	}
}

class Firma{
  	String nazwa;
  	Osoba[] pracownicy;
  	
  	static int iluPracownikow;       //ilu jest aktualnie zatrudnionych
  	static int iloscPracownikow = 0; //maksymalne zatrudnienie w firmie
  	
  	public Firma(String naz, int iluPracownikow){
    	nazwa = naz;
    	this.iluPracownikow = iluPracownikow;
    	pracownicy = new Osoba[iluPracownikow];
  	}
  	
  	public void zatrudnij(Osoba nowa){
    	if (iloscPracownikow < iluPracownikow) {
      		pracownicy[iloscPracownikow] = nowa;
      		iloscPracownikow++;
      		nowa.zatrudnij(this);
    	}
  	}
  	
  	public void listaPracownikow() {
  		System.out.println("Firma : " + nazwa + "\n");
  		for (int i=0; i<iloscPracownikow; i++) {
  			System.out.println("Nazwisko (" + i + "): " + pracownicy[i].imie);
			System.out.println();
  		}
  	}
}

public class Associations {
	public static void main(String [] args) {
		//tworzymy obiekt firma
		Firma company = new Firma("Coca-Cola", 3);

		//zatrudniamy now� osob�
		Osoba nowa = new Osoba("Wojciech");
		company.zatrudnij(nowa);
		
		//zatrudniamy now� osob�
		nowa = new Osoba("Kazimierz");
		company.zatrudnij(nowa);
		
		//zatrudniamy now� osob�
		nowa = new Osoba("Karol");
		company.zatrudnij(nowa);
		
		//Wypisz wszystkich pracownik�w
		company.listaPracownikow();
		
	}
}