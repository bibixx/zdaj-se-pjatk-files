class Dom {
	int iloscPokojow;
	Pokoj[] pokoje;
	Dom(int iloscPokojow) {
		this.iloscPokojow = iloscPokojow;
		pokoje = new Pokoj[iloscPokojow];
		for (int i = 0; i<iloscPokojow; i++) {
			pokoje[i]=new Pokoj("Pokoj " + i);
		}
	}
	void WypiszPokoje() {
		for (int i = 0; i<iloscPokojow; i++) {
			System.out.println(pokoje[i].nazwa);
		}
	}
	
	class Pokoj {
		String nazwa;
		Pokoj(String nazwa) {
			this.nazwa = nazwa;
		}
	}
}

class Associations {
	public static void main(String [] args) {
		Dom moj = new Dom(5);
		moj.WypiszPokoje();
	}
}