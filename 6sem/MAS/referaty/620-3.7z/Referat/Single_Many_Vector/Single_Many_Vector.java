import java.util.*;

class Osoba{
  String imie;
  Firma pracodawca;
  public Osoba(String im){
    imie = im;
    pracodawca = null;
  }
  public void zatrudnij(Firma f){
    pracodawca = f;
  }
}
class Firma{
  String nazwa;
  Vector pracownicy;
  public Firma(String naz){
    nazwa = naz;
    pracownicy = new Vector();
  }
  public void zatrudnij(Osoba nowa){
    pracownicy.add(nowa);
    nowa.zatrudnij(this);
  }
  public void wypiszPracownikow() {
  	System.out.println("Firma : " + nazwa + "\n");
  	
  	Iterator iter = pracownicy.iterator();
		while (iter.hasNext()) {
			System.out.println((Osoba)iter.next().imie);
		}
  }
}

public class Associations {
	public static void main(String [] args) {
		//tworzymy obiekt firma
		Firma company = new Firma("Coca-Cola");

		//zatrudniamy osoby
		company.zatrudnij(new Osoba("Jan"));
		company.zatrudnij(new Osoba("Piotr"));
		company.zatrudnij(new Osoba("Mateusz"));
		
		//Wypisz wszystkich pracownik�w
		company.listaPracownikow();
		
	}
}