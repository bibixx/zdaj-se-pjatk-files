//gdy osoba mo�e pracowa� w wielu firmach 
import java.util.*;

class Osoba{
  	String imie;
  	static Hashtable zatrudnienie = new Hashtable();
  	
  	Osoba(String im){
    	imie = im;
    	zatrudnienie.put(this, new Vector());
  	}
  	
  	public void zatrudnij(Firma f){
    	Vector pracodawca = (Vector)zatrudnienie.get(this);
    	pracodawca.add(f);
    	if (!((Vector)(f.zatrudnienie.get(f))).contains(this)) f.zatrudnij(this);
  	}
  	
  	public void wypiszFirmy() {
  		System.out.println("Osoba : " + imie + "\n");
  		
  		ListIterator iter = ((Vector)(zatrudnienie.get(this))).listIterator();
  		
		while (iter.hasNext()) {
			System.out.println("Firma (" + iter.nextIndex() + ") " + 
								((Firma)iter.next()).nazwa);
		}

		System.out.println();	
  	}
}

class Firma{
  	String nazwa;
  	static Hashtable zatrudnienie = new Hashtable();
  	
  	Firma(String naz){
    	nazwa = naz;
    	zatrudnienie.put(this, new Vector());
  	}
  	
  	public void zatrudnij(Osoba nowa){
    	Vector pracownicy = (Vector)zatrudnienie.get(this);
    	pracownicy.add(nowa);
    	if (!((Vector)(nowa.zatrudnienie.get(nowa))).contains(this)) nowa.zatrudnij(this);
  	}
  	
  	public void wypiszPracownikow() {
  		System.out.println("Firma : " + nazwa + "\n");
  		
  		ListIterator iter = ((Vector)(zatrudnienie.get(this))).listIterator();
  		
		while (iter.hasNext()) {
			System.out.println("Osoba (" + iter.nextIndex() + ") " + ((Osoba)iter.next()).imie);
		}

		System.out.println();	
  	}	
}

public class Associations {
	public static void main(String [] args) {
		//tworzymy obiekt firma
		Firma cocacola = new Firma("Coca-Cola");
		Firma company = new Firma("company");

		//tworzymy osob�
		Osoba nowa = new Osoba("Karol");
		nowa.zatrudnij(cocacola);
		nowa.zatrudnij(company);
		
		//zatrudniamy osoby
		company.zatrudnij(new Osoba("Jan"));
		company.zatrudnij(new Osoba("Piotr"));
		company.zatrudnij(new Osoba("Mateusz"));
		
		//Wypisz wszystkich pracownik�w
		company.wypiszPracownikow();
		cocacola.wypiszPracownikow();
		nowa.wypiszFirmy();
		
	}
}