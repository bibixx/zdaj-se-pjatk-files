import java.util.*;

class Osoba{
  	String imie;
  	static Hashtable zatrudnienie = new Hashtable();
  	
  	Osoba(String im){
    	imie = im;
    	zatrudnienie.put(this, new Vector());
  	}
  	
  	public void zatrudnij(Firma f, int czas){
    	Vector pracodawca = (Vector)zatrudnienie.get(this);
    	new Zatrudnienie(this, f, czas);
  	}
  	
  	public void wypiszFirmy() {
  		System.out.println("Osoba : " + imie + "\n");
  		
  		ListIterator iter = ((Vector)(zatrudnienie.get(this))).listIterator();
  		
		while (iter.hasNext()) {
			Zatrudnienie aktualne = (Zatrudnienie)iter.next();
			System.out.println("Firma (" + iter.nextIndex() + ") " +
								aktualne.pracodawca.nazwa + 
								" Czas - " + aktualne.czas);
		}

		System.out.println();	
  	}
}

class Firma{
  	String nazwa;
  	static Hashtable zatrudnienie = new Hashtable();
  	
  	Firma(String naz){
    	nazwa = naz;
    	zatrudnienie.put(this, new Vector());
  	}
  	
  	public void zatrudnij(Osoba nowa, int czas){
    	Vector pracownicy = (Vector)zatrudnienie.get(this);
    	new Zatrudnienie(nowa, this, czas);
  	}
  	
  	public void wypiszPracownikow() {
  		System.out.println("Firma : " + nazwa + "\n");
  		
  		ListIterator iter = ((Vector)(zatrudnienie.get(this))).listIterator();
  		
		while (iter.hasNext()) {
			Zatrudnienie aktualne = (Zatrudnienie)iter.next();
			System.out.println("Osoba (" + iter.nextIndex() + ") " + 
								aktualne.pracownik.imie + 
								" czas - " + aktualne.czas);
		}

		System.out.println();	
  	}	
}

class Zatrudnienie {
	int czas;
	Osoba pracownik;
	Firma pracodawca;
	Zatrudnienie(Osoba pracownik, Firma pracodawca, int czas) {
		this.czas = czas;
		this.pracownik = pracownik;
		this.pracodawca = pracodawca;
		((Vector)(pracownik.zatrudnienie.get(pracownik))).add(this);
		((Vector)(pracodawca.zatrudnienie.get(pracodawca))).add(this);
	}
}

public class Associations {
	public static void main(String [] args) {
		//tworzymy obiekt firma
		Firma cocacola = new Firma("Coca-Cola");
		Firma company = new Firma("company");

		//tworzymy osob�
		Osoba nowa = new Osoba("Karol");
		nowa.zatrudnij(cocacola, 10);
		nowa.zatrudnij(company, 20);
		
		//zatrudniamy osoby
		company.zatrudnij(new Osoba("Jan"), 30);
		company.zatrudnij(new Osoba("Piotr"), 40);
		company.zatrudnij(new Osoba("Mateusz"), 50);
		
		//Wypisz wszystkich pracownik�w
		company.wypiszPracownikow();
		cocacola.wypiszPracownikow();
		nowa.wypiszFirmy();
		
	}
}