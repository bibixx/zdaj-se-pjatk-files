// przyk�ad implementacji asocjacji dwukierunkowej jeden - jeden

class Student{
  	String nazwisko;
  	Index nrAlbumu;
  	
  	public Student(String naz, String tryb){
    	nazwisko = naz;
    	nrAlbumu = new Index(tryb, this);
  	}
  	
  	public void wyswietl() {
  		System.out.println("Nazwisko : " + this.nazwisko);
		System.out.println("Tryb studiowania : " + this.nrAlbumu.trybStudiow);
		System.out.println("Nr. indeksu : " + this.nrAlbumu.numer);
		System.out.println();
  	}
}

class Index{
	String trybStudiow;
 	int numer;
  	Student wlasciciel;
  	static int kolejnyNumer = 1111;
  	
  	public Index(String tryb, Student wlas){
    	numer = kolejnyNumer;
    	trybStudiow = tryb;
    	wlasciciel = wlas;
    	kolejnyNumer++;	
  	}
}

public class Associations {
	public static void main(String [] args) {
		
		Student nowy = new Student("Kowalski", "wieczorowe");
		nowy.wyswietl();
		
		nowy = new Student("Malinowski", "dzienne");
		nowy.wyswietl();
	}
}