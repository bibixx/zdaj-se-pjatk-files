
public class Originator {
	
	private State s;
	
	public void recoverState(Magazine mag, Integer key){
		this.s = mag.getMemento(key).getState();
	}
	
	public void createMemento(Magazine mag) {
		Memento m = new Memento(s);
		mag.saveMemento(m);
	}
	
	public void setState(State s){
		this.s = s;
	}
	
	public String getState() {
		return s.toString();
	}
	
}
