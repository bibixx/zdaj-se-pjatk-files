import java.util.HashMap;

public class Magazine {
	private HashMap<Integer,Memento> mementos = new HashMap<Integer,Memento>();
	
	public void saveMemento(Memento m){
		mementos.put(m.key, m);
	}
	public Memento getMemento(Integer key){
		return mementos.get(key);
	}
	
	public static void main(String[] args) {
		Originator o = new Originator();
		State s  = new State(1, 10, "desc");
		State s2 = new State(2, 20, "desc2");
		
		Magazine mag = new Magazine();
		
		o.setState(s);
		o.createMemento(mag);
		
		o.setState(s2);
		o.createMemento(mag);
		
		o.recoverState(mag, 1);
		System.out.println(o.getState());
		
		o.recoverState(mag, 2);
		System.out.println(o.getState());
	}
}
