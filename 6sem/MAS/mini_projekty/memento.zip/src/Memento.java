
public class Memento {
	private State s;
	public Integer key;
	
	public Memento(State s){
		this.s = s;
		this.key = s.key();
	}
	
	public State getState(){
		return this.s;
	}
}
