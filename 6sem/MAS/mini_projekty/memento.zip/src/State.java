
public class State {
	private int id;	
	private int velocity;
	private String description;
	
	public State(int id, int velocity, String description){
		this.id = id;
		this.velocity = velocity;
		this.description = description;
	}
	public int key() {
		return id;
	}
	public String toString(){
		return id+" "+velocity+" "+description;		
	}
}
