import java.util.StringTokenizer;


public class AddOperation extends Operation {

	@Override
	public void compute(String s) {
		System.out.println("AddOperation");
		StringTokenizer st = new StringTokenizer(s, " ");
		String arg1        = st.nextToken();
		String operation   = st.nextToken();
		String arg2        = st.nextToken();
		
		if(operation.equals("+")){
			System.out.println("I can handle that, result: " + (Integer.parseInt(arg1)+Integer.parseInt(arg2)));
			handledOperations++;
		} else {
			System.out.println("I cannot do this! Garry move out!");
			goNext(s);
		}
	}

}
