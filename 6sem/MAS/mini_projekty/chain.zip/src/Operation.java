import java.util.ArrayList;


public abstract class Operation {
	public Operation next;
	public int handledOperations = 0;
	
	public abstract void compute(String s);
	public void setNext(Operation o){
		this.next = o;
	}
	public void goNext(String s) {
		if(next != null){
			next.compute(s);
		}
	}
	public static void main(String[] args) {
		ArrayList<Operation> operations = new ArrayList<Operation>();
		
		Operation o1 = new AddOperation();
		Operation o2 = new SubtractionOperation();
		Operation o3 = new DivisionOperation();
		Operation o4 = new MultiplicationOperation();
		
		o1.setNext(o2);
		o2.setNext(o3);
		o3.setNext(o4);
		
		o1.compute("3 * 2");
		
		/*operations.add(o1);
		operations.add(o2);
		operations.add(o3);
		operations.add(o4);*/
	}
}
