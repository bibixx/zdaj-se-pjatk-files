public class VehicleStateBackwards extends VehicleState {
	public VehicleStateBackwards(Vehicle v) {
		super(v);
		this.v = v;
		v.setSpeed(-10);
	}
}
