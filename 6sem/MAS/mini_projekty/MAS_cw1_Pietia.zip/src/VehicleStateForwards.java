public class VehicleStateForwards extends VehicleState {
	Vehicle v;
	public VehicleStateForwards(Vehicle v) {
		super(v);
		this.v = v;
		v.setSpeed(10);
	}
}
