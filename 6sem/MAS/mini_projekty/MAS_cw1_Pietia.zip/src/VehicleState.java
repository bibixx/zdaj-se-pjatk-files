public abstract class VehicleState {
	Vehicle v;
	public VehicleState(Vehicle v) {
		this.v = v;
	}
}
