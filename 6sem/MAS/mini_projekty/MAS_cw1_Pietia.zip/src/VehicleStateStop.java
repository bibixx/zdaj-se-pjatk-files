
public class VehicleStateStop extends VehicleState {
		Vehicle v;
		public VehicleStateStop(Vehicle v) {
			super(v);
			this.v = v;
			v.setSpeed(0);
		}
	}
