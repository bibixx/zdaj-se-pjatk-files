
public class Driver {
	Vehicle vehicle;
	public Driver(){
		
	}
	public void accessVehicle(Vehicle v){
		vehicle = v;
	}
	
	public void goForwards(){
		vehicle.goForwards();				
	}
	public void goBackwards(){
		vehicle.goBackwards();				
	}
	public void stopVehicle(){
		vehicle.stop();				
	}

	public static void main(String[] args) {
		Driver d = new Driver();
		d.accessVehicle(new Vehicle());
		d.goBackwards();
		d.goForwards();
		d.stopVehicle();
	}	
}
