public class Vehicle {
	VehicleState state;
	private int current_speed;
	
	public Vehicle() {
		state = new VehicleStateStop(this);
	}
	private void setState(VehicleState newState){
		state = newState;
		System.out.println(current_speed);
	}
	
	public void goBackwards() {
		setState(new VehicleStateBackwards(this));
	}
	public void goForwards() {
		setState(new VehicleStateForwards(this));
	}
	public void stop() {
		setState(new VehicleStateStop(this));
	}	
	public void setSpeed(int newSpeed){
		current_speed = newSpeed;
	}
}
