#!/usr/bin/perl -w

# usage count <node-number> <protocol> <type> [<outgoing>]
# node is the destination node, unless 4th argument is given -- in that case, node is source node 
# type is one of: r - + d, where r is "read", - is "left the queue", + is "entered the queue", d is "dropped"
# Script returns the number of bytes.
# example: count bytes received by node 3 in all the incoming tcp packets
# ./count.pl 3 tcp r < out.tr 
# example: count bytes send by node 0 in all the outgoing tcp packets
# ./count.pl 0 cbr - outgoing < out.tr


#$node = '5';
#$prot = "cbr";
$node = $ARGV[0];
$prot = $ARGV[1];
$type = $ARGV[2];


if ($#ARGV > 2) { # count outgoing packets
	$node_field = 2;
}
else {
	$node_field = 3;
}

$bytes = 0;
while($tline = <STDIN>)
{
     chomp $tline;

     @tr = split(" ", $tline);

     if($tr[0] eq $type) {
          if($tr[$node_field] eq $node and $tr[4] eq $prot) {
               #kolumna 5 zawiera wielko�� pakietu
               $bytes += $tr[5];
			   #print "$tline\n"
          }
     }
}
print "$bytes\n"

