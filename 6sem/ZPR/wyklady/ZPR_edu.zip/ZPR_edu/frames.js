function chFrames(URLtop, URLleft, URLmain) {
	if(URLtop != '') {
		parent.topFrame.document.location = URLtop;
	}
	if(URLleft != '') {
		parent.leftFrame.document.location = URLleft;
	}
	if(URLmain != '') {
		parent.mainFrame.document.location = URLmain;
	}
}