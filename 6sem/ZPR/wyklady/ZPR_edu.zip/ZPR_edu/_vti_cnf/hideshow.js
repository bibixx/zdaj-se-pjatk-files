vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Oct 2002 16:47:56 -0000
vti_extenderversion:SR|6.0.2.6551
vti_cacheddtm:TX|13 Oct 2002 16:47:56 -0000
vti_filesize:IR|326
vti_backlinkinfo:VX|lekcje/wyklady/1_2.html
