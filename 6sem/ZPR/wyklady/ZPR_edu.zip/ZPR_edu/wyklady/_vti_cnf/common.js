vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Oct 2002 13:13:10 -0000
vti_extenderversion:SR|6.0.2.6551
vti_cacheddtm:TX|12 Oct 2002 13:13:10 -0000
vti_filesize:IR|103
vti_backlinkinfo:VX|lekcje/wyklady/topw1.html lekcje/wyklady/topw9.html lekcje/wyklady/topw15.html lekcje/wyklady/topw5.html lekcje/wyklady/topw6.html lekcje/wyklady/topw7.html lekcje/wyklady/topw8.html lekcje/wyklady/topw12.html lekcje/wyklady/topw13.html lekcje/wyklady/topw14.html lekcje/wyklady/topw2.html lekcje/wyklady/topw3.html lekcje/wyklady/topw4.html lekcje/wyklady/topw10.html lekcje/wyklady/topw11.html
