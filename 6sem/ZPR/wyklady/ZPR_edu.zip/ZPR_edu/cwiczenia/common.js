function backToMain()
{
 var book = parent.window;
 parent.window.opener.focus();
 book.close();
}