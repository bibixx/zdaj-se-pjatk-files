vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|29 Mar 2004 13:13:42 -0000
vti_extenderversion:SR|6.0.2.6551
vti_cacheddtm:TX|29 Mar 2004 13:13:42 -0000
vti_filesize:IR|103
vti_backlinkinfo:VX|lekcje/cwiczenia/topc8.html lekcje/cwiczenia/topc9.html lekcje/cwiczenia/topc12.html lekcje/cwiczenia/topc10.html lekcje/cwiczenia/topc11.html lekcje/cwiczenia/topc4.html lekcje/cwiczenia/topc5.html lekcje/cwiczenia/topc6.html lekcje/cwiczenia/topc7.html lekcje/cwiczenia/topc1.html lekcje/cwiczenia/topc2.html lekcje/cwiczenia/topc3.html lekcje/cwiczenia/topc14.html lekcje/cwiczenia/topc13.html lekcje/cwiczenia/topc15.html
