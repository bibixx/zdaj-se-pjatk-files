vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Oct 2002 13:13:10 -0000
vti_extenderversion:SR|6.0.2.6551
vti_cacheddtm:TX|12 Oct 2002 13:13:10 -0000
vti_filesize:IR|103
vti_backlinkinfo:VX|lekcje/start/top.html
