import java.util.*;

// Klasa definiuj�ca zadanie do wykonania
// tu b�dzie to wypisywanie komunikat�w

class Message extends TimerTask {

  private String msg;        // komunikat
  private boolean showDate;  // czy pokaza� dat�

  public Message(String s, boolean show) {
    msg = s;
    showDate = show;
  }

  // Ten kod b�dzie wykonywany przez Timer
  // wed�ug charakterystyk czasowych podanych w metodzie schedule
  public void run() {
    String msg1 = msg;
    if (showDate) msg1 = "Jest " + new Date() + '\n' + msg;
    System.out.println(msg1);
  }
}

// Test
public class Timer1 {

  public static void main(String[] args) {

    // Utworzenie zada�
    Message msgTask1 = new Message("Przypominam o podlaniu kwiat�w!", true),
            msgTask2 = new Message("I zako�cz ten program!", false);

    // Czas rozpocz�cia drugiegi zadania:
    // za trzy sekundy od teraz
    long taskTime2 = System.currentTimeMillis() + 3000;

    // Utworzenie timera
    Timer tm = new Timer();

    // Zlecenie pierwszego zadania do wykonania
    // Ma si� zacz�� JU� - podano 0 jako moment startu
    // i powtarza� si� co 2 sekundy
    tm.schedule(msgTask1, 0, 2000);

    // Zlecenie drugiego zadania do wykonania
    // Zacznie si� w momencie okre�lanym przez dat�
    // - utworzony obiekt Date; tu - zgodnie z czasem timeTask2
    // ale mog�oby to by� np. 11 lipca o 9 rano
    tm.schedule(msgTask2, new Date(taskTime2), 2000);

    // Po twierdz�cej odpowiedzi na to pytanie ...
    int rc = javax.swing.JOptionPane.showConfirmDialog(null,
        "Czy kwiaty podlane?");
    // ... ko�czymy dzia�anie zadania msgTask1
    // do czego s�u�y metoda cancel():
    if (rc == 0) msgTask1.cancel();

    // zadanie 2 nadal dzia�a
    javax.swing.JOptionPane.showMessageDialog(null, "Ko�czy� trzeba");

    // teraz ko�czymy wszystko
    System.exit(0);
  }

}
