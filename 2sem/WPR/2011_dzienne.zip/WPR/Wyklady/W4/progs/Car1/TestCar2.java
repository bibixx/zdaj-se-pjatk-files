public class TestCar2 {

   // Symulacja up�ywu czasu...
   static void delay(int sek) {
     while(sek-- > 0) { 
       try {
         Thread.sleep(1000);
       } catch (Exception exc)  { }
     }  
    } 
       
 public static void main(String[] args)  {
    Car c = new Car("WA1090", new Person("Janek", "0909090"), 
                     100, 100, 100, 100, 50);
    
    c.fill(10);   // nape�niamy bak
    c.start();    // ruszamy ...
    System.out.println(c + ""); // co si� dzieje z samochodem
    delay(3);     // niech up�ynie 5 sek. od tego momentu
    c.stop();
    System.out.println(c + ""); // co si� dzieje z samochodem
    delay(9);    // niech up�ynie jeszcze 6 sek. od tego momentu 
    System.out.println(c + ""); // co si� dzieje z samochodem
 }
}  