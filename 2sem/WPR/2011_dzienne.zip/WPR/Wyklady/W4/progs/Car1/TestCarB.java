public class TestCarB {

   static int timerN;
   // Symulacja up�ywu czasu...
   static void delay(int sek) {
     System.out.println("Start up�ywu czasu " + ++timerN + ": " + sek + " sek....");
     while(sek-- > 0) {
       try {
         Thread.sleep(1000);
       } catch (Exception exc)  { }
     }
     System.out.println("... koniec up�ywu czasu " + timerN);       
    }

 public static void main(String[] args)  {
    CarB c = new CarB("WA1090", new Person("Janek", "0909090"),
                     100, 100, 100, 100, 50);

    c.fill(10);   // nape�niamy bak
    c.start();    // ruszamy ...
    System.out.println(c + ""); // co si� dzieje z samochodem
    delay(3);    // niech up�ynie 3 sek. jazdy od tego momentu
    c.stop();    // zatrzymujemy samoch�d
    System.out.println(c + "");
    delay(1);
    c.start();
    System.out.println(c + "");
    delay(2);
    c.stop();
    System.out.println(c + "");
    delay(2);
    c.start();
    System.out.println(c + "");
    delay(4);
    System.out.println(c + "");
    delay(2);
    System.out.println(c + "");
 }
}