class Person  {
   private String name;
   private String pesel;
   
   Person(String aname, String id)  {
       name = aname;
       pesel = id;
   }
   
   public String getName()  { return name; }
   public String getPesel()     { return pesel;}
}


public class Vehicle  {
  
  public final static int BROKEN = 0, STOPPED = 1, MOVING = 2;
  private final static String[] states =  { "ZEPSUTY", "STOI", "JEDZIE" };
  
  private static int count;
  private int currNr = ++count;
  
  private int width, height, length, weight;
  private Person owner;
  private int state = STOPPED;
  
  Vehicle()  {  }
  
  Vehicle(int w, int h, int l, int ww)  {
     this(null, w, h, l, ww);
  }
  
  
  Vehicle(Person p, int w, int h, int l, int ww)  {
     owner = p;
     width = w;
     height = h;
     length = l;
     weight = ww;
  }
  
  public void start()  { 
     setState(MOVING);
  }
  
  public void stop()  {
     setState(STOPPED);
  }
  
  private void setState(int newState)  {
     if (state == newState || state == BROKEN)  
        System.out.println("Nie jest mozliwe przejscie ze stanu " + states[state] + " do stanu " + states[newState]); 
     else state = newState;
  }
  
  public Vehicle repair()  {
     if (state == MOVING) System.out.println("Nie mo�na reperowa� jad�cego pojazdu");
     else if (state != BROKEN) System.out.println("Pojazd sprawny");
     else state = STOPPED;
     return this;
  }
  
  public int getState()  { return state; }
  public static String getState(int state)  { return states[state];} 
  
  public boolean isStopped()  { return state == STOPPED; }
    
  public void crash(Vehicle v)  {
      if (state != MOVING && v.state != MOVING) 
         System.out.println("Nie ma kolizji");
      else  {    
        setState(BROKEN);
        v.setState(BROKEN);
      }
  }
  
  public void sellTo(Person p)  {
     owner = p;
  }
  
  public int getNr()  { return currNr; }
  
  public boolean isTooHighToGoUnder(int limit)  {
      return height > limit ? true : false;
  }
    
  public String toString()  {
    String s = (owner == null ? "sklep" : owner.getName());
    return "Pojazd " + currNr + " ,w�a�cicielem kt�rego jest " 
           + s + " - " + states[state];
  }
  
  static int getCount()  { return count; }
  
  static String[] getAvailableStates()  {
     return states;
  }
  
}  
