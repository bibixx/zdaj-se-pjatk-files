import java.util.*;

// Klasa dla ustalania i pobierania tekst�w
class Teksty {

  String txt = null;
  boolean newTxt = false;

  // Metoda ustalaj�ca tekst - wywo�uje Autor
  synchronized void setTextToWrite(String s) {
    txt = s;
  }

  // Metoda pobrania tekstu - wywo�uje Writer
  synchronized String getTextToWrite() {
    return txt;
  }

}

// Klasa "wypisywacza"
class Writer extends Thread {

  Teksty txtArea;

  Writer(Teksty t) {
    txtArea=t;
  }

  public void run() {
    String txt = txtArea.getTextToWrite();
    while(txt != null) {
      System.out.println("-> " + txt);
      txt = txtArea.getTextToWrite();
      }
  }

}

// Klasa autora
class Author extends Thread {

  Teksty txtArea;

  Author(Teksty t)  {
    txtArea=t;
  }

  public void run() {

    String[] s = { "Pies", "Kot", "Zebra", "Lew", "Owca", "S�o�", null };
    Random rand = new Random();
    for (int i=0; i<s.length; i++) {
      try { // autor zastanawia si� chwil� co napisa�
        sleep((rand.nextInt(1) + 1)*1000);
      } catch(InterruptedException exc) { }
      txtArea.setTextToWrite(s[i]);
    }
  }

}

// Klasa testuj�ca
public class Koord0 {

   public static void main(String[] args) {
     Teksty t = new Teksty();
     Thread t1 = new Author(t);
     Thread t2 = new Writer(t);
     t1.start();
     try { Thread.sleep(5000); } catch(Exception exc) {}
     t2.start();
   }

}

