import javax.swing.*;

class ThreadReporter {

  // Jako argument podajemy tryb, okre�laj�cy czy mamy
  // korzysta� z element� GUI
  // od tego trybu zale�y ile w�tk�w b�dzie dzia�a�
  // w naszym programie  
  public ThreadReporter(String mode) {

    if (mode.equals("Frame")) {
      JFrame f = new JFrame();
    }

    else if (mode.equals("Dialog"))
      JOptionPane.showMessageDialog(null, "Zobaczmy!");

    showThreads();
    try { Thread.sleep(3000); } catch(Exception exc) {}
    tryToInterruptAllInterruptible();
    try { Thread.sleep(3000); } catch(Exception exc) {exc.printStackTrace();}
    showThreads();

  }

  // Metoda zwraca tablic� aktywnych w�tk�w w bie��cej grupie
  public Thread[] getActiveThreads() {
    ThreadGroup tgr = Thread.currentThread().getThreadGroup();

    // Uwaga: activeCount() daje estymowan� liczb� w�tk�w w grupie
    Thread[] t = new Thread[tgr.activeCount()];

    // Metoda enumerate - wypelnia tablic� w�tk�w
    int n = tgr.enumerate(t, true);

    // Dzia�aj�ce w�tki
    Thread[] realThreads = new Thread[n];
    for (int i=0; i<n; i++) realThreads[i] = t[i];
    return realThreads;
  }

  // Pokazuje informacje o diz�alaj�cych w�tkach
  public void showThreads() {
    Thread[] t = getActiveThreads();
    System.out.println("Liczba aktywnych w�tk�w " + t.length);
    for (int i=0; i < t.length; i++) {
      System.out.println(t[i].getName() + ", priority = " +
                         t[i].getPriority() +
                         (t[i].isDaemon() ? " daemon " : " user ") + "thread"
                        );
    }
  }

  // Ko�czy wszystkie w�tki, kt�re nale�� do klasy
  // InterruptibleRepetitiveThread
  public void tryToInterruptAllInterruptible() {
    Thread[] t = getActiveThreads();
    for (int i=0; i < t.length; i++) {
      if (t[i] instanceof InterruptibleRepetitiveThread)
         t[i].interrupt();
    }
  }


  public static void main(String[] args) {

    String s = (args.length == 0 ? "none" : args[0]);

    new InterruptibleRepetitiveThread("Gwiazdki", 1000,
        new Command() {
          public void execute() {
            System.out.println("***");
          }
        }).start();

    new InterruptibleRepetitiveThread("Plusy", 1000,
        new Command() {
          public void execute() {
            System.out.println("+++");
          }
        }).start();

    new ThreadReporter(s);

  }
}

