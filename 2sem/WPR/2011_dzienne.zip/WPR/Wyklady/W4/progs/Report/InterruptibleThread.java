// Implementacja tego interfejsu w jakiej� klasie
// dostarczy definicji metody do wykonania w w�tku
interface Command {
  public void execute();
}

// Klasa przerywalnych w�tk�w
// wykonuj�cych powtarzalne czynno�ci
class InterruptibleRepetitiveThread extends Thread {

  // obiekt dostarczaj�cy definicji czynno�ci
  private Command command;

  // Muteks do synchronizacji wait
  // Potrzebny jedynie dla zapewnienia regu� sk�adniowych
  // Obiekt ten na pewno nie b�dzie wsp�ldzielony!
  private final Object waitMutex = new Object();

  // Cz�stotliwo�� powtarzania czynno�ci
  int freq;

  public InterruptibleRepetitiveThread(String name, int f, Command com) {
    super(name);
    command = com;
    freq = f;
  }

  public void run() {
    // Tu p�tla niesko�czona, mo�na doda� warianty
    // np. powt�rzenie ile� razy
    while (true) {
      // Wykonanie czynno�ci.
      // Za�o�enie: synchronizacja dost�pu do jakich� wsp�ldzielonych
      // obiekt�w - na poziomie definicji metody execute()!!!
      command.execute();

      // Umo�liwienie zako�czenia pracy w�tku
      synchronized(waitMutex) {
        try {
          waitMutex.wait(freq);
        } catch (InterruptedException exc) {
            System.out.println(getName() +  " - interrupted");
            return;
        }
       }
    }
  }

}

