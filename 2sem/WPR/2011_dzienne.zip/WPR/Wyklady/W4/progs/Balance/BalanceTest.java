import javax.swing.*;

class Balance {
  
  private int number = 0;
  
  public int balance() {
    number++;
    number--;
    return number;
  }  
  
}  

class BalanceThread extends Thread {
  
  private Balance b;  // referencja do obiektu klasy Balance
  private int count;  // liczba pwot�rze� p�tli w metodzie run 
    
  public BalanceThread(String name, Balance b, int count) {
    super(name); 
    this.b = b;
    this.count = count;
    start();
  }  

  public void run() {
    int wynik = 0; 
    synchronized (b) {  
      for (int i = 0; i < count; i++) {
        wynik = b.balance();  
        if (wynik != 0) break;
      }
    }  

    System.out.println(Thread.currentThread().getName() + 
                       " konczy z wynikiem  " + wynik);
  }
}  

class BalanceTest {
  
  public static void main(String[] args) {
    
    int tnum = Integer.parseInt(args[0]);     // liczba w�tk�w  
    int count = Integer.parseInt(args[1]);    // liczba powt�rze� p�tli w run() 
    
    // Tworzymy obiekt klasy balance
    Balance b = new Balance();
    
    // Tworzymy i uruchamiamy w�tki
    Thread[] thread = new Thread[tnum];
    for (int i = 0; i < tnum; i++) 
      thread[i] = new BalanceThread("W"+(i+1), b, count);

  }

}       