import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test3 extends JFrame {

  public Test3() {
    JTextArea msg = new JTextArea(20, 40);
    msg.setBackground(new Color(0, 0, 110));
    msg.setForeground(Color.white);
    msg.setCaretColor(Color.yellow);
    msg.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 18));
    getContentPane().add(new JScrollPane(msg));
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    pack();
    show();
  }

  public static void main(String[] args) {
    new Test3();
  }
}