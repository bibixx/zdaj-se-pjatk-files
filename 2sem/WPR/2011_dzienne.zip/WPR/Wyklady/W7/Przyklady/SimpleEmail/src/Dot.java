import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Dot extends JComponent implements Runnable {
  private int x;
  private int y;
  private int dotW;
  private int dotH;
  private int step = 1;
  private boolean show = false;
  private long waitTime;
  private int oldW;
  private int oldH;

  public Dot(int size, int step, int waitTime) {
    Dimension d = new Dimension(size,size);
    setPreferredSize(d);
    setMaximumSize(d);
    setMinimumSize(d);

    this.step = step;
    this.waitTime = waitTime;
  }

  private synchronized void init() {
    int w = getWidth();
    int h = getHeight();
    oldW = w;
    oldH = h;
    dotW = w/50;
    dotH = h/50;
    x = (int) ((w - dotW)/2.0);
    y = (int) ((h - dotH)/2.0);
  }

  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    g.setColor(Color.red);
    if (show) {
      g.fillOval(x, y, dotW, dotH);
    } else g.clearRect(0,0, getWidth(), getHeight());

  }

  public void run() {
    while (show) {
      int w = getWidth();
      int h = getHeight();
      if (w != oldW || h != oldH) {
        init();
        oldW = w;
        oldH = h;
      }
      repaint();
      try { Thread.sleep(waitTime); } catch (Exception exc) {}
      x -= step;
      y -= step;
      dotW += 2*step;
      dotH += 2*step;
      if (dotW >= w || dotH >= h) init();
    }
    repaint();
  }

  public synchronized void startShowing() {
    if (show == false) {
      init();
      show = true;
      new Thread(this).start();
    }
  }

  public synchronized void stopShowing() {
    show = false;
  }

  public synchronized boolean isRunning() { return show; }

}