import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Sender extends Thread {

  SimpleEmail gui;

  public Sender(SimpleEmail gui) {
    this.gui = gui;
    start();
  }

  public void run() {
    boolean sending;
    gui.showStatus(sending = true);
    // ... tutaj faktyczna wysy�ka listu
    // ... symulujemy up�yw czasu
    // ... do potwierdzenia od serwera pocztowego
    try { sleep(30000); } catch(Exception exc) {}
    gui.showStatus(sending = false);
  }

}