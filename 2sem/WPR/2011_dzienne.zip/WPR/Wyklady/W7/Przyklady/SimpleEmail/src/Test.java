import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test extends JFrame {

  public Test() {
    getContentPane().add(new JLabel(new ImageIcon("globe.gif")));
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    pack();
    show();
  }

  public static void main(String[] args) {
    Test test = new Test();
  }
}