import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Test2 extends JFrame {

  public Test2() {
    final Dot dot = new Dot(200, 1, 50 );
    JButton b = new JButton("Start/stop");
    getContentPane().add(dot, "Center");
    getContentPane().add(b, "North");

    b.addActionListener( new ActionListener() {
         public void actionPerformed(ActionEvent e) {
           if (!dot.isRunning()) dot.startShowing();
           else dot.stopShowing();
         }
      });


    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    pack();
    show();
  }

  public static void main(String[] args) {
    new Test2();
  }
}