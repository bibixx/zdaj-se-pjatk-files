import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class SimpleEmail extends JFrame {

  private JTextField tfTo = new JTextField(25);
  private JTextField tfSubject = new JTextField(50);

  private JTextArea msg = new JTextArea(20, 40);
  private JScrollPane sp = new JScrollPane(msg);

  private JLabel textLab = new JLabel("Ready");
  private Dot dot = new Dot(30, 1, 50);
  private ImageIcon icon = new ImageIcon("globe.gif");
  private JLabel animLab = new JLabel(icon);

  private int imgW = icon.getImage().getWidth(this);
  private int imgH = icon.getImage().getHeight(this);

  Box addressPanel = Box.createVerticalBox();


  private JLayeredPane layerPane = getLayeredPane();
  private Container cp = getContentPane();


  public SimpleEmail() {
    JPanel toPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    toPanel.add(new JLabel("         To: "));
    toPanel.add(tfTo);
    JPanel subPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
    subPanel.add(new JLabel("Subject: "));
    subPanel.add(tfSubject);

    addressPanel.add(toPanel);
    addressPanel.add(subPanel);
    addressPanel.setBorder(BorderFactory.createLineBorder(Color.blue));

    cp.add(addressPanel, "North");

    msg.setBackground(new Color(0, 0, 110));
    msg.setForeground(Color.white);
    msg.setCaretColor(Color.yellow);
    msg.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 18));

    cp.add(sp);

    JButton b = new JButton("Send");
    b.addActionListener( new ActionListener() {
         public void actionPerformed(ActionEvent e) {
           new Sender(SimpleEmail.this);
         }
      });

    Box controlPanel = Box.createHorizontalBox();
    controlPanel.add(b);

    controlPanel.add(Box.createGlue());
    controlPanel.add(dot);
    controlPanel.add(Box.createRigidArea(new Dimension(30,30)));
    controlPanel.add(textLab);
    controlPanel.setBorder(BorderFactory.createLineBorder(Color.red, 2));

    cp.add(controlPanel, "South");

    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    pack();
    show();
  }

  public void showStatus(final boolean sending) {

    if (sending) dot.startShowing();
    else dot.stopShowing();

    SwingUtilities.invokeLater( new Runnable() {
      public void run() {
        if (sending) {
          int msgW = sp.getWidth();
          int msgH = sp.getHeight();

          int x = msgW/2 - imgW/2;
          int y = addressPanel.getHeight() + msgH/2 - imgH/2;

          animLab.setBounds(x, y, imgW, imgH);

          layerPane.add(animLab, JLayeredPane.DEFAULT_LAYER);
          textLab.setText("Sending...");

        } else {
          layerPane.remove(animLab);
          SimpleEmail.this.repaint();
          textLab.setText("Ready.");
        }
      }
    });

  }

  public static void main(String[] args) {
     new SimpleEmail();
  }


}