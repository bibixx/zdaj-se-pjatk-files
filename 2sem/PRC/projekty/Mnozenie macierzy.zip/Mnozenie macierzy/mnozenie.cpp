
#include<iostream>
#include<fstream>
#include<conio.h>	
using namespace std;

class macierz;							//deklarujemy klas� macierz;
class wektor 							//deklarujemy klas� wektor;
{	int wek[3]; 						//[3] bo macierz ma byc 3 stopnia;

public:
    wektor(){}; 
   ~wektor(){};							//dekonstruktor

void wpisz () 							//wpisanie wartosci do tablicy;
{ 
          ofstream plik1;
          plik1.open("Wektor.txt");
          plik1 << "------------------" << endl;
          plik1 << " Elementy wektora " << endl;
          plik1 << "------------------" << endl << endl;

          cout << "-------------------------" << endl;
          cout << " Podaj 3 elmenty wektora " << endl;
          cout << "-------------------------" << endl;

          int i;
			for(i=0;i<3;i++)
				{cout << "Element "<<i<<" : ";
				 cin >> wek[i];
				 plik1 << "Element "<<i<<" : ";
                 plik1 << wek[i] << endl;
		} 
		   plik1.close();
};
	
void wyswietl () 						//funkcja wy�wietlania wektora; 
{ 
          ofstream wynik("Wynik MxW.txt");
          wynik << "-----------------------------" << endl;
          wynik << " Elementy macierzy wynikowej " << endl;
          wynik << "-----------------------------" << endl << endl;
           int i;
			for(i=0;i<3;i++){
				cout << wek[i]<<"\t";
				wynik << "Element "<<i<<" : ";
                wynik << wek[i] << endl;
                }
                wynik.close();
		};
        
	
	friend wektor mnoz_wektor_macierz (wektor,macierz);	//zaprzyjazniona (dostep do prywatnych)
	
};

class macierz 							//deklarujemy ponownie klas� macierz
{ int mac[3][3];
	
public:
		macierz(){};
		~macierz(){};
		void wpisz(int n)				//wpisanie wartosci do macierzy, n okresla ktora macierz
			{
          ofstream plik2;
          if (n==0){
               plik2.open("Macierz1.txt");
          }
          else{
               plik2.open("Macierz2.txt");
          }
          plik2 << "-------------------" << endl;
          plik2 << " Elementy macierzy " << endl;
          plik2 << "-------------------" << endl << endl;
          	
          cout << "------------------------" << endl;
          cout << " Podaj elmenty macierzy " << endl;
          cout << "------------------------" << endl;
                int i,j; 
				for(i=0;i<3;i++)
					for (j=0;j<3;j++)
						{cout << "Element "<<i<<" wiersza i "<< j <<" kolumny : ";
						 cin >> mac[i][j];
						 plik2 << "Element "<<"|"<<i<<" - "<<j<<"|"<<" : ";
                         plik2 << mac[i][j] << endl;
			};
			plik2.close();				// zamykamy drzwi aby nie bylo przeciagu ;)
};
void wyswietl()							// wyswietlamy zawartosc macierzy
{	
          ofstream wynik("Wynik MxM.txt");
          wynik << "-----------------------------" << endl;
          wynik << " Elementy macierzy wynikowej " << endl;
          wynik << "-----------------------------" << endl << endl;
            int i,j; 
				for(i=0;i<3;i++)
					{ for (j=0;j<3;j++){
					     cout <<mac[i][j]<< "\t";
                        wynik << "Element "<<"|"<<i<<" - "<<j<<"|"<<" : ";
                        wynik << mac[i][j] << endl;
                        }
					   cout << endl;
                    }
          wynik.close();					// zamykamy drzwi aby nie bylo przeciagu ;)							
};
	
    macierz mnoz_macierzy ( macierz ); 				// funkcja bedzie sluzyc obliczaniu macierzy
	
    friend wektor mnoz_wektor_macierz (wektor,macierz); 

};


wektor mnoz_wektor_macierz(wektor w,macierz m)			// funkcja obliczajaca iloczyn dwoch macierzy;
{ int i,j;
	wektor tym;						//tymczasowy wektor;
	for(i=0;i<3;i++)
		{tym.wek[i]=0;
	    	for(j=0;j<3;j++)
			tym.wek[i]+=w.wek[j]*m.mac[j][i];
		};
	return tym; 						// zwracamy wt przez wartosc;
};

macierz macierz::mnoz_macierzy(macierz s)			// funkcja mnozenia dwoch macierzy;
{ int i,j,p;
	macierz tymcz; 						// tak jak z wektorem tymczasowym
	for (i=0;i<3;i++) 
		for (j=0;j<3;j++)  
		{tymcz.mac[i][j]=0;
			for (p=0;p<3;p++)
				tymcz.mac[i][j]+=mac[i][p] * s.mac[p][j];
		};
	return tymcz; 
};

int read(int number){
  
  ifstream file;
  
  if (number == 1) ifstream file("Wektor.txt", ios::in);
  if (number == 2) ifstream file("Macierz1.txt", ios::in);
  if (number == 3) ifstream file("Macierz2.txt", ios::in);
  if (number == 4) ifstream file("Wynik MxW.txt", ios::in);
  if (number == 5) ifstream file("Wynik MxM.txt", ios::in);
  
  if (!file)
  {
                cout<<"\n\n NIE ZNALEZIONO PLIKU \n" << endl;
  }
  else
  {
                int i;
                cout<<"\n\nPlik znaleziony w katalogu programu.\n" << endl;
                file.close();					// zamykamy drzwi aby nie bylo przeciagu ;)
  }
  
return 0;
};

int main ()
{ 
  int i;
  int choose;
  cout<<"-----------\n";
  cout<<" MAIN MENU \n";
  cout<<"-----------\n";
  cout<<"1. - Rozpocznij procedure na nowo.\n";
  cout<<"2. - Sprawdz czy jest historia.\n";  
  cin>> choose;
  
  if(choose == 1)// //-------------------------------------------------------- 1
  {
            
  static int number = 0; 				// s�u�y do sprawdzania czy mam juz stworzon� pierwsza macierz
  wektor w1,wynik;	
  macierz m1,m2,wyniki;

  w1.wpisz();cout<<"\n\n";
  m1.wpisz(number);cout<<"\n\n";
  number += 1;
  m2.wpisz(number);cout<<"\n\n";
 
  wynik=mnoz_wektor_macierz(w1,m1);
  wyniki=m1.mnoz_macierzy(m2);
  
  cout<<"----------------------------------------\n";
  cout<<" Oto wyniki mno�enia wektora x macierz: \n";
  cout<<"----------------------------------------\n";
  
  wynik.wyswietl();
  getche(); // wstrzymanie wy�wietlania
  
  cout<<"\n\n";
  cout<<"----------------------------------------\n";
  cout<<" Oto wyniki mno�enia macierz x macierz: \n";
  cout<<"----------------------------------------\n";
  
  wyniki.wyswietl();
  getche(); 						// wstrzymanie wy�wietlania
  
  };							// koniec wyboru 1
  
  if (choose == 2)//---------------------------------------------------------- 2
  {
  
  int choose2;
  cout<<"\n";
  cout<<"---------------\n";
  cout<<" CHECK HISTORY \n";
  cout<<"---------------\n";
  cout<<"1. - Wektor.txt\n";
  cout<<"2. - Macierz1.txt\n";  
  cout<<"3. - Macierz2.txt\n";
  cout<<"4. - Wynik MxW.txt\n";  
  cout<<"5. - Wynik MxM.txt\n";  
  cin>> choose2;
  if(choose2 ==1 ) read(1);
    if(choose2 ==2 ) read(2);
      if(choose2 ==3 ) read(3);
        if(choose2 ==4 ) read(4);
          if(choose2 ==5 ) read(5);
   getche(); 						// wstrzymanie wy�wietlania            
  
  };							// koniec wyboru 2

  return 0;  
};
