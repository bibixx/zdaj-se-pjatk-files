void Sito()
{
int i,j,zakres,do_kad;
int tablica[10000];
clrscr();
cout<<"Podaj gorny zakres, do ktorego chcesz odnalezc liczby pierwsze\n";
cin>>zakres;
if (zakres<=0) return;
do_kad=floor(sqrt(zakres));
for (i=1; i<=zakres; i++) tablica[i]=i;				//tymczasowe wypelnienie tablicy
for (i=2; i<=do_kad; i++)					//prawidlowe wypelnienie tablicy od 2 pozycji (1 pozycja to liczba pierwsza)
	if (tablica[i]!=0)					//sprawdzenie stanu tablicy
		for (j=i+1; j<=zakres; j++)			//bierzemy kolejne liczby i sprawdzamy czy sa podzielne przez zmienna 'i'
			if (j%i==0) tablica[j]=0;		//jesli liczna jest podzielna przez zmienna 'i' to ta liczbe usuwamy
cout<<"\nLiczby pierwsze z zakresu od 1 do "<<zakres<<'\n';
for (i=2; i<=zakres; i++) if (tablica[i]!=0) cerr<<" "<<i;	//drukowanie wyniku
}


//do_kad=floor(sqrt(zakres)) - oznaczam, �e
//kolejne wykre�lania nale�y powtarza�, nie dalej jak do liczby b�d�cej
//zaokr�glonym w d� pierwiastkiem zakresu



