
typedef int element;
const long M=200;
const int m=10;

void wypelnij(element t[], long& ile)
{
    for(long i=0; i<M; i++)
	 t[i]=random(3200);							//wypelniamy randomowo tablice
    ile=M;									//zmianna ile = zmiennej M (adresy)
}

void wyswietl(element t[], long ile)
{ 
	for(long i=0; i<ile; i++)
	{ 
	printf("%d \n", t[i]);						
        if (i==ile-1) cout<<"\nKoniec sortowania.\n";				//dodatkowy komunikat
		if (i%15==0 && i!=0)						//jesli cos podzielne przez 15
	 	{ 
			cout<<"\t\t Nacisnij dowolny klawisz...\n";
            		char z=getch();						//"pobierz klawisz"
	    		if (z=='k') return; 					//jelsli k to zakoncz
		}
	}
}

inline void zamien(element  &a, element  &b)					//zamiana adres�w
{ 
    element pom=a;
    a=b;
    b=pom; 
}

inline void porownaj_zamien(element &a, element &b,int& ilosc_przypisan)
{ 
      if (b<a) 
      {
      zamien(a,b);
      ilosc_przypisan=ilosc_przypisan+3;
      } 
}

void szybki1(element t[], long l, long p,int &ilosc_przypisan)
{	
	long i=l,j=p;
	element pom=t[(i+j)/2];							//dzielimy tabele na 2 (pom to srodek tabeli)
	do
	 {  while(t[i]<pom) i++;						//lewa strona
	    while(t[j]>pom) j--;						//prawa strona
	     if (i<=j)								//jezeli sie nie spotkali
		 { ilosc_przypisan=ilosc_przypisan+3;
                   zamien(t[i],t[j]);
		    i++; j--;  }
	  } while(i<=j);
	if (l<j) szybki1(t,l,j,ilosc_przypisan);
	if (p>i) szybki1(t,i,p,ilosc_przypisan);
}

void Szybki()
{
 int ilosc_przypisan=0;
 element * t=new element[M];
 long ile=0;
 clrscr();
 cout<<"Sortowanie szybkie\n";
 wypelnij(t,ile);
 cout<<"\nLiczby przed sortowaniem:\n";
 wyswietl(t,ile);
 szybki1(t,0,ile-1,ilosc_przypisan);
 cout<<"\nLiczby po sortowaniu:\n";
 wyswietl(t,ile);
 cout<<"\nIlosc przypisan: "<<ilosc_przypisan;
}

void babelki(element t[], long l, long p,int &ilosc_przypisan)			//p - wielkosc, l - od kiedy
{   for( long i =l; i<p; i++)
	     for (long j=l;j<p-i; j++)
	        porownaj_zamien(t[j], t[j+1], ilosc_przypisan);			//jesli cos jest mniejsze to zamienia
}

void Babelki()
{
 element * t=new element[M];
 long ile=0;
 clrscr();
 cout<<"Sortowanie babelkowe\n";
 wypelnij(t,ile);
 cout<<"\nLiczby przed sortowaniem:\n";
 wyswietl(t,ile);
 int ilosc_przypisan=0;
 babelki(t,0,ile-1,ilosc_przypisan);
 cout<<"\nLiczby po sortowaniu:\n";
 wyswietl(t,ile);
 cout<<"\nIlosc przypisan: "<<ilosc_przypisan<<" .";
}