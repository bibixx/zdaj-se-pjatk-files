
const int roz=10;								//wielkosc tablicy

struct mojamama
{
 int Id;
 int x,y;
};									//zmienna z struktury

void Graf()
{
 int tab[roz][roz],czy,i,j;
 mojamama wierzcholki[roz];						//tworzymy zmienna
 for (i=0;i<roz;i++)
     {
      wierzcholki[i].Id=i+1;                                                    //nr wierzch.
      wierzcholki[i].x=random(800);                                             //wsp. x wierzch.
      wierzcholki[i].y=random(600);                                             //wsp. y wierzch.
     }

for (i=0;i<roz;i++)                                                             //macierz sasiedztwa
 {
  czy=0;
  for (j=i;j<roz;j++)								//uzupelniamy polowe macierzy (PG czesc)
  {
   if (i==j) tab[i][j]=0;							//na przekatnej wstawiamy wszystko 0
   else
   {
    if ((tab[i][j]=rand() % 2)==1) czy=1;					//dzielimy otrzymane liczby (ramdomy) mod 2
    //if ((czy==0) && (j==roz-1)) tab[i][j]=1;					//prawy 'gorny' rog
    //if ((i==roz-1) && (j==roz-2) && (czy==0)) tab[i][j]=1;			//prawy 'dolny' rog
   }
  }
 }

for (i=0;i<roz;i++)								//wstawiamy LD czesc macierzy
      for(j=0;j<roz;j++)
         tab[j][i]=tab[i][j];
clrscr();
cout<<"Wierzcholki:\n";
for (i=0;i<roz;i++)
     {
      cout<<"Id="<<wierzcholki[i].Id;
      if (i<9)   cout<<" ";							//dodatkowo dla przejrzystosci
      cout<<" x="<<wierzcholki[i].x<<" y="<<wierzcholki[i].y<<endl;
     }
cout<<"\nNacisnij dowolny klawisz ...";
getch();
clrscr();

cout<<"Macierz sasiedztwa:\n";							//pokazuje jakie sa aktywne komorki w wierszu
for (i=0;i<roz;i++)								//wyswietla w formacie macierzy
 {
      for (j=0;j<roz;j++) cout<<tab[i][j];
           cout<<endl;
 }

cout<<"\nLista sasiedztwa:\n";							//pokazuje jakie sa aktywne komorki w wierszu
for (i=0;i<roz;i++)
 {
     cout<<i+1<<':';								//indeksy
     if (i<9) cerr<<' ';							//dodatkowo dla przyjrzystosci
     for (j=0;j<roz;j++)							
          if (tab[i][j]==1) cout<<" "<<j+1;					//wyswietla aktywne komorki w tabeli (j+1)
     cout<<endl;								//zmienna 'j' "zaczyna sie" od 0, dlatego j+1
 }
 cout<<"\nKoniec Grafu.";
}