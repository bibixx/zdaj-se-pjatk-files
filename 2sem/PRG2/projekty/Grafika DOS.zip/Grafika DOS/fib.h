
int fib(int n)
{
if (n<=0 || n>25) return 0;				//ograniczenie do 25
if ((n==1)||(n==2))					//podanie wyniku dla liczb 1 i 2
 return 1;
 else
return fib(n-1)+fib(n-2);				//zwracamy i uruchamiamy na nowo
}

void Fib()
{
 int n;
 clrscr();
 cout<<"Wyznaczanie elementu ciagu Fibonacciego o indeksie 0=<n<=25\n\nPodaj n= ";
 cin>>n;
 cout<<"\n"<<n<<"-ty wyraz ciagu Fibonacciego: "<<fib(n);
}


//--------------------------------------------------------------
//1. uruchamia sie funkcja Fig()
//2. ona uruchania funkcje fig()
//3. funkcja fib() tworzy pseudo petle
//4. petla ta, konczy sie dopiero jak n==1 albo n == 2
//5. n za kazdym razem maleje (return w funkcji fib() )
//6. return ponownie wywoluje funkcje fib(), poki n==1 albo n==2
//----------------------------------------------------------------
