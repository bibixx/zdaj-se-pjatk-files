#include <iostream>
#include <fstream>

using namespace std;

 class Vehicle 
{
protected: 
      char* brand;
      char* model;
      char* color;
      int price;
public:
       Vehicle() 
                : brand(strcpy(new char[10],"brand")),
                  model(strcpy(new char[10],"model")),
                  color(strcpy(new char[10],"color")),
                  price(0)
      {}
       
       
      Vehicle(const char* t, const char* a, const char* g, int p) 
                    : brand(strcpy(new char[strlen(t)+1], t)),
                      model(strcpy(new char[strlen(a)+1], a)),
                      color(strcpy(new char[strlen(g)+1], g)),
                      price(p)
      {}
      
           
      ~Vehicle(){}
      
             
      virtual char* getBrand()=0;     
      virtual char* getModel()=0;
      virtual char* getColor()=0;
      virtual int getPrice()=0;
};


class Car : public Vehicle
{
        int engine;
   public:
          Car(): engine(0)   
          {}
          
          
          Car(const char* t, const char* a, const char* g, int p, int tN)
                   : Vehicle(t, a, g, p), 
                     engine(tN)         
          {} 
          
                          
          
          ~Car()
          {
               cout << "Car has been deleted!" << endl; 
          }
          
          
          
          char* getBrand()
          {
                return brand;      
          }
           
          char* getModel()
          {
                return model;      
          }
          
          char* getColor()
          {
                return color;
          }
          
          int getPrice()
          {
                return price;
          }
          
          int getEngine()
          {
                return engine;
          }
          
          friend void addCar();
          friend void displayAll();
          friend void findByBrand();
          friend void findByModel();
          friend void findByColor();
          friend void delCar();
          friend void save();
          friend void load();
          
          Car* next;
};
Car* First = NULL;
Car* Last = NULL;



void addCar()
{
        char b[100];
        char m[100];
        char c[100];
        int p;
        int e;
   
            
        cout << "What is the car brand?" << endl;
        cin >> b;
	    cout << "What is the car model?" << endl;
        cin >> m;
	    cout << "What is the car color?" << endl;
	    cin >> c;
        cout << "What is the car price?" << endl;
	    cin >> p;
        cout << "What is the engine power?" << endl;
        cin >> e;
        cout << "-----------------------------------------------------" << endl; 
        Car* car = new Car(b, m, c, p, e);
        
         if (Last)
		      Last->next = car;
		      car->next = NULL;
		      Last = car;

         if (First == NULL)
              First=car;
}



void displayAll()
{
 
    cout << "ALL Cars:" << endl;    
    for (Car *car=First; car != NULL; car = car->next)
        cout << "brand:" << car->getBrand() << "  model:" << car->getModel() << 
        "  color:" << car->getColor() << "  Price:" << car->getPrice() << 
        "  Number of tracks:" << car->getEngine() << endl;

    cout << "-----------------------------------------------------" << endl; 
}

void findByBrand()
{
	char brand1[100];
	cout << "What is the brand you are looking for?:" << endl;
	cin >> brand1;
	
    cout << "Cars FOUND:" << endl;
	for (Car *car=First; car != NULL; car = car->next)
		if (strcmp(car->brand, brand1)==0)
		   cout << "brand:" << car->getBrand() << "  model:" << car->getModel() << 
           "  color:" << car->getColor() << "  Price:" << car->getPrice() << 
           "  Number of tracks:" << car->getEngine() << endl;
   
    cout << "-----------------------------------------------------" << endl; 
}

void findByModel()
{
    char model1[100];
    cout << "What is the model you are looking for?:" << endl;
	cin >> model1;

    cout << "Cars FOUND:" << endl;
	for (Car *car=First; car != NULL; car = car->next)
		if (!strcmp(car->model, model1))
		   cout << "brand:" << car->getBrand() << "  model:" << car->getModel() << 
           "  color:" << car->getColor() << "  Price:" << car->getPrice() << 
           "  Number of tracks:" << car->getEngine() << endl;
  
    cout << "-----------------------------------------------------" << endl; 
}

void findByColor()
{
    char color1[100];
    cout << "What is the color of the car you are looking for?:" << endl;
	cin >> color1;

    cout << "Cars FOUND:" << endl;
	for (Car *car=First; car != NULL; car = car->next)
		if (!strcmp(car->color, color1))
           cout << "brand:" << car->getBrand() << "  model:" << car->getModel() << 
           "  color:" << car->getColor() << "  Price:" << car->getPrice() << 
           "  Number of tracks:" << car->getEngine() << endl;
    
}

void delCar()
{
        char t_brand[100]; 
        char a_model[100];
        cout << "What is the brand of the car you want to remove?:" << endl;
        cin >> t_brand;
        cout << "What is the model of the car you want to remove?:" << endl;
        cin >> a_model;
        if(strcmp(First->brand,t_brand)==0 && strcmp(First->model,a_model)==0) 
        {
             First = First->next;
        }

 Car* a = First;
 Car* b = First;

	
	while( a != NULL )
    {
		if( strcmp(a->brand,t_brand)==0 && strcmp(a->model,a_model)==0)
        {
			b->next = a->next;
			a -> ~Car();
    	    
			return;
		}
		b = a;
		a = a->next;
	}
	cout << "-----------------------------------------------------" << endl; 
}



void saveCar()
{
     ofstream file_out("Cars.txt", ios::out);
     
     for(Car *car=First; car != NULL; car = car->next)
        file_out << car->getBrand() << " " << car->getModel() << " " << car->getColor() << 
        " " << car->getPrice() << " " << car->getEngine() << endl;
      
     file_out.close();
     cout << "-----------------------------------------------------" << endl;    
}

void loadCar()
{
       ifstream file_in("Cars.txt", ios::in);
       if ( !file_in.is_open() )
	   {
		  cout << "NO FILE: Cars.txt" << endl;
		  return;
	   }  
	   else
	   {
        file_in.seekg( 0, ios::end ); 
		int x = file_in.tellg();     
		if ( file_in.tellg() )     
		{
			file_in.seekg( 0, ios::beg );  
			char brand[100];
			char model[100];
			char color[100];
			int price;
			int engine;
			while( !file_in.eof() )       
			{
				file_in >> brand;
				file_in >> model;
				file_in >> color;
				file_in >> price;
				file_in >> engine;
				cout << "brand:" << brand << "  model:" << model << 
                "  color:" << color << "  price:" << price << 
                "  Number of tracks:" << engine << endl;
                
                Car* car = new Car(brand, model, color, price, engine);
                
                if (Last)
		           Last->next = car;
		           car->next = NULL;
		           Last = car;

                if (First == NULL)
                   First=car;
			}
		}
		file_in.clear(); 
        file_in.close();    
       }
       cout << "-----------------------------------------------------" << endl; 
}





int main()
{
   cout<<( "             ________             ")<<endl;
	cout<<("            /   |    [            ")<<endl;
	cout<<("      _____/____|_____[____/      ")<<endl;
	cout<<("     /<    |   =|    =|    [      ")<<endl;
	cout<<("    /__OO__|____|_____|OO_||      ")<<endl;
	cout<<("       OO              OO         ")<<endl;
    cout << "***********************************************" << endl;
	cout << "*   0.EXIT                                    *" << endl;
    cout << "*   1.ADD NEW CAR TO DATABASE                 *" << endl;
   	cout << "*   2.FIND BY BRAND                           *" << endl;
    cout << "*   3.FIND BY MODEL                           *" << endl;
    cout << "*   4.FIND BY COLOR                           *" << endl;
    cout << "*   5.REMOVE CAR FROM DATABASE                *" << endl;
    cout << "*   6.SHOW ALL CARS                           *" << endl;
    cout << "*   7.SAVE CARS                               *" << endl;
    cout << "*   8.LOAD CARS                               *" << endl;
    cout << "***********************************************" << endl;
	cout << "----SELECT THE NUMBER:-------------------------" << endl;
  int s;
  while (true)
  {
    cin >> s;    
    switch(s)
     {
               case 0: 
                    exit(1);
               case 1: 
                    addCar();
                    break;
               case 2:
                    findByBrand();
                    break;
               case 3:
                    findByModel();
                    break;
               case 4:
                    findByColor();
                    break;
               case 5:
                    delCar();
                    break;
               case 6:
                    displayAll();
                    break;
               case 7:
                    saveCar();
                    break;
               case 8:
                    loadCar();
                    break;
               
               default:   
                    cout << "PLEASE ENTER CORRECT NUMBER" << endl;        
     }
    }
     
	system ("PAUSE");
   return 1; 
    
}