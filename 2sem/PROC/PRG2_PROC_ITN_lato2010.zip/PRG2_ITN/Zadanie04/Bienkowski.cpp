#include <iostream>
#include <cmath>

double riemann(double (*f)(double), double a, double b, int n)
	{
	double Result = 0;
	double Step = (b-a)/n;
	for(int i = 0; i < n; i++) Result += f(a + i*Step + 0.5 * Step) * Step;
	return Result;
	}

double xlogx(double x)
	{
	return x*log(x);
	}
	
int main()
	{
	double Wynik = riemann(xlogx,1,M_E,120);
	std::cout << Wynik << std::endl;
	return 0;
	}

