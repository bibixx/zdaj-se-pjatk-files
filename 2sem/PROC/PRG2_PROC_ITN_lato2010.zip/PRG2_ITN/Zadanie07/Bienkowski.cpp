#include <cstdlib>
#include <iostream>
#include <string>

using namespace std;

class Rectangle 
	{
	public:
	double LLx, LLy;
	double URx, URy;
	
	Rectangle (double _LLx, double _LLy, double _URx, double _URy)
		{
		this->LLx = _LLx;
		this->LLy = _LLy;
		this->URx = _URx;
		this->URy = _URy;
		}
	
	static bool Intersects(const Rectangle& Left, const Rectangle& Right)
		{
		if(Left.LLy > Right.URy || Left.LLx > Right.URx || Left.URx < Right.LLx || Left.URy < Right.LLy) return false;
		else return true;
		}
		
	bool Intersects(const Rectangle & Other)
		{
		return Intersects(*this,Other);
		}

	};

const Rectangle operator+(const Rectangle& Left, const Rectangle& Right)
	{
	return Rectangle(Left.LLx < Right.LLx ? Left.LLx : Right.LLx,
			 Left.LLy < Right.LLy ? Left.LLy : Right.LLy,
			 Left.URx > Right.URx ? Left.URx : Right.URx,
			 Left.URy > Right.URy ? Left.URy : Right.URy);
	}
	
const Rectangle operator*(const Rectangle& Left, const Rectangle& Right)
	{
	if(Rectangle::Intersects(Left,Right))
		{
		return Rectangle(Left.LLx > Right.LLx ? Left.LLx : Right.LLx,
				 Left.LLy > Right.LLy ? Left.LLy : Right.LLy,
				 Left.URx < Right.URx ? Left.URx : Right.URx,
				 Left.URy < Right.URy ? Left.URy : Right.URy);
		}
	else
		{
		string Error = "ERROR: Rectangles do not intersect!";
		throw Error;
		}
	}
	
ostream & operator<<(ostream & stream, const Rectangle &R)
	{
	stream << "[(" << R.LLx << "," << R.LLy << ")/(" << R.URx << "," << R.URy << ")]";
	return stream;
	}


int main(int argc, char *argv[])
	{
	Rectangle r1(1,2,6,6), r2(3,3,5,8), r3(4,1,7,4), r4(0,0,2,4), r5(0,0,6,2);
	
	Rectangle rx = r1*r2 + r3;
	
	cout << "rx = " << rx << endl;
	
	cout << rx << " and " << r4 << " do ";
	if(rx.Intersects(r4)) cout << "intersect." << endl;
	else cout << "not intersect." << endl;
	
	try
		{
		Rectangle ry = rx * r5;
		cout << "Intersection of " << rx << " and " << r5 << " is " << ry << endl;
		}
	catch(string &E)
		{
		cout << E << endl;
		}
		
	Rectangle a(0,0,1,1), b(2,2,3,3);
	cout << "Intersection of " << a << " and " << b << " is ";


	try
		{
		cout << a*b << endl;
		}
	catch(string &E)
		{
		cout << E << endl;
		}
    system("PAUSE");
    return EXIT_SUCCESS;
}
