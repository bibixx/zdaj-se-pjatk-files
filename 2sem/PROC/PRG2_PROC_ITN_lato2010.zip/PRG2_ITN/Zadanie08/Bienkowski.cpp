// zmienilem lekko specyfikacje, poniewaz aby String::toUpper() lub String::toLower() zwrocilo String&, 
// musialbym zmieniac dana instancje, co uwazam za nielogiczne


#include <iostream>
#include <ostream>
#include <cstring>
#include <cctype>
#include <cstdlib>

using namespace std;

class String{
	public:
	String(){
		data=0;
	}

	String(const char * cstring){
		size_t len = strlen(cstring);
		data = new char[len+1];
		strcpy(data,cstring);
	}

	String(const String &in){
		size_t len = strlen(in.c_str());
		data = new char[len+1];
		strcpy(data,in.c_str());
	}

	~String(){
		delete data;
	}
	
	size_t Length() const{
		return data ? strlen(data) : 0;
	}
	
	String & operator+(const char * cstring){
		this->Append(cstring);
		return *this;
	}
		
	String & operator+(const String in){
		this->Append(in);
		return *this;
	}
	
	void Append(const char *cstring){
		char *ptr = new char[strlen(cstring) + (data ? strlen(data) : 0) + 1];
		if(data) strcpy(ptr,data);
		strcpy(ptr+(data ? this->Length() : 0),cstring);
		delete data;
		data = ptr;
	}
	
	void Append(const String in){
		this->Append(in.c_str());
	}
	
	char * c_str() const{
		return data;
	}
		
	char & operator[](const int no){
		return *(data+no);
	}
	
	String toUpper() const{
		String x(*this);
		for(unsigned int i = 0; i < strlen(x.c_str()); i++) x[i] = toupper(x.c_str()[i]);
		return x;
	}	
	
	String toLower() const {
		String x(*this);
		for(unsigned int i = 0; i < strlen(x.c_str()); i++) x[i] = tolower(x.c_str()[i]);
		return x;
	}
		
	String & operator=(const String &s){
		if(this != &s){
			if(this->data) delete this->data;
			if(s.c_str()){
				this->data = new char[s.Length()+1];
				strcpy(this->data,s.c_str());
			}
			else{
				this->data = 0;
			}
		}
		return *this;
	}
	
	String & operator=(const char* s){
		if(this->data) delete this->data;
		this->data = new char[strlen(s)+1];
		strcpy(this->data,s);
		return *this;
	}
	
	bool operator==(const char * p){
		return strcmp(data,p) == 0 ? true : false;
	}
	
	bool operator==(const String &s){
		return strcmp(data,s.c_str()) ? true : false;
	}

	private:
	char * data;
};
		
String operator+(const char * A, const String &B){
	String Ret(A);
	Ret.Append(B);
	return Ret;
}
		
String operator+(const String &A, const String &B){
	String Ret(A);
	Ret.Append(B);
	return Ret;
}
	
  ostream & operator<<(ostream &stream, const String &str){
	if(str.c_str()) stream << str.c_str();
	return stream;
}
	
	
int main(int argc, char *argv[]){
	String s = "ALA " + String("ma ") + "kota";
	cout << s << endl;

	if(s == "ALA ma kota")
		cout << s.toUpper() << endl;
	s = s = "KONIEC PROGRAMU"; // <- sic!

	cout << s.Length() << " " << s << endl;
    system("PAUSE");
    return EXIT_SUCCESS;
}
