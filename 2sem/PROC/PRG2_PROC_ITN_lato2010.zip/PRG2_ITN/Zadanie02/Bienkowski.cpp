#include <iostream>

int fun(int arr[], int size, int* pmn, int& mx)
	{
	int IloscParzystych=0;
	*pmn = mx = arr[0];
	for(int i = 0; i < size; i++)
		{
		if(!(arr[i]%2)) IloscParzystych++;
		if(arr[i] < *pmn) *pmn = arr[i];
		if(arr[i] > mx) mx = arr[i];
		}
	
	bool Zmieniono;
	do
		{
		Zmieniono = false;
		for(int i = 0; i < size-1; i++)
			{
			if(arr[i]%2 == 1 && arr[i+1]%2 == 0)
				{
				int temp = arr[i];
				arr[i] = arr[i+1];
				arr[i+1] = temp;
				Zmieniono = true;
				}
			}
		} while(Zmieniono);
	
	return IloscParzystych;
	}

int main()
	{
	using namespace std;
	int minim, maxim;
	int t[] = {3,1,6,7,4,8,1,7,0};
	int size = sizeof(t)/sizeof(t[0]);
	cout << "Original array: ";
	for (int i = 0; i < size; ++i) cout << t[i] << " ";
	cout << endl;
	int w = fun(t,size,&minim,maxim);
	cout << "Array after fun: ";
	for (int i = 0; i < size; ++i) cout << t[i] << " ";
	cout << endl;
	cout << "minim, maxim = "
	<< minim << ", " << maxim << endl
	<< "first odd at = " << w << endl;
	}
