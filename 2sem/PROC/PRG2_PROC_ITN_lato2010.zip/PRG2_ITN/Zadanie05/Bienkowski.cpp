#include <iostream>

struct Node
	{
	int data;
	Node* next;
	};
	
void addSorted(Node *& head, int data)
	{
	if(head->data > data)
		{
		Node *New = new Node;
		New->data = data;
		New->next = head;
		head = New;
		return;
		}
	Node *Ptr = head;
	do
		{
		if(!Ptr->next || Ptr->next->data >= data)
			{
			Node *New = new Node;
			New->data = data;
			New->next = Ptr->next;
			Ptr->next = New;
			return;
			}
		Ptr = Ptr->next;
		}while(Ptr);
	}
	
Node* arrayToSortedList(const int arr[], int size)
	{
	if(!size) return 0;
	
	Node * First = new Node;
	First->data = arr[0];
	First->next = 0;
	for(int i = 1; i < size; i++) addSorted(First,arr[i]);
	return First;
	}
	
void deleteList(Node*& head)
	{
	while(head)
		{
		Node *Temp = head;
		head = head->next;
		std::cout << "del " << Temp->data << "; ";
		delete Temp;
		}
	std::cout << std::endl;
	}
	
void printList(const Node* head)
	{
	Node *Temp = const_cast<Node*>(head);
	while(Temp)
		{
		std::cout << Temp->data << " ";
		Temp = Temp->next;
		}
	std::cout << std::endl;
	}
	
int main(void)
	{
	int arr[] = {7,4,8,3};
	int size = sizeof(arr)/sizeof(arr[0]);
	
	Node *head = arrayToSortedList(arr, size);
	printList(head);
	
	addSorted(head,6);
	addSorted(head,1);
	addSorted(head,9);
	printList(head);
	
	deleteList(head);	
	return 0;
	}



