#include <iostream>
#include <cstring>

class Person{
protected:
	char *Name;
public:
	friend class Couple;
	friend std::ostream & operator<<(std::ostream &, const Person&);

	explicit Person(const char *);
	Person (const Person &);
	Person& operator=(const Person&);
	~Person();
};

std::ostream& operator<<(std::ostream &stream, const Person &P){
	stream << P.Name;
	return stream;
}

Person::Person(const char *N){
	if(N){
		Name = new char[strlen(N)+1];
		strcpy(Name,N);
	}
	else throw std::string("PATRZ CO WRZUCASZ!");
}

Person::Person(const Person &P){
	Name = 0;
	this->operator=(P);
}

Person& Person::operator=(const Person &P){
	if(this != &P){
		delete Name;
		Name = new char[strlen(P.Name)+1];
		strcpy(Name,P.Name);
	}
	return *this;
}

Person::~Person(){
	delete Name;
}

class Couple{
protected:
	Person *Husband,*Wife;
public:
	friend std::ostream& operator<<(std::ostream&, const Couple&);
	Couple(const Person&, const Person&);
	Couple(const Couple&);
	Couple& operator=(const Couple&);
	~Couple();
};

std::ostream & operator<<(std::ostream &stream, const Couple &C){
	stream << "he " << *C.Husband << ", she " << *C.Wife;
	return stream;
}

Couple::Couple(const Person & H, const Person & W){
	Husband = new Person(H.Name);
	Wife = new Person(W.Name);
}

Couple::Couple(const Couple & C){
	Couple(*C.Husband,*C.Wife);
}

Couple & Couple::operator=(const Couple &C){
	if(this != &C){
		delete Husband;
		delete Wife;
		Husband = new Person(*C.Husband);
		Wife = new Person(*C.Wife);
	}
	return *this;
}

Couple::~Couple(){
	delete Husband;
	delete Wife;
}


int main(){

	int i = 0;
	Person john("John"), jenny("Jenny");
	Couple cpl1(john, jenny);
	Couple *pcpl2 = new Couple(Person("Kevin"),Person("Kathy"));
	Couple cpl3(Person("Bill"),Person("Betty"));
	cpl3 = cpl3;
	*pcpl2 = cpl3;

	std::cout << "John : " << john << std::endl;
	std::cout << "Jenny: " << jenny << std::endl;
	std::cout << *pcpl2 << std::endl;

	delete pcpl2;

	return 0;
}

