#include <iostream>

#define BYTE unsigned char
#define WORD unsigned short
#define DWORD unsigned long

/*
rozklad bitow (big endian):
numer pytania, jego polozenie w zmiennej WORD
1223 3445 5666 6777

*/

WORD koduj(int plec, int stan_cyw, int grupa_wiek, int edu, int zam, int region, int odp)
	{
	if(plec > 1 || plec < 0 || stan_cyw > 3 || stan_cyw < 0 || grupa_wiek > 3 || grupa_wiek < 0 || 
	   edu > 3 || edu < 0 || zam > 3 || zam < 0 || region > 15 || region < 0 || odp > 7 || odp < 0) 
	   {
	   std::cout << "niepoprawne dane wejsciowe" << std::endl;
	   return 0xFFFF;
	   }
	WORD wynik = 0x0000;
	wynik = wynik | (plec << 15);
	wynik = wynik | (stan_cyw << 13);
	wynik = wynik | (grupa_wiek << 11);
	wynik = wynik | (edu << 9);
	wynik = wynik | (zam << 7);
	wynik = wynik | (region << 3);
	wynik = wynik | odp;
	return wynik;
	}
	
	
void info(WORD kod)
	{
	std::cout << "plec:\t\t" << (int)((kod&0x8000)>>15)  << std::endl;
	std::cout << "stan cywilny:\t" << (int)((kod&0x6000)>>13) << std::endl;
	std::cout << "grupa wiekowa:\t" << (int)((kod&0x1800)>>11) << std::endl;
	std::cout << "wyksztalcenie:\t" << (int)((kod&0x0600)>>9) << std::endl;
	std::cout << "miejsce zam.:\t" << (int)((kod&0x0180)>>7) << std::endl;
	std::cout << "region:\t\t" << (int)((kod&0x0078)>>3) << std::endl;
	std::cout << "odpowiedz:\t" << (int)(kod&0x0007) << std::endl;
	}
	
		
	
	
	

int main()
	{
	info(koduj(0,3,2,3,0,12,6));
	return 0;
	}




