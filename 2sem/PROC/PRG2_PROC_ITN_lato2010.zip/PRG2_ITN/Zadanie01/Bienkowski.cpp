#define POL

#if defined(POL) && defined(ENG)
       #error Please define only one language
#elif !(defined(POL) || defined(ENG))
       #error Please define language
#endif

#ifdef POL
       #define txt_01 "Czy to: "
       #define txt_02 "To musi byc: "
#elif defined(ENG)
       #define txt_01 "Is it: "
       #define txt_02 "It has to be: "
#endif

#include <cstdlib>
#include <iostream>
using namespace std;
int main(int argc, char *argv[])
{
    int i=0,liczba=1,min=0, max=1000000+1;
    while (liczba!=0 && i<20 && (max-min)>=2){
          if ((max-min)==2) cout << txt_02 << (min+max)/2 << endl;
          else{
               cout << txt_01 << (min+max)/2 << endl;
               cin >> liczba;
          }
          i++;
          if (liczba==1)  min=(min+max)/2;
          if (liczba==-1) max=(min+max)/2;
    }
    system("PAUSE");
    return EXIT_SUCCESS;
}
