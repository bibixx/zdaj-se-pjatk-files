#include <iostream>
#include <string>
#include <sstream>

enum Banks {PKO,BGZ,BRE,BPH};

struct Account {
	Banks bank;
	int balance;
};

struct Person {
	char name[20];
	Account account;
};

struct Couple {
	Person he;
	Person she;
};

int SumOfCouple(Couple &c, Banks bank)
	{
#if 0
	return (c.he.account.bank == bank ? c.he.account.balance : 0) + (c.she.account.bank == bank ? c.she.account.balance : 0);
#else
	return c.he.account.balance + c.she.account.balance;
#endif
	}

Couple *bestClient(Couple *cpls, int size, Banks bank)
	{
	Couple *Ret = 0;
	
	for(int i = 0; i < size; i++)
		{
		if(cpls[i].he.account.bank == bank || cpls[i].she.account.bank == bank)
			{
			if(!Ret) Ret = cpls+i;
			else if(SumOfCouple(*Ret,bank) < SumOfCouple(cpls[i],bank)) Ret = cpls+i;
			}
		}
	return Ret;
	}

std::string CoupleString(Couple &c, Banks bank)
	{
	std::stringstream Ret;
	Ret << c.he.name << " and " << c.she.name << ": " << SumOfCouple(c,bank);
	std::string RetS = Ret.str();
	return RetS;
	}
	
int main(void)
	{
    Couple cpls[] = {
					{ { "Johny", {PKO, 1100} }, {"Mary", {BGZ, 1500} } },
					{ { "Peter", {BGZ, 1400} }, {"Suzy", {BRE, 1300} } },
					{ { "Kevin", {PKO, 1600} }, {"Katy", {BPH, 1500} } },
					{ { "Kenny", {BPH, 1800} }, {"Lucy", {BRE, 1700} } }
					};
					
	
	std::cout << CoupleString(*bestClient(cpls,sizeof(cpls)/sizeof(Couple),BGZ),BGZ) << std::endl;
	return 0;
	}




