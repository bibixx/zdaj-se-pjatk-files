//#define M_PI 3.14159265358979323846
#define  Alfa  30.0*(M_PI/180.0)
#define HH 15.0
