/*************************************************************************
 *                                                                       *
 *                    IX Olimpiada Informatyczna                         *
 *                                                                       *
 *   Rozwi�zanie zadania: Minusy                                         *
 *   Plik:                min.cpp                                        *
 *   Autor:               Jaros�aw Byrka                                 *
 *************************************************************************/
#include<iostream.h>
#include<fstream.h>

int n;
char last,next;

int main()
{
	ifstream cin("min.in");
	ofstream cout("min.out");

  cin >> n;
  cin >> last;
  if (last=='+') return 1;
  cout << last;
  for (int i=1; i<n-1; i++)
    {
      cin >> next;
      if (last != next)
       {
        if (last=='-')
          cout << '(';
        else
          cout << ')';
       }
      cout << '-';
      last = next;
    }
  if (last=='+')
    cout << ')';
  cout << endl;
  return 0;
}
