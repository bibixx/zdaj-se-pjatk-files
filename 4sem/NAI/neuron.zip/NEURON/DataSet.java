
import java.util.*;

public
class DataSet {

	private Set[] datasets;
    
    DataSet(int datagroups) 
    {
    	datasets = new Set [datagroups];
    }
    
    public void addData(int datagroup, float[] sample) 
    {
    	datasets[datagroup].add(sample);
    }

}