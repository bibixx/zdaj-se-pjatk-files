
public
class Nauczyciel {
	
	Siec siec;
	Dane dane;
	float stalaUczaca;
	
	public Nauczyciel(Siec siec, float stala){
		
		this.siec = siec;
		stalaUczaca = stala;
	}	
	
	
	void ucz() {
		
		Set data = dane.getEntrySet();
		Iterator it = data.iterator();
		
		while (it.hasNext()) {
		
			dane.next();
			
			siec.odpal();
			float[] wyniki = siec.out();
			
			if (!Array.equals(data, wyniki))
				
			
		}
		
	}
	
}