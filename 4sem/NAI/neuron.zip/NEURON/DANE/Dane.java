
import java.util.*;

public 
class Dane {
	
	HashMap hm;
	int inlen;
	int outlen;
		
	public Dane (int inlen, int outlen) {
		
		this.inlen = inlen;
		this.outlen = outlen;
		
	} 
	
	void add (float[] wej, float[] wyj) {
		
		if (wej.length == inlen && wyj.length == outlen) 
			hm.put(wej, wyj);
		else 	
			System.out.println("Niew�a�ciwy wymiar wektora wej�ciowego lub wyj�ciowego!");
	} 
	
	Set getEntrySet() 
	{
		return hm.entrySet();	
	}
	
}