
package neuralnetwork;

public
class NeuralNetwork {

	Layer[] layers;
    
    public NeuralNetwork(int input_no, int[] neuron_no) 
    {
 		layers = new Layer [neuron_no.length];
        layers[0] = new Layer(neuron_no[0], input_no);
        
        for (int i = 1; i < neuron_no.length ; i++) {
        	layers[i] = new Layer(neuron_no[i], neuron_no[i - 1]);
        	layers[i].connect(layers[i - 1].getOutputs());
        }
               
        layers[0].createInputs(input_no);
    }
    
    public void fire() 
    {
    	for (int i = 0 ; i < layers.length ; i++)
        	layers[i].fire();
    }
    
    public void learn(float learnRate, float[] d) 
    {
    	Connection[] out = layers[layers.length - 1].getOutputs();
        
        for (int i = 0 ; i < out.length; i++) {	// obliczenie bledow warstwy wyjsciowej
        	Neuron n = layers[layers.length - 1].getNeuron(i);
            n.setErr(out[i].getValue() - d[i]);
        }
        
        for (int i = layers.length - 2 ; i >= 0 ; i--) // obliczenie bledow reszty neuronow
        	for (int j = 0 ; j < layers[i].getSize() ; j++) {
            	float errsum = 0;
            	for (int k = 0 ; k < layers[i + 1].getSize() ; k++) {
        			Neuron n = layers[i + 1].getNeuron(k);
                    errsum += n.getErr()*n.getW(j);
                }
                layers[i].getNeuron(j).setErr(errsum);
        	}
        
        for (int i = layers.length - 1 ; i >= 0 ; i--)
        	layers[i].changeW(learnRate);
            
    }
    
    public void setInputs(float[] data) 
    {
    	layers[0].setInputs(data);
    }
    
    public float[] getResults() 
    {
    	Connection[] out = layers[layers.length - 1].getOutputs();
        
        float[] results = new float [out.length];
        for (int i = 0 ; i < out.length ; i++)
        	results[i] = out[i].getValue();
        
        return results;    
    }
	
}