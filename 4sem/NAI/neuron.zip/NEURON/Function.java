package neuralnetwork;

interface Function {
	
    public float funVal(float x);
    public float diffVal(float x);
    
}