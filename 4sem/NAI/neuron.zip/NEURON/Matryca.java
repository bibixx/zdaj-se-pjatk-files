
package neuralnetwork;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public
class Matryca 
	extends JFrame {

	private Container contentPane;
    private Field fields[][];
    private int cur_x;
    private int cur_y;
    private Field selectedfield;
    private JButton trainbtn = new JButton ("Trenuj sie�");
    private JButton recogbtn = new JButton ("Rozpoznawaj");
    private JButton clearbtn = new JButton("Wyczy��");
    private Watcher watcher = new Watcher();
    private NeuralNetwork cr;
    private float[][] wzorce;
    
    final int fieldsize = 20;
        
    public static void main(String[] args) 
    {
    	new Matryca();
        
    }
    float[] setArray(int number) 
    {
    	float[] array = new float [2];
        array[number] = 1f;
        return array;
    }
    
    public Matryca() {
    	
        wzorce = new float [2][128];
        cr = new NeuralNetwork(128, new int[] { 2, 8, 8, 2 });
                
        fields = new Field [16][8];
        
        setTitle("Matryca - wprowadzanie wzorc�w");
        setResizable(false);
        setLocation(100, 100);
        setSize(300, 500);
        contentPane = new ContentPane();
        contentPane.setLocation(20, 20);
        setContentPane(contentPane);
        
        addWindowListener( 
        	new WindowAdapter() {
            
            	public void windowClosing(WindowEvent evt) 
                {
                	System.exit(0);
            	}
            
        	}
            
        );
        
        addMouseMotionListener(watcher);
        addMouseListener(watcher);
        
        SwingUtilities.invokeLater (
        	new Runnable() {
            
            	public void run() {
          	    
                	contentPane.requestFocus();
                    show();
                                    
            	}    
            
        	}
        
    	);    
	}

	class Field  {
    	
        private int x;
        private int y;
        private int size;
        private boolean marked;
        
        public Field(int x, int y, int size) {
        	
            this.x = x;
            this.y = y;
            this.size = size;
            marked = false;
        }
        
        boolean isInside (int x1 , int y1) 
        {
        	y1 -= 20;	// konieczne do prawid�owego wy�wietlania - rozmiar 
            			// paska z nazw� okna
                        
            if ((x1 > x && x1 < x + size) && (y1 > y && y1 < y + size))
            	return true;
            else
            	return false;    
        }
        
        void Mark() {
        	marked = true;
        }
        
        void unMark()  {
           	marked = false;
        }
        
        boolean isMarked() {
        	return marked;
        }
        
        void draw(Graphics DC, boolean cursor_over) 
        {
        	if (cursor_over) {
            	if (marked == false)
	                DC.setColor(Color.red);
                else
                	DC.setColor(Color.gray);    
	            
                DC.fillRect(x + 1, y + 1, size - 1, size - 1);
            	
        	}
            else  {
            	if (marked == true)
                	DC.setColor(Color.black);
                else
                    DC.setColor(Color.lightGray);
                    
                DC.fillRect(x, y, size, size);
                DC.setColor(Color.black);
                DC.drawRect(x, y, size, size);
            }
        }
    
	}
	
    class ContentPane
    	extends JPanel {
        
        public ContentPane() 
        {
        	setLayout(null);
            
            for (int i = 0 ; i < fields.length ; i++)
                for (int j = 0 ; j < fields[i].length ; j++)
                	fields[i][j] = new Field(j*fieldsize + 50, i*fieldsize + 50, fieldsize);
        
        	trainbtn.setLocation(10, 380);
            trainbtn.setSize(120, 40);
            
            clearbtn.setLocation(150, 380);
            clearbtn.setSize(120, 40);
            
            recogbtn.setLocation(20, 425);
            recogbtn.setSize(250, 40);
            
            add(trainbtn);
            add(clearbtn);
            add(recogbtn);
            
            trainbtn.addMouseListener(watcher);
            clearbtn.addMouseListener(watcher);
            recogbtn.addMouseListener(watcher);
                        
        }
        
    	public void paintComponent(Graphics gDC) 
        {
        	super.paintComponent(gDC);
            
            selectedfield = null;
            
            for (int i = 0 ; i < fields.length ; i++)
                for (int j = 0 ; j < fields[i].length ; j++) {
                	if (fields[i][j].isInside(cur_x, cur_y)) {
                    	fields[i][j].draw(gDC, true);
                		selectedfield = fields[i][j];
                    }
                    else    
                    	fields[i][j].draw(gDC, false);
                
                }
                	 
    	}
    }


	class Watcher
    	extends MouseInputAdapter {
        
    		public void mouseMoved(MouseEvent evt) 
            {
                cur_x = evt.getX();
                cur_y = evt.getY();
                repaint();                
            }
            
            public void mousePressed(MouseEvent evt) 
            {
            	Object src = evt.getSource();
                
                if (src == trainbtn) {
                	
                    float[] data = new float [128];
                    String exp_val = JOptionPane.showInputDialog(null, "Podaj cyfr�:");
                    int cyfra = Integer.parseInt(exp_val);
                                        
                    for (int i = 0 ; i < fields.length ; i++) 
                		for (int j = 0 ; j < fields[i].length ; j++)
                        	if (fields[i][j].isMarked())
                            	data[i*8 + j] = 1f;
                            else
                            	data[i*8 + j] = 0f;  
                                
                    if (cyfra == 0)
                    	System.arraycopy(data, 0, wzorce[0], 0, 128);
                    else if (cyfra == 1)
                    	System.arraycopy(data, 0, wzorce[1], 0, 128);
                    else if (cyfra == -1) {
                    
                    	for (int i = 0 ; i < 20000 ; i++) {
                        	float d1[] = setArray(0);
                            cr.setInputs(wzorce[0]);
                            cr.fire();
                            cr.learn(0.2f, d1);
                            float d2[] = setArray(1);
                            cr.setInputs(wzorce[1]);
                            cr.fire();
                            cr.learn(0.2f, d2);
                            System.out.println(i);
                           
                    	}
                    }
                        
                	
                }    
                		
                            
                if (src == recogbtn) {
                	float[] data = new float [128];
                    
                    for (int i = 0 ; i < fields.length ; i++) 
                		for (int j = 0 ; j < fields[i].length ; j++)
                        	if (fields[i][j].isMarked())
                            	data[i*8 + j] = 1f;
                            else
                            	data[i*8 + j] = 0f;
                    
                    
                    cr.setInputs(data);
                    cr.fire();
                    float[] out = cr.getResults();
                
                	for (int i = 0 ; i < out.length ; i++)
                    	System.out.println("WYNIK " + i + ":" + out[i]);
                }
                
                if (src == clearbtn)
                	for (int i = 0 ; i < fields.length ; i++)
                		for (int j = 0 ; j < fields[i].length ; j++)
                        	fields[i][j].unMark();
                
                if (selectedfield != null)
                	if (!evt.isMetaDown())  {
                		selectedfield.Mark();
            		}
                	else 
                    	selectedfield.unMark();   
                
                repaint();    
            }
            
            public void mouseDragged(MouseEvent evt) 
            {
            	cur_x = evt.getX();
                cur_y = evt.getY();
                
                if (selectedfield != null)
                	if (!evt.isMetaDown())  {
                		selectedfield.Mark();
            		}
                	else 
                    	selectedfield.unMark();   
                
                repaint();    
                
            }
                                         
    }

}