
package neuralnetwork;

public
class SquareFun 
	implements Function {

	float threshold;
    
    SquareFun(float threshold) 
    {
    	this.threshold = threshold;
    }
    
    public float funVal(float sum) {
    	if (sum >= threshold)
        	return 1;
        else
        	return 0;    
    }
    
    public float diffVal(float sum)  {
    
    	return Float.NaN;
    }
	
}