
package neuralnetwork;

public
class Neuron {


	private Connection[] inputs; 
	private Connection output;
	private float[] weights;
	private Function func;
    private float sum = 0;
    private float error = 0;
  
	public Neuron(int inp) 
    {	 
    	inputs = new Connection [inp];
        weights = new float [inp];
        
        for (int i = 0; i < inp ; i++) 
        	weights[i] = (float)Math.random();
    	
        func = new SigmFun(SigmFun.UNIPOLAR, 1); 
        output = new Connection();
    }


	public Neuron(Function functype, float[] weights)
    {
    	int len = weights.length;
        
        inputs = new Connection [len];
        this.weights = new float [len];
        
        for (int i = 0 ; i < len ; i++)
        	this.weights[i] = weights[i];
        
        func = functype;
        
        output = new Connection();
    }
    

	public void fire()
	{
    	sum = 0;
        
        for (int i = 0; i < weights.length ; i++)
           	sum += inputs[i].getValue() * weights[i];
    
    	output.setValue(func.funVal(sum));
    }
    
    public void connect(Connection input, int inputno)
    {
    	try {
        	inputs[inputno] = input;
    	}
        
        catch (NullPointerException e) 
        {
        	System.out.println("You fucked it up, moron!");
        }
    }
    
    public void setErr(float err) 
    {
    	error = err * func.diffVal(sum);
    }
    
    public float getErr() 
    {
    	return error;
    }
    
    public float getW(int i) 
    {
    	return weights[i];
    }
    
    public void changeW(float learnRate) 
    {   
        for (int i = 0 ; i < weights.length ; i++)
        	weights[i] -= learnRate*error*inputs[i].getValue();
    }
    public Connection getOutput()
    {
    	return output;
    }
    
    public void setFType(Function f) 
    {
		func = f;    
    }
    
}