
package neuralnetwork;

import java.util.*;
import java.io.*;

public
class DataSet 
	implements Serializable {

	private HashSet[] datasets;
    
    DataSet(int datagroups) 
    {
    	datasets = new HashSet [datagroups];
        
        for (int i = 0 ; i < datagroups ; i++)
        	datasets[i] = new HashSet(1);
    }
    
    public void addData(int datagroup, float[] sample) 
    {
    	datasets[datagroup].add(sample);
    }
    
    public float[] getData(int datagroup, int index) 
    {
    	Iterator it = datasets[datagroup].iterator();
        Object o = null;
        for (int i = 0 ; i <= index ; i++)
        	o = it.next();
        
        float[] data = (float [])o;
        return data;       
    }
    
    public int getGroups() {
    	return datasets.length;
	}
    
    public int getGroupSize(int datagroup) 
    {
    	return datasets[datagroup].size();
    }
    
    public static float[] setArray(int number, int length) 
    {
    	float[] array = new float [length];
        array[number] = 1f;
        return array;
    }
    
    public void writeSet(String filename) {
    	
        ObjectOutputStream out = null;
        
        try {
	    	out = new ObjectOutputStream (new FileOutputStream(filename));
        }
        catch (IOException e) { }
        
        try {
        	out.writeObject(this);
        	out.close();
        }
        catch (IOException e) {}
           
    }
    
    public static DataSet loadSet(String filename) 
    {
        ObjectInputStream in = null;
        Object data = null;
        
        try {
	    	in = new ObjectInputStream (new FileInputStream(filename));
        }
        catch (IOException e) { }
        
        try {
        	data = in.readObject();
        	in.close();
        }
        catch (Exception e) {}
        
        return (DataSet)data;
        
    }
    
}

