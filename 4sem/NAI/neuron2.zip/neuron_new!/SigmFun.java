
package neuralnetwork;

public
class SigmFun 
	implements Function {

	private float beta;
    private int functype;
    
    public static int UNIPOLAR = 0;
    public static int BIPOLAR = 1;
    
    SigmFun(int ftype, float beta) 
    {
    	this.beta = beta;
        functype = ftype;
    }
    
    public float getBeta() 
    {
    	return beta;
    }
    
    public float getFType() 
    {
    	return functype;
    }
    
    public float funVal(float x) {
    	
        if (functype == UNIPOLAR)
        	return (float)(1/(1 + Math.exp(-beta*x)));	// 1/(1 + e(-Bx))
        else if (functype == BIPOLAR)
        return	// tangens hiperboliczny 
        	(float)((Math.exp(beta*x)-Math.exp(-beta*x))/(Math.exp(beta*x)+Math.exp(-beta*x)));
        
        else return Float.NaN;
    
	}
    
    public float diffVal(float x) {
    	if (functype == UNIPOLAR)
        	return (float)(beta*funVal(x)*(1 - funVal(x)));
        else
        	return (float)(1 - Math.pow(funVal(x), 2));    
    
    }


}