
package neuralnetwork;

public
class Neuron {


	private Connection[] inputs; 
	private Connection output;
	private float[] weights;
	private Function func;
    private float sum = 0;
    private float error = 0;
    private float prog;
	
    /** Tworzy Neuron o "inp" wej�ciach
    *	Wagi s� dobierane losowo
    *
    */
    public Neuron(int inp) 
    {	 
    	inputs = new Connection [inp];
        weights = new float [inp];
        
        for (int i = 0; i < inp ; i++) 
        	weights[i] = (float)Math.random();
        
        prog = (float)Math.random();    
    	
        func = new SigmFun(SigmFun.UNIPOLAR, 1); 
        output = new Connection();
    }

	/** Tworzy neuron o funkcji aktywacji okre�lonej przez "functype"
    *	Ilo�� wej�� neuronu jest r�wna d�ugo�ci tablicy wag
    */
    public Neuron(Function functype, float[] weights)
    {
    	int len = weights.length;
        
        inputs = new Connection [len];
        this.weights = new float [len];
        
        for (int i = 0 ; i < len ; i++)
        	this.weights[i] = weights[i];
        
        func = functype;
        
        output = new Connection();
    }

	public void fire()
	{
    	sum = 0;
        
        for (int i = 0; i < weights.length ; i++)
           	sum += inputs[i].getValue() * weights[i];
    
        output.setValue(func.funVal(sum - prog));
    }
    
    public void connect(Connection input, int inputno)
    {
    	try {
        	inputs[inputno] = input;
    	}
        
        catch (NullPointerException e) 
        {
        	System.out.println("You fucked it up, moron!");
        }
    }
    
    public void setErr(float err)  
    {
    	error = err * func.diffVal(sum - prog);
    }
    
    public float getErr() 
    {
    	return error;
    }
    
    public float getW(int i) 
    {
    	return weights[i];
    }
    
    public void changeW(float learnRate) 
    {   
        for (int i = 0 ; i < weights.length ; i++)
        	weights[i] -= learnRate*error*inputs[i].getValue();
        
        	prog -= learnRate*error;  
    }
    public Connection getOutput()
    {
    	return output;
    }
    
    public void setFType(Function f) 
    {
		func = f;    
    }
    
}