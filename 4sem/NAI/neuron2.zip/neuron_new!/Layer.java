
package neuralnetwork;

public
class Layer {

	private Neuron[] neurons;
    private Connection[] inputs;
    private Connection[] outputs;

	public Layer (int neuron_no, int input_no) {
    
    	neurons = new Neuron [neuron_no];
        
        for (int i = 0; i < neuron_no ; i++) {
        	neurons[i] = new Neuron(input_no);
            neurons[i].setFType(new SigmFun(SigmFun.UNIPOLAR, 1f));
        }
        
        outputs = new Connection [neuron_no];
        for (int k = 0 ; k < neuron_no ; k++)
        	outputs[k] = neurons[k].getOutput();
    }
    
    public Layer (int neuron_no, int input_no, Connection[] conns) 
    {
    	this(neuron_no, input_no);
        
        for (int i = 0; i < neuron_no ; i++)
        	for (int j = 0 ; j < conns.length ; j++)
            	neurons[i].connect(conns[j], j); 
    }
    
    public Connection[] getOutputs() 
    {
    	return outputs;
    }
    
    public Neuron getNeuron(int i) 
    {
    	return neurons[i];    
    }
    
    public void fire() {
        for (int i = 0 ; i < neurons.length ; i++)
        	neurons[i].fire();
    }
    
    public void connect(Connection[] conns) 
    {
		for (int i = 0; i < neurons.length ; i++)
        	for (int j = 0 ; j < conns.length ; j++)
            	neurons[i].connect(conns[j], j); 
    }
    
    public void changeW(float learnRate) 
    {
    	for(int i = 0 ; i < neurons.length ; i++)
        	neurons[i].changeW(learnRate);
    }
    public void createInputs(int input_no) 
    {
    	
        inputs = new Connection [input_no];
        
        for (int k = 0; k < input_no ; k++)
        	inputs[k] = new Connection();
            
        for (int i = 0 ; i < neurons.length ; i++)
        	for (int j = 0 ; j < input_no ; j++)
          		neurons[i].connect(inputs[j], j); // kazdy z kazdym
    }
    
    
    public void setInputs(float[] data) 
    {
    	for(int i = 0 ; i < inputs.length; i++)
           	inputs[i].setValue(data[i]);
    }
    
    public int getSize() 
    {
    	return neurons.length;
    }
    
}