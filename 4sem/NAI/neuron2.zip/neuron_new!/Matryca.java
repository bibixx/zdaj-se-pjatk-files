
package neuralnetwork;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public
class Matryca 
	extends JFrame {
	
	private Container contentPane;
    private Field fields[][];
    private int cur_x;
    private int cur_y;
    private Field selectedfield;
 
    private JButton databtn = new JButton ("Zapisz wzorzec");
    private JButton trainbtn = new JButton ("Trenuj sie�");
    private JButton recogbtn = new JButton ("Rozpoznawaj");
    private JButton datareport = new JButton ("Raport");
    private JButton clearbtn = new JButton("Wyczy��");
    private JButton loaddata = new JButton("�aduj wzorce");
    private JButton savedata = new JButton("Zachowaj wzorce");
    
    private Watcher watcher = new Watcher();
 
    private NeuralNetwork cr;
    private DataSet dataset;
    
    private final int fieldsize = 20;
    private final int ILE_CYFR = 10;
    private final float ERR_MAX = 0.05f;
       
    public static void main(String[] args) 
    {
    	new Matryca();
    }
      
    /** Konstruktor matrycy
     *
     *
     */
    
    public Matryca() {
    	
        dataset = new DataSet(ILE_CYFR);
        
        cr = new NeuralNetwork(128, new int[] { 10, 20, dataset.getGroups() });
                
        fields = new Field [16][8];
        
        setTitle("Matryca - wprowadzanie wzorc�w");
        setResizable(false);
        setLocation(100, 100);
        setSize(450, 600);
        contentPane = new ContentPane();
        //contentPane.setLocation(...
        setContentPane(contentPane);
        
        addWindowListener( 
        	new WindowAdapter() {
            
            	public void windowClosing(WindowEvent evt) 
                {
                	System.exit(0);
            	}
            
        	}
            
        );
        
        addMouseMotionListener(watcher);
        addMouseListener(watcher);
        
        SwingUtilities.invokeLater (
        	new Runnable() {
            
            	public void run() {
          	    
                	contentPane.requestFocus();
                    show();
                                    
            	}    
            
        	}
        
    	);    
	}

	class Field  {
    	
        private int x;
        private int y;
        private int size;
        private boolean marked;
        
        public Field(int x, int y, int size) {
        	
            this.x = x;
            this.y = y;
            this.size = size;
            marked = false;
        }
        
        boolean isInside (int x1 , int y1) 
        {
        	y1 -= 20;	// konieczne do prawid�owego wy�wietlania - rozmiar 
            			// paska z nazw� okna
                        
            if ((x1 > x && x1 < x + size) && (y1 > y && y1 < y + size))
            	return true;
            else
            	return false;    
        }
        
        void Mark() {
        	marked = true;
        }
        
        void unMark()  {
           	marked = false;
        }
        
        boolean isMarked() {
        	return marked;
        }
        
        void draw(Graphics DC, boolean cursor_over) 
        {
        	if (cursor_over) {
            	if (marked == false)
	                DC.setColor(Color.red);
                else
                	DC.setColor(Color.gray);    
	            
                DC.fillRect(x + 1, y + 1, size - 1, size - 1);
            	
        	}
            else  {
            	if (marked == true)
                	DC.setColor(Color.black);
                else
                    DC.setColor(Color.lightGray);
                    
                DC.fillRect(x, y, size, size);
                DC.setColor(Color.black);
                DC.drawRect(x, y, size, size);
            }
        }
    
	}
	
    class ContentPane
    	extends JPanel {
        
        public ContentPane() 
        {
        	setLayout(null);
            
            for (int i = 0 ; i < fields.length ; i++)
                for (int j = 0 ; j < fields[i].length ; j++)
                	fields[i][j] = new Field(j*fieldsize + 50, i*fieldsize + 50, fieldsize);
        
        	databtn.setLocation(10, 380);
            databtn.setSize(140, 40);
            
            clearbtn.setLocation(150, 380);
            clearbtn.setSize(120, 40);
            
            trainbtn.setLocation(20, 425);
            trainbtn.setSize(250, 40);
            
            recogbtn.setLocation(20, 470);
            recogbtn.setSize(250, 40);
            
            datareport.setLocation(230, 200);
            datareport.setSize(200, 40);
            
            loaddata.setLocation(230, 260);
            loaddata.setSize(200, 30);
            
            savedata.setLocation(230, 300);
            savedata.setSize(200, 30);
                        
            add(databtn);
            add(clearbtn);
            add(trainbtn);
            add(recogbtn);
            add(datareport);
            add(loaddata);
            add(savedata);
            
            databtn.addMouseListener(watcher);
            clearbtn.addMouseListener(watcher);
            recogbtn.addMouseListener(watcher);
            trainbtn.addMouseListener(watcher);
            datareport.addMouseListener(watcher);
            loaddata.addMouseListener(watcher);
            savedata.addMouseListener(watcher);
	    }
        
    	public void paintComponent(Graphics gDC) 
        {
        	super.paintComponent(gDC);
            
            selectedfield = null;
            
            for (int i = 0 ; i < fields.length ; i++)
                for (int j = 0 ; j < fields[i].length ; j++) {
                	if (selectedfield == null && fields[i][j].isInside(cur_x, cur_y)) {
                    	fields[i][j].draw(gDC, true);
                		selectedfield = fields[i][j];
                    }
                	else    
                    	fields[i][j].draw(gDC, false);
                }
                
            gDC.setColor(Color.black);
                            	 
    	}
    }


	class Watcher
    	extends MouseInputAdapter {
        
    		public void mouseMoved(MouseEvent evt) 
            {
                cur_x = evt.getX();
                cur_y = evt.getY();
                repaint();                
            }
            
            public void mousePressed(MouseEvent evt) 
            {
            	Object src = evt.getSource();
                
                if (src == databtn) {
                	
                    float[] data = new float [fields.length * fields[0].length]; // 128 p�l
                    String exp_val = JOptionPane.showInputDialog(null, "Podaj cyfr�:");
                    int cyfra = Integer.parseInt(exp_val);
                                        
                    for (int i = 0 ; i < fields.length ; i++) 
                		for (int j = 0 ; j < fields[i].length ; j++)
                        	if (fields[i][j].isMarked())
                            	data[i*8 + j] = 1f;
                            else
                            	data[i*8 + j] = -0.5f; 
  						                	
                    dataset.addData(cyfra, data);
                }    
                            
                if (src == trainbtn) {
                	
                    float error = 0f;
                	float learnRate = 0.2f;
                    
                    do {
	                    error = cr.networkError(dataset);
                                                                       	                        	                       
                        int group = (int)(Math.random()*dataset.getGroups());
	                    
	                    cr.setInputs(dataset.getData(group, 0));
	                    cr.fire();
                        cr.learn(learnRate, DataSet.setArray(group, dataset.getGroups()));
                        System.out.println(error);
                    }
                    while (error > ERR_MAX);
                    
                    System.out.println("LEARNING FINISHED!");
                }
                
                if (src == recogbtn) {
                	float[] data = new float [fields.length * fields[0].length];
                    
                    for (int i = 0 ; i < fields.length ; i++) 
                		for (int j = 0 ; j < fields[i].length ; j++)
                        	if (fields[i][j].isMarked())
                            	data[i*8 + j] = 1f;
                            else
                            	data[i*8 + j] = -0.5f;
                    
                    
                    cr.setInputs(data);
                    cr.fire();
                    float[] out = cr.getResults();
                
                	for (int i = 0 ; i < out.length ; i++)
                    	System.out.println("WYNIK " + i + ":" + out[i]);
                }
                if (src == datareport) {
                	String report = "Informacje o danych:\n====================\n\n";
                    
                    for (int i = 0 ; i < dataset.getGroups() ; i++)
                    	report += "Klasa " + i + "    wzorc�w: " + dataset.getGroupSize(i) + "\n";
                
                	JOptionPane.showMessageDialog(null, report,
                    	"Raport", JOptionPane.INFORMATION_MESSAGE);
                
                }
                
                if (src == clearbtn)
                	for (int i = 0 ; i < fields.length ; i++)
                		for (int j = 0 ; j < fields[i].length ; j++)
                        	fields[i][j].unMark();
                        
                if (src == loaddata) {
                	String filename = JOptionPane.showInputDialog(null, "Podaj nazw� pliku:");
                    dataset = DataSet.loadSet(filename);
                }
                
                if (src == savedata) {
                	String filename = JOptionPane.showInputDialog(null, "Podaj nazw� pliku:");
                    dataset.writeSet(filename);
                }
                
                if (selectedfield != null)
                	if (!evt.isMetaDown())  {
                		selectedfield.Mark();
            		}
                	else 
                    	selectedfield.unMark();   
                
                repaint();    
            }
            
            public void mouseDragged(MouseEvent evt) 
            {
            	cur_x = evt.getX();
                cur_y = evt.getY();
                
                if (selectedfield != null)
                	if (!evt.isMetaDown())  {
                		selectedfield.Mark();
            		}
                	else 
                    	selectedfield.unMark();   
                
                repaint();    
                
            }
                                         
    }

}