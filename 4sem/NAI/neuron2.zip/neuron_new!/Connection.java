package neuralnetwork;

public
class Connection {

	private float value;
    
    Connection() 
    {
    	value = 0;
    }

    Connection(float val) 
    {
    	value = val;
    }

	float getValue() 
    {
    	return value;
	}

	void setValue(float val) 
    {
    	value = val;
    }
}



