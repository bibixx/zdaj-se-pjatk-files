public class TicTacToeMove extends Move {
  public int moveIndex;
}
