abstract public class Move {
}
