Thank you for downloading the new version 4 of the NLBean.

This version is released under an Open Source license agreement
and is free for private and commercial use.

Peter Hearty kindly gave me permission to include the compiled
version of his VERY COOL pure Java database program InstantDB.

Please note that InstantDB is only free for non-commercial
use!  Peter charges a very reasonable fee for commercial
use of InstantDB.  Please visit his web site at
http://instantdb.enhydra.org/ for details.  Thanks Peter!
(The directories 'jdbc' and 'db' contain Peter's compiled
code and the directory 'database' contains a small test
database created with the nlbean.MakeTestDB program.)

The source code and compiled files for the NLBean are in
the directory 'nlbean'.

Some of you may have noticed a large jump in version number.
Version 4 is a major cleanup of the NLBean: it needed it!
(I had originally written the NLBean quite quickly for my own
use, and the old source code was very ugly.) Anyway, I had a
lot of experimental code in teh NLBean, which I have removed.

There is still some more cleanup work to be done on the
source code, so look for a future update with a small
version number change.

To run the NLBean, use the run.bat file.  There are several
example queries in a selection list.  If you are typing
a query and the word that you just typed changes to all
uppercase characters, that means that the NLBean does not
understand that word; click the mouse on the upper case word
to get a popup window with suggested alternative words.

The c.bat command file can be used to re-compile everything,
but I included compiled class files so you will not have to
do this until you edit the source.

The NLBean is packaged up as a demo.  The file nlbean.NLBean.java
contains a hardwired database, usename, and password.  In a future
version, I will use a small config file to change the database setup
so that you don't have to edit the code to use another database system.

Enjoy!

-Mark Watson   www.markwatson.com
