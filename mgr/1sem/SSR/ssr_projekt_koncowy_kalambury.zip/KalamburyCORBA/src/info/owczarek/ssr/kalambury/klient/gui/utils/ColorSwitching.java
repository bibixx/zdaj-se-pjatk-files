package info.owczarek.ssr.kalambury.klient.gui.utils;

public interface ColorSwitching {
	public void setColour(int rgb);
}
