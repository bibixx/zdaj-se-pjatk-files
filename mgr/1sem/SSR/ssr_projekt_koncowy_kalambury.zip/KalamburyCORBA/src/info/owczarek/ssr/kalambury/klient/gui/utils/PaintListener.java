package info.owczarek.ssr.kalambury.klient.gui.utils;

public interface PaintListener {
	public void aReceiveMouseTrack(MouseTrack mt);
}
