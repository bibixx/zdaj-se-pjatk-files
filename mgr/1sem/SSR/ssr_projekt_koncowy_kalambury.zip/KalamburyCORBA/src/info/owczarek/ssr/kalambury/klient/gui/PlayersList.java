package info.owczarek.ssr.kalambury.klient.gui;

import java.util.*;
import org.apache.logging.log4j.*;
import javax.swing.*;

public class PlayersList extends JList<Score> {
	private DefaultListModel<Score> lmUzytkownicy;
	private List<Score> users;
	private Logger logger = LogManager.getLogger("PlayersList");

	public PlayersList() {
		createElements();
		deployElements();
	}

	private void createElements() {
		lmUzytkownicy = new DefaultListModel<Score>();
		users = new ArrayList(10);
		Score prototype = new Score("Jan z Warszawy");
		prototype.addPoint();
		setPrototypeCellValue(prototype);
	}

	private void deployElements() {
		setModel(lmUzytkownicy);
	}

	public void newUser(String userName) {
		Score s = new Score(userName);
		lmUzytkownicy.addElement(s);
		users.add(s);
		logger.debug("User {} added", userName);
	}

	public void removeUser(String userName) {
		Score s = new Score(userName);
		lmUzytkownicy.removeElement(s);
		users.remove(s);
		logger.debug("User {} removed", userName);
	}

	public int getNumberOfPlayers() {
		return users.size();
	}

	public void addPoint(String userName) {
		logger.debug("Adding point for user {}", userName);
		for (Score s: users) {
			if (s.getPlayerName().equals(userName)) {
				s.addPoint();
				this.repaint();
				logger.info("Adding point for user {}", userName);
			}
		}
	}
}

 class Score {
	private String playerName;
	private int points;
	
	public Score(String playerName) {
		this.playerName = playerName;
		points = 0;
	}

	public String getPlayerName() {
		return playerName;
	}

	public int getPoints() {
		return points;
	}

	public void addPoint() {
		
		points++;
	}
	
	@Override
	public String toString() {
		return getPlayerName() + ": " + getPoints();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Score other = (Score) obj;
		if (playerName == null) {
			if (other.playerName != null)
				return false;
		} else if (!playerName.equals(other.playerName))
			return false;
		return true;
	}
}