package info.owczarek.corbachat.klient;

public class KlientImpl extends chat.KlientPOA {
	private Kontroler kontroler;
	
	public KlientImpl(Kontroler k) {
		this.kontroler = k;
	}
	
	@Override
	public void otrzymajWiadomosc(String nazwaUzytkownika, String wiadomosc) {
		System.out.println("Otrzymano wiadomość:\n\t" + nazwaUzytkownika + ": " + wiadomosc);
		kontroler.nowaWiadomosc(nazwaUzytkownika, wiadomosc);
	}

	@Override
	public void powiadomONowymUzytkowniku(String nowyKlient) {
		System.out.println("Nowy użytkownik: " + nowyKlient);
		kontroler.nowyUzytkownik(nowyKlient);
	}

	@Override
	public void powiadomOWylogowaniuUzytkownika(String bylyKlient) {
		System.out.println("Użytkownik " + bylyKlient + " się wylogował");
		kontroler.wylogowanyUzytkownik(bylyKlient);
	}
}
