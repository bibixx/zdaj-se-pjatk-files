package info.owczarek.corbachat.serwer;

import java.util.*;
import org.omg.CORBA.ORB;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import chat.*;

public class ServerImpl extends chat.SerwerPOA {
	ORB orb;
	NamingContextExt context;
	private Map<String, Klient> uzytkownicy;

	public ServerImpl(ORB orb, NamingContextExt context) {
		this.orb = orb;
		this.context = context;
		uzytkownicy = new HashMap();
	}

	@Override
	public String[] zaloguj(String nazwaUzytkownika) {
		System.out.println("Przyszedł użytkownik " + nazwaUzytkownika);
		String[] lista = dajListeUzytkownikow();
		dodajIPolaczUzytkownika(nazwaUzytkownika);
		powiadomUzytkownikowONowymUzytkowniku(nazwaUzytkownika);
		wypiszListeUzytkownikow();

		return lista;
	}

	private String[] dajListeUzytkownikow() {
		Set klucze = uzytkownicy.keySet();
		Iterator<String> it = klucze.iterator();

		String[] lista = new String[klucze.size()];

		for (int x = 0; x < klucze.size(); x++) {
			lista[x] = it.next();
		}

		return lista;
	}

	private void wypiszListeUzytkownikow() {
		System.out.println("\nAKTUALNIE ZALOGOWANI:");
		for (String u : dajListeUzytkownikow()) {
			System.out.println("\t" + u);
		}
	}

	private void dodajIPolaczUzytkownika(String nazwaUzytkownika) {
		try {
			Klient nowyKlient = KlientHelper.narrow(context
					.resolve_str(nazwaUzytkownika));
			uzytkownicy.put(nazwaUzytkownika, nowyKlient);
		} catch (NotFound e) {
			e.printStackTrace();
		} catch (CannotProceed e) {
			e.printStackTrace();
		} catch (InvalidName e) {
			e.printStackTrace();
		}
	}

	@Override
	public void wyslijWiadomoscDoWszystkich(String wiadomosc,
			String nazwaUzytkownika) {
		System.out.println("Rozsyłanie wiadomości od użytkownika "
				+ nazwaUzytkownika + ":\n\t" + wiadomosc);
		Iterator<String> iteratorKluczy = uzytkownicy.keySet().iterator();

		while (iteratorKluczy.hasNext()) {
			String klucz = iteratorKluczy.next();

			if (!nazwaUzytkownika.equals(klucz)) {
				Klient k = uzytkownicy.get(klucz);
				k.otrzymajWiadomosc(nazwaUzytkownika, wiadomosc);
			}
		}
	}

	@Override
	public void wyloguj(String nazwaUzytkownika) {
		powiadomUzytkownikowOWylogowaniu(nazwaUzytkownika);
		uzytkownicy.remove(nazwaUzytkownika);
		System.out.println("Wylogowywanie użytkownika " + nazwaUzytkownika);
		wypiszListeUzytkownikow();
	}

	private void powiadomUzytkownikowOWylogowaniu(String nazwaUzytkownika) {
		Iterator<String> iteratorKluczy = uzytkownicy.keySet().iterator();

		while (iteratorKluczy.hasNext()) {
			String klucz = iteratorKluczy.next();

			if (!nazwaUzytkownika.equals(klucz)) {
				Klient k = uzytkownicy.get(klucz);
				k.powiadomOWylogowaniuUzytkownika(nazwaUzytkownika);
			}
		}
	}

	private void powiadomUzytkownikowONowymUzytkowniku(String nazwaUzytkownika) {
		Iterator<String> iteratorKluczy = uzytkownicy.keySet().iterator();

		while (iteratorKluczy.hasNext()) {
			String klucz = iteratorKluczy.next();

			if (!nazwaUzytkownika.equals(klucz)) {
				Klient k = uzytkownicy.get(klucz);
				k.powiadomONowymUzytkowniku(nazwaUzytkownika);
			}
		}
	}
}
