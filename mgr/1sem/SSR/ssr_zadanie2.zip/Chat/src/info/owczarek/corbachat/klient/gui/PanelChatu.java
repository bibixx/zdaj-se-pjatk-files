package info.owczarek.corbachat.klient.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.*;

public class PanelChatu extends JPanel implements ActionListener, KeyListener {
	private GUI gui;
	private JTextArea taWiadomosci;
	private JList lUzytkownicy;
	private DefaultListModel<String> lmUzytkownicy;
	private JTextField tfWiadomosc;
	private JButton bWyslij;
	private JButton bPrywatnaWiadomosc;

	public PanelChatu(GUI g) {
		this.gui = g;
		stworzElementy();
		rozmiescElementy();
		podlaczSluchaczy();
	}

	private void stworzElementy() {
		setLayout(new BorderLayout());
		taWiadomosci = new JTextArea(20, 40);
		taWiadomosci.setEditable(false);
		lmUzytkownicy = new DefaultListModel<String>();
		lUzytkownicy = new JList<String>(lmUzytkownicy);
		lUzytkownicy.setPreferredSize(new Dimension(300, 100));
		lUzytkownicy.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tfWiadomosc = new JTextField(50);
		bWyslij = new JButton("Wyślij");
		bPrywatnaWiadomosc = new JButton("Wyślij prywatną wiadomość");
	}

	private void podlaczSluchaczy() {
		bWyslij.addActionListener(this);
		bPrywatnaWiadomosc.addActionListener(this);
		tfWiadomosc.addKeyListener(this);
	}

	private void rozmiescElementy() {
		JPanel lewa = new JPanel();
		lewa.setLayout(new BoxLayout(lewa, BoxLayout.PAGE_AXIS));
		lewa.add(new JScrollPane(lUzytkownicy));
		lewa.add(bPrywatnaWiadomosc);

		JPanel dol = new JPanel();
		dol.add(tfWiadomosc);
		dol.add(bWyslij);

		add(lewa, BorderLayout.LINE_START);
		add(new JScrollPane(taWiadomosci), BorderLayout.CENTER);
		add(dol, BorderLayout.PAGE_END);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == bWyslij) {
			aWyslij();
		} else if (e.getSource() == bPrywatnaWiadomosc) {
			aWyslijPrywatnaWiadomosc();
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	@Override
	public void keyPressed(KeyEvent e) {
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if (e.getSource() == tfWiadomosc) {
			if (e.getKeyCode() == KeyEvent.VK_ENTER) {
				aWyslij();
			}
		}
	}

	private void aWyslij() {
		gui.aWyslij(tfWiadomosc.getText());
		tfWiadomosc.setText("");
	}

	private void aWyslijPrywatnaWiadomosc() {
		if (!lUzytkownicy.isSelectionEmpty()) {
			String adresat = lUzytkownicy.getSelectedValue().toString();

			String wiadomosc = JOptionPane.showInputDialog(gui,
					"Jaką wiadomość wysłać użytkownikowi " + adresat + "?");

			if (wiadomosc != null) {
				gui.aWyslijPrywatnaWiadomosc(wiadomosc, adresat);
			}
		} else {
			JOptionPane
					.showMessageDialog(gui,
							"Musisz wybrać z listy użytkownika do którego chcesz wysłać wiadomość");
		}
	}

	public void nowyUzytkownik(String nazwaUzytkownika,
			boolean powiadomWOknieWiadomosci) {
		lmUzytkownicy.addElement(nazwaUzytkownika);
		if (powiadomWOknieWiadomosci) {
			taWiadomosci.setText(taWiadomosci.getText() + "***Użytkownik: "
					+ nazwaUzytkownika + " dołączył do chatu***\n");
		}
	}

	public void nowaWiadomosc(String nazwaUzytkownika, String wiadomosc) {
		taWiadomosci.setText(taWiadomosci.getText() + nazwaUzytkownika + ": "
				+ wiadomosc + "\n");
	}

	public void wylogowanyUzytkownik(String nazwaUzytkownika) {
		lmUzytkownicy.removeElement(nazwaUzytkownika);
		taWiadomosci.setText(taWiadomosci.getText() + "***Użytkownik "
				+ nazwaUzytkownika + " opuścił chat***\n");
	}
}
