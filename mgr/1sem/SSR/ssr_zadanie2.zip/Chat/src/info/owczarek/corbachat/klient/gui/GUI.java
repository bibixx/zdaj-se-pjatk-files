package info.owczarek.corbachat.klient.gui;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import info.owczarek.corbachat.klient.Kontroler;

import javax.swing.*;

public class GUI extends JFrame implements WindowListener {
	private Kontroler kontroler;
	private PanelLaczenia panelLaczenia;
	private PanelChatu panelChatu;

	public GUI() {
		setTitle("Chat");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		stworzElementy();
		rozmiescElementy();
		podlaczSluchaczy();
	}

	private void stworzElementy() {
		panelLaczenia = new PanelLaczenia(this);
		panelChatu = new PanelChatu(this);
	}

	private void rozmiescElementy() {
		add(panelLaczenia);
		pack();
	}

	private void podlaczSluchaczy() {
		addWindowListener(this);
	}

	public void podlaczKontroler(Kontroler kontroler) {
		if (this.kontroler == null) {
			this.kontroler = kontroler;
			this.kontroler.podlaczGUI(this);
		}
	}

	public void pokazPanelLaczenia() {
		add(panelLaczenia);
		pack();
	}

	public void pokazPanelChatu() {
		remove(panelLaczenia);
		add(panelChatu);
		pack();
	}

	public boolean aZaloguj(String host, String port, String nazwaUzytkownika) {
		boolean czySieUdalo = kontroler.zaloguj(host, port, nazwaUzytkownika);
		if (czySieUdalo) {
			pokazPanelChatu();
		}
		return czySieUdalo;
	}

	public void aWyslij(String wiadomosc) {
		kontroler.wyslijWiadomosc(wiadomosc);
	}

	public void aWyslijPrywatnaWiadomosc(String wiadomosc, String adresat) {
		kontroler.wyslijPrywatnaWiadomosc(wiadomosc, adresat);
	}

	public void nowyUzytkownik(String nazwaUzytkownika) {
		panelChatu.nowyUzytkownik(nazwaUzytkownika, true);
	}

	public void wczytajListeUzytkownikow(String[] uzytkownicy) {
		for (String u : uzytkownicy) {
			panelChatu.nowyUzytkownik(u, false);
		}
	}

	public void nowaWiadomosc(String nazwaUzytkownika, String wiadomosc) {
		panelChatu.nowaWiadomosc(nazwaUzytkownika, wiadomosc);
	}

	@Override
	public void windowClosing(WindowEvent e) {
		if (kontroler.isZalogowany()) {
			kontroler.wyloguj();
			System.out.println("Wyloguj");
		}
	}

	@Override
	public void windowOpened(WindowEvent e) {
	}

	@Override
	public void windowClosed(WindowEvent e) {
	}

	@Override
	public void windowIconified(WindowEvent e) {
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
	}

	@Override
	public void windowActivated(WindowEvent e) {
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
	}

	public void wylogowanyUzytkownik(String nazwaUzytkownika) {
		panelChatu.wylogowanyUzytkownik(nazwaUzytkownika);
	}
}
