package info.owczarek.corbachat.klient;

import java.util.*;

import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.AlreadyBound;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.POAManagerPackage.AdapterInactive;
import org.omg.PortableServer.POAPackage.ServantNotActive;
import org.omg.PortableServer.POAPackage.WrongPolicy;
import chat.*;
import info.owczarek.corbachat.klient.gui.GUI;

public class Kontroler {
	private ORB orb;
	private GUI gui;
	private NamingContextExt nc;
	private KlientImpl klient;
	private Serwer serwer;
	private String nazwaUzytkownika;
	private Map<String, Klient> podlaczeniKlienci;
	private boolean zalogowany;
	
	public Kontroler() {
		podlaczeniKlienci = new HashMap<String, Klient>();
		zalogowany = false;
	}

	public void podlaczGUI(GUI g) {
		if (gui == null) {
			gui = g;
			g.podlaczKontroler(this);
		}
	}

	public boolean zaloguj(String host, String port, String nazwaUzytkownika) {
		try {
			System.out.println("Próba zalogowania użytkownika "
					+ nazwaUzytkownika + " na serwerze " + host + ":" + port);
			
			// Ustawiamy właściwości połączenia dla orbd
			Properties props = new Properties();
			props.put("org.omg.CORBA.ORBInitialPort", port);
			props.put("org.omg.CORBA.ORBInitialHost", host);
			
			final ORB orbF = ORB.init(new String[] {}, props);
			// Potrzebne mi są dwie referencje, bo jedna musi być stała na potrzeby
			// wykorzystania wewnątrz osobnego wątku (żeby nie blokować GUI)
			orb = orbF;

			// Referencja i aktywowanie POAManagera
			POA rootpoa = POAHelper.narrow(orbF
					.resolve_initial_references("RootPOA"));
			rootpoa.the_POAManager().activate();
			
			// Tworzenie klienta i pobieranie referencji
			klient = new KlientImpl(this);
			org.omg.CORBA.Object klientReferencja = rootpoa.servant_to_reference(klient);
			Klient klientHref = KlientHelper.narrow(klientReferencja);
			
			// Pobieramy referencję do usługi nazw
			org.omg.CORBA.Object objRef = orbF
					.resolve_initial_references("NameService");
			nc = NamingContextExtHelper.narrow(objRef);

			// Rejestrujemy referencję do klienta w usłudze nazw
			NameComponent sciezka[] = nc.to_name(nazwaUzytkownika);
			nc.bind(sciezka, klientHref);

			System.out.println("Zarejestrowano klienta pod nazwą "
					+ nazwaUzytkownika);
			
			// Łączymy się z serwerem
			System.out.println("Łączenie z serwerem");
			String name = "serwer";
			serwer = SerwerHelper.narrow(nc.resolve_str(name));
			
			// Logujemy się do serwera i pobieramy listę zalogowanych użytkowników
			String[] uzytkownicy = serwer.zaloguj(nazwaUzytkownika);
			
			wczytajListeUzytkownikow(uzytkownicy);
			
			// Tworzymy i uruchamiamy wątek obsługi wywołań
			Thread watek = new Thread(new Runnable() {
				@Override
				public void run() {
					orbF.run();
				}
			});
			watek.start();
			
			// Zmieniamy pasek tytułowy, aby było wiadomo kto się zalogował
			this.nazwaUzytkownika = nazwaUzytkownika;
			gui.setTitle("Chat: " + this.nazwaUzytkownika);
			zalogowany = true;
			System.out.println("Połączono z serwerem");
		} catch (AdapterInactive e) {
			return false;
		} catch (ServantNotActive e) {
			return false;
		} catch (WrongPolicy e) {
			return false;
		} catch (NotFound e) {
			return false;
		} catch (CannotProceed e) {
			return false;
		} catch (org.omg.CosNaming.NamingContextPackage.InvalidName e) {
			return false;
		} catch (InvalidName e) {
			return false;
		} catch (AlreadyBound e) {
			return false;
		}
		return true;
	}
	
	public void wyloguj() {
		serwer.wyloguj(nazwaUzytkownika);
		try {
			NameComponent sciezka[] = nc.to_name(nazwaUzytkownika);
			nc.unbind(sciezka);
		} catch (NotFound e) {
			e.printStackTrace();
		} catch (CannotProceed e) {
			e.printStackTrace();
		} catch (org.omg.CosNaming.NamingContextPackage.InvalidName e) {
			e.printStackTrace();
		}
		zalogowany = false;
	}

	public void wyslijWiadomosc(String wiadomosc) {
		serwer.wyslijWiadomoscDoWszystkich(wiadomosc, nazwaUzytkownika);
		nowaWiadomosc(nazwaUzytkownika, wiadomosc);
	}

	public void wyslijPrywatnaWiadomosc(String wiadomosc, String adresat) {
		if (!podlaczeniKlienci.containsKey(adresat)) {
			try {
				Klient nowyKlient = KlientHelper.narrow(nc
						.resolve_str(adresat));
				podlaczeniKlienci.put(adresat, nowyKlient);
			} catch (NotFound e) {
				e.printStackTrace();
			} catch (CannotProceed e) {
				e.printStackTrace();
			} catch (org.omg.CosNaming.NamingContextPackage.InvalidName e) {
				e.printStackTrace();
			}
		}
		
		podlaczeniKlienci.get(adresat).otrzymajWiadomosc(nazwaUzytkownika, wiadomosc);
		nowaWiadomosc(nazwaUzytkownika, wiadomosc);
	}
	
	public void nowyUzytkownik(String nazwaUzytkownika) {
		gui.nowyUzytkownik(nazwaUzytkownika);
	}
	
	public void wczytajListeUzytkownikow(String[] uzytkownicy) {
		gui.wczytajListeUzytkownikow(uzytkownicy);
	}
	
	public void wylogowanyUzytkownik(String nazwaUzytkownika) {
		if (podlaczeniKlienci.containsKey(nazwaUzytkownika)) {
			podlaczeniKlienci.remove(nazwaUzytkownika);
		}
		gui.wylogowanyUzytkownik(nazwaUzytkownika);
	}
	
	public void nowaWiadomosc(String nazwaUzytkownika, String wiadomosc) {
		gui.nowaWiadomosc(nazwaUzytkownika, wiadomosc);
	}

	public boolean isZalogowany() {
		return zalogowany;
	}
}
