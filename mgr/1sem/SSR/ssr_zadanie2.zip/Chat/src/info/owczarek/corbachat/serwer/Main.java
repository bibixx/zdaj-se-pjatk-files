package info.owczarek.corbachat.serwer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import org.omg.CORBA.ORB;
import org.omg.CORBA.ORBPackage.InvalidName;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;
import org.omg.CosNaming.NamingContextPackage.AlreadyBound;
import org.omg.CosNaming.NamingContextPackage.CannotProceed;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.POAManagerPackage.AdapterInactive;
import org.omg.PortableServer.POAPackage.ServantNotActive;
import org.omg.PortableServer.POAPackage.WrongPolicy;

import chat.*;

public class Main {
	public static void main(String[] args) {
		System.out.println("Włączanie serwera");
		Properties allProps = new Properties();
		try {
			allProps.load(new FileInputStream("config.properties"));
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		Properties props = new Properties();
		props.put("org.omg.CORBA.ORBInitialPort", allProps.get("server_port"));
		props.put("org.omg.CORBA.ORBInitialHost", allProps.get("server_host"));
		ORB orb = ORB.init(args, props);

		try {
			// Pobieranie referencji do rootpoa i aktywowanie POAManagera
			POA rootpoa = POAHelper.narrow(orb
					.resolve_initial_references("RootPOA"));
			rootpoa.the_POAManager().activate();

			// Pobieranie referencji do usługi nazw
			org.omg.CORBA.Object ncObjectRef = orb
					.resolve_initial_references("NameService");
			NamingContextExt ncRef = NamingContextExtHelper.narrow(ncObjectRef);
			System.out
					.println("Pobrano referencję do usługi nazw pracującej na "
							+ allProps.get("server_host") + ":"
							+ allProps.get("server_port"));

			System.out.println("Tworzenie obiektu serwera");

			ServerImpl serwer = new ServerImpl(orb, ncRef);
			System.out.println("Stworzono obiekt serwera");

			org.omg.CORBA.Object serwerReferencja = rootpoa
					.servant_to_reference(serwer);
			Serwer serwerHref = SerwerHelper.narrow(serwerReferencja);
			System.out.println("Stworzono referencję do serwera");

			String nazwaSerwera = allProps.getProperty("server_name");
			NameComponent sciezka[] = ncRef.to_name(nazwaSerwera);
			ncRef.rebind(sciezka, serwerHref);
			System.out.println("Zarejestrowano serwer pod nazwą \""
					+ nazwaSerwera + "\"");

			System.out.println("Serwer oczekuje na połączenia od klientów");
			orb.run();
			System.out.println("Praca serwera została zakończona");

		} catch (InvalidName e) {
			e.printStackTrace();
		} catch (AdapterInactive e) {
			e.printStackTrace();
		} catch (org.omg.CosNaming.NamingContextPackage.InvalidName e) {
			e.printStackTrace();
		} catch (ServantNotActive e) {
			e.printStackTrace();
		} catch (WrongPolicy e) {
			e.printStackTrace();
		} catch (NotFound e) {
			e.printStackTrace();
		} catch (CannotProceed e) {
			e.printStackTrace();
		}
	}
}
