package info.owczarek.corbachat.klient.gui;

import java.awt.event.*;

import javax.swing.*;

public class PanelLaczenia extends JPanel implements ActionListener {
	private GUI gui;
	private JTextField tfIPSerwera;
	private JTextField tfPortSerwera;
	private JTextField tfNazwaUzytkownika;
	private JButton bZaloguj;

	public PanelLaczenia(GUI g) {
		this.gui = g;
		stworzElementy();
		rozmiescElementy();
		ustawDomyslneWartosciPol();
		podlaczSluchaczy();
	}

	private void stworzElementy() {
		tfIPSerwera = new JTextField(15);
		tfPortSerwera = new JTextField(15);
		tfNazwaUzytkownika = new JTextField(15);
		bZaloguj = new JButton("Zaloguj");
	}

	private void ustawDomyslneWartosciPol() {
		tfIPSerwera.setText("127.0.0.1");
		tfPortSerwera.setText("1050");
		tfNazwaUzytkownika.setText("Ja");
	}

	private void rozmiescElementy() {
		setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));

		JPanel pIP = new JPanel();
		pIP.add(new JLabel("Host:"));
		pIP.add(tfIPSerwera);
		
		JPanel pPort = new JPanel();
		pPort.add(new JLabel("Port:"));
		pPort.add(tfPortSerwera);

		JPanel pNazwa = new JPanel();
		pNazwa.add(new JLabel("Nazwa użytkownika"));
		pNazwa.add(tfNazwaUzytkownika);

		add(pIP);
		add(pPort);
		add(pNazwa);
		add(bZaloguj);
	}

	private void podlaczSluchaczy() {
		bZaloguj.addActionListener(this);
	}

	public String getIP() {
		return tfIPSerwera.getText();
	}
	
	public String getPort() {
		return tfPortSerwera.getText();
	}

	public String getNazwaUzytkownika() {
		return tfNazwaUzytkownika.getText();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == bZaloguj) {
			aZaloguj();
		}
	}

	private void aZaloguj() {
		boolean czySieUdalo = gui.aZaloguj(getIP(), getPort(), getNazwaUzytkownika());
		if (!czySieUdalo) {
			JOptionPane.showMessageDialog(gui, "Nie udało się zalogować. Prawdopodobnie nazwa użytkownika jest już zajęta.", "Błąd logowania", JOptionPane.ERROR_MESSAGE);
		}
	}

}
