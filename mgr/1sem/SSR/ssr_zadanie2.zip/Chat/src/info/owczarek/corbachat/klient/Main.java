package info.owczarek.corbachat.klient;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import info.owczarek.corbachat.klient.gui.GUI;
import info.owczarek.corbachat.serwer.ServerImpl;

import javax.swing.SwingUtilities;

public class Main {
	public static void main(String[] args) {
		
		
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				Kontroler k = new Kontroler();
				GUI g = new GUI();
				k.podlaczGUI(g);
				g.setVisible(true);
			}
		});
	}
}
