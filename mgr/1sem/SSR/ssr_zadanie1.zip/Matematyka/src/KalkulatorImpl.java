
import java.text.SimpleDateFormat;
import java.util.Date;
import org.omg.CORBA.*;

public class KalkulatorImpl extends Matematyka.KalkulatorPOA {
	private ORB orb;
	
	public void setORB(ORB orb_new) {
		orb = orb_new;
	}

	@Override
	public String dajCzas() {
		SimpleDateFormat df = new SimpleDateFormat("yyyyy-mm-dd hh:mm:ss");
		return df.format(new Date());
	}

	@Override
	public int sumuj(int a, int b) {
		return a + b;
	}

	@Override
	public void zamknij() {
		orb.shutdown(false);
	}
}
