
import java.util.Scanner;

import Matematyka.*;
import org.omg.CORBA.*;
import org.omg.CosNaming.*;

public class Client {
	public static void main(String[] args) {
		try {
			ORB orb = ORB.init(args, null);
			
			org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
			NamingContextExt nc = NamingContextExtHelper.narrow(objRef);
			
			String name = "Kalkulator";
			Kalkulator kalkulatorImp = KalkulatorHelper.narrow(nc.resolve_str(name));
			
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Aktualny czas to " + kalkulatorImp.dajCzas());
			System.out.println("DODAWANIE");
			System.out.println("Podaj pierwszą liczbę ");
			int a = sc.nextInt();
			System.out.println("Podaj drugą liczbę ");
			int b = sc.nextInt();
			
			int suma = kalkulatorImp.sumuj(a, b);
			
			System.out.println("Suma liczb " + a + " i " + b + " wynosi " + suma);
			//kalkulatorImp.zamknij();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
