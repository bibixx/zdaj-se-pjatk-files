
import org.omg.CORBA.*;
import org.omg.CosNaming.*;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.POAHelper;

import Matematyka.Kalkulator;
import Matematyka.KalkulatorHelper;

public class Server {
	public static void main(String[] args) {
		try {
			ORB orb = ORB.init(args, null);
			System.out.println("Start ORB");
			
			POA rootpoa = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
			rootpoa.the_POAManager().activate();
			
			KalkulatorImpl kalkulator = new KalkulatorImpl();
			kalkulator.setORB(orb);
			System.out.println("Stworzono kalkulator");
			
			org.omg.CORBA.Object kalkulator_ref = rootpoa.servant_to_reference(kalkulator);
			Kalkulator kalkulatorHref = KalkulatorHelper.narrow(kalkulator_ref);
			
			org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
			NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
			
			String name = "Kalkulator";
			NameComponent path[] = ncRef.to_name(name);
			ncRef.rebind(path, kalkulatorHref);
			
			System.out.println("Serwer gotowy do działania");
			orb.run();
			System.out.println("Serwer zamknięty");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
