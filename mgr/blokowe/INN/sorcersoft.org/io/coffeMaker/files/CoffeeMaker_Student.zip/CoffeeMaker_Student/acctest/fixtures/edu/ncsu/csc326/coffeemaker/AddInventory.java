package edu.ncsu.csc326.coffeemaker;

import fit.ActionFixture;

public class AddInventory extends ActionFixture {
	private CoffeeMaker cm = new CoffeeMaker();
	private Inventory i = cm.checkInventory();
	
	public void unitsCoffee(int coffee) {
		cm.addInventory(coffee,0,0,0);
	}

	public void unitsMilk(int milk) {
		cm.addInventory(0,milk,0,0);
	}

	public void unitsSugar(int sugar) {
		cm.addInventory(0,0,sugar,0);
	}

	public void unitsChocolate(int chocolate) {
		cm.addInventory(0,0,0,chocolate);
	}

	public int coffeeInventory() {
		return i.getCoffee();
	}

	public int milkInventory() {
		return i.getMilk();
	}

	public int sugarInventory() {
		return i.getSugar();
	}

	public int chocolateInventory() {
		return i.getChocolate();
	}
}
