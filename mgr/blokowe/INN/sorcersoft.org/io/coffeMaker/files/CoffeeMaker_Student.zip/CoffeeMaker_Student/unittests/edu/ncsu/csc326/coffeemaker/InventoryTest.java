package edu.ncsu.csc326.coffeemaker;

import junit.framework.TestCase;

public class InventoryTest extends TestCase {

	private Inventory i;
	
	protected void setUp() throws Exception {
		i = new Inventory();
		super.setUp();
	}

	public void testInventory() {
		assertEquals(15, i.getCoffee());
		assertEquals(15, i.getMilk());
		assertEquals(15, i.getSugar());
		assertEquals(15, i.getChocolate());
	}

	public void testGetChocolate() {
		assertEquals(15, i.getChocolate());
	}

	public void testSetChocolate() {
		i.setChocolate(4);
		assertEquals(4, i.getChocolate());
	}
	
	public void testSetChocolateNeg() {
		i.setChocolate(-1);
		assertEquals(15, i.getChocolate());
	}

	public void testGetCoffee() {
		assertEquals(15, i.getCoffee());
	}

	public void testSetCoffee() {
		i.setCoffee(7);
		assertEquals(7, i.getCoffee());
	}
	
	public void testSetCoffeeNeg() {
		i.setCoffee(-1);
		assertEquals(15, i.getCoffee());
	}

	public void testGetMilk() {
		assertEquals(15, i.getMilk());
	}

	public void testSetMilk() {
		i.setMilk(3);
		assertEquals(3, i.getMilk());
	}
	
	public void testSetMilkNeg() {
		i.setMilk(-1);
		assertEquals(15, i.getMilk());
	}

	public void testGetSugar() {
		assertEquals(15, i.getSugar());
	}

	public void testSetSugar() {
		i.setSugar(1);
		assertEquals(1, i.getSugar());
	}
	
	public void testSetSugarNeg() {
		i.setSugar(-1);
		assertEquals(15, i.getSugar());
	}

	public void testEnoughIngredients() {
		Recipe r1 = new Recipe();
		r1.setAmtChocolate(16);
		assertFalse(i.enoughIngredients(r1));
		r1.setAmtChocolate(0);
		r1.setAmtCoffee(16);
		assertFalse(i.enoughIngredients(r1));
		r1.setAmtChocolate(0);
		r1.setAmtCoffee(0);
		r1.setAmtMilk(16);
		assertFalse(i.enoughIngredients(r1));
		r1.setAmtMilk(0);
		r1.setAmtSugar(16);
		assertFalse(i.enoughIngredients(r1));
	}

	/*
	 * Class under test for String toString()
	 */
	public void testToString() {
		String s = "Coffee: 15\n" +
			"Milk: 15\n" +
			"Sugar: 15\n" +
			"Chocolate: 15\n";
		assertEquals(i.toString(), s);
	}

}
