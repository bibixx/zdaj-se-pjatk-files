package greeters;

import edu.ttu.cs.greeter.Greeter;

public class Hello implements Greeter {

    public String greet() {
        return "Hello, world!";
    }
}