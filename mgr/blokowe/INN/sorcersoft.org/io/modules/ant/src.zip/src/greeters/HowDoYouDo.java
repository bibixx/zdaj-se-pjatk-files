package greeters;

import edu.ttu.cs.greeter.Greeter;

public class HowDoYouDo implements Greeter {

    public String greet() {
        return "How do you do, globe!";
    }
}
