package greeters;

import edu.ttu.cs.greeter.Greeter;

public class Surprise implements Greeter {

    public String greet() {

        // Choose one of four greeters pseudo-randomly and
        // invoke its greet() method.
        int choice = (int) (Math.random() * 3.99);

        Greeter g;

        switch(choice) {

        case 0:
            g = new Hello();
            return g.greet();

        case 1:
            g = new Greetings();
            return g.greet();

        case 2:
            g = new Salutations();
            return g.greet();

        case 3:
            g = new HowDoYouDo();
            return g.greet();
            
        default : return "Hi";
        }
    }
}