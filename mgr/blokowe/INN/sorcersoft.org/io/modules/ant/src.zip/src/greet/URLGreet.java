package greet;

import edu.ttu.cs.greeter.*;
import java.net.*;

public class URLGreet {

    // -fs ->file system  -url ->URL
    // java <-fs basePath class / -url baseURL class> <.......> <.......>

    public static final String USAGE = "java <-fs basePath class / -url baseURL class> <.......> <.......>";
    
    
    static public void main(String[] args) {
	
        if (args.length < 3) {
            System.out.println(USAGE);
            return;
        }
	
	ClassLoader cl = null;
	String type, base, className;
   
	for (int i = 0; i < args.length; i = i+3) {
	    type  = args[i];
	    base  = args[i+1];
	    className = args[i+2];
	
	    Class c = null;

	    if ("-fs".equals(type)) {
		try { 
		    c = new GreeterClassLoader(base).loadClass(className) ;
		} catch(Exception e) { e.printStackTrace(); };
	    } else if ("-url".equals(type)) {   
		try {
		    URL[] urls = { new URL(base) };
		    c = new URLClassLoader(urls).loadClass(className);
		} catch(Exception e) { e.printStackTrace(); };
	    } 
		
	    try {
		if (c!=null) {
		    // Instantiate it into a greeter object
		    Object o = c.newInstance();
		    
		    // Cast the Object ref to the Greeter interface type
		    // so greet() can be invoked on it
		    Greeter greeter = (Greeter) o;
		    
		    // Greet the world in this greeter's special way
		    String reply = greeter.greet();
		    System.out.println(reply);
		}//if 
	    }catch (Exception e) { }	

	}//for
    
    }//Main

}
