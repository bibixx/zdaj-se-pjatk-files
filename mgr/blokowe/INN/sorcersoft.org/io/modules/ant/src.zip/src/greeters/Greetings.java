package greeters;

import edu.ttu.cs.greeter.Greeter;

public class Greetings implements Greeter {

    public String greet() {
        return "Greetings, planet!";
    }
}
