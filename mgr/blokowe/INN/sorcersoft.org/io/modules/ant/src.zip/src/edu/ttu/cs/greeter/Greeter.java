package edu.ttu.cs.greeter;

public interface Greeter {

    public String greet();
}
