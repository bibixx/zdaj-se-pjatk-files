package greeters;

import edu.ttu.cs.greeter.Greeter;

public class Salutations implements Greeter {

    public String greet() {
        return "Salutations, orb!";
    }
}