package greeters;

import edu.ttu.cs.greeter.Greeter;
import java.util.Date;

public class HiTime implements Greeter {

    public String greet() {

        // Date's no-arg constructor initializes itself to the
        // current date and time
        Date date = new Date();
        int hours = date.getHours();

        // Some hours: midnight, 0; noon, 12; 11PM, 23;
        if (hours >= 4 && hours <= 11) {
            return "Good morning, world!";
        }
        else if (hours >= 12 && hours <= 16) {
            return "Good afternoon, world!";
        } 
        else if (hours >= 17 && hours <= 21) {
            return "Good evening, world!";
        } 
        else {
            return "Good night, world!";
        }
    }
}
