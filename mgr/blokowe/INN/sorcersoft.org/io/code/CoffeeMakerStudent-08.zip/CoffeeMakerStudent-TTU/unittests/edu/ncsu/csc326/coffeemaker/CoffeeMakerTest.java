package edu.ncsu.csc326.coffeemaker;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

/**
 * @author Mike Sobolewski
 */
public class CoffeeMakerTest {
	private CoffeeMaker cm;
	private Inventory i;
	private Recipe r1;

	@Before
	public void setUp() {
		cm = new CoffeeMaker();
		i = cm.checkInventory();

		r1 = new Recipe();
		r1.setName("Coffee");
		r1.setPrice(50);
		r1.setAmtCoffee(6);
		r1.setAmtMilk(1);
		r1.setAmtSugar(1);
		r1.setAmtChocolate(0);
	}

	@Test
	public void testAddRecipe() {
		assertTrue(cm.addRecipe(r1));
	}

	/**
	 * Needed for compatibility with JUnit 3.x runner.
	 */
	public static junit.framework.Test suite() {
		return new junit.framework.JUnit4TestAdapter(CoffeeMakerTest.class);
	}

	/**
	 * Run the test directly via <code>main</code> that is much less important
	 * with the advent of IDE runners.
	 */
	public static void main(String args[]) {
		org.junit.runner.JUnitCore.main(CoffeeMakerTest.class.getName());

	}
}
