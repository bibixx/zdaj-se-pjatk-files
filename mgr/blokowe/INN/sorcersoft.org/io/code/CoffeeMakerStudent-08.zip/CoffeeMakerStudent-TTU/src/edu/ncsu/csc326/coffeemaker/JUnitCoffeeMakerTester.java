package edu.ncsu.csc326.coffeemaker;

import java.util.logging.Logger;

import org.junit.runner.Result;

public class JUnitCoffeeMakerTester {
	private final static Logger logger = Logger.getLogger("cs.3365");

	public static void main(String[] args) {

		Result result = org.junit.runner.JUnitCore
				.runClasses(edu.ncsu.csc326.coffeemaker.CoffeeMakerTest.class);
		logger.info("Time elapsed: " + result.getRunTime() + " ms");
		logger.info("Failures: " + result.getFailureCount());
	}
}
