package CW_13_10_08;
public class Zadanie09 
{
	public static void main(String[] args) 
	{   	
		System.out.println("   *\n  ***\n *****\n*******");
   	} 

}
