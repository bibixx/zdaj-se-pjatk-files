package CW_13_10_08;
public class Zadanie10 
{
	public static void main(String[] args)
	{
		int x=11,y=5;
		System.out.println("x = " + x);
		System.out.println("y = " + y);
		System.out.println("x + y = " + (x+y));
		System.out.println("x - y = " + (x-y));
		System.out.println("x * y = " + (x*y));
		double z = (double)x/(double)y;
		System.out.println("x : y = " + z);
		System.out.println("x % y = " + (x%y));
		System.out.println("x / y = " + (x/y));

	}

}
