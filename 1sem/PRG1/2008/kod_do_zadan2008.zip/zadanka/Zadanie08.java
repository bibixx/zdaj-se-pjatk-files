package CW_13_10_08;
public class Zadanie08 
{
	public static void main(String[] args) 
	{   	
		System.out.println("Hello \nMiko�aj Bie�kowski");
   	} 

}
