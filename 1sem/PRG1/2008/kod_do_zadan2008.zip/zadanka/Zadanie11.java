package CW_13_10_08;
public class Zadanie11 {

	public static void main(String[] args) {
			double tempf=100;
			tempf=(5*(tempf-32)/9);
			int tempc = (int) tempf;
			System.out.println(tempc+"'C");
	 
	}

}
