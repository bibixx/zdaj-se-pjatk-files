package CW_17_10_08;

public class Zadanie13 {

	public static void main(String[] args) {
		char a='�';
		System.out.println("� = " +(int)a);
		char e='�';
		System.out.println("� = " +(int)e);
		char c='�';
		System.out.println("� = " +(int)c);
		char l='�';
		System.out.println("� = " +(int)l);
		char n='�';
		System.out.println("� = " +(int)n);
		char o='�';
		System.out.println("� = " +(int)o);
		char s='�';
		System.out.println("� = " +(int)s);
		char z1='�';
		System.out.println("� = " +(int)z1);
		char z2='�';
		System.out.println("� = " +(int)z2);
	}

}
