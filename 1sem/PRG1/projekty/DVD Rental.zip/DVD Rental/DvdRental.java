import java.io.*;
import javax.swing.*;
import java.util.*;
 class DvdRental
 {
  
  public Vhs tabV[]=new Vhs[200];
  public Person tab[]=new Person[200];
  public Dvd tabD[]=new Dvd[200];
  public int idx;
  public int idxV;
  public int idxD;
  public int rentV;
  public int rentD;
    public static void main (String args[])
    {
      new DvdRental();
    }
       
    
	 public DvdRental()
	 {
	  int idxV=0;
    int idx=0;
    //Password
     while (true)
            {String pass=("1");
             String check=JOptionPane.showInputDialog("Password:");
  
  
             if (pass.equals(check)) break;
            } 
            //Menu
               
      while (true){
        
        System.out.println("Movies Section:");
        System.out.println("-----------");
        System.out.println("0 Display All Movies:");
        System.out.println("1 Rent a Movie:");
        System.out.println("2 Display rented Movies:");
        System.out.println("3 Add Movie:");
        System.out.println("\n");
        System.out.println("Users Section:");
        System.out.println("-----------");  
        System.out.println("4 Find person by:");
        System.out.println("5 Add new contact:");
        System.out.println("6 Display Users:");
        System.out.println("\n");
        System.out.println("Administration Section:");
        System.out.println("-----------");        
        System.out.println("7.1 Save Persons data to file:");
        System.out.println("7.2 Save VHS data to file:");
        System.out.println("8.1 Load Persons from file:");
        System.out.println("8.2 Load VHS from file:");
        System.out.println("9 Block Station");
        System.out.println("10 Change Blocking Password");
        System.out.println("D- Delete Movie");
        System.out.println("e- Exit");
        String str=JOptionPane.showInputDialog("Select");
        if (str.equals("e")) System.exit (0);
        //Persons Section
        if (str.equals("5")) AddPerson();
        if (str.equals("9"))
         { 
          while (true)
            {
             String pass=("1");
             String check=JOptionPane.showInputDialog("Password:");
             if (pass.equals(check)) break;
            }             
          }
        if (str.equals("8")) System.out.println("a");
        if (str.equals("6")) DisplayAll();
        //Search Person SubMenu
        if (str.equals("4")) 
        {
        for (int ii=0;ii<12;ii++)
          {
            System.out.println("\n");
          }
          System.out.println("Search by:");
          System.out.println("----------");
          System.out.println("1 Enter ID:");
          System.out.println("2 Enter Name:");
          System.out.println("3 Enter City:");
          System.out.println("4 Back to previous menu:");
            for (int ii=0;ii<9;ii++)
            {
              System.out.println("\n");
            }
           String str1=JOptionPane.showInputDialog("Choice:");
           int choice =Integer.parseInt(str1); 
           if (choice==1) SearchID();
           if (choice==2) SearchName();
           if (choice==3) SearchCity();
         }             
    
      //VHS and DVD Section
        if (str.equals("1")) {
          System.out.println("Renting a Movie:");
          System.out.println("----------");
          String str2=JOptionPane.showInputDialog("Dvd or Vhs?");
          if (str2.equalsIgnoreCase("Dvd")) RentTitleD();
          if (str2.equalsIgnoreCase("vhs")) RentTitleV();
   }
   
        if (str.equals("3"))
        {
          for (int i=0;i<12;i++)
          {
            System.out.println("\n");
          }
          System.out.println("Adding New Movie:");
          System.out.println("----------");
          System.out.println("1 VHS:?");
          System.out.println("2 DVD:?");
          System.out.println("3 Back to previous menu:");
          
          for (int i=0;i<9;i++)
          { 
            System.out.println("\n");
          }
          String str1=JOptionPane.showInputDialog("Choice:");
          int choice =Integer.parseInt(str1);
          if (choice==1) AddVhs();
          if (choice==2) AddDvd();
         }
            
        if (str.equals("0")) {
         {
          for (int i=0;i<12;i++)
          {
            System.out.println("\n");
          }
          System.out.println("Display All Movies:");
          System.out.println("----------");
          System.out.println("1 VHS:?");
          System.out.println("2 DVD:?");
          System.out.println("3 All:?");
          System.out.println("4 Back to previous menu:");
          
          for (int i=0;i<9;i++)
          { 
            System.out.println("\n");
          }
          String str1=JOptionPane.showInputDialog("Choice:");
          int choice =Integer.parseInt(str1);
          if (choice==1) DisplayAllV();
          if (choice==2) DisplayAllD();
          if (choice==3) 
          {
            System.out.println("Vhs Section:");
            DisplayAllV();
            System.out.println("DVD Section:");
            DisplayAllD();
          }
         }
        }
       if (str.equals("7.1"))
       {
        String str1=JOptionPane.showInputDialog("Name of file:?");
        SaveFile(str1.concat(".txt"));
       }  
       if (str.equals("8.1"))
       {
        String str1=JOptionPane.showInputDialog("Name of file:?");
        LoadFile(str1.concat(".txt"));
       } 
       if (str.equals("7.2"))
       {
        String str1=JOptionPane.showInputDialog("Name of file:?");
        SaveFileV(str1.concat("V.txt"));
        SaveFileD(str1.concat("D.txt"));
       }
       if (str.equals("8.2"))
       {
        String str1=JOptionPane.showInputDialog("Name of file:? txt+V v txt+D");
        LoadFileV(str1.concat("V.txt"));
        LoadFileD(str1.concat("D.txt"));
       }  
       
       if (str.equals("2"))
       {
        String str2=JOptionPane.showInputDialog("Dvd , Vhs, all?");
          if (str2.equalsIgnoreCase("Dvd")) RentDisplD();
          if (str2.equalsIgnoreCase("vhs")) RentDisplV();
          if (str2.equalsIgnoreCase("all"))
          {
            System.out.println("Vhs Section:");
            RentDisplV();
            System.out.println("DVD Section:");
            RentDisplD();
          }
          
       }

      
      }  
    }  
          
        
    public void DisplayAll()
    {
      for (int i=0;i<tab.length;i++) 
        if (tab[i]!=null)
          {
            System.out.println("");
            tab[i].Displ();
          } 
    }
    
    public void SearchID()
    {
      String str=JOptionPane.showInputDialog("ID:?");
       
        for (int i=0;i<tab.length;i++)
        {
          if (tab[i]!=null)
            if (tab[i].id.equalsIgnoreCase(str))
              {
                System.out.println("********");
                tab[i].Displ();
                System.out.println("********");
              }
        }
    }
    
    public void SearchName()
    {
      String str=JOptionPane.showInputDialog("Name:?");
       
        for (int i=0;i<tab.length;i++)
        {
          if (tab[i]!=null)
            if (tab[i].name.equalsIgnoreCase(str))
              {
                System.out.println("********");
                tab[i].Displ();
                System.out.println("********");
              }
        }
    }
    
    public void SearchCity()
    {
      String str=JOptionPane.showInputDialog("City:?");
       
        for (int i=0;i<tab.length;i++)
        {
          if (tab[i]!=null)
            if (tab[i].city.equalsIgnoreCase(str))
              {
                System.out.println("********");
                tab[i].Displ();
                System.out.println("********");
              }
        }
    }
    
       
    public void AddPerson()
    {
      
      String name=JOptionPane.showInputDialog("Name?");
      String pesel=JOptionPane.showInputDialog("Pesel?");
      String age1=JOptionPane.showInputDialog("Age?");
      int age=Integer.parseInt(age1);
      String address=JOptionPane.showInputDialog("Address?");
      String city=JOptionPane.showInputDialog("City?");
      String postal=JOptionPane.showInputDialog("Zip Code?");
      String phone=JOptionPane.showInputDialog("Phone?");
      String id =String.valueOf(idx);
      tab[idx]=new Person (id,name,pesel,age,address,city,postal,phone);
      idx++;
    }
    
     //VHS Section
  public void AddVhs ()
 {   
    int quantityloop=0;
    String quantityloop1=JOptionPane.showInputDialog("Quantity?");
    quantityloop=Integer.parseInt(quantityloop1);
    if (quantityloop==1)
    {
    
      String titleV=JOptionPane.showInputDialog("Title?");
      String directorV=JOptionPane.showInputDialog("Director?");
      String actor1V=JOptionPane.showInputDialog("Actor num.1?");
      String actor2V=JOptionPane.showInputDialog("Actor num.2?");
      String actor3V=JOptionPane.showInputDialog("Actor num.3?");
      String duration1=JOptionPane.showInputDialog("Duration?");
      int durationV=Integer.parseInt(duration1);
      String year1=JOptionPane.showInputDialog("Year?");
      int yearV=Integer.parseInt(year1);
      String genderV=JOptionPane.showInputDialog("Gender?");
      String imdb1=JOptionPane.showInputDialog("Imdb number?");
      int imdbV=Integer.parseInt(imdb1);
      int idV=idxV;
      String borrowedV="No";
      tabV[idxV]=new Vhs (idV,titleV,borrowedV,directorV,actor1V,actor2V,actor3V,durationV,yearV,genderV,imdbV);
      idxV++;
   }
   if (quantityloop!=1)
   {
      String titleV=JOptionPane.showInputDialog("Title?");
      String directorV=JOptionPane.showInputDialog("Director?");
      String actor1V=JOptionPane.showInputDialog("Actor num.1?");
      String actor2V=JOptionPane.showInputDialog("Actor num.2?");
      String actor3V=JOptionPane.showInputDialog("Actor num.3?");
      String duration1=JOptionPane.showInputDialog("Duration?");
      int durationV=Integer.parseInt(duration1);
      String year1=JOptionPane.showInputDialog("Year?");
      int yearV=Integer.parseInt(year1);
      String genderV=JOptionPane.showInputDialog("Gender?");
      String imdb1=JOptionPane.showInputDialog("Imdb number?");
      int imdbV=Integer.parseInt(imdb1);
      String borrowedV="No";
      for(int i=0;i<quantityloop;i++)
      {
      int idV=idxV;
      tabV[idxV]=new Vhs (idV,titleV,borrowedV,directorV,actor1V,actor2V,actor3V,durationV,yearV,genderV,imdbV);
      idxV++;
      }
        
      
   }
   
   
 }
  
  
  
  public void SearchTitleV()
    { 
      for (int count=1;count<2;count++)
      {
      
      String str=JOptionPane.showInputDialog("Title?");
      for (int i=0;i<tabV.length;i++)
        {
          if (tabV[i]!=null)
             if (tabV[i].titleV.equalsIgnoreCase(str))
              { 
                System.out.println("********");
                tabV[i].DisplV();
                System.out.println("********");
              }
        }
        }
        
    }
    
  
  public void DisplayAllV()
    {
      for (int i=0;i<tabV.length;i++) 
        if (tabV[i]!=null)
          {
            System.out.println("");
            tabV[i].DisplV();
            System.out.println("-----------");
          } 
    }
    
  public void DisplayAllD()
    {
      for (int i=0;i<tabD.length;i++) 
        if (tabD[i]!=null)
          {
            System.out.println("");
            tabD[i].DisplD();
            System.out.println("-----------");
          } 
    }
     
  public void RentTitleV()
    { 
      for (int count=1;count<2;count++)
      {
      
      String str=JOptionPane.showInputDialog("Title?");
      for (int i=0;i<tabV.length;i++)
        {
          if (tabV[i]!=null)
             if (tabV[i].titleV.equalsIgnoreCase(str))
                if (tabV[i].borrowedV.equals("No"))
              { 
                System.out.println("********");
                tabV[i].DisplV();
                System.out.println("********");
                rentV=i;
              }
        }
      }
      String ask=JOptionPane.showInputDialog("Person's ID: ?");
      tabV[rentV].borrowedV=ask;
   }
     
     
     public void RentDisplV()
    { 
      for (int i=0;i<tabV.length;i++)
       {   
          if (tabV[i]!=null)
               if (tabV[i].borrowedV!="No")
              { 
                System.out.println("********");
                tabV[i].DisplV();
                System.out.println("********");
                rentV=i;
              }
       }
    }
     
     
     public void RentDisplD()
    { 
      for (int i=0;i<tabD.length;i++)
       {   
          if (tabD[i]!=null)
               if (tabD[i].borrowedV!="No")
              { 
                System.out.println("********");
                tabD[i].DisplV();
                System.out.println("********");
                rentD=i;
              }
       }
    }
     
  public void RentTitleD()
    { 
      for (int count=1;count<2;count++)
      {
      
      String str=JOptionPane.showInputDialog("Title?");
      for (int i=0;i<tabD.length;i++)
        {
          if (tabD[i]!=null)
             if (tabD[i].titleV.equalsIgnoreCase(str))
                if (tabD[i].borrowedV.equals("No"))
              { 
                System.out.println("********");
                tabD[i].DisplD();
                System.out.println("********");
                rentD=i;
              }
        }
      }
      String ask=JOptionPane.showInputDialog("Person's ID: ?");
      tabD[rentD].borrowedV=ask;
   }
    //DVD
    
    public void AddDvd ()
 {   
    int quantityloop=0;
    String quantityloop1=JOptionPane.showInputDialog("Quantity?");
    quantityloop=Integer.parseInt(quantityloop1);
    if (quantityloop==1)
    {
    
      String titleV=JOptionPane.showInputDialog("Title?");
      String directorV=JOptionPane.showInputDialog("Director?");
      String actor1V=JOptionPane.showInputDialog("Actor num.1?");
      String actor2V=JOptionPane.showInputDialog("Actor num.2?");
      String actor3V=JOptionPane.showInputDialog("Actor num.3?");
      String duration1=JOptionPane.showInputDialog("Duration?");
      int durationV=Integer.parseInt(duration1);
      String year1=JOptionPane.showInputDialog("Year?");
      int yearV=Integer.parseInt(year1);
      String genderV=JOptionPane.showInputDialog("Gender?");
      String imdb1=JOptionPane.showInputDialog("Imdb number?");
      int imdbV=Integer.parseInt(imdb1);
      int idV=idxV;
      String borrowedV="No";
      String dolby=JOptionPane.showInputDialog("Dolby: ?");
      String subs=JOptionPane.showInputDialog("Subtitles: ?");
      String language=JOptionPane.showInputDialog("Language: ?");
      tabD[idxD]=new Dvd(idV,titleV,borrowedV,directorV,actor1V,actor2V,actor3V,durationV,yearV,genderV,imdbV,dolby,subs,language);
      idxD++;
   }
   if (quantityloop!=1)
   {
      String titleV=JOptionPane.showInputDialog("Title?");
      String directorV=JOptionPane.showInputDialog("Director?");
      String actor1V=JOptionPane.showInputDialog("Actor num.1?");
      String actor2V=JOptionPane.showInputDialog("Actor num.2?");
      String actor3V=JOptionPane.showInputDialog("Actor num.3?");
      String duration1=JOptionPane.showInputDialog("Duration?");
      int durationV=Integer.parseInt(duration1);
      String year1=JOptionPane.showInputDialog("Year?");
      int yearV=Integer.parseInt(year1);
      String genderV=JOptionPane.showInputDialog("Gender?");
      String imdb1=JOptionPane.showInputDialog("Imdb number?");
      int imdbV=Integer.parseInt(imdb1);
      String borrowedV="No";
      String dolby=JOptionPane.showInputDialog("Dolby: ?");
      String subs=JOptionPane.showInputDialog("Subtitles: ?");
      String language=JOptionPane.showInputDialog("Language: ?");
      for(int i=0;i<quantityloop;i++)
      {
      int idV=idxD;
      tabD[idxD]=new Dvd(idV,titleV,borrowedV,directorV,actor1V,actor2V,actor3V,durationV,yearV,genderV,imdbV,dolby,subs,language);
      idxD++;
      }
        
      
   }
   
   
 }
    
     
//Save and Load for Persons
  



public BufferedWriter OpenOutFile( String name )
{
        try 
        {
            FileWriter tmpOut = new FileWriter( name );
            return new BufferedWriter( tmpOut );
        }
        catch (Exception e) 
        { 
            System.out.println( "open out file '" + name + "' ERROR!" );
        }
        return null;
}
    
    public BufferedReader OpenInFile( String name )
    {
        try 
        {
            FileReader tmpIn = new FileReader( name );    
          return new BufferedReader( tmpIn );
        }
        catch (Exception e) 
        { 
            System.out.println( "open in file '" + name + "' ERROR!" );
        }
        return null;
    }   
    
    public boolean LoadFile( String name )
    {
      int l=0;
      
        BufferedReader in = OpenInFile( name );
        if ( in == null )
            return false;        

      String line1;            
        System.out.println(" Reading from "+name+" file --------" );  
        try
        {
          while ( (line1=in.readLine()) != null )
          {
              System.out.print("Line"+l+": ");  
              StringTokenizer stringTokens = new StringTokenizer( line1,";" );
              int countTokens  = stringTokens.countTokens();
          String idX="";
          String nameX="??";
          String peselX="";
          int ageX=0;
          String ageX1=String.valueOf(ageX);
          String addressX="??";
          String cityX="??";
          String postalX="??";
          String phoneX="??";
          String a=" ";
          for ( int i=0; i<countTokens; i++ ) 
          {         
            String token = stringTokens.nextToken();
            System.out.print(token);
            
            if (i==0) idX=token;
            if (i==1) nameX=token;
            if (i==2) peselX=token;
            if (i==3) ageX1=token;
            if (i==4) addressX=token;
            if (i==5) cityX=token;
            if (i==6) postalX=token;
            if (i==7) phoneX=token;
                  
          }
              tab[l]=new Person(idX,nameX,peselX,ageX,addressX,cityX,postalX,phoneX);
              l++;
              System.out.println();        
          }
        }
      catch (IOException e )
      {}
      
      return true;
    }
    
    public void save( BufferedWriter outBuf )
    {
            try
            {
              for( int i=0; i<tab.length; i++ )
              {   
                if (tab[i]!=null)
                {
                  String str=tab[i].id +";"+tab[i].name+";"+tab[i].pesel+";"+ tab[i].age+";"+tab[i].address+";"+tab[i].city+";"+tab[i].postal+";"+tab[i].phone+ "\n";
                  
                  outBuf.write( str );
                }
              } 
            }
            catch (Exception e) { 
                System.out.println( "save ERROR!" );
                                }
    }
               
    public boolean SaveFile( String name )
    {
        BufferedWriter out = OpenOutFile( name );
        if ( out == null )
            return false;        
    
        save( out );
        
        try 
        {    
            out.close();
            return true;
        }
        catch (Exception e) 
        { 
            System.out.println( "close out file '" + name + "' ERROR!" );
        }
        return false;
    }    
    


  //Save and Load for Vhs

public BufferedWriter OpenOutFileV( String name )
{
        try 
        {
            FileWriter tmpOut = new FileWriter( name );
            return new BufferedWriter( tmpOut );
        }
        catch (Exception e) 
        { 
            System.out.println( "open out file '" + name + "' ERROR!" );
        }
        return null;
}
    
    public BufferedReader OpenInFileV( String name )
    {
        try 
        {
            FileReader tmpIn = new FileReader( name );    
          return new BufferedReader( tmpIn );
        }
        catch (Exception e) 
        { 
            System.out.println( "open in file '" + name + "' ERROR!" );
        }
        return null;
    }   
    
    public boolean LoadFileV ( String nameV )
    {
      int l=0;
      
        BufferedReader in = OpenInFile( nameV );
        if ( in == null )
            return false;        

      String line1;            
        System.out.println(" Reading from "+nameV+" file --------" );  
        try
        {
          while ( (line1=in.readLine()) != null )
          {
              System.out.print("Line"+l+": ");  
              StringTokenizer stringTokens = new StringTokenizer( line1, ";" );
              int countTokens  = stringTokens.countTokens();
          int idXV=0;
          String idXV1=String.valueOf(idXV);
          String titleXV="??";
          String borrowedXV="No";
          String directorXV="";
          String actor1XV="";
          String actor2XV="";
          String actor3XV="";
          int durationXV=0;
          String durationXV1=String.valueOf(durationXV);
          int yearXV=0;
          String yearXV1=String.valueOf(yearXV);
          String genderXV="??";
          int imdbXV=0;
          String imdbXV1=String.valueOf(imdbXV);
          for ( int i=0; i<countTokens; i++ ) 
          {         
            String tokenV = stringTokens.nextToken();
            System.out.print(tokenV);
            
            if (i==0) idXV1=tokenV;
            if (i==1) titleXV=tokenV;
            if (i==2) borrowedXV=tokenV;
            if (i==3) directorXV=tokenV;
            if (i==4) actor1XV=tokenV;
            if (i==5) actor2XV=tokenV;
            if (i==6) actor3XV=tokenV;
            if (i==7) durationXV1=tokenV;
            if (i==8) yearXV1=tokenV;
            if (i==9) genderXV=tokenV;
           // if (i==10) imdbXV=tokenV;
          }
              tabV[l]=new Vhs (idXV,titleXV,borrowedXV,directorXV,actor1XV,actor2XV,actor3XV,durationXV,yearXV,genderXV,imdbXV);
              l++;
              System.out.println();        
          }
        }
      catch (IOException e )
      {}
      
      return true;
    }
    
    public void saveV ( BufferedWriter outBufV )
    {
            try
            {
              for( int i=0; i<tabV.length; i++ )
              {   
                if (tabV[i]!=null)
                {
                  String str=tabV[i].idV +";"+tabV[i].titleV+";"+tabV[i].borrowedV+";"+ tabV[i].directorV+";"+tabV[i].actor1V+";"+tabV[i].actor2V+";"+tabV[i].actor3V+";"+tabV[i].durationV+";"+tabV[i].yearV+";"+tabV[i].genderV+";"+tabV[i].imdbV+"\n";
                  
                  outBufV.write( str );
                }
              } 
            }
            catch (Exception e) { 
                System.out.println( "save ERROR!" );
                                }
    }
               
    public boolean SaveFileV ( String nameV )
    {
        BufferedWriter outV = OpenOutFileV( nameV );
        if ( outV == null )
            return false;        
    
        saveV( outV );
        
        try 
        {    
            outV.close();
            return true;
        }
        catch (Exception e) 
        { 
            System.out.println( "close out file '" + nameV + "' ERROR!" );
        }
        return false;
    }    
    
public BufferedWriter OpenOutFileD( String name )
{
        try 
        {
            FileWriter tmpOut = new FileWriter( name );
            return new BufferedWriter( tmpOut );
        }
        catch (Exception e) 
        { 
            System.out.println( "open out file '" + name + "' ERROR!" );
        }
        return null;
}
    
    public BufferedReader OpenInFileD( String name )
    {
        try 
        {
            FileReader tmpIn = new FileReader( name );    
          return new BufferedReader( tmpIn );
        }
        catch (Exception e) 
        { 
            System.out.println( "open in file '" + name + "' ERROR!" );
        }
        return null;
    }   
    
    public boolean LoadFileD ( String nameD )
    {
      int l=0;
      
        BufferedReader in = OpenInFile( nameD );
        if ( in == null )
            return false;        

      String line1;            
        System.out.println(" Reading from "+nameD+" file --------" );  
        try
        {
          while ( (line1=in.readLine()) != null )
          {
              System.out.print("Line"+l+": ");  
              StringTokenizer stringTokens = new StringTokenizer( line1,";");
              int countTokens  = stringTokens.countTokens();
          int idXV=0;
          String idXV1=String.valueOf(idXV);
          String titleXV="??";
          String borrowedXV="No";
          String directorXV="";
          String actor1XV="";
          String actor2XV="";
          String actor3XV="";
          int durationXV=0;
          String durationXV1=String.valueOf(durationXV);
          int yearXV=0;
          String yearXV1=String.valueOf(yearXV);
          String genderXV="??";
          int imdbXV=0;
          String imdbXV1=String.valueOf(imdbXV);
          String dolbyX="";
          String subsX="";
          String languageX="";
          for ( int i=0; i<countTokens; i++ ) 
          {         
            String token = stringTokens.nextToken();
            System.out.print(token);
            
            if (i==0) idXV1=token;
            if (i==1) titleXV=token;
            if (i==2) borrowedXV=token;
            if (i==3) directorXV=token;
            if (i==4) actor1XV=token;
            if (i==5) actor2XV=token;
            if (i==6) actor3XV=token;
            if (i==7) durationXV1=token;
            if (i==8) yearXV1=token;
            if (i==9) genderXV=token;
            if (i==10) imdbXV1=token;
            if (i==11) dolbyX=token;
            if (i==12) subsX=token;
            if (i==13) languageX=token;
            
          }
              tabD[l]=new Dvd (idXV,titleXV,borrowedXV,directorXV,actor1XV,actor2XV,actor3XV,durationXV,yearXV,genderXV,imdbXV,dolbyX,subsX,languageX);
              l++;
              System.out.println();        
          }
        }
      catch (IOException e )
      {}
      
      return true;
    }
    
    public void saveD ( BufferedWriter outBufD )
    {
            try
            {
              for( int i=0; i<tabD.length; i++ )
              {   
                if (tabD[i]!=null)
                {
                  String str=tabD[i].idV +";"+tabD[i].titleV+";"+tabD[i].borrowedV+";"+ tabD[i].directorV+";"+tabD[i].actor1V+";"+tabD[i].actor2V+";"+tabD[i].actor3V+";"+tabD[i].durationV+";"+tabD[i].yearV+";"+tabD[i].genderV+";"+tabD[i].imdbV+";"+tabD[i].dolby+";"+tabD[i].subs+";"+tabD[i].language+"\n";
                  
                  outBufD.write( str );
                }
              } 
            }
            catch (Exception e) { 
                System.out.println( "save ERROR!" );
                                }
    }
               
    public boolean SaveFileD ( String nameD )
    {
        BufferedWriter outD = OpenOutFileD( nameD );
        if ( outD == null )
            return false;        
    
        saveD( outD );
        
        try 
        {    
            outD.close();
            return true;
        }
        catch (Exception e) 
        { 
            System.out.println( "close out file '" + nameD + "' ERROR!" );
        }
        return false;
    }    
    
}
class Person {
      String id;
      String name;
      String pesel; 
      int age;
      String address;
      String city;
      String postal;
      String phone;
      
  
    public Person ()
    {
      id="";
      name="";
      pesel="";
      age=0;
      address="";
      city="";
      postal="";
      phone="";   
    }
  
  public Person (String id,String name,String pesel,int age,String address,String city,String postal,String phone)
  {
    this.id=id;
    this.name=name;
    this.pesel=pesel;
    this.age=age;
    this.address=address;
    this.city=city;
    this.postal=postal;
    this.phone=phone;    
  }
  
  public Person (String id,String name,String pesel,int age,String address,String city,String postal)
  {
    this.id=id;
    this.name=name;
    this.pesel=pesel;
    this.age=age;
    this.address=address;
    this.city=city;
    this.postal=postal;
    this.phone="Nie podano";    
  }
  public Person (String id,String name,String pesel,String address,String city,String postal)
  {
    this.id=id;
    this.name=name;
    this.pesel=pesel;
    this.age=666;
    this.address=address;
    this.city=city;
    this.postal=postal;
    this.phone="Nie podano";    
  }
  
  public void Displ()
  {
    System.out.println ("Id: "+id+" Name:"+name+" Pesel: "+pesel+" Age: "+age+" Address: "+address+" City: "+city+" Postal Code: "+postal+" Phone: "+phone);
  }
   
} 

class Vhs {
  int idV;
  String titleV;
  String directorV;
  String actor1V;
  String actor2V;
  String actor3V;
  int durationV;
  int yearV;
  String genderV;
  int imdbV;
  String borrowedV;
  
  public Vhs ()
  {
    idV=0; 
    titleV="";
    directorV="";
    actor1V="";
    actor2V="";
    actor3V="";
    durationV=0;
    yearV=0;
    genderV="";
    imdbV=0;
    String borrowedV="No";
  }
  
  
  public Vhs (int idV,String titleV,String borrowedV,String directorV,String actor1V,String actor2V,String actor3V,int durationV,int yearV,String genderV,int imdbV)
    {
      this.idV=idV;
      this.titleV=titleV;
      this.directorV=directorV;
      this.actor1V=actor1V;
      this.actor2V=actor2V;
      this.actor3V=actor3V;
      this.durationV=durationV;
      this.yearV=yearV;
      this.genderV=genderV;
      this.imdbV=imdbV;
      this.borrowedV=borrowedV;
    }
    
    public void DisplV()
  {
    System.out.println ("ID: "+idV+" Title: "+titleV+" Borrowed: "+borrowedV+" Director: "+directorV+" Actors: "+actor1V+","+actor2V+","+actor3V+" Duration: "+durationV+" Year: "+yearV+" Gender: "+genderV+" Imdb: "+imdbV);
  }
    
}    
 class Dvd extends Vhs
  {
     String dolby;
     String subs;
     String language;
     

  public Dvd (int idV,String titleV,String borrowedV,String directorV,String actor1V,String actor2V,String actor3V,int durationV,int yearV,String genderV,int imdbV,String dolby,String subs,String language)
  {
  
    super(idV,titleV,borrowedV,directorV,actor1V,actor2V,actor3V,durationV,yearV,genderV,imdbV);
    this.dolby = dolby;
    this.subs=subs;
    this.language=language;
  }
public void DisplD()
  {
    System.out.println ("ID: "+idV+" Title: "+titleV+" Borrowed: "+borrowedV+" Director: "+directorV+" Actors: "+actor1V+","+actor2V+","+actor3V+" Duration: "+durationV+" Year: "+yearV+" Gender: "+genderV+" Imdb: "+imdbV+" Dolby: "+dolby+" Subs: "+subs+ " Language: "+language);
  }
 
 }