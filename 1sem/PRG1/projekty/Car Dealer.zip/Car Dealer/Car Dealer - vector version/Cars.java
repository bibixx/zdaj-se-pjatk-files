import java.io.*;
import javax.swing.*;
import java.util.*;
class Cars

{
	public int indx;
	public Vector dbase=new Vector();
	public Vector dbaseHis=new Vector();
	public static void main (String[]args)
 	{
		new Cars();		
	}
public Cars()
{
 	while (true)
	{
	
			
		
		System.out.println("             ________             ");
		System.out.println("            /   |    [            ");
		System.out.println("      _____/____|_____[____/      ");
		System.out.println("     /<    |   =|    =|    [      ");
		System.out.println("    /__OO__|____|_____|OO_||      ");
		System.out.println("       OO              OO         ");
		
		
	
		String str = JOptionPane.showInputDialog("Choose from 0 to 6 or a LETTER(A to D)"+
		"\n 1. Add new car to database\n 2. Display available cars\n 3. Sell car "+
		"\n 4. Display Transaction history (sold cars)"+
		"\n ----------FINDING OPTIONS------------------\n"+
		" a)Find car by brand\n b)Find car by model\n"+
		" c)Find car by price(your highest)\n"+
		" d)Find car by year \n"+
		" ------------SAVE AND LOAD------------------ \n"+
		" 5. Save available cars to file\n"+
		" 6. Load available cars from file\n"+
		"------------------------------------------------------\n"+
		"0. Exit");  
		                           
		 
	
	
		if (str.equals ("1")) AddCar();
		if (str.equals ("2")) DisplayAllC();
		if (str.equals ("3")) DeleteCar();
		if (str.equals ("4")) DisplayHis();
		if (str.equals ("a")) FindCar();
		if (str.equals ("b")) FindMod();
		if (str.equals ("c")) FindPrice();
		if (str.equals ("d")) FindYear();
		if (str.equals ("5")) SaveFile("cars.txt");
		if (str.equals ("6")) LoadFile("cars.txt");
	    if (str.equals ("0")) System.out.println("HAVE A NICE DAY!!!");
	    if (str.equals ("0")) System.exit(0);
	
	} 
} 

public void AddCar()
{
	
	String brand = JOptionPane.showInputDialog("What is the car brand?");
	String model = JOptionPane.showInputDialog("What is the model?");
	String made = JOptionPane.showInputDialog("What is the year of production?");
	String colour = JOptionPane.showInputDialog("What is the colour?");
	String price = JOptionPane.showInputDialog("What is the car price?");
	String interior = JOptionPane.showInputDialog("What is the colour of interior?");
	Car x=new Car (brand, model, made, colour, price, interior);
	dbase.add(x);
	
}

public void FindMod()
{
	String str = JOptionPane.showInputDialog(" Write a model of  the car which you are looking for. ");
	for (int i=0;i<dbase.size();i++)
        {
        	Car x = (Car)dbase.elementAt(i);
		 		if (x!=null)
            	 if (x.model.equalsIgnoreCase(str))
            	  
              { 
                System.out.println("********");
                System.out.println( x.CarToString() );
                System.out.println("********");
                
              }
        }
 }

public void DisplayAllC()
     {
      for (int i=0;i<dbase.size();i++) 
          {
            Car x = (Car)dbase.elementAt(i);
			System.out.println( x.CarToString() );
          } 
    }
    
    public void DisplayHis()
     {
      for (int i=0;i<dbaseHis.size();i++) 
          {
            Car x = (Car)dbaseHis.elementAt(i);
			System.out.println( x.CarToString() );
          } 
    }


public void FindCar()
{
	String str = JOptionPane.showInputDialog(" Write a brand of  the car which you are looking for. ");
	for (int i=0;i<dbase.size();i++)
        {
        	Car x = (Car)dbase.elementAt(i);
		 		if (x!=null)
            	 if (x.brand.equalsIgnoreCase(str))
            	  
              { 
                System.out.println("********");
                System.out.println( x.CarToString() );
                System.out.println("********");
                
              }
        }
}



public void FindPrice()
{
	String MyPrice = JOptionPane.showInputDialog(" Write a highest price of  the car which you are looking for. ");
	int Mprice= Integer.parseInt(MyPrice);
		for (int i=0;i<dbase.size();i++)
        {
        	Car x = (Car)dbase.elementAt(i);
		 		if (x!=null)
            	 
            	  
              { 
              
              int yy=Integer.parseInt(x.price);
                if (Mprice >= yy)
					{
						System.out.println("######################################");
						System.out.println( x.CarToString() );
						System.out.println("######################################");
					}
                
              }
        }
		
}



public void FindYear()
{
	String str = JOptionPane.showInputDialog(" Write a production year of the car which you are looking for. ");
	for (int i=0;i<dbase.size();i++)
        {
        	Car x = (Car)dbase.elementAt(i);
		 		if (x!=null)
            	 if (x.made.equalsIgnoreCase(str))
            	  
              { 
                System.out.println("********");
                System.out.println( x.CarToString() );
                System.out.println("********");
                
              }
        }
}

public void DeleteCar()
{
	String str = JOptionPane.showInputDialog("Which car (brand) is being sold?");
for (int i=0;i<dbase.size();i++)
        {
        	Car x = (Car)dbase.elementAt(i);
		 		if (x!=null)
            	 if (x.brand.equalsIgnoreCase(str))
            	  
              { 
                System.out.println("Selling...");
                dbaseHis.add(x);
                dbase.remove(x);
                System.out.println("Sold. Deleted from available cars completed.");
                
              }
        }
}



public void save ( BufferedWriter outBuf )
    {
            try
            {
              for( int i=0; i<dbase.size(); i++ )
              {   
                
                
                Car x = (Car)dbase.elementAt(i);
                	if (x!=null) {
                  String str=x.brand+" "+x.model+" "+x.made+" "+x.made+" "+x.colour+" "+x.price+" "+x.interior+"\n";
                  
                  outBuf.write( str );
                  }
                }
              } 
            catch (Exception e) { 
                System.out.println( "save ERROR!" );
                                }
    
}

public BufferedWriter OpenOutFile( String name )
{
        try 
        {
            FileWriter tmpOut = new FileWriter( name );
            return new BufferedWriter( tmpOut );
        }
        catch (Exception e) 
        { 
            System.out.println( "open out file '" + name + "' ERROR!" );
        }
        return null;
}  
    
    
    //**********************************************************
   	public BufferedReader OpenInFile( String name )
    {
        try 
        {
            FileReader tmpIn = new FileReader( name );    
          return new BufferedReader( tmpIn );
        }
        catch (Exception e) 
        { 
            System.out.println( "open in file '" + name + "' ERROR!" );
        }
        return null;
    }    
  
  
    //**********************************************************
    public boolean SaveFile ( String name )
    {
        BufferedWriter out = OpenOutFile( name );
        if ( out == null )
            return false;        
    
        save( out );
        
        try 
        {    
            out.close();
            return true;
        }
        catch (Exception e) 
        { 
            System.out.println( "close out file '" + name + "' ERROR!" );
        }
        return false;
    }     
  
  
    //**********************************************************
    public blean LoadFile( String name )
    {
    	int l=0;
    	BufferedReader in = OpenInFile( name );
        
        if ( in == null )
            return false;        

		String line1;            
       	System.out.println(" Reading from "+ name +" file --------" );	
       	try
       	{
        	while ( (line1=in.readLine()) != null )
        	{
	           	System.out.print("Line"+l+": ");	
			   	StringTokenizer stringTokens = new StringTokenizer( line1 );
            	int countTokens  = stringTokens.countTokens();
    
	    	  	String brandX = "unknown";
	    	  	String modelX ="unknown";
	    	  	String madeX ="unknown";
	    	  	String colourX ="unknown";
	    	  	String priceX ="unknown";
	    	  	String interiorX="unknown";
	    	  	
	    	  		    	  	
	    	  		for ( int i=0; i<countTokens; i++ ) {  	
	   				String token = stringTokens.nextToken();
    	       		System.out.print(token);	
    	 		if (i==0) brandX= token;
    	 		if (i==1) modelX = token;
    	 	    if (i==2) madeX= token; 
    	 	    if (i==3) colourX= token;
    	 	    if (i==4) priceX = token;
    	 	    if (i==5) interiorX = token;	           	}
           	
           		Car x= new Car(brandX, modelX, madeX, colourX, priceX,interiorX);
           		l++;
           		indx=l;
           		dbase.add(x);
           		System.out.println();	    	 	
    		}
    	}
    	catch (IOException e )
    	{}
    	
    	return true;
   }

}




class Car
	{
		String brand;
		String model;
		String made;
		String colour;
		String price;
		String interior;
	
		
	public Car (String brand, String model, String made, String colour, String interior, String price)
		{
			this.brand = brand;
			this.model = model;
			this.made = made;
			this.colour = colour;
			this.price = interior;
			this.interior = price;			
		}
	
		
			
		public String CarToString()
			{   
		 return("############################################"+"\n"+
				" Brand : " +brand+","+"\n"+
				" Model: " +model+","+"\n"+
				" Year of production: " +made+","+"\n"+
				" Colour: " +colour+","+"\n"+
				" Interior colour: " +interior+ ","+"\n"+ 
				" Price: " +price+ "."+"\n"+	
			    "############################################");
			}
	
	}

