import java.io.*;
import javax.swing.*;
import java.util.*;
class Cars

{
	public int indx;
	public Car tab[]=new Car[100];
	public Car tabHis[]=new Car[100]; 
	public static void main (String[]args)

 	{
		new Cars();		
}
public Cars()
{
 	while (true)
	{
	
			
		
		System.out.println("             ________             ");
		System.out.println("            /   |    [            ");
		System.out.println("      _____/____|_____[____/      ");
		System.out.println("     /<    |   =|    =|    [      ");
		System.out.println("    /__OO__|____|_____|OO_||      ");
		System.out.println("       OO              OO         ");
		
		
	
		String str = JOptionPane.showInputDialog("Choose from 0 to 6 or a LETTER(A to D)"+
		"\n 1. Add new car to database\n 2. Display available cars\n 3. Sell car "+
		"\n 4. Display Transaction history (sold cars)"+
		"\n ----------FINDING OPTIONS------------------\n"+
		" a)Find car by brand\n b)Find car by model\n"+
		" c)Find car by price(your highest)\n"+
		" d)Find car by year \n"+
		" ------------SAVE AND LOAD------------------ \n"+
		" 5. Save available cars to file\n"+
		" 6. Load available cars from file\n"+
		"------------------------------------------------------\n"+
		"0. Exit");  
		                           
		 
	
	
		if (str.equals ("1")) AddCar();
		if (str.equals ("2")) DisplayAll();
		if (str.equals ("3")) DeleteCar();
		if (str.equals ("4")) DisplayHis();
		if (str.equals ("a")) FindCar();
		if (str.equals ("b")) FindMod();
		if (str.equals ("c")) FindPrice();
		if (str.equals ("d")) FindYear();
		if (str.equals ("5")) SaveFile("cars.txt");
		if (str.equals ("6")) LoadFile("cars.txt");
	    if (str.equals ("0")) System.out.println("HAVE A NICE DAY!!!");
	    if (str.equals ("0")) System.exit(0);
	
	} 
} 

public void AddCar()
{
	
	String brand = JOptionPane.showInputDialog("What is the car brand?");
	String model = JOptionPane.showInputDialog("What is the model?");
	String made = JOptionPane.showInputDialog("What is the year of production?");
	String colour = JOptionPane.showInputDialog("What is the colour?");
	String price = JOptionPane.showInputDialog("What is the car price?");
	String interior = JOptionPane.showInputDialog("What is the colour of interior?");
	
	tab[indx] = new Car (brand, model, made, colour, price, interior);
	
}

public void FindMod()
{
	String str = JOptionPane.showInputDialog(" Write a model of  the car which you are looking for. ");
	for (int i=0; i<tab.length; i++)
	if (tab[i]!=null)
		if (tab[i].model.equals(str))
			{
				System.out.println("######################################");
				System.out.println("######################################");
				tab[i].displ();
	         }	  
	  }



public void FindCar()
{
	String str = JOptionPane.showInputDialog(" Write a brand of  the car which you are looking for. ");
	for (int i=0; i<tab.length; i++)
	if (tab[i]!=null)
		if (tab[i].brand.equals(str))
			{
				System.out.println("######################################");
				System.out.println("######################################");
				tab[i].displ();
			}
}



public void FindPrice()
{
	String MyPrice = JOptionPane.showInputDialog(" Write a highest price of  the car which you are looking for. ");
	int Mprice= Integer.parseInt(MyPrice);
		for (int i=0; i< tab.length; i++)
	if (tab[i]!=null)
		if (Mprice >= Integer.parseInt(tab[i].price))
	{				System.out.println("######################################");
					System.out.println("######################################");
				tab[i].displ();
			}
}



public void FindYear()
{
	String str = JOptionPane.showInputDialog(" Write a production year of the car which you are looking for. ");
	for (int i=0; i<tab.length; i++)
	if (tab[i]!=null)
		if (tab[i].made.equals(str))
			{
				System.out.println("######################################");
				System.out.println("######################################");
				tab[i].displ();
			}

}

public void DeleteCar()
{
	String str = JOptionPane.showInputDialog("Which car (brand) is being sold?");
	for (int i=0; i<tab.length; i++)
	if (tab[i]!=null)
		if (tab[i].brand.equals(str))
			{
				System.out.println("######################################");
				System.out.println("######################################");
				tab[i].displ();
				tabHis[i]=tab[i];
			  	tab[i]=null;
			}
}


public void DisplayAll()
{
	for (int i=0; i<tab.length; i++) if (tab[i]!=null) tab[i].displ();
}

public void DisplayHis()
{
	for (int i=0; i<tabHis.length; i++) if (tabHis[i]!=null) tabHis[i].displ();
}	



public void save (BufferedWriter outBuf)
{
	try
	{
		for( int i=0; i<tab.length; i++)
		{
			if(tab[i] != null)
			{
				String str =" "+ tab[i].brand +" "+ tab[i].model+" " +tab[i].made+" "+tab[i].colour+ " " +tab[i].price+" "+tab[i].interior+"\n";
				outBuf.write(str);
			}
		}
	}
	catch(Exception e) {
		System.out.println (" save ERROR!");
	}
}

public BufferedWriter OpenOutFile( String brand )
    {
        try {
            FileWriter tmpOut = new FileWriter( brand );
            return new BufferedWriter( tmpOut );
        }
        catch (Exception e) {
            System.out.println( "open out file '" + brand + "' ERROR!" );
        }
        return null;
    }       
    
    
    //**********************************************************
   	public BufferedReader OpenInFile( String brand )
    {
        try {
            FileReader tmpIn = new FileReader( brand );    
        	return new BufferedReader( tmpIn );
        }
        catch (Exception e) { 
            System.out.println( "open in file '" + brand + "' ERROR!" );
        }
        return null;
    }    
  
  
    //**********************************************************
    public boolean SaveFile( String brand )
    {
        BufferedWriter out = OpenOutFile( brand );
        if ( out == null )
            return false;        
    
        save( out );
        
        try {    
            out.close();
            return true;
        }
        catch (Exception e) { 
            System.out.println( "close out file '" + brand + "' ERROR!" );
        }
        return false;
    }    
  
  
    //**********************************************************
    public boolean LoadFile( String brand )
    {
    	int l=0;
    	BufferedReader in = OpenInFile( brand );
        
        if ( in == null )
            return false;        

		String line1;            
       	System.out.println(" Reading from "+ brand +" file --------" );	
       	try
       	{
        	while ( (line1=in.readLine()) != null )
        	{
	           	System.out.print("Line"+l+": ");	
			   	StringTokenizer stringTokens = new StringTokenizer( line1 );
            	int countTokens  = stringTokens.countTokens();
    
	    	  	String brandX = "unknown";
	    	  	String modelX ="unknown";
	    	  	String madeX ="unknown";
	    	  	String colourX ="unknown";
	    	  	String priceX ="unknown";
	    	  	String interiorX="unknown";
	    	  	
	    	  		    	  	
	    	  		for ( int i=0; i<countTokens; i++ ) {  	
	   				String token = stringTokens.nextToken();
    	       		System.out.print(token);	
    	 		if (i==0) brandX= token;
    	 		if (i==1) modelX = token;
    	 	    if (i==2) madeX= token; 
    	 	    if (i==3) colourX= token;
    	 	    if (i==4) priceX = token;
    	 	    if (i==5) interiorX = token;	           	}
           	
           		tab[l] = new Car(brandX, modelX, madeX, colourX, priceX,interiorX);
           		l++;
           		indx=l;
           		System.out.println();	    	 	
    		}
    	}
    	catch (IOException e )
    	{}
    	
    	return true;
   }


}//close Cars



class Car
	{
		String brand;
		String model;
		String made;
		String colour;
		String price;
		String interior;
	
		
	public Car (String brand, String model, String made, String colour, String interior, String price)
		{
			this.brand = brand;
			this.model = model;
			this.made = made;
			this.colour = colour;
			this.price = interior;
			this.interior = price;			
		}
	
		
			
		public void displ()
			{   
			    System.out.println("############################################");
				System.out.println(" Brand : " +brand+",");
				System.out.println(" Model: " +model+",");
				System.out.println(" Year of production: " +made+",");
				System.out.println(" Colour: " +colour+",");
				System.out.println(" Interior colour: " +interior+ ","); 
				System.out.println(" Price: " +price+ ".");	
			    System.out.println("############################################");
			}
	
	}

