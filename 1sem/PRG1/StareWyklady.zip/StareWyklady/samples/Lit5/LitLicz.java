public class LitLicz {

  public static void main(String[] args) {

    System.out.println( 10 + 0x10 );   
    System.out.println( 10/3 );      
    System.out.println( 10./3 );
    System.out.println( 10d/3);
    System.out.println( 2147483648L );
    System.out.println( 2147483647 + 1 );
    System.out.println( 2147483647L + 1 );

  }
}
 
     