public class LitZn {

  public static void main(String[] args) {

    System.out.print('a');
    System.out.print('\u0061');
    System.out.print('\\');
    System.out.print('\'');   
    System.out.print(" Ala ma kota "); 
    System.out.println("Pierwszy\nDrugi\nTrzeci");
    System.out.println("c:\\util\\bak");
    System.out.println("");
    System.out.println("\"");
    System.out.print("abcd\r12\n1234\rab");
  }
}
 
     