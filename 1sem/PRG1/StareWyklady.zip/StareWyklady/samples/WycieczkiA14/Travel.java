public class Travel {

   private String dest;
   private double price;

   public Travel(String s, double p) {
     dest = s;
     price = p;
   }

   public String getDest() { return dest; }
   public double getPrice() { return price; }

}
 


