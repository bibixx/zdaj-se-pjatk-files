public class ParaSetAndShow {

  public static void main(String[] args) {
    
    Para para1 = new Para();
    para1.set( 1, 2 );
    para1.show(); 

  }

}
 
     