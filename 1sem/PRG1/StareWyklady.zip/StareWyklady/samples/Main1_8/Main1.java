 
public class Main1 {
 
  public static void main(String[] args) {
    double a = 12.0,
           b = 14.0,
           c =  4.0;
    double sum = a + b + c;
    double avg = (a + b + c)/3;
    System.out.println("Suma " + sum);
    System.out.println("Srednia " + avg);
    a++;
    b++;
    c++;
    sum = a + b + c;
    avg = (a + b + c)/3;
    System.out.println("Suma " + sum);
    System.out.println("Srednia " + avg);
    a++;
    b++;
    c++;
    sum = a + b + c;
    avg = (a + b + c)/3;
    System.out.println("Suma " + sum);
    System.out.println("Srednia " + avg);
 
  } 
 
}
