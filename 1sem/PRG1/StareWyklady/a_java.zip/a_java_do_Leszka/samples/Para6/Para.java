class Para {

  private int a;
  private int b;

  void set(int x, int y) {
    a = x;
    b = y;
  }

  void show() {
    System.out.println( "( " + a + " , " + b + " )" );
  }

}