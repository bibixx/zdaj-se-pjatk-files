 
public class NoCatch {
 
  public static void main(String[] args) {
    int a = 1, b = 0, c = 0;
    c = a/b;
    System.out.println(c);
  } 
 
}
