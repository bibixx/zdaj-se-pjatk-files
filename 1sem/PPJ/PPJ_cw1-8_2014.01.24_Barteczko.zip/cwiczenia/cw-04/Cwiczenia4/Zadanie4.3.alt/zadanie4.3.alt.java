import javax.swing.*;

class Main {
	public static void main(String[] args) {
		String x;
		String initformula="";
		do{
			x = (String)javax.swing.JOptionPane.showInputDialog(null, "dzialanie:", "kalkulator", javax.swing.JOptionPane.QUESTION_MESSAGE, null, null, initformula);
			if(x==null || x.equals("KONIEC")) break;
			initformula="";
			String num1="";
			String num2="";
			int numlen=0;
			char dzialanie=0;
			for(int i=0;i<x.length();i++){
				char c=x.charAt(i);
				if(c==' '){
					continue;
				}
				if(c>='0' && c<='9' || c=='.' || (numlen==0 && c=='-')){
					if(dzialanie == 0){
						if(c=='.' && numlen==0){
							num1+='0';
						}else if(numlen==1){
							if(num1.charAt(0)=='-') num1+='0';
						}
						num1+=c;
					}else{
						if(c=='.' && numlen==0 || (numlen==1 && num2.charAt(0)=='-')){
							num2+='0';
						}else if(numlen==1){
							if(num2.charAt(0)=='-') num2+='0';
						}
						num2+=c;
					}
					numlen++;
				}else if(c=='-'||c=='+'||c=='*'||c=='/'){
					if(dzialanie == 0){
						dzialanie = c;
						if(num1.length()==0 || (num1.length()==1 && num1.charAt(0)=='-')) num1="0.0";
					}else{
						break; //wprowadzono 2x znak dzialania
					}
					numlen=0;
				}else{
					//wprowadzono nieznany znak
				}
			}
			String out="";
			if(num1.length()>=1){
				double num1d = Double.parseDouble(num1);
				if(dzialanie != 0){
					if(num2.length()>=1){
						double num2d = Double.parseDouble(num2);
						out = num1d+" "+dzialanie+" "+num2d+" = ";
						switch(dzialanie){
							case '+':
								out+=(num1d+num2d);
								break;
							case '-':
								out+=(num1d-num2d);
								break;
							case '*':
								out+=(num1d*num2d);
								break;
							case '/':
								if(num2d != 0.0){
									out+=(num1d/num2d);
								}else{
									out="dzielenie przez 0. popraw dzialanie";
									initformula = num1d+" / ";
								}
								break;
						}
					}else{
						out = "brak 2 liczby; wprowadzona liczba: "+num1d;
					}
				}else{
					out = "brak dzialania; wprowadzona liczba: "+num1d;
				}
			}else{
				out = "bledne dzialanie";
			}
			javax.swing.JOptionPane.showMessageDialog(null, out, "Message", javax.swing.JOptionPane.INFORMATION_MESSAGE);
		}while(true);
	}
}