class Account{
	private static double interestrate=0.05;
	public double stan=0.0;
	public Account(double s){
		stan=s;
	}
	public void deposit(double ammount){
		stan+=ammount;
	}
	public boolean withdraw(double ammount){
		if(stan >= ammount){
			stan-=ammount;
			return true;
		}else{
			return false;
		}
	}
	public void transfer(Account receiver, double ammount){
		if(withdraw(ammount)){
			receiver.deposit(ammount);
		}else{
			//odrzucono
		}
	}
	public void addInterest(){
		stan*=(1+interestrate);
	}
	
	public static void setInterestRate(double r){
		interestrate=r/100.0;
	}
}

class Person{
	public String name;
	public Person(String n){
		name = n;
	}
}
class BankCustomer{
	Person personinfo;
	Account acc0;
	public BankCustomer(Person p){
		personinfo=p;
		acc0 = new Account(0.0);
	}
	Account getAccount(){
		return acc0;
	}
	public String toString(){
		return "Klient: "+personinfo.name+" stan konta "+acc0.stan+"";
	}
}

class Main {
	public static void main(String[] args) {
	    Person janP = new Person("Jan"),
	           alaP = new Person("Ala");
	    BankCustomer jan = new BankCustomer(janP);
	    BankCustomer ala = new BankCustomer(alaP);
	    jan.getAccount().deposit(1000);
	    ala.getAccount().deposit(2000);
	    jan.getAccount().transfer(ala.getAccount(), 500);
	    ala.getAccount().withdraw(1000);
	    System.out.println(jan);
	    System.out.println(ala);
	    Account.setInterestRate(4.5);
	    jan.getAccount().addInterest();
	    ala.getAccount().addInterest();
	    System.out.println(jan);
	    System.out.println(ala);
	}
}