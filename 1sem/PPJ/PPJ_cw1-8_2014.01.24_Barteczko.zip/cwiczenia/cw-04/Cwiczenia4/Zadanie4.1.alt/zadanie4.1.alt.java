class Zbiornik{
	double pojemnosc;
	double stan;
	int numer;
	static int n=0;
	public Zbiornik(double p, double s){
		pojemnosc=p;
		stan=s;
		n++;
		numer=n;
	}
	public void dolej(double woda){
		if((stan+woda) > pojemnosc){
			stan = pojemnosc;
		}else{
			stan += woda;
		}
		return;
	}
	public void odlej(double woda){
		if((stan-woda) < 0.0){
			stan = 0.0;
		}else{
			stan -= woda;
		}
		return;
	}
	public void przelej(Zbiornik from, double woda){
		if(from.stan < woda){
			woda = from.stan;
		}
		if((stan+woda) > pojemnosc){
			woda = pojemnosc-stan;
		}
		from.odlej(woda);
		dolej(woda);
		return;
	}
	public String toString(){
		return "Zbiornik nr "+numer+", pojemno�� "+pojemnosc+", stan wody "+stan+"";
	}
	void show(){
		System.out.println(toString());
	}
}

public class Main {
	public static void main(String[] args) {
		Zbiornik z1 = new Zbiornik(10, 5),
				z2 = new Zbiornik(20, 10);
		z1.show();
		z2.show();
		z1.odlej(20);
		z2.dolej(5);
		z1.show();
		z2.show();
		z1.przelej(z2, 50);
		z1.show();
		z2.show();
	}
}