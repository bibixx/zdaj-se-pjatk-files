import javax.swing.*;

class Kalkulator{
	
	public static void main(String[] args){
		
		String x, y[], znak="", wynik="";
		y = new String [1];
			
		do{
			x=JOptionPane.showInputDialog("Dzialanie (postaci [argument][operator][argument]):");
			if(x==null || x.equalsIgnoreCase("koniec")) break;
			
			if(x.indexOf('+')>(-1)) znak="+";
			if(x.indexOf('-')>(-1)) znak="-";
			if(x.indexOf('*')>(-1)) znak="*";
			if(x.indexOf('/')>(-1)) znak="/";
			if(!(x.indexOf('+')>(-1)) && !(x.indexOf('-')>(-1)) && !(x.indexOf('*')>(-1)) && !(x.indexOf('/')>(-1))) znak="e";
			if((x.indexOf('+')>(-1)) || (x.indexOf('-')>(-1)) || (x.indexOf('*')>(-1)) || (x.indexOf('/')>(-1))) y=x.split("\\"+znak,2);
			if(y[1].equals("0")) znak="e";
			if(y[1].contains("+")||y[1].contains("-")||y[1].contains("*")||y[1].contains("/")) znak="e";
			if(y[0].contains("+")||y[0].contains("-")||y[0].contains("*")||y[0].contains("/")) znak="e";
			
			switch(znak){
				case "+":
					wynik=(Double.parseDouble(y[0]))+(Double.parseDouble(y[1]))+"";
					break;
				case "-":
					wynik=(Double.parseDouble(y[0]))-(Double.parseDouble(y[1]))+"";
					break;
				case "*":
					wynik=(Double.parseDouble(y[0]))*(Double.parseDouble(y[1]))+"";
					break;
				case "/":
					wynik=(Double.parseDouble(y[0]))/(Double.parseDouble(y[1]))+"";
					break;
				case "e":
					JOptionPane.showMessageDialog(null, "Niewlasciwy format wyrazenia, wprowadz ponownie.");
					break;
				default:
					break;
			}
			
			if(!znak.equals("e"))JOptionPane.showMessageDialog(null, y[0]+znak+y[1]+"="+wynik);	
			
		}while(true);
		
	}
	
}