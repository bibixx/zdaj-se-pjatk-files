class Account{
	
	private static double interestRate=1;
	public double stan;
	
	public Account(double s){
		stan=s;
	}
	
	public Account(){
		this(0);
	}
	
	public void deposit(double s){
		stan+=s;
	}
	
	public void withdraw(double s){
		if(stan>=s) stan-=s;
		//else stan=0;
		else System.out.println("Niewystarczajaca ilosc srodkow na koncie");
	}
	
	public void transfer(Account acc, double s){
		if(stan<s) s=stan;
		stan-=s;
		acc.stan+=s;
	}
	
	public void addInterest(){
		stan+=(stan*interestRate);
	}
	
	public static void setInterestRate(double s){
		interestRate=s/100;
	}
	
}


class Person{
	
	public String name;
	
	public Person(String p){
		name=p;
	}
	
}


class BankCustomer{
	
	private Person customer;
	private Account acc;
	
	public BankCustomer(Person c, Account a){
		customer=c;
		acc=a;
	}
	
	public BankCustomer(Person c){
		this(c, new Account());
	}
	
	public Account getAccount(){
		return acc;
	}
	
	public String toString(){
		return "Klient: "+customer.name+" stan konta "+acc.stan;
	}
	
}


class BankingTest{
	
	public static void main(String[] args){
		
		Person janP = new Person("Jan");
		Person alaP = new Person("Ala");
		BankCustomer jan = new BankCustomer(janP);
		BankCustomer ala = new BankCustomer(alaP);
		jan.getAccount().deposit(1000);
		ala.getAccount().deposit(2000);
		jan.getAccount().transfer(ala.getAccount(), 500);
		ala.getAccount().withdraw(1000);
		System.out.println(jan);
		System.out.println(ala);
		Account.setInterestRate(4.5);
		jan.getAccount().addInterest();
		ala.getAccount().addInterest();
		System.out.println(jan);
		System.out.println(ala);
		
	}
	
}