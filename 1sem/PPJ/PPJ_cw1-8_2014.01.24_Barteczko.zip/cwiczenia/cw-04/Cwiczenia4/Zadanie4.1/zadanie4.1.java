class Zbiornik{
	
	private double pojemnosc;
	private double stan;
	private int numer;
	private static int n=1;
	
	public Zbiornik(double x, double y){
		pojemnosc=x;
		stan=y;
		numer=n;
		n++;
	}
	
	public Zbiornik(double x){
		this(x, 0);
	}
	
	public void dolej(double x){
		if((x+stan)<pojemnosc) stan+=x;
		else stan=pojemnosc;
	}
	
	public void odlej(double x){
		if((stan-x)<0) stan=0;
		else stan-=x;
	}
	
	public void przelej(Zbiornik zb, double x){
		if(this.stan<x) x=this.stan;
		if((zb.stan+x)>zb.pojemnosc) x=zb.pojemnosc-zb.stan;
		this.stan-=x;
		zb.stan+=x;
	}
	
	public String toString(){
		return "zbiornik nr "+numer+", pojemnosc "+pojemnosc+", stan wody "+stan;
	}
	
	public void show(){
		System.out.println("zbiornik nr "+numer+", pojemnosc "+pojemnosc+", stan wody "+stan);
	}
	
}

class Main{
	
	public static void main(String[] args){
		
		Zbiornik a = new Zbiornik(1000,500);
		Zbiornik b = new Zbiornik(1200);
		
		a.dolej(100);
		a.przelej(b,550);
		b.odlej(500);
		a.show();
		b.show();
		a.odlej(1000);
		b.odlej(1500);
		a.show();
		b.show();
		a.dolej(1000);
		b.dolej(1500);
		System.out.println(a.toString());
		System.out.println(b.toString());
		
	}
	
}


/*Zdefiniowa� klas� Zbiornik, kt�rej obiekty b�d� stanowi� zbiorniki wody. Ka�dy zbiornik ma zadan� pojemno��, numer oraz aktualny stan wody. Zbiorniki s� numerowane automatycznie: pierwszy stworzony w  programie otrzymuje numer 1, ka�dy nast�pny o 1 wi�kszy od poprzedniego.
Metody dolej(double woda), odlej(double woda) pozwalaj� zmienia� stan wody poprzez dolewanie i odlewanie.
Metoda przelej(...) przelewa wod� z jednego zbiornika do innego.
Dostarczy� te� metody public String toString(), kt�ra zwraca opis zbiornika w postaci "Zbiornik nr N, pojemno�� V, stan wody W"
oraz metody void show() wy�wietlaj�cej informacje o zbiorniku na konsoli.

Uwzgl�dni� fakt �e ze zbiornik nie mo�e mie� stanu ujemnego ani wi�kszego ni� pojemno��*/ 