import javax.swing.*;

class Main{
	
	public static void main(String[] args){
		
		int a=Integer.parseInt(JOptionPane.showInputDialog(null,"Podaj pierwszy paramertr pary p1: "));
		int b=Integer.parseInt(JOptionPane.showInputDialog(null,"Podaj drugi paramertr pary p1: "));
		Para p1 = new Para(a,b);
		
		a=Integer.parseInt(JOptionPane.showInputDialog(null,"Podaj pierwszy paramertr pary p2: "));
		b=Integer.parseInt(JOptionPane.showInputDialog(null,"Podaj drugi paramertr pary p2: "));
		Para p2 = new Para(a,b);
		
		String napis1=JOptionPane.showInputDialog(null,"Podaj pierwszy napis: ");
		String napis2=JOptionPane.showInputDialog(null,"Podaj drugi napis: ");
		
		if (p1.equals(p2)) System.out.println("Para p1 i p2 takie same.");
		else System.out.println("Para p1 i p2 rozne.");
		if (napis1.equals(napis2)) System.out.println("Napis1 i napis2 takie same.");
		else System.out.println("Napis1 i napis2 rozne.");
	}
	
}