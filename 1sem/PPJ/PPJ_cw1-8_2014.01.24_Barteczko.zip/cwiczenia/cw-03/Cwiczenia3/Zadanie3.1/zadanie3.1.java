import javax.swing.*;

class Test{
	
	public static void main (String[] args){
		
		int a=Integer.parseInt(JOptionPane.showInputDialog(null,"Podaj pierwszy paramertr pary p1: "));
		int b=Integer.parseInt(JOptionPane.showInputDialog(null,"Podaj drugi paramertr pary p1: "));
		Para p1 = new Para(a,b);
		
		a=Integer.parseInt(JOptionPane.showInputDialog(null,"Podaj pierwszy paramertr pary p2: "));
		b=Integer.parseInt(JOptionPane.showInputDialog(null,"Podaj drugi paramertr pary p2: "));
		Para p2 = new Para(a,b);
		
		Para p3 = new Para();
		p3= p1.add(p2);
		
		JOptionPane.showMessageDialog(null,"Para p1 = "+p1.toString()+"\nPara p2 = "+p2.toString()+"\nSuma = "+p3.toString());
	}
	
}