class Para{
	
	private String name;
	private int first;
	private int second;
	private int number;
	private static int n=1;
	
	//Konstruktory
	
	public Para(){
		this(null, 1, 1, null);
	}
	
	public Para(Para p){
		this(null, 1, 1, p);
	}
	
	public Para(int x){
		this(null, x, x, null);
	}
	
	public Para(int x, int y){
		this(null, x, y, null);
	}
	
	public Para(String str){
		this(str, 1, 1, null);
	}
	
	public Para(String str, Para p){
		this(str, 1, 1, p);
	}
	
	public Para(String str, int x){
		this(str, x, x, null);
	}
	
	public Para(String str, int x, int y){
		this(str, x, y, null);
	}
	
	public Para(String str, int x, int y, Para p){
		number=n;
		n++;
		if(str==null){
			name="bez nazwy";
		}
		else{
			name=str;
		}
		if(p==null){
			first=x;
			second=y;
		}
		else{
			first=p.first;
			second=p.second;
		}
	}
	
	//Metody
	
	public int getFirst(){
		return first;
	}
	
	public int getSecond(){
		return second;
	}
	
	public String getName(){
		return name;
	}
	
	public void setFirst(int x){
		first=x;
	}
	
	public void setSecond(int x){
		second=x;
	}
	
	public void setName(String str){
		name=str;
	}
	
	//Metoda add
	
	public Para add(Para p){
		Para wynik = new Para ();
		wynik.name="suma par "+name+" i "+p.name;
		wynik.first=first+p.first;
		wynik.second=second+p.second;
		return wynik;
	}
	
	public Para add(int x){
		Para wynik = new Para ();
		wynik.name="suma pary "+name+" i liczby "+x;
		wynik.first=first+x;
		wynik.second=second+x;
		return wynik;
	}
	
	public Para add(int x, int y){
		Para wynik = new Para ();
		wynik.name="suma pary "+name+" i liczb "+x+" oraz "+y;
		wynik.first=first+x;
		wynik.second=second+y;
		return wynik;
	}
	
	//Metoda multiply
	
	public Para multiply(Para p){
		Para wynik = new Para ();
		wynik.name="iloczyn par "+name+" i "+p.name;
		wynik.first=first*p.first;
		wynik.second=second*p.second;
		return wynik;
	}
	
	public Para multiply(int x){
		Para wynik = new Para ();
		wynik.name="iloczyn pary "+name+" i liczby "+x;
		wynik.first=first*x;
		wynik.second=second*x;
		return wynik;
	}
	
	public Para multiply(int x, int y){
		Para wynik = new Para ();
		wynik.name="iloczyn pary "+name+" i liczb "+x+" oraz "+y;
		wynik.first=first*x;
		wynik.second=second*y;
		return wynik;
	}
	
	//Metody increase i decrease
	
	public void increase(){
		first++;
		second++;
	}
	
	public void decrease(){
		first--;
		second--;
	}
	
	//Metoda toString i equals
	
	public String toString(){
		return "Para nr "+number+" "+name+" = ( "+first+" , "+second+" )";
	}
	
	public boolean equals(Object o){
		if (!(o instanceof Para)) return false;
		Para p = (Para) o;
		return first == p.first && second == p.second;
	}
	
}

class ParaTest{
	
	public static void main(String[] args){
		
		Para p1 = new Para();
		Para p2 = new Para("fajna para", 2, 3);
		Para p3 = new Para("bla",5);
		System.out.println(p1.toString());
		System.out.println(p2.toString());
		System.out.println(p3.toString());
		
		Para p4 = p1.add(p2);
		System.out.println(p4.toString());
		
		Para p5 = p2.multiply(p3);
		System.out.println(p5.toString());
		
		System.out.println(p5.multiply(p3).toString());
		
		Para p6 = new Para("p6", p1);
		System.out.println(p6.toString());
		
		Para p7 = new Para("p7", p5.multiply(p3));
		System.out.println(p7.toString());
		
		Para p8 = new Para("p8", p5.multiply(p3));
		System.out.println(p8.toString());
		
		System.out.println(p5.toString());
		System.out.println(p6.toString());
		System.out.println(p7.toString());
		System.out.println(p8.toString());
		
	}
	
}