import javax.swing.*;

class Main{
	
	public static void main(String[] args){
		
		String str,wynik;
		wynik="";
		int i=1;
		
		while(true){
			str=JOptionPane.showInputDialog(null,"Skrobnij napisa");
			if(str==null || str.equalsIgnoreCase("koniec")) break;
			else{
				wynik+=i+"."+str+"\n";
				i++;
			}
		}
		
		System.out.println(wynik);
		
	}
	
}