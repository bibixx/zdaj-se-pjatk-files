class Test{
	
	public static void main(String[] args){
		
		String s = "A";
		int n = 1, m = 2;
		String out;
		out = ""+n + m; // jak zapewni�, by out zawiera�a napis 3?
		System.out.println(out);
		out = s + n + m; // jak zapewni�, by out zawiera� napis A3 ?
		System.out.println(out);
		
		out = ""+(n+m); //tak
		System.out.println(out);
		
		out = s+(n+m); //i tak
		System.out.println(out);
		
	}
	
}