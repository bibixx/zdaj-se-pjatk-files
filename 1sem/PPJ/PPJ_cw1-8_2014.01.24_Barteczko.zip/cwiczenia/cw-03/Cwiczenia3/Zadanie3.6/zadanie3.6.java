class Box{
	
	private double wysokosc;
	private double szerokosc;
	private double dlugosc;
	private double waga;
	
	public Box(double a, double b, double c, double d){
		wysokosc = a;
		szerokosc = b;
		dlugosc =c;
		waga = d;
	}
	
	public void setWysokosc(double a){
		wysokosc = a;
	}
	
	public void setSzerokosc(double a){
		szerokosc = a;
	}
	
	public void setDlugosc(double a){
		dlugosc = a;
	}
	
	public void setWaga(double a){
		waga = a;
	}
	
	public String toString(){
		return "Wysokosc="+wysokosc+" Szerokosc="+szerokosc+" Dlugosc="+dlugosc+" Waga="+waga;
	}
}

class LudzieWBunkrze{
	
	private double euro;
	private double amer;
	private double azja;
	
	public LudzieWBunkrze(double a, double b, double c){
		euro = a;
		amer = b;
		azja = c;
	}
	
	public void setEuro(double a){
		euro = a;
	}
	
	public void setAmer(double a){
		amer = a;
	}
	
	public void setAzja(double a){
		azja = a;
	}
	
	public String getPercentOfEuro(){
		return ((euro/(euro+amer+azja))*100)+"%";
	}
	
	public String getPercentOfAmer(){
		return ((amer/(euro+amer+azja))*100)+"%";
	}
	
	public String getPercentOfAzja(){
		return ((azja/(euro+amer+azja))*100)+"%";
	}
		
}

class Velocity {
 	
 	private double distance; // metry
 	private double time; // sekundy
 
  	public Velocity(double a, double b){
  		distance = a;
 		time = b;
 	}
 	
 	public void setDistance(double a){
 		distance = a;
 	}
 	
 	public void setTime(double a){
 		time = a;
 	}
 
 	public double getDistance(){
 		return distance;
 	}
 	
 	public double getTime(){
 		return time;
 	}
 	
 	public double getVelocity(){
 		return distance/time;
 	}
 	
} 

class Test{
	
	public static void main(String[] args){
		
		Box box1 = new Box (12, 10, 40, 5);
		box1.setWysokosc(15.3);
		box1.setSzerokosc(15.5);
		box1.setDlugosc(15.7);
		box1.setWaga(15.9);
		System.out.println(box1.toString());
		
		LudzieWBunkrze ludzie1 = new LudzieWBunkrze(10, 50, 120);
		ludzie1.setEuro(1);
		ludzie1.setAmer(99);
		ludzie1.setAzja(100);
		System.out.println(ludzie1.getPercentOfEuro());
		
		Velocity v1 = new Velocity(150, 60);
		System.out.println(v1.getVelocity());
		v1.setDistance(50);
		v1.setTime(2);
		System.out.println(v1.getDistance());
		System.out.println(v1.getTime());
		System.out.println(v1.getVelocity());
		
	}
	
}