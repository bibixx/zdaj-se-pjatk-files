class Para{
	
	private String name;
	private int first;
	private int second;
	private int number;
	private static int n=1;
	
	//Konstruktory
	
	public Para(){
		name="bez nazwy";
		first=second=1;
		number=n;
		n++;
	}
	
	public Para(int x){
		name="bez nazwy";
		first=second=x;
		number=n;
		n++;
	}
	
	public Para(int x, int y){
		name="bez nazwy";
		first=x;
		second=y;
		number=n;
		n++;
	}
	
	public Para(Para p){
		name="bez nazwy";
		first=p.first;
		second=p.second;
		number=n;
		n++;
	}
	
	public Para(String str){
		name=str;
		first=second=1;
		number=n;
		n++;
	}
	
	public Para(String str, int x){
		name=str;
		first=second=x;
		number=n;
		n++;
	}
	
	public Para(String str, int x, int y){
		name=str;
		first=x;
		second=y;
		number=n;
		n++;
	}
	
	public Para(String str, Para p){
		name=str;
		first=p.first;
		second=p.second;
		number=n;
		n++;
	}
	
	//Metody
	
	public int getFirst(){
		return first;
	}
	
	public int getSecond(){
		return second;
	}
	
	public String getName(){
		return name;
	}
	
	public void setFirst(int x){
		first=x;
	}
	
	public void setSecond(int x){
		second=x;
	}
	
	public void setName(String str){
		name=str;
	}
	
	//Metoda add
	
	public Para add(Para p){
		Para wynik = new Para ();
		wynik.name="suma par "+name+" i "+p.name;
		wynik.first=first+p.first;
		wynik.second=second+p.second;
		return wynik;
	}
	
	public Para add(int x){
		Para wynik = new Para ();
		wynik.name="suma pary "+name+" i liczby "+x;
		wynik.first=first+x;
		wynik.second=second+x;
		return wynik;
	}
	
	public Para add(int x, int y){
		Para wynik = new Para ();
		wynik.name="suma pary "+name+" i liczb "+x+" oraz "+y;
		wynik.first=first+x;
		wynik.second=second+y;
		return wynik;
	}
	
	//Metoda multiply
	
	public Para multiply(Para p){
		Para wynik = new Para ();
		wynik.name="iloczyn par "+name+" i "+p.name;
		wynik.first=first*p.first;
		wynik.second=second*p.second;
		return wynik;
	}
	
	public Para multiply(int x){
		Para wynik = new Para ();
		wynik.name="iloczyn pary "+name+" i liczby "+x;
		wynik.first=first*x;
		wynik.second=second*x;
		return wynik;
	}
	
	public Para multiply(int x, int y){
		Para wynik = new Para ();
		wynik.name="iloczyn pary "+name+" i liczb "+x+" oraz "+y;
		wynik.first=first*x;
		wynik.second=second*y;
		return wynik;
	}
	
	//Metody increase i decrease
	
	public void increase(){
		first++;
		second++;
	}
	
	public void decrease(){
		first--;
		second--;
	}
	
	//Metoda toString i equals
	
	public String toString(){
		return "Para nr "+number+" "+name+" = ( "+first+" , "+second+" )";
	}
	
	public boolean equals(Object o){
		if (!(o instanceof Para)) return false;
		Para p = (Para) o;
		return first == p.first && second == p.second;
	}
	
}

class ParaTest{
	
	public static void main(String[] args){
		
		Para p1 = new Para();
		Para p2 = new Para("fajna para", 2, 3);
		Para p3 = new Para("bla",5);
		System.out.println(p1.toString());
		System.out.println(p2.toString());
		System.out.println(p3.toString());
		
		Para p4 = p1.add(p2);
		System.out.println(p4.toString());
		
		Para p5 = p2.multiply(p3);
		System.out.println(p5.toString());
		
	}
	
}