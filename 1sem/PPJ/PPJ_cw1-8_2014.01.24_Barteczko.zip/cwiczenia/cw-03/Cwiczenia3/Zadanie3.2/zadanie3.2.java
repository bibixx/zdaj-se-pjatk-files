import javax.swing.*;

class Main{
	
	public static void main(String[] args){
		
		String napis;
		String wynik = "";
		int length = 0;
		
		for(int i=0; i<5; i++){
			napis=JOptionPane.showInputDialog(null,"Napis =");
			napis= napis.toUpperCase();
			wynik+="\n"+napis;
			if(napis.indexOf("JAVA")>=0) wynik+=" (java found)";
			length+=napis.length();
		}
		
		System.out.println(wynik);
		System.out.println(length);
		
	}
	
}