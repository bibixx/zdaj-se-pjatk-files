class Box{
	double w, h;
	public Box(double width, double height){
		w = width;
		h = height;
	}
	public Box joinDiagonal(Box i){
		Box tmp = new Box(w+i.w, h+i.h);
		return tmp;
	}
	public Box joinHorizontal(Box i){
		Box tmp = new Box(w>i.w?w:i.w, h+i.h);
		return tmp;
	}
	public Box joinVertical(Box i){
		Box tmp = new Box(w+i.w, h>i.h?h:i.h);
		return tmp;
    }
}

public class Main {
	public static void main(String[] args) {
		Box bdiag = new Box(0,0);
		Box bw = new Box(0,0);
		Box bh = new Box(0,0);
		while(true){
			String x = (String)javax.swing.JOptionPane.showInputDialog(null, "szerokosc:", "pudelka", javax.swing.JOptionPane.QUESTION_MESSAGE);
			if(x == null) break;
			double dx;
			try{
				dx = Double.parseDouble(x);
			}catch(Exception err){
				dx = 0.0;
			}
			if(dx != 0.0){
				Box btmp = new Box(2*dx, dx);
				bdiag = bdiag.joinDiagonal(btmp);
				bw = bw.joinVertical(btmp);
				bh = bh.joinHorizontal(btmp);
			}
		}
		System.out.println("Polaczone diagonalnie : w="+bdiag.w+", h="+bdiag.h);
		System.out.println("Polaczone wertykalne  : w="+bw.w+", h="+bw.h);
		System.out.println("Polaczone horyzontalne: w="+bh.w+", h="+bh.h);
	}
}