class Employee{
	String imie;
	String nazwisko;
	int wiek;
	double pensja;
	public Employee(String i, String n, int w, double p){
		imie=i;
		nazwisko=n;
		wiek=w;
		pensja=p;
	}
	public String toString(){
		return imie+" "+nazwisko+" (wiek: "+wiek+"), pensja: "+pensja+"";
	}
	public void zmienpensje(double oprocent){
		pensja*=(1+oprocent/100.0);
	}
}

class Main {
	public static void main(String[] args) {
		Employee p1 = new Employee("aaa", "bbb", 20, 1000);
		Employee p2 = new Employee("ccc", "ddd", 30, 2000);
		System.out.println(p1.toString());
		p1.zmienpensje(10);
		System.out.println(p1.toString());
		p2.zmienpensje(-10);
		System.out.println(p2.toString());
	}
}