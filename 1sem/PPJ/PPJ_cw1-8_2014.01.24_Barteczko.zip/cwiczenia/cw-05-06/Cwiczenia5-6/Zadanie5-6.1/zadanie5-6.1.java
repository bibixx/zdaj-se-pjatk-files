class Employee{
	
	private String name, surname;
	private int age;
	private double salary;
	
	public Employee(String n, String s, int a, double c){
		name=n;
		surname=s;
		age=a;
		salary=c;
	}
	
	public String toString(){
		return "Name "+name+"\nSurname "+surname+"\nAge "+age+"\nSalary "+salary+"$\n";
	}
	
	public void changeSalaryToPercent(double p){
		salary*=(p/100);
	}
	
}

class Main{
	
	public static void main(String[] args){
		
		Employee A, B, C, D;
		A = new Employee("On1", "Non1", 30, 1500);
		B = new Employee("On2", "Non2", 35, 2000);
		C = new Employee("On3", "Non3", 40, 2500);
		D = new Employee("On4", "Non4", 35, 3000);
		
		B.changeSalaryToPercent(50);
		D.changeSalaryToPercent(200);
		
		System.out.println(A.toString());
		System.out.println(B.toString());
		System.out.println(C.toString());
		System.out.println(D.toString());
		
	}
	
}