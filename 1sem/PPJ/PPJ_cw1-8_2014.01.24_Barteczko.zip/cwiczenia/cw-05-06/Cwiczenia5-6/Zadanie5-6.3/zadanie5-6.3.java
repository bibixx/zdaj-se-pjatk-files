import javax.swing.*;

class Box{
	
	private double height, width;
	
	public Box (double h, double w){
		height=h;
		width=w;
	}
	
	public Box joinDiagonal(Box b){
		Box newbox = new Box (this.height+b.height, this.width+b.width);
		return newbox;
	}
	
	public Box joinHorizontal(Box b){
		Box newbox = new Box (0, this.width+b.width);
		if(this.height>b.height) newbox.height=this.height;
		else newbox.height=b.height;
		return newbox;
	}
	
	public Box joinVertical(Box b){
		Box newbox = new Box (this.height+b.height, 0);
		if(this.width>b.width) newbox.width=this.width;
		else newbox.width=b.width;
		return newbox;
	}
	
	public String toString(){
		return "Wysokosc: "+height+"   Szerokosc: "+width;
	}
	
	public static boolean isDouble(String s){
		try{
			Double.parseDouble(s);
		}catch(NumberFormatException e){
			return false;
		}
		return true;
	}
	
}

class BoxTest{
	
	public static void main(String args[]){
		
		String value="";
		Box d, h, v;
		d = new Box (0,0);
		h = new Box (0,0);
		v = new Box (0,0);
		
		outerloop:
		do{
			do{
				value=JOptionPane.showInputDialog(null, "Podaj szerokosc pudelka:");
				if(value==null || value.equalsIgnoreCase("koniec")) break outerloop;
			}while(!Box.isDouble(value));
			Box box = new Box ((Double.parseDouble(value)*2), Double.parseDouble(value));
			System.out.println(box);
			d=d.joinDiagonal(box);
			h=h.joinHorizontal(box);
			v=v.joinVertical(box);
			
		}while(true);
		
		System.out.println("Laczenie diagonalne: "+d);
		System.out.println("Laczenie horyzontalne: "+h);
		System.out.println("Laczenie wertykalne: "+v);
		
	}
	
}