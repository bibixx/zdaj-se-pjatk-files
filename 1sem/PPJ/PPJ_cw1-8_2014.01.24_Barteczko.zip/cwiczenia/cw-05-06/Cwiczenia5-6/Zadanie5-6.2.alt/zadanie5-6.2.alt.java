class Employee{
	String imie;
	String nazwisko;
	int wiek;
	double pensja;
	public Employee(String i, String n, int w, double p){
		imie=i;
		nazwisko=n;
		wiek=w;
		pensja=p;
	}
	public String toString(){
		return imie+" "+nazwisko+" (wiek: "+wiek+"), pensja: "+pensja+"";
	}
	public void zmienpensje(double oprocent){
		pensja*=(1+oprocent/100.0);
	}
}

class EmployeeInterface{
	public EmployeeInterface(){
	}
	public static Employee defEmp(String msg){
		String i = (String)javax.swing.JOptionPane.showInputDialog(null, "imie:", msg, javax.swing.JOptionPane.QUESTION_MESSAGE);
		String n = (String)javax.swing.JOptionPane.showInputDialog(null, "nazwisko:", msg, javax.swing.JOptionPane.QUESTION_MESSAGE);
		String w = (String)javax.swing.JOptionPane.showInputDialog(null, "wiek:", msg, javax.swing.JOptionPane.QUESTION_MESSAGE);
		String p = (String)javax.swing.JOptionPane.showInputDialog(null, "pensja:", msg, javax.swing.JOptionPane.QUESTION_MESSAGE);
		int wi;
		try{
			wi = Integer.parseInt(w);
		}catch(Exception err){
			wi = 0;
		}
		if(wi < 0) wi = 0;
		double pd;
		try{
			pd = Double.parseDouble(p);
		}catch(Exception err){
			pd = 0.0;
		}
		if(pd < 0.0) pd = 0.0;
		Employee tmp = new Employee(i, n, wi, pd);
		return tmp;
	}
	public static void showInfo(Employee e){
		javax.swing.JOptionPane.showMessageDialog(null, e.toString(), "Message", javax.swing.JOptionPane.INFORMATION_MESSAGE);
		return;
	}
	public static void changeSalary(Employee e){
		String p = (String)javax.swing.JOptionPane.showInputDialog(null, "o jaki procent:", e.imie+" "+e.nazwisko, javax.swing.JOptionPane.QUESTION_MESSAGE);
		double pd;
		try{
			pd = Double.parseDouble(p);
		}catch(Exception err){
			pd = 0.0;
		}
		e.zmienpensje(pd);
	}
}

public class Main {
	public static void main(String[] args) {
		Employee e1 = EmployeeInterface.defEmp("Pracownik 1");
		Employee e2 = EmployeeInterface.defEmp("Pracownik 2");
		Employee e3 = EmployeeInterface.defEmp("Pracownik 3");
		EmployeeInterface.showInfo(e1);
		EmployeeInterface.showInfo(e2);
		EmployeeInterface.showInfo(e3);
		EmployeeInterface.changeSalary(e1);
		EmployeeInterface.changeSalary(e2);
		EmployeeInterface.changeSalary(e3);
		EmployeeInterface.showInfo(e1);
		EmployeeInterface.showInfo(e2);
		EmployeeInterface.showInfo(e3);
	}
}