import javax.swing.*;

class Employee{
	
	private String name, surname;
	private int age;
	private double salary;
	
	public Employee(String n, String s, int a, double c){
		name=n;
		surname=s;
		age=a;
		salary=c;
	}
	
	public static boolean isInteger(String s){
		try{
			Integer.parseInt(s);
		}catch(NumberFormatException e){
			return false;
		}
		return true;
	}
	
	public static boolean isDouble(String s){
		try{
			Double.parseDouble(s);
		}catch(NumberFormatException e){
			return false;
		}
		return true;
	}
	
	public static Employee defEmp(){
		String msg, msgA[];
		msg=JOptionPane.showInputDialog(null, "Podaj imie:")+";";
		msg+=JOptionPane.showInputDialog(null, "Podaj nazwisko:")+";";
		msg+=JOptionPane.showInputDialog(null, "Podaj wiek:")+";";
		msg+=JOptionPane.showInputDialog(null, "Podaj pensje:");
		msgA=msg.split(";",4);
		while(!Employee.isInteger(msgA[2])) msgA[2]=JOptionPane.showInputDialog(null, "Podaj wiek:");
		while(!Employee.isDouble(msgA[3])) msgA[3]=JOptionPane.showInputDialog(null, "Podaj pensje:");
		Employee Pracownik = new Employee (msgA[0], msgA[1], Integer.parseInt(msgA[2]), Double.parseDouble(msgA[3])); 
		return Pracownik;
	}
	
	public static void showInfo(Employee e){
		JOptionPane.showMessageDialog(null, "Name "+e.name+"\nSurname "+e.surname+"\nAge "+e.age+"\nSalary "+e.salary+"$\n");
	}
	
	public static void changeSalary(Employee e){
		String msg;
		msg=JOptionPane.showInputDialog(null, "O jaki procent zmienic pensje pracownika?");
		while(!Employee.isDouble(msg)) msg=JOptionPane.showInputDialog(null, "O jaki procent zmienic pensje pracownika?");
		e.salary*=1+(Double.parseDouble(msg)/100);
	}
	
	public String toString(){
		return "Name "+name+"\nSurname "+surname+"\nAge "+age+"\nSalary "+salary+"$\n";
	}
	
	public void changeSalaryToPercent(double p){
		salary*=(p/100);
	}
	
}

class Main{
	
	public static void main(String[] args){
		
		Employee A, B, C;
		
		A = Employee.defEmp();
		Employee.showInfo(A);
		Employee.changeSalary(A);
		Employee.showInfo(A);
		
		B = Employee.defEmp();
		Employee.showInfo(B);
		Employee.changeSalary(B);
		Employee.showInfo(B);
		
		C = Employee.defEmp();
		Employee.showInfo(C);
		Employee.changeSalary(C);
		Employee.showInfo(C);
		
	}
	
}