class Employee{
	String imie;
	String nazwisko;
	int wiek;
	double pensja;
	public Employee(String i, String n, int w, double p){
		imie=i;
		nazwisko=n;
		wiek=w;
		pensja=p;
	}
	public String toString(){
		return imie+" "+nazwisko+" (wiek: "+wiek+"), pensja: "+pensja+"";
	}
	public void zmienpensje(double oprocent){
		pensja*=(1+oprocent/100.0);
	}
}

class List{
	Emps head = null;
	Emps tail = null;
	public void init(){
		Emps pr = head;
		while(true){
			String i = (String)javax.swing.JOptionPane.showInputDialog(null, "imie:", "nowy pracownik", javax.swing.JOptionPane.QUESTION_MESSAGE);
			if(i==null) break;
			String n = (String)javax.swing.JOptionPane.showInputDialog(null, "nazwisko:", "nowy pracownik", javax.swing.JOptionPane.QUESTION_MESSAGE);
			if(n==null) break;
			String w = (String)javax.swing.JOptionPane.showInputDialog(null, "wiek:", "nowy pracownik", javax.swing.JOptionPane.QUESTION_MESSAGE);
			if(w==null) break;
			String p = (String)javax.swing.JOptionPane.showInputDialog(null, "pensja:", "nowy pracownik", javax.swing.JOptionPane.QUESTION_MESSAGE);
			if(p==null) break;
			int wi;
			try{
				wi = Integer.parseInt(w);
			}catch(Exception err){
				wi = 0;
			}
			if(wi < 0) wi = 0;
			double pd;
			try{
				pd = Double.parseDouble(p);
			}catch(Exception err){
				pd = 0.0;
			}
			if(pd < 0.0) pd = 0.0;
			Employee te = new Employee(i, n, wi, pd);
			Emps tmp = new Emps();
			tmp.ref = te;
			tmp.prev = pr;
			tmp.next = null;
			if(pr == null) head=tmp; else pr.next = tmp;
			tail = tmp;
			pr = tmp;
		}
	}
	public int getSize(){
		int size=0;
		Emps tmp=head;
		while(tmp != null){
			size++;
			tmp = tmp.next;
		}
		return size;
	}
	public void showForward(){
		Emps tmp=head;
		System.out.println("wyswietlanie listy od poczatku");
		while(tmp != null){
			System.out.println(tmp.ref.toString());
			tmp = tmp.next;
		}
	}
	public void showBackward(){
		Emps tmp=tail;
		System.out.println("wyswietlanie listy od konca");
		while(tmp != null){
			System.out.println(tmp.ref.toString());
			tmp = tmp.prev;
		}
	}
	public void changeAllSalaries(double oprocent){
		Emps tmp=head;
		while(tmp != null){
			tmp.ref.zmienpensje(oprocent);
			tmp = tmp.next;
		}
	}
}

class Emps{
	Emps prev = null;
	Emps next = null;
	Employee ref = null;
}

public class Main{
	public static void main(String[] args) {
		List l = new List();
		l.init();
		System.out.println(l.getSize());
		l.showForward();
		System.out.println("zmiana pensji o +10%");
		l.changeAllSalaries(10.0);
		l.showBackward();
	}
}