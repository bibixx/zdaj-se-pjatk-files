import javax.swing.*;

class List{
	
	public Emps first, last;
	
	public List(Emps emp1, Emps emp2){
		first = emp1;
		last = emp2;
	}
	
	public static List init(){
		List createdlist;
		Emps first, last, old, latest;
		Employee currentEmployee;
		int res, optionType;
		optionType = JOptionPane.YES_NO_OPTION;
		
		currentEmployee = Employee.defEmp();
		latest = new Emps(null, null, currentEmployee);
		first = latest;
		
		loop1:
		do{
			res = JOptionPane.showConfirmDialog(null, "Dodac kolejnego pracownika?", "Employee-o-matic", optionType);
			if(res == JOptionPane.YES_OPTION){
				old = latest;
				currentEmployee = Employee.defEmp();
				latest = new Emps(old, null, currentEmployee);
				old.next = latest;
			}
			if(res == JOptionPane.NO_OPTION){
				last = latest;
				break loop1;
			}
		}while(true);
		createdlist = new List(first, last);
		return createdlist;
	}
	
	public int getSize(){
		int size=1;
		Emps current;
		current = this.first;
		while(current.next!=null){
			current=current.next;
			size++;
		}
		return size;
	}
	
	public void showForward(){
		Emps current;
		current = this.first;
		do{
			System.out.println(current.employee);
			current=current.next;
		}while(current!=null);
	}
	
	public void showBackward(){
		Emps current;
		current = this.last;
		do{
			System.out.println(current.employee);
			current=current.prev;
		}while(current!=null);
	}
	
	public void changeAllSalaries(){
		String temp;
		double value;
		Emps current;
		
		do{
			temp = JOptionPane.showInputDialog(null, "Na jaki procent zmienic pensje pracownikow?");
		}while(!Employee.isDouble(temp));
		value = Double.parseDouble(temp);
		
		current = this.last;
		do{
			current.employee.changeSalaryToPercent(value);
			current=current.prev;
		}while(current!=null);
	}
	
}