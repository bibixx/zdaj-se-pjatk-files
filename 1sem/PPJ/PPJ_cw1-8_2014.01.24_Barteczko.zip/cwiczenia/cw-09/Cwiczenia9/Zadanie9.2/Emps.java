class Emps{
	
	public Emps prev, next;
	public Employee employee;
	
	public Emps(Emps p, Emps n, Employee e){
		prev = p;
		next = n;
		employee = e;
	}
	
}