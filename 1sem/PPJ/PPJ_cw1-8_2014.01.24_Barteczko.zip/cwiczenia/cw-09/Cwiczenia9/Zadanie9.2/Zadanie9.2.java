/*
 * @(#)Zadanie9.2.java 1.0 14/01/23
 *
 * You can modify the template of this file in the
 * directory ..\JCreator\Templates\Template_1\Project_Name.java
 *
 * You can also create your own project template by making a new
 * folder in the directory ..\JCreator\Template\. Use the other
 * templates as examples.
 *
 */
package myprojects.zadanie9.2;

import java.awt.*;
import java.awt.event.*;

class Zadanie9.2 extends Frame {
	
	public Zadanie9.2() {
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				dispose();
				System.exit(0);
			}
		});
	}

	public static void main(String args[]) {
		System.out.println("Starting Zadanie9.2...");
		Zadanie9.2 mainFrame = new Zadanie9.2();
		mainFrame.setSize(400, 400);
		mainFrame.setTitle("Zadanie9.2");
		mainFrame.setVisible(true);
	}
}
