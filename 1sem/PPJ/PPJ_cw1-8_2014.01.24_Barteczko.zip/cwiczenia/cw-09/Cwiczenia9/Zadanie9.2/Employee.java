import javax.swing.*;

class Employee{
	
	private String name, surname;
	private int age;
	public double salary;
	
	public Employee(String n, String s, int a, double c){
		name=n;
		surname=s;
		age=a;
		salary=c;
	}
	
	public static boolean isInteger(String s){
		try{
			Integer.parseInt(s);
		}catch(NumberFormatException e){
			return false;
		}
		return true;
	}
	
	public static boolean isDouble(String s){
		try{
			Double.parseDouble(s);
		}catch(NullPointerException | NumberFormatException e){
			return false;
		}
		return true;
	}
	
	public static Employee defEmp(){
		String n, s, a, c;
		do{
			n=JOptionPane.showInputDialog(null, "Podaj imie:");
		}while(n==null);
		do{
			s=JOptionPane.showInputDialog(null, "Podaj nazwisko:");
		}while(s==null);
		do{
			a=JOptionPane.showInputDialog(null, "Podaj wiek:");
		}while(!Employee.isInteger(a));
		do{
			c=JOptionPane.showInputDialog(null, "Podaj pensje:");
		}while(!Employee.isDouble(c));
		Employee Pracownik = new Employee (n, s, Integer.parseInt(a), Double.parseDouble(c)); 
		return Pracownik;
	}
	
	public static void showInfo(Employee e){
		JOptionPane.showMessageDialog(null, "Name "+e.name+"\nSurname "+e.surname+"\nAge "+e.age+"\nSalary "+e.salary+"$\n");
	}
	
	public static void changeSalaryByPercent(Employee e){
		String msg;
		msg=JOptionPane.showInputDialog(null, "O jaki procent zmienic pensje pracownika?");
		while(!Employee.isDouble(msg)) msg=JOptionPane.showInputDialog(null, "O jaki procent zmienic pensje pracownika?");
		e.salary*=1+(Double.parseDouble(msg)/100);
	}
	
	public String toString(){
		return "Name "+name+"\nSurname "+surname+"\nAge "+age+"\nSalary "+salary+"$\n";
	}
	
	public void changeSalaryToPercent(double p){
		salary*=(p/100);
	}
	
}