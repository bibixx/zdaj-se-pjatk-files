public class Main{
	
	public static void main(String[] args){
		
		List testlist;
		testlist = List.init();
		System.out.println(testlist.getSize());
		System.out.println();
		testlist.showForward();
		testlist.changeAllSalaries();
		testlist.showBackward();
		
	}
	
}