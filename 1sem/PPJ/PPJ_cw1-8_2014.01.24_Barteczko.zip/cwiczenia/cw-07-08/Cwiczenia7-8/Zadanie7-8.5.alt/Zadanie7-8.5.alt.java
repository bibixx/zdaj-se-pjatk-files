class Student{
	double oceny[][];
	public Student(){
		oceny = new double[4][2];
		oceny[0][0]=2.0;
		oceny[0][1]=0.0;
		oceny[1][0]=2.0;
		oceny[1][1]=2.0;
		oceny[2][0]=2.0;
		oceny[2][1]=0.0;
		oceny[3][0]=2.0;
		oceny[3][1]=2.0;
	}
	
	public double min(){
		double n=0.0;
		for(int i=0;i<4;i++){
			for(int j=0;j<2;j++){
				if(oceny[i][j] != 0.0 && (oceny[i][j] < n || n==0.0))
					n = oceny[i][j];
			}
		}
		return n;
	}

	public double max(){
		double n=0.0;
		for(int i=0;i<4;i++){
			for(int j=0;j<2;j++){
				if(oceny[i][j] > n)
					n = oceny[i][j];
			}
		}
		return n;
	}
	
	public double sred(){
		double n=0.0;
		int c=0;
		for(int i=0;i<4;i++){
			for(int j=0;j<2;j++){
				if(j==0 || (j==1 && oceny[i][j] != 0.0)){
					n += oceny[i][j];
					c++;
				}
			}
		}
		return c!=0?n/(double)c:0;
	}
	
	public double minZal(){
		double n=0.0;
		for(int i=0;i<4;i++){
			if(oceny[i][0] != 0.0 && (oceny[i][0] < n || n==0.0))
				n = oceny[i][0];
		}
		return n;
	}
	
	public double maxZal(){
		double n=2.0;
		for(int i=0;i<4;i++){
			if(oceny[i][0] > n)
				n = oceny[i][0];
		}
		return n;
	}
	
	public double minEgz(){
		double n=0.0;
		for(int i=0;i<4;i++){
			if(oceny[i][1] != 0.0 && (oceny[i][1] < n || n==0.0))
				n = oceny[i][1];
		}
		return n;
	}
	
	public double maxEgz(){
		double n=2.0;
		for(int i=0;i<4;i++){
			if(oceny[i][1] > n)
				n = oceny[i][1];
		}
		return n;
	}
	
	public double sredZal(){
		double n=0.0;
		int c=0;
		for(int i=0;i<4;i++){
			n += oceny[i][0];
			c++;
		}
		return c!=0?n/(double)c:0;
	}
	
	public double sredEgz(){
		double n=0.0;
		int c=0;
		for(int i=0;i<4;i++){
			if(oceny[i][1] != 0.0){
				n += oceny[i][1];
				c++;
			}
		}
		return c!=0?n/(double)c:0;
	}
}

class Main {
	public static void main(String[] args) {
		java.util.List<Student> listastudentow = new java.util.ArrayList<Student>();
		while(true){
			String in = (String)javax.swing.JOptionPane.showInputDialog(null, "d dodaj\nl lista\nz zmienocene [numer studenta 1..n] [przedmiot] [z/e] [ocena]\ni info [numer studenta 1..n]", "interface", javax.swing.JOptionPane.QUESTION_MESSAGE);
			if(in == null) break;
			String[] inex = in.split(" ");
			if(inex[0].equalsIgnoreCase("d")){
				listastudentow.add(new Student());
			}else if(inex[0].equalsIgnoreCase("l")){
				String out="";
				if(listastudentow.size() >= 1){
					for(int i=0;i<listastudentow.size();i++){
						out+="student "+(i+1)+":\n";
						Student s = listastudentow.get(i);
						out+="\t\tzaliczenie\tegzamin\n";
						out+="ANG\t\t"+s.oceny[0][0]+"\t\tbrak\n";
						out+="MAD\t\t"+s.oceny[1][0]+"\t\t"+s.oceny[1][1]+"\n";
						out+="PRG1\t\t"+s.oceny[2][0]+"\t\tbrak\n";
						out+="ALG\t\t"+s.oceny[3][0]+"\t\t"+s.oceny[3][1]+"\n";
						out+="\n";
					}
				}else{
					out = "nie ma studentow";
				}
				System.out.println(out);
			}else if(inex[0].equalsIgnoreCase("z")){
				String out="";
				if(inex.length >= 5){
					int sireal = Integer.parseInt(inex[1])-1;
					if(sireal < listastudentow.size()){
						Student s = listastudentow.get(sireal);
						int subjn=-1;
						if(inex[2].equalsIgnoreCase("ang")) subjn=0;
						else if(inex[2].equalsIgnoreCase("mad")) subjn=1;
						else if(inex[2].equalsIgnoreCase("prg1")) subjn=2;
						else if(inex[2].equalsIgnoreCase("alg")) subjn=3;
						if(subjn != -1){
							int ze=-1;
							if(inex[3].equalsIgnoreCase("z")) ze=0;
							else if(inex[3].equalsIgnoreCase("e")) ze=1;
							if(ze != -1){
								if(ze == 0 || (ze == 1 && s.oceny[subjn][ze] != 0.0)){
									double oc = Double.parseDouble(inex[4]);
									if(oc >= 1.999 && oc <= 5.001){
										s.oceny[subjn][ze] = oc;
										out = "ocena zmieniona";
									}
								}else{
									out = "ocena poza zakresem";
								}
							}else{
								out = "podaj z (zaliczenie) lub e (egzamin)";
							}
						}else{
							out = "taki przedmiot nie istnieje";
						}
					}else{
						out = "numer studenta za duzy";
					}
				}else{
					out = "podaj parametry";
				}
				System.out.println(out);
			}else if(inex[0].equalsIgnoreCase("i")){
				String out="";
				if(inex.length >= 2){
					int sireal = Integer.parseInt(inex[1])-1;
					if(sireal < listastudentow.size()){
						Student s = listastudentow.get(sireal);
						out="najni�sza ocena w tabeli: "+s.min()+"\nnajwy�sza ocena w tabeli: "+s.max()+"\n�rednia arytmetyczna ocen w tabeli: "+s.sred()+"\nnajni�sza ocena zaliczenia: "+s.minZal()+"\nnajwy�sza ocena zaliczenia: "+s.maxZal()+"\nnajni�sza ocena z egzaminu: "+s.minEgz()+"\nnajwy�sza ocena z egzaminu: "+s.maxEgz()+"\n�rednia arytmetyczna ocen z zalicze�: "+s.sredZal()+"\n�rednia arytmetyczna ocen z egzamin�w: "+s.sredEgz()+"\n";
					}else{
						out = "numer studenta za duzy";
					}
				}else{
					out = "podaj parametry";
				}
				System.out.println(out);
			}
		}
	}
}