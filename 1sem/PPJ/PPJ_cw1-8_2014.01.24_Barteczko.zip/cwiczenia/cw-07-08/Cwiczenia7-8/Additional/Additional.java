import java.util.*;

class Main{
	
	public static void main(String[] args){
		
		ArrayList<String> list = new ArrayList<>();
		list.add("lol");
		list.add("kola");
		list.add("dupa");
		System.out.println(list.size());
		
		
	}
	
}