class Matrix{
	public int w=0, h=0;
	public double m[][];
	public Matrix(int width, int height){
		w=width;
		h=height;
		if(w>0 && h>0)
			m = new double[w][h];
	}
	public void printmatrix(){
		for(int j=0;j<h;j++){
			for(int i=0;i<w;i++){
				System.out.print(m[i][j]+"\t");
			}
			System.out.print("\n");
		}
		System.out.print("\n");
		return;
	}
	public Matrix sumamacierzy(Matrix in){
		int maxw = w>in.w?w:in.w;
		int maxh = h>in.h?h:in.h;
		Matrix tmp = new Matrix(maxw,maxh);
		for(int i=0;i<maxw;i++){
			for(int j=0;j<maxh;j++){
				tmp.m[i][j]=0;
				if(i < w && j < h)
					tmp.m[i][j] += m[i][j];
				if(i < in.w && j < in.h)
					tmp.m[i][j] += in.m[i][j];
			}
		}
		return tmp;
	}
	public Matrix iloczynmacierzy(Matrix in){
		Matrix tmp;
		if(w == in.h){
			tmp = new Matrix(in.w,h);
			for(int i=0;i<in.w;i++){
				for(int j=0;j<h;j++){
					double esuma=0.0;
					for(int k=0;k<w;k++){
						esuma += m[k][j]*in.m[i][k];
					}
					tmp.m[i][j] = esuma;
				}
			}
		}else{
			tmp = new Matrix(0,0);
			System.out.println("Nie mozna pomnozyc");
		}
		return tmp;
	}
	public Matrix iloczynskalar(double in){
		Matrix tmp = new Matrix(w,h);
		for(int i=0;i<w;i++){
			for(int j=0;j<h;j++){
				tmp.m[i][j]=m[i][j]*in;
			}
		}
		return tmp;
	}
	
	public double sumakolumny(int col){
		double sum=0.0;
		for(int j=0;j<h;j++){
			sum+=m[col][j];
		}		
		return sum;
	}
	public double sumawiersza(int row){
		double sum=0.0;
		for(int i=0;i<w;i++){
			sum+=m[i][row];
		}		
		return sum;
	}
	public double sumamacierz(){
		double sum=0.0;
		for(int i=0;i<w;i++){
			for(int j=0;j<h;j++){
				sum+=m[i][j];
			}
		}
		return sum;
	}
}

class Main {
	public static void main(String[] args) {
		Matrix m1 = new Matrix(2,3);
		m1.m[0][0]=2; m1.m[1][0]=3;
		m1.m[0][1]=1; m1.m[1][1]=7;
		m1.m[0][2]=3.1; m1.m[1][2]=2;
		Matrix m2 = new Matrix(3,2);
		m2.m[0][0]=1; m2.m[1][0]=8; m2.m[2][0]=2;
		m2.m[0][1]=2; m2.m[1][1]=2; m2.m[2][1]=2;
		Matrix m3 = new Matrix(3,2);
		m3.m[0][0]=2; m3.m[1][0]=2; m3.m[2][0]=2;
		m3.m[0][1]=2; m3.m[1][1]=2; m3.m[2][1]=2;
		System.out.println("Suma macierzy A + B:");
		m1.sumamacierzy(m2).printmatrix();
		System.out.println("Suma macierzy B + C:");
		m3.sumamacierzy(m2).printmatrix();
		System.out.println("Iloczyn macierzy AB:");
		m1.iloczynmacierzy(m2).printmatrix();
		System.out.println("Iloczyn macierzy BC:");
		m2.iloczynmacierzy(m3).printmatrix();

		Matrix x = new Matrix(3,1);
		x.m[0][0]=1; x.m[1][0]=2; x.m[2][0]=3;
		Matrix y = new Matrix(1,3);
		y.m[0][0]=1;
		y.m[0][1]=2;
		y.m[0][2]=3;
		System.out.println("Iloczyn macierzy Ax:");
		m1.iloczynmacierzy(x).printmatrix();
		System.out.println("Iloczyn macierzy Bx:");
		m2.iloczynmacierzy(x).printmatrix();
		System.out.println("Iloczyn macierzy Ay:");
		m1.iloczynmacierzy(y).printmatrix();
		System.out.println("Iloczyn macierzy By:");
		m2.iloczynmacierzy(y).printmatrix();
		System.out.println("Iloczyn macierzy xy:");
		x.iloczynmacierzy(y).printmatrix();
		System.out.println("Iloczyn macierzy yx:");
		y.iloczynmacierzy(x).printmatrix();

		System.out.println("Iloczyn przez skalar qA, q=3:");
		m1.iloczynskalar(3).printmatrix();
		System.out.println("Iloczyn przez skalar qx, q=3:");
		x.iloczynskalar(3).printmatrix();

		System.out.println("Suma kolumny 1 macierzy A:");
		System.out.println(m1.sumakolumny(0));
		System.out.println("Suma wiersza 1 macierzy A:");
		System.out.println(m1.sumawiersza(0));
		System.out.println("Suma element�w macierzy A:");
		System.out.println(m1.sumamacierz());

		System.out.println("Suma kolumny 1 macierzy B:");
		System.out.println(m2.sumakolumny(0));
		System.out.println("Suma wiersza 1 macierzy B:");
		System.out.println(m2.sumawiersza(0));
		System.out.println("Suma element�w macierzy B:");
		System.out.println(m2.sumamacierz());
		
		System.out.println("Suma kolumny 1 macierzy x:");
		System.out.println(x.sumakolumny(0));
		System.out.println("Suma wiersza 1 macierzy x:");
		System.out.println(x.sumawiersza(0));
		System.out.println("Suma element�w macierzy x:");
		System.out.println(x.sumamacierz());

		System.out.println("Suma kolumny 1 macierzy y:");
		System.out.println(y.sumakolumny(0));
		System.out.println("Suma wiersza 1 macierzy y:");
		System.out.println(y.sumawiersza(0));
		System.out.println("Suma element�w macierzy y:");
		System.out.println(y.sumamacierz());
	}
}