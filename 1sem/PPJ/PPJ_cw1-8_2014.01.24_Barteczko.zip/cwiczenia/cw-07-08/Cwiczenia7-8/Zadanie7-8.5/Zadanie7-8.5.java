import java.util.*;
import javax.swing.*;

class Student{
	
	private static int idcounter=1;
	public int id;
	public double oceny[][];
	
	public Student(){
		id=idcounter;
		idcounter++;
		oceny = new double[][]{{0,0},{0,0},{0,0},{0,0}};
		// Ocena 0 oznacza, iz z danego przedmiotu nie bylo egzaminu.
	}
	
	public String getTable(){
		String temp="";
		temp+="\tPass\tExam";
		temp+="\nANG\t"+oceny[0][0]+"\t"+oceny[0][1];
		temp+="\nMAD\t"+oceny[1][0]+"\t"+oceny[1][1];
		temp+="\nPRG1\t"+oceny[2][0]+"\t"+oceny[2][1];
		temp+="\nALG\t"+oceny[3][0]+"\t"+oceny[3][1];
		return temp;
	}
	
	public String getInfo(){
		String temp="";
		temp+="\nmin\t"+this.min();
		temp+="\nmax\t"+this.max();
		temp+="\naverage\t"+this.average();
		temp+="\nminPass\t"+this.minPass();
		temp+="\nmaxPass\t"+this.maxPass();
		temp+="\nminExam\t"+this.minExam();
		temp+="\nmaxExam\t"+this.maxExam();
		temp+="\naveragePass\t"+this.averagePass();
		temp+="\naverageExam\t"+this.averageExam();
		return temp;
	}	
	
	public double min(){
		double m=6;
		for (int k=0;k<oceny.length;k++){
			for (int j=0;j<oceny[k].length;j++){
				if(oceny[k][j]!=0) m=Math.min(m,oceny[k][j]);
			}
		}
		return m;
	}
	
	public double max(){
		double m=0;
		for (int k=0;k<oceny.length;k++){
			for (int j=0;j<oceny[k].length;j++){
				if(oceny[k][j]!=0) m=Math.max(m,oceny[k][j]);
			}
		}
		return m;
	}
	
	public double average(){
		double a=0;
		int c=0;
		for (int k=0;k<oceny.length;k++){
			for (int j=0;j<oceny[k].length;j++){
				if(oceny[k][j]!=0){
					a+=oceny[k][j];
					c++;
				}
			}
		}
		return a/c;
	}
	
	public double minPass(){
		double m=6;
		for (int k=0;k<oceny.length;k++){
			if(oceny[k][0]!=0) m=Math.min(m,oceny[k][0]);
		}
		return m;
	}
	
	public double maxPass(){
		double m=0;
		for (int k=0;k<oceny.length;k++){
			if(oceny[k][0]!=0) m=Math.max(m,oceny[k][0]);
		}
		return m;
	}
	
	public double minExam(){
		double m=6;
		for (int k=0;k<oceny.length;k++){
			if(oceny[k][1]!=0) m=Math.min(m,oceny[k][1]);
		}
		return m;
	}
	
	public double maxExam(){
		double m=0;
		for (int k=0;k<oceny.length;k++){
			if(oceny[k][1]!=0) m=Math.max(m,oceny[k][1]);
		}
		return m;
	}
	
	public double averagePass(){
		double a=0;
		int c=0;
		for (int k=0;k<oceny.length;k++){
			if(oceny[k][0]!=0){
				a+=oceny[k][0];
				c++;
			}
		}
		return a/c;
	}
	
	public double averageExam(){
		double a=0;
		int c=0;
		for (int k=0;k<oceny.length;k++){
			if(oceny[k][1]!=0){
				a+=oceny[k][1];
				c++;
			}
		}
		return a/c;
	}
	
	public static boolean isDouble(String str){
		if(str!=null){
			try{
				Double.parseDouble(str);
				return true;
			}catch (NumberFormatException e){
				return false;
			}
    	}else return false;
    }

}



class Main{
	
	public static void main(String args[]){
		
		HashMap<String, Student> map = new HashMap<>();
		Object options1[] = {"Dodaj","Pokaz","Edytuj","Koniec"};
		Object options2[] = {"Lista","Student"};
		Object options3[] = {"ANG","MAD","PRG1","ALG"};
		
		loop1:
		while(true){
			int choice1 = JOptionPane.showOptionDialog(null,"Co chcesz zrobic?","Student-o-Matic", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options1, options1[3]);
			//System.out.println(choice);
			switch(choice1){
				
				case -1:
				break loop1;
				
				case 3:
				break loop1;
				
				case 0:
				map.put(JOptionPane.showInputDialog(null, "Podaj nazwe studenta"),new Student());
				break;
				
				case 1:
				int choice2 = JOptionPane.showOptionDialog(null,"Co chcesz zrobic?","Student-o-Matic", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options2, options2[0]);
				String display ="";
				switch(choice2){
					
					case -1:
					break loop1;
					
					case 0:
					Set<String> keys = map.keySet();
					Iterator iter = keys.iterator();
					for(String elt : keys) display+=elt+"\n";
					JOptionPane.showMessageDialog(null, "Lista studentow\n"+display);
					break;
					
					case 1:
					String tmp = JOptionPane.showInputDialog(null,"Podaj nazwe studenta:");
					if(map.containsKey(tmp)){
						display=map.get(tmp).getTable()+"\n"+map.get(tmp).getInfo();
						JOptionPane.showMessageDialog(null, new JTextArea(display));
					}
					else{
						display="Nie istnieje student o nazwie: "+tmp;
						JOptionPane.showMessageDialog(null, display);
					}
					break;
				}				
				break;

				case 2:
				String tmp = JOptionPane.showInputDialog(null,"Podaj nazwe studenta:");
				if(map.containsKey(tmp)){
					int choice3 = JOptionPane.showOptionDialog(null,"Wybierz przedmiot","Student-o-Matic", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options3, options3[0]);
					if(choice3==(-1)) break loop1;
					double mark1=10, mark2=10;
					String input;
					do{
						input = JOptionPane.showInputDialog(null,"Ocena z zaliczenia:");
						if(Student.isDouble(input)) mark1 = Double.parseDouble(input);
					}while(!((mark1==0)||((mark1>=2)&&(mark1<=5))));
					map.get(tmp).oceny[choice3][0] = mark1;
					do{
						input = JOptionPane.showInputDialog(null,"Ocena z egzaminu:");
						if(Student.isDouble(input)) mark2 = Double.parseDouble(input);
					}while(!((mark2==0)||((mark2>=2)&&(mark2<=5))));
					map.get(tmp).oceny[choice3][1] = mark2;
				}
				else{
					display="Nie istnieje student o nazwie: "+tmp;
					JOptionPane.showMessageDialog(null, display);
				}
				break;
			}
			
		}
		
	}
	
}