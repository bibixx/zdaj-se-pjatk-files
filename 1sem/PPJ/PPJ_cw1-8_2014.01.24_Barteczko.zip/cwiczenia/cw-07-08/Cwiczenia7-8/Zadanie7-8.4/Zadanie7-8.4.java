import java.util.*;

class Shelf{
	
	public String name;
	public int size;
	public ArrayList<String> list = new ArrayList<>();
	
	public Shelf(String n, int s){
		name=n;
		size=s;
	}
	
	public void info(){
		System.out.println("\n"+name+"\n----------");
		for (int i = 0; i < list.size(); i++){
			System.out.println(list.get(i));
		}
	}
	
}

class Book{
	
	public String title, author;
	public Object location;
	
	public Book(String t, String a){
		title=t;
		author=a;
		location="luzem";
	}
	
	public void info(){
		System.out.print("\n"+title+", "+author+", ");
		if(location=="luzem") System.out.println("luzem");
		else System.out.println(((Shelf)location).name);
	}
	
	public void putOn(Shelf s){
		if((s.list.size()+1)<=s.size){
			if(location=="luzem"){
				location=s;
			}else{
				((Shelf)location).list.remove(title);
				location=s;
			}
			s.list.add(title);
		}else{
			System.out.println("Shelf \""+s.name+"\" is full, cannot place another book.");
		}

	}
	
	public void takeOf(){
		if(location!="luzem") ((Shelf)location).list.remove(title);
		location="luzem";
	}
	
}


class Main{
	
	public static void main(String[] args){
		
		Shelf s1 = new Shelf("Entertainment",5);
		Shelf s2 = new Shelf("School",10);
		Shelf s3 = new Shelf("Cooking",15);
		
		Book b1 = new Book("Comics 1001Z","C.Oolguy");
		Book b2 = new Book("Games'n'U!","Mr. No L. Ife");
		Book b3 = new Book("Cookin' for dummies","M.Gessler");
		Book b4 = new Book("Math: Damn Hard","G.I. Neus");
		Book b5 = new Book("Programming languages for mentally challenged","Derp Derpetto");
		Book b6 = new Book("Some book about some stuff","Undecided Indecidentio");
		
		b1.putOn(s1);
		b2.putOn(s1);
		b3.putOn(s1);
		b4.putOn(s1);
		b5.putOn(s1);
		b6.putOn(s1);
		
		System.out.println("***");
		s1.info();
		s2.info();
		s3.info();
		
		b5.takeOf();
		
		System.out.println("***");
		s1.info();
		s2.info();
		s3.info();
		
		b4.putOn(s2);
		b5.putOn(s2);
		b6.putOn(s2);
		
		System.out.println("***");
		s1.info();
		s2.info();
		s3.info();
		
		b3.putOn(s3);
		
		System.out.println("***");
		s1.info();
		s2.info();
		s3.info();

	}
	
}