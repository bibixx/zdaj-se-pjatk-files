class Matrix{
	
	public int r, c;
	public double m[][];
	
	public Matrix(int rows, int columns){
		if(rows==0) rows=1;
		if(columns==0) columns=1;
		r=rows;
		c=columns;
		m = new double[r][c];
	}
	
	public Matrix(Matrix a, Matrix b){
		r = a.r>b.r?a.r:b.r;
		c = a.c>b.c?a.c:b.c;
		m = new double[r][c];
	}
	
	public void print(){	
		for(int k=0;k<r;k++){
			for(int l=0;l<c;l++){
				System.out.print(m[k][l]+"\t");
			}
			System.out.println();
		}
		System.out.println();
	}
	
	public Matrix add(Matrix x){
		Matrix n = new Matrix(this, x);
		for(int k=0;k<n.r;k++){
			for(int t=0;t<n.c;t++){
				try{
					n.m[k][t]=this.m[k][t]+x.m[k][t];
				}catch(ArrayIndexOutOfBoundsException err1){
					try{
						n.m[k][t]=this.m[k][t];
					}catch(ArrayIndexOutOfBoundsException err2){}
					try{
						n.m[k][t]=x.m[k][t];
					}catch(ArrayIndexOutOfBoundsException err3){}
				}
			}
		}
		return n;
	}
	
	public Matrix subtract(Matrix x){
		Matrix n = new Matrix(this, x);
		for(int k=0;k<n.r;k++){
			for(int t=0;t<n.c;t++){
				try{
					n.m[k][t]=this.m[k][t]-x.m[k][t];
				}catch(ArrayIndexOutOfBoundsException err1){
					try{
						n.m[k][t]=this.m[k][t];
					}catch(ArrayIndexOutOfBoundsException err2){}
					try{
						n.m[k][t]=0-x.m[k][t];
					}catch(ArrayIndexOutOfBoundsException err3){}
				}
			}
		}
		return n;
	}
	
	public Matrix multiply(double x){
		Matrix n = new Matrix(r,c);
		for(int k=0;k<r;k++){
			for(int t=0;t<c;t++){
				n.m[k][t]=this.m[k][t]*x;
			}
		}
		return n;
	}
	
	public Matrix multiply(Matrix x){
		Matrix n;
		if(c==x.r){
			n = new Matrix(r,x.c);
			for(int z=0;z<r;z++){
				for(int k=0;k<x.c;k++){
					n.m[z][k]=0;
					for(int i=0;i<c;i++){
						n.m[z][k]+=m[z][i]*x.m[i][k];
					}
				}
			}
		}else{
			n = new Matrix(this, x);
			System.out.println("Liczba kolumn pierwszej macierzy rozna od liczby wierszy drugiej macierzy.\n");
		}
		return n;
	}
	
	public double sumRow(int n){
		double sum=0;
		for(int k=0;k<c;k++){
			sum+=m[n][k];
		}
		return sum;
	}
	
	public double sumColumn(int n){
		double sum=0;
		for(int k=0;k<r;k++){
			sum+=m[k][n];
		}
		return sum;
	}
	
	public double sumElements(){
		double sum=0;
		for(int k=0;k<r;k++){
			for(int l=0;l<c;l++){
				sum+=m[k][l];
			}
		}
		return sum;
	}
	

}


class Main{
	
	public static void main(String[] args){
		
		Matrix A, B, C, x, y, q;
		A = new Matrix(3,2);
		B = new Matrix(2,3);
		C = new Matrix(2,3);
		x = new Matrix(1,3);
		y = new Matrix(3,1);
		q = new Matrix(1,1);
		
		A.m = new double[][]{{2,3},{1,7},{3.1,2}};
		B.m = new double[][]{{1,8,2},{2,2,2}};
		C.m = new double[][]{{2,2,2},{2,2,2}};
		x.m = new double[][]{{1,2,3}};
		y.m = new double[][]{{1},{2},{3}};
		q.m = new double[][]{{3}};
		
		System.out.println("A:");
		A.print();
		System.out.println("B:");
		B.print();
		System.out.println("C:");
		C.print();
		System.out.println("x:");
		x.print();
		System.out.println("y:");
		y.print();
		System.out.println("q:");
		q.print();
		
		System.out.println("A+B:");
		A.add(B).print();
		System.out.println("B+C:");
		B.add(C).print();
		System.out.println("AB:");
		A.multiply(B).print();
		System.out.println("BC:");
		B.multiply(C);
		System.out.println("Ax:");
		A.multiply(x);
		System.out.println("Bx:");
		B.multiply(x);
		System.out.println("Ay:");
		A.multiply(y);
		System.out.println("By:");
		B.multiply(y).print();
		System.out.println("xy:");
		x.multiply(y).print();
		System.out.println("yx:");
		y.multiply(x).print();
		System.out.println("qA (macierz q=[3]):");
		q.multiply(A);
		System.out.println("qx (macierz q=[3]):");
		q.multiply(x).print();
		System.out.println("qA (skalar q=3):");
		A.multiply(3).print();
		System.out.println("qx (skalar q=3):");
		x.multiply(3).print();
		
		System.out.println("A:");
		System.out.println("Suma wierszowa dla wiersza 0-ego:");
		System.out.println(A.sumRow(0));
		System.out.println("Suma kolumnowa dla kolumny 0-ej:");
		System.out.println(A.sumColumn(0));
		System.out.println("Suma wszystkich elementow:");
		System.out.println(A.sumElements());
		
		System.out.println("\nB:");
		System.out.println("Suma wierszowa dla wiersza 1-ego:");
		System.out.println(B.sumRow(1));
		System.out.println("Suma kolumnowa dla kolumny 1-ej:");
		System.out.println(B.sumColumn(1));
		System.out.println("Suma wszystkich elementow:");
		System.out.println(B.sumElements());
		
		System.out.println("\nx:");
		System.out.println("Suma wierszowa dla wiersza 0-ego:");
		System.out.println(x.sumRow(0));
		System.out.println("Suma kolumnowa dla kolumny 1-ej:");
		System.out.println(x.sumColumn(1));
		System.out.println("Suma wszystkich elementow:");
		System.out.println(x.sumElements());
		
		System.out.println("\ny:");
		System.out.println("Suma wierszowa dla wiersza 1-ego:");
		System.out.println(y.sumRow(1));
		System.out.println("Suma kolumnowa dla kolumny 0-ej:");
		System.out.println(y.sumColumn(0));
		System.out.println("Suma wszystkich elementow:");
		System.out.println(y.sumElements());
		
	}
	
}