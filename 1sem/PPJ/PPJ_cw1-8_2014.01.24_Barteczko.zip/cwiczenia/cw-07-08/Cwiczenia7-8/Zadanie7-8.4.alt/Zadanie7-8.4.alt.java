class polka{
	String nazwa;
	private java.util.Set<ksiazka> listaksiazek = new java.util.HashSet<ksiazka>();
	public polka(String n){
		nazwa=n;
	}
	public void polozksiazke(ksiazka k){
		listaksiazek.add(k);
		return;
	}
	public void zdejmijksiazke(ksiazka k){
		if(listaksiazek.contains(k)){
			listaksiazek.remove(k);
		}
		return;
	}
	public void listaksiazek(){
		System.out.println("lista ksiazek polki: "+nazwa);
		java.util.Iterator<ksiazka> iterator = listaksiazek.iterator();
		while(iterator.hasNext()) {
			ksiazka el = iterator.next();
			el.infooksiazce();
		}
		return;
	}
}

class ksiazka{
	String tytul;
	String autor;
	polka p;
	public ksiazka(String t, String a){
		tytul=t;
		autor=a;
		p=null;
	}
	public ksiazka(String t){
		this(t,"nieznany");
	}
	
	public void zdejmijzpolki(){
		if(p != null){
			p.zdejmijksiazke(this);
			p=null;
		}
		return;
	}
	public void poloznapolke(polka polka){
		if(p != null){
			zdejmijzpolki();
		}
		p=polka;
		p.polozksiazke(this);
		return;
	}
	public void infooksiazce(){
		System.out.println("ksiazka: "+tytul+", autor: "+autor);
	}
	public void infogdzie(){
		System.out.print("polka: ");
		if(p == null){
			System.out.println("luzem");
		}else{
			System.out.println(p.nazwa);
		}
	}
}

class Main {
	public static void main(String[] args) {
		polka polka1 = new polka("polka 1");
		polka polka2 = new polka("polka 2");
		
		ksiazka ksiazka1 = new ksiazka("ksiazka 1", "aaa");
		ksiazka ksiazka2 = new ksiazka("ksiazka 2", "bbb");
		ksiazka ksiazka3 = new ksiazka("ksiazka 3");
		
		polka1.listaksiazek();
		polka2.listaksiazek();
		
		System.out.println("\npolozenie ksiazki 1 na polke 1, ksiazki 2 na polke 1, ksiazki 3 na polke 2");
		ksiazka1.poloznapolke(polka1);
		ksiazka2.poloznapolke(polka1);
		ksiazka3.poloznapolke(polka2);
		
		polka1.listaksiazek();
		polka2.listaksiazek();

		System.out.println("\nzdjecie ksiazki 1 z polki");
		ksiazka1.zdejmijzpolki();

		polka1.listaksiazek();
		polka2.listaksiazek();

		System.out.println("\nprzelozenie ksiazki 3 na polke 1");
		ksiazka3.poloznapolke(polka1);

		polka1.listaksiazek();
		polka2.listaksiazek();
		
		System.out.println("\nksiazka 1 znajduje sie na polce:");
		ksiazka1.infogdzie();
		System.out.println("ksiazka 2 znajduje sie na polce:");
		ksiazka2.infogdzie();
		System.out.println("ksiazka 3 znajduje sie na polce:");
		ksiazka3.infogdzie();
	}
}