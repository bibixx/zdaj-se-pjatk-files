import javax.swing.*;

class Main{ 
	
	public static void main(String[] args){
		
		int c=1;
		Object array[][] = new Object[c][2];
		
		while(true){
			String input = JOptionPane.showInputDialog(null, "Podaj napis:");
			if (input==null) break;
			boolean exists = false;
			for(int i=0;i<c;i++){
				if(input.equals(array[i][0])){
					exists=true;
					array[i][1]=(int)array[i][1]+1;
				}
			}
			if(exists==false){
				c++;
				Object temp[][] = array;
				array = new Object[c][2];
				for(int l=0;l<temp.length;l++){
					array[l][0]=temp[l][0];
					array[l][1]=temp[l][1];
				}
				array[c-2][0]=input;
				array[c-2][1]=1;
				array[c-1][0]="Liczba wszystkich wpisow:";
			}
			array[c-1][1]=0;
			for(int j=0;j<(array.length-1);j++){
				array[c-1][1]=(int)array[c-1][1]+(int)array[j][1];
			}
			
		}
		
		for(int i=0;i<c;i++){
			System.out.println(array[i][0]+" "+array[i][1]);
		}
		
	}
	
}