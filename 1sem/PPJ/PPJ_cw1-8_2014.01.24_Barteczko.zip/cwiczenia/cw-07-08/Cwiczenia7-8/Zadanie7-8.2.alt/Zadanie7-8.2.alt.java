class Main {
	public static void main(String[] args) {
		String napisy[];
		int counts[];
		int size=2;
		int elemscount=0;
		napisy = new String[size];
		counts = new int[size];
		while(true){
			String in = (String)javax.swing.JOptionPane.showInputDialog(null, "wprowadz napis:", "napis", javax.swing.JOptionPane.QUESTION_MESSAGE);
			if(in == null) break;
			boolean exists=false;
			for(int j=0;j<elemscount;j++){
				if(napisy[j].equals(in)){
					counts[j]++;
					exists=true;
				}
			}
			if(!exists){
				if(size <= elemscount){
					String tmpn[]=napisy;
					int tmpc[]=counts;
					size*=2;
					napisy = new String[size];
					counts = new int[size];
					for(int c=0;c<elemscount;c++){
						napisy[c]=tmpn[c];
						counts[c]=tmpc[c];
					}
				}
				napisy[elemscount] = in;
				counts[elemscount] = 1;
				elemscount++;
			}
		}
		for(int i=0;i<elemscount;i++){
			if(i != 0) System.out.print(", ");
			System.out.print(napisy[i]+" "+counts[i]);
		}
	}
}