class Tab{
	
	public static int sumaParzystych(int[] t){
		int suma=0;
		for(int i=0; i<t.length; i+=2){
			suma+=t[i];
		}
		return suma;
	}
	
	public static String[] ciagZnakow(int[] t){
		String[] txt = new String[t.length];
		char abc='a';
		for(int i=0; i<txt.length; i++){
			txt[i]="";
			for(int l=0; l<t[i]; l++){
				txt[i]+=abc;
			}
			abc++;
		}
		return txt;
	}
	
	public static String[] przestawZnaki(String[] t){
		String[] txt = new String[t.length];
		for(int i=0; i<t.length; i+=2){
			try{
				txt[i]=t[i+1];
				txt[i+1]=t[i];
			}catch(ArrayIndexOutOfBoundsException err){
				txt[i]=t[i];
			}
		}
		return txt;
	}
	
	public static void toString(String[] t){
		for(String d : t){
			System.out.println(d);
		}
	}
	
}


class Main{
	
	public static void main(String[] args){
		
		int[] ltab = {5,6,7,8,9,10,11};
		String[] txt1 = Tab.ciagZnakow(ltab); 
		String[] txt2 = Tab.przestawZnaki(txt1);
		
		System.out.println(ltab.length);
		System.out.println(Tab.sumaParzystych(ltab));
		System.out.println("\ntxt1:");
		Tab.toString(txt1);
		System.out.println("\ntxt2:");
		Tab.toString(txt2);
		
		
	}
	
}