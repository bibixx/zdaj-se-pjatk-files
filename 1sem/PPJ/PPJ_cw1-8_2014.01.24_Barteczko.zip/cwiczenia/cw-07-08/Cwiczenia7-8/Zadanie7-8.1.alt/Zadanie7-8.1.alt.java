class Main {
	public static void main(String[] args) {
		int ltab[] = {2,5,3,1,7};
		int suma=0;
		for(int i=0;i<ltab.length;i+=2){
			suma+=ltab[i];
		}
		System.out.println("suma elementow parzystych: "+suma);
		String txt[] = new String[ltab.length];
		for(int i=0;i<ltab.length;i++){
			txt[i] = "";
			for(int j=0;j<ltab[i];j++){
				txt[i] += (char)(97+i%26);
			}
		}
		System.out.println("stworzona tablica:");
		for(int i=0;i<ltab.length;i++){
			System.out.println("element "+i+": "+txt[i]);
		}
		for(int i=1;i<ltab.length;i+=2){
			String tmp = txt[i];
			txt[i] = txt[i-1];
			txt[i-1] = tmp;
		}
		System.out.println("tablica z przestawionymi wyrazami:");
		for(int i=0;i<ltab.length;i++){
			System.out.println("element "+i+": "+txt[i]);
		}
	}
}