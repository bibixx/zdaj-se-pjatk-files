import java.util.*;
import javax.swing.*;

class Mat{
	
	static String sumaOgraniczona(int n, int m, int x){
		int S=0;
		int i;
		for(i=n;i<=m;i++){
			S+=i;
			if(S>x) return (S-i)+", "+(--i);
		}
		return S+" "+i;
	}
	
	static int suma(int n, int m){
		int S=0;
		for(int i=n;i<=m;i++) S+=i;
		return S;
	}
	
	static long iloczyn(int n, int m){
		long I=1;
		for(int i=n;i<=m;i++) I*=i;
		return I;
	}
	
	static long silnia(int n){
		long I=1;
		for(int i=1;i<=n;i++) I*=i;
		return I;
	}
	
	static double eX(double n, double m){
		double wynik=0, test=0;
		int i=0;
		do{
			test=wynik;
			wynik+=(Math.pow(n,i)/Mat.silnia(i));
			i++;
		}while(Math.abs(test-wynik)>=m);
		return wynik;
	}
	
}

class Main{
	
	public static void main(String[] args){
		
		while(true){
			Object[] operacje = {"Suma","Iloczyn","Silnia","Suma ograniczona","E do potegi X","Koniec"};
			int o = JOptionPane.showOptionDialog(
				null,
				"Wybierz operacje:",
				"Menu",
				JOptionPane.DEFAULT_OPTION,
				JOptionPane.QUESTION_MESSAGE,
				null,
				operacje,
				operacje[0]);
			if(o==5) System.exit(1);
			if(o==0){
				String argumenty = JOptionPane.showInputDialog(null, "Podaj dwie liczby calkowite oddzielone spacja (zakres od-do): ");
				Scanner scan = new Scanner(argumenty);
				int a=scan.nextInt();
				int b=scan.nextInt();
				JOptionPane.showMessageDialog(null, "Wynik kolejnego sumowania liczb od "+a+" do "+b+" to "+Mat.suma(a,b));
			}
			if(o==1){
				String argumenty = JOptionPane.showInputDialog(null, "Podaj dwie liczby calkowite oddzielone spacja (zakres od-do): ");
				Scanner scan = new Scanner(argumenty);
				int a=scan.nextInt();
				int b=scan.nextInt();
				JOptionPane.showMessageDialog(null, "Wynik kolejnego mnozenia liczb od "+a+" do "+b+" to "+Mat.iloczyn(a,b));
			}
			if(o==2){
				String argumenty = JOptionPane.showInputDialog(null, "Podaj liczbe calkowita: ");
				Scanner scan = new Scanner(argumenty);
				int a=scan.nextInt();
				JOptionPane.showMessageDialog(null, "Wynik silni to "+Mat.silnia(a));
			}
			if(o==3){
				String argumenty = JOptionPane.showInputDialog(null, "Podaj trzy liczby calkowite: ");
				Scanner scan = new Scanner(argumenty);
				int a=scan.nextInt();
				int b=scan.nextInt();
				int c=scan.nextInt();
				JOptionPane.showMessageDialog(null, "Wynik to "+Mat.sumaOgraniczona(a,b,c));
			}
			if(o==4){
				String argumenty = JOptionPane.showInputDialog(null, "Podaj wykladnik oraz dokladnosc (oddziel spacja): ");
				Scanner scan = new Scanner(argumenty);
				scan.useLocale(new Locale("en"));
				double a=scan.nextDouble();
				double b=scan.nextDouble();
				JOptionPane.showMessageDialog(null, "Wynik podniesienia liczby E do potegi "+a+" z dokladnoscia do "+b+" to "+Mat.eX(a,b));
			}
			
		}
		
	}
	
}