import java.util.*;
import javax.swing.*;

class Main{
	
	public static void main(String[] args){
		
		String result="";
		String temp1="";
		String temp2="";
		String longest=null;
		String shortest=null;
		String first=null;
		String last=null;
		
		while(true){
			temp1 = JOptionPane.showInputDialog(null, "Podaj ciag znakow:");
			if(temp1==null){
				if(!(temp2.equals(""))){
					if(longest==null || temp2.length()>longest.length()) longest=temp2;
				}
				if(!(temp2.equals(""))){
					if(shortest==null || temp2.length()<shortest.length()) shortest=temp2;
				}
				if(!(temp2.equals(""))){
					if(first==null || temp2.compareTo(first)<0) first=temp2;
				}
				if(!(temp2.equals(""))){
					if(last==null || temp2.compareTo(last)>0) last=temp2;
				}
				if(temp2.equals("")){
					break;
				}
				else{
					result+=(temp2+"\n");
					break;
				}
			}
			while(temp1.contains(".")){
				temp2 += temp1.substring(0,temp1.indexOf("."));
				if(longest==null || temp2.length()>longest.length()) longest=temp2;
				if(shortest==null || temp2.length()<shortest.length()) shortest=temp2;
				if(first==null || temp2.compareTo(first)<0) first=temp2;
				if(last==null || temp2.compareTo(last)>0) last=temp2;
				result+=(temp2+"\n");
				temp2="";
				temp1=temp1.substring((temp1.indexOf(".")+1));
			}
			if(!(temp1.contains("."))){
				temp2 += temp1;
			}
		
		}
		
		System.out.println("Wszystkie ciagi: \n"+result);
		System.out.println("Najdluzszy: "+longest);
		System.out.println("Najkrotszy: "+shortest);
		System.out.println("Pierwszy w porzadku leksykograficznym: "+first);
		System.out.println("Ostatni w porzadku leksykograficznym: "+last+"\n");
		
	}
	
}