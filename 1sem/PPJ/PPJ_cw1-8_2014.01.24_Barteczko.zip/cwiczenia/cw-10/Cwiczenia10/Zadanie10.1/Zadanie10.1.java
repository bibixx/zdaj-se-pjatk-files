/* GENERATOR LICZB PSEUDOLOSOWYCH */

import java.util.concurrent.*;

class Main{
	
	public static void main (String args[]){
		
		int gracz1, gracz2, bet1, bet2, roll1, roll2, round=0;
		gracz1=500;
		gracz2=500;
		
		System.out.println("Runda\tStawka\t\tGraczA-oczka\tGraczB-oczka\tGraczA-kwota\tGraczB-kwota");
		
		for(long timer=System.nanoTime()+TimeUnit.SECONDS.toNanos(1);timer>System.nanoTime();){
			round++;
			bet1=(int)(Math.random()*(gracz1-1)+1);
			bet2=(int)(Math.random()*(gracz2-1)+1);
			do{
				roll1=(int)(Math.random()*(12-1)+1);
				roll2=(int)(Math.random()*(12-1)+1);
			}while(roll1==roll2);
			
			gracz1 += roll1>roll2 ? bet2 : (-bet1);
			gracz2 += roll2>roll1 ? bet1 : (-bet2);
			
			System.out.println(round+"\t"+bet1+"+"+bet2+"\t\t"+roll1+"\t\t"+roll2+"\t\t"+gracz1+"\t\t"+gracz2);
			
			if(gracz1==0) break;
			if(gracz2==0) break;
			
		}
		
	}
	
}