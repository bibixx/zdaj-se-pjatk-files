class Sequence{
	public static int a(int n){
		if(n<0) return 0;
		if(n==0) return 1;
		if(n==1) return -3;
		return 6*a(n-1)-9*a(n-2);
	}
	public static int rekurencyjna(int n){
		return a(n);
	}
	public static int iteracyjna(int n){
		int a=0;
		int an1=1,an2=-3;
		for(int i=0;i<n;i++){
			a=6*an1-9*an2;
			an2=an1;
			an1=a;
		}
		return a;
	}
	public static int obliczeniowa(int n){
		return ((int)Math.pow(3, n))*(1-2*n);
	}
}

public class Main {
	public static void main(String[] args) {
		int n = 15;
		long m1 = System.currentTimeMillis();
		for(int i=0;i<100000;i++)
			Sequence.rekurencyjna(n);
		long m2 = System.currentTimeMillis();
		System.out.println("metoda rekurencyjna: "+(m2-m1)+" ms");
		m1 = System.currentTimeMillis();
		for(int i=0;i<100000;i++)
			Sequence.iteracyjna(n);
		m2 = System.currentTimeMillis();
		System.out.println("metoda iteracyjna: "+(m2-m1)+" ms");
		m1 = System.currentTimeMillis();
		for(int i=0;i<100000;i++)
			Sequence.obliczeniowa(n);
		m2 = System.currentTimeMillis();
		System.out.println("metoda obliczeniowa: "+(m2-m1)+" ms");
	}
}