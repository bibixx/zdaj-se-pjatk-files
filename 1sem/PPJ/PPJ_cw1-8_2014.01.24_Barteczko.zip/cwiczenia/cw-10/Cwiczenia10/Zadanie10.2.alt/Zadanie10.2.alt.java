class tbitow{
	public static int[] t(int num){
		java.util.List<Integer> t = new java.util.ArrayList<Integer>();
		int bp=1;
		for(int i=1;i<=Integer.SIZE;i++,bp*=2){
			if((num & bp) != 0){
				t.add(i);
			}
		}
		int[] ti = new int[t.size()];
	    for(int i=0;i<t.size();i++){
	        ti[i] = t.get(i);
	    }
		return ti;
	}
}

public class Main {
	public static void main(String[] args) {
		int[] t = tbitow.t(170); //10101010
		System.out.println("bity jedynkowe na pozycjach (od lsb):");
	    for(int i=0;i<t.length;i++){
	    	System.out.println(t[i]);
	    }
	}
}