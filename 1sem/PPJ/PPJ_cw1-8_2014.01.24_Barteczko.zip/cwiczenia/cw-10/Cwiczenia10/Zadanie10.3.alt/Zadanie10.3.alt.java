class Input{
	private static void get2IntArray(String in){
		java.util.List<Integer> ints = new java.util.ArrayList<Integer>();
		String[] intssp = in.split(" ");
		for(int i=0;i<intssp.length;i++){
			ints.add(Integer.parseInt(intssp[i]));
		}
		while(true){
			String data = "";
			for(int i=0;i<ints.size();i++){
				data+="liczba "+i+" = "+ints.get(i)+"\n";
			}
			in = (String)javax.swing.JOptionPane.showInputDialog(null, data, "podaj numer danej ktora chcesz zmienic", javax.swing.JOptionPane.QUESTION_MESSAGE);
			if(in == null) break;
			int num = Integer.parseInt(in);
			if(num < ints.size()){
				String in2 = (String)javax.swing.JOptionPane.showInputDialog(null, "podaj nowa wartosc", "input", javax.swing.JOptionPane.QUESTION_MESSAGE);
				if(in2 == null) continue;
				ints.set(num, Integer.parseInt(in2));
			}
		}
		java.util.Collections.sort(ints);
		String data = "";
		for(int i=0;i<ints.size();i++){
			if(data.length() > 0) data+=" ";
			data+=ints.get(i);
		}
		javax.swing.JOptionPane.showMessageDialog(null, data, "kolejnosc rosnaca", javax.swing.JOptionPane.INFORMATION_MESSAGE);
		java.util.Collections.reverse(ints);
		data = "";
		for(int i=0;i<ints.size();i++){
			if(data.length() > 0) data+=" ";
			data+=ints.get(i);
		}
		javax.swing.JOptionPane.showMessageDialog(null, data, "kolejnosc malejaca", javax.swing.JOptionPane.INFORMATION_MESSAGE);
	}
	public static void getIntArray(){
		String in = (String)javax.swing.JOptionPane.showInputDialog(null, "podaj liczby calkowite oddzielone spacjami", "input", javax.swing.JOptionPane.QUESTION_MESSAGE);
		get2IntArray(in);
	}
	public static void getintfromfile(){
		String in = (String)javax.swing.JOptionPane.showInputDialog(null, "podaj sciezke do pliku", "input", javax.swing.JOptionPane.QUESTION_MESSAGE);
		if(in == null) return;
	    String data=null;
	    try{
	    	java.io.FileInputStream inputStream = new java.io.FileInputStream(in);
	    	java.io.Reader reader = new java.io.BufferedReader(new java.io.InputStreamReader(inputStream, java.nio.charset.StandardCharsets.UTF_8));
			StringBuilder builder = new StringBuilder();
			char[] buffer = new char[8192];
			int read;
			while((read = reader.read(buffer, 0, buffer.length)) > 0) {
			    builder.append(buffer, 0, read);
			}
	        data = builder.toString();
	    	inputStream.close();
	    }catch(java.io.FileNotFoundException ex){
	    }catch(java.io.IOException ex){
	    }
	    if(data != null)
	    	get2IntArray(data);
	    else
	    	javax.swing.JOptionPane.showMessageDialog(null, "wystapil blad przy pracy z plikiem", "blad", javax.swing.JOptionPane.INFORMATION_MESSAGE);
	}
	public static void getDoubleArray(){
		java.util.List<Double> doubles = new java.util.ArrayList<Double>();
		String in = (String)javax.swing.JOptionPane.showInputDialog(null, "podaj liczby rzeczywiste oddzielone spacjami", "input", javax.swing.JOptionPane.QUESTION_MESSAGE);
		String[] intssp = in.split(" ");
		for(int i=0;i<intssp.length;i++){
			doubles.add(Double.parseDouble(intssp[i]));
		}
		while(true){
			String data = "";
			for(int i=0;i<doubles.size();i++){
				data+="liczba "+i+" = "+doubles.get(i)+"\n";
			}
			in = (String)javax.swing.JOptionPane.showInputDialog(null, data, "podaj numer danej ktora chcesz zmienic", javax.swing.JOptionPane.QUESTION_MESSAGE);
			if(in == null) break;
			int num = Integer.parseInt(in);
			if(num < doubles.size()){
				String in2 = (String)javax.swing.JOptionPane.showInputDialog(null, "podaj nowa wartosc", "input", javax.swing.JOptionPane.QUESTION_MESSAGE);
				if(in2 == null) continue;
				doubles.set(num, Double.parseDouble(in2));
			}
		}
		java.util.Collections.sort(doubles);
		String data = "";
		for(int i=0;i<doubles.size();i++){
			if(data.length() > 0) data+=" ";
			data+=doubles.get(i);
		}
		javax.swing.JOptionPane.showMessageDialog(null, data, "kolejnosc rosnaca", javax.swing.JOptionPane.INFORMATION_MESSAGE);
		java.util.Collections.reverse(doubles);
		data = "";
		for(int i=0;i<doubles.size();i++){
			if(data.length() > 0) data+=" ";
			data+=doubles.get(i);
		}
		javax.swing.JOptionPane.showMessageDialog(null, data, "kolejnosc malejaca", javax.swing.JOptionPane.INFORMATION_MESSAGE);
	}
}

public class Main {
	public static void main(String[] args) {
		Input.getIntArray();
		Input.getDoubleArray();
		Input.getintfromfile();
	}
}