class Main{
	
	public static void main (String[] args){
		
		double a,b,c,y;
		a=54.4324;
		b=54.23424;
		c=54.823424;
		
		y=a;
		
		if(b>y)y=b;
		if(c>y)y=c;
		
		System.out.println(y);
		
	}
				
}