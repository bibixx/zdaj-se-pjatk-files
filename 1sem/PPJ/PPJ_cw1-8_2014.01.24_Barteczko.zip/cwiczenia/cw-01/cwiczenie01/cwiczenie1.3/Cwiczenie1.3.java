class Main{
	
	public static void main(String[] args){
		
		double B, Bmax, KiB, MiB, cs;
		int p;
		
		B=10; //bajty
		MiB=0.0001; //mebibajty
		p=0;
		cs=B;
		
		Bmax=MiB*1024*1024;
		
		while(Bmax>cs){
			p++;
			KiB=B/1024;
			System.out.println("Pakiet: "+p+" ma rozmiar: "+B+" bajtow, czyli "+KiB+" kibibajtow.");
			B=2*B;
			cs=cs+B;
						
		}
		
		cs=cs-B;
		System.out.println("Liczba wszystkich pakietow o lacznym rozmiarze "+cs+" bajtow to: "+p);
				
	}
	
}