class Main{
	
	public static void main (String[] args){
		
		int suma, i, n;
		double iloczyn;
		
		suma=1;
		iloczyn=1;
		i=1;
		n=6;
		
		while(i<n){
			suma=suma+(1+i);
			iloczyn=iloczyn*(1+i);
			i++;
		}
		
		System.out.println("Obliczenia dla "+n+" kolejnych liczb naturalnych zaczynajac od 1.\nSuma: "+suma+"\nIloczyn: "+iloczyn);		
		
	}	
	
} 




