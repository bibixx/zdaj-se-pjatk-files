class Main{
	
	public static void main (String[] args){
		
		double e, xL, xP, xS;
		
		/* f(x)=Math.pow(x,3)+3 */
		
		e=0.00000000001; // dok�adno��
		xL=-10; // lewa strona przedzia�u
		xP=10; // prawa stona przedzia�u
		xS=(xL+xP)/2; // �rednia arytmetyczna przedzia�u
		
		if(Math.pow(xS,2)-2==0){
			System.out.println("Pierwiatek danego rownania: "+xS);
		}
		else{
			while(Math.abs(xL-xP)>e){
				xS=(xL+xP)/2;
				if(((Math.pow(xL,2)-2)*(Math.pow(xS,2)-2))<0){
					xP=xS;
				}
				if(((Math.pow(xP,2)-2)*(Math.pow(xS,2)-2))<0){
					xL=xS;
				}
			}
						
			System.out.println("Pierwiatek danego rownania: "+xS);
			System.out.println(Math.sqrt(2));
			
		}
		
	}
	
}