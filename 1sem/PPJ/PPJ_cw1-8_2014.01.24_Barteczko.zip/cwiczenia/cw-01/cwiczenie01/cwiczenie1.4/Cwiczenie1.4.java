class Main{
	
	public static void main (String[] args){
		
		double A1,r,B1,q,sumaA,sumaB;
		int i,n,m;
		
		n=5;
		A1=6;
		r=6;
		
		m=4;
		B1=1;
		q=2;
		
		i=1;
		sumaA=A1;
		
		while(i<n){
			sumaA=sumaA+A1+(r*i);
			i++;			
		}		
		
		i=1;
		sumaB=B1;
		
		while(i<m){
			sumaB=sumaB+(B1*Math.pow(q,i));
			i++;			
		}
		
		System.out.println("Sumy obliczone metoda iteracyjna:\nArytmetyczny: "+sumaA+"\nGeometryczny: "+sumaB);
		
		sumaA=(A1+(A1+r*(n-1)))*n/2;
		sumaB=(B1*(1-Math.pow(q,m)))/(1-q);
				
		System.out.println("Sumy obliczone wzorem:\nArytmetyczny: "+sumaA+"\nGeometryczny: "+sumaB);
					
	}
	
}


