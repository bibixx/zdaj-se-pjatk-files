class Main{
	
	public static void main (String[] args){
  	
  	int ld=5;
  	int lo=2;
  	double cp=100;
  	double ch=200;
  	double wd=300;
  	
  	double kp, kh, kwd, kc;
  	
  	kp=cp*lo;
  	kh=ch*lo*ld;
  	kwd=wd*ld;
  	
  	kc=kp+kh+kwd;
  	
  	System.out.println(kc);
  	
  	}
	
}