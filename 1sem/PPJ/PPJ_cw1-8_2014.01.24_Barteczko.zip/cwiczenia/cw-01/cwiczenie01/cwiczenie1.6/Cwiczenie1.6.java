class Main{
	
	public static void main (String[] args){
		
		int i;
		double K, J, kwota;
		
		kwota=50;
		i=1;
		K=0;
		J=0;
		
		while(i<=30){
			if((i%2)==1){
				K=K+kwota;
			}
			else{
				J=J+kwota;
			}
			kwota=kwota*1.05;
			i++;		
		}
		
		System.out.println("Po 30 dniach stan pieniezny (bez zaokraglenia) wyglada nastepujaco:\nKasia: "+K+"\nJoasia: "+J+"\nRazem: "+(J+K));
		
	}
	
}