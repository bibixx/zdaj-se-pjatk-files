import javax.swing.JOptionPane;

class Main{
	
	public static void main (String[] args){
		
		double x=Double.parseDouble(JOptionPane.showInputDialog("Podaj x:"));
		double y=Double.parseDouble(JOptionPane.showInputDialog("Podaj y:"));
		
		JOptionPane.showMessageDialog(null,x+" + "+y+" = "+(x+y));
		
	}
	
}