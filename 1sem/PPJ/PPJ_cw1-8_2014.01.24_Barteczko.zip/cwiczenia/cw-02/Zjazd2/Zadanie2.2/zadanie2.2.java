class Main{
	
	public static void main (String[] args){
		
		int a, b, c;
		double czDruga, czTrzecia;
		a=1;
		b=3;
		c=3;
		czDruga=2;
		czTrzecia=3;
		
		System.out.println("Liczby to: "+a+", "+b+", "+c+".");
		System.out.println("Suma: "+(a+b+c));
		System.out.println("Iloczyn: "+(a*b*c));
		System.out.println("Suma polowek: "+(a/czDruga+b/czDruga+c/czDruga));
		System.out.println("Suma czesci trzecich: "+(a/czTrzecia+b/czTrzecia+c/czTrzecia));
		
		
	}
	
}