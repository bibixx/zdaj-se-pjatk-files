import javax.swing.JOptionPane;

class Main{
	
	public static void main (String[] args){
		
		String s1, s2, s3;
		double x, y, z;		
		z=0;

		while(true){ //wieczna petla
			
			s1=JOptionPane.showInputDialog("Podaj x:"); // podaj x
			if((s1.equals("KONIEC"))||(s1.equals("Koniec"))||(s1.equals("koniec"))){
				System.exit(1);
			}
			x=Double.parseDouble(s1);
			
			do{ //wybierz operator
				s2=JOptionPane.showInputDialog("Podaj operator ( + - * / ):");
				if((s2.equals("KONIEC"))||(s2.equals("Koniec"))||(s2.equals("koniec"))){
					System.exit(1);
				}
			}while(!(s2.equals("+"))&&!(s2.equals("-"))&&!(s2.equals("*"))&&!(s2.equals("/")));
			
			do{ // podaj y
				s3=JOptionPane.showInputDialog("Podaj y (inne niz 0 w przypadku dzielenia):");
				if((s3.equals("KONIEC"))||(s3.equals("Koniec"))||(s3.equals("koniec"))){
					System.exit(1);
				}
			}while((s2.equals("/"))&&((s3.equals("0"))||(s3.equals(".0"))||(s3.equals("0."))||(s3.equals("00"))));
			y=Double.parseDouble(s3);
			
			if(s2.equals("+")){ //dodawanie
				z=x+y;
			}
			
			if(s2.equals("-")){ //odejmowanie
				z=x-y;
			}
			
			if(s2.equals("*")){ //mnozenie
				z=x*y;
			}
			
			if(s2.equals("/")){ //dzielenie
				z=x/y;
			}
			
			JOptionPane.showMessageDialog(null,s1+" "+s2+" "+s3+" = "+z); //wynik
			
		}

	}
	
}