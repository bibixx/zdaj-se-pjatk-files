class Main{
	
	public static void main (String[] args){
		
		int suma=0;
		double iloczyn=1;
		
		for(int i=1; i<=40; i++){
			suma+=i;
			iloczyn*=i;	
			
			if(i==10){
				System.out.println("Suma liczb od 1 do 10: "+suma);
				System.out.println("Iloczyn liczb od 1 do 10: "+iloczyn);
			}
			
			if(i==20){
				System.out.println("Suma liczb od 1 do 20: "+suma);
				System.out.println("Iloczyn liczb od 1 do 20: "+iloczyn);
			}
			
			if(i==40){
				System.out.println("Suma liczb od 1 do 40: "+suma);
				System.out.println("Iloczyn liczb od 1 do 40: "+iloczyn);
			}
										
		}
		
	}
	
}