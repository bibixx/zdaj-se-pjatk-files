import javax.swing.JOptionPane;

class Main{
	
	public static void main(String[] args){
		
		String S;
		double y, x;
		final double ratio = 4.2;
		
		S=JOptionPane.showInputDialog("Podaj liczbe euro:");
		x=Double.parseDouble(S);
		y=Math.round(x*ratio*100);
		y=y/100;
		JOptionPane.showMessageDialog(null,x+" EUR = "+y+" PLN");
				
	}
	
}