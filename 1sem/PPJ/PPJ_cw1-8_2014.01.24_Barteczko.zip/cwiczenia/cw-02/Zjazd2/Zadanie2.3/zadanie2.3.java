class Main{
	
	public static void main (String[] args){
		
		int ln, a, b;
		ln=1;
		a=0;
		b=0;
		
		a=ln++;
		System.out.println("Przyrostkowa inkrementacja, a="+a+", ln="+ln);
		
		b=++ln;
		System.out.println("Przedrostkowa inkrementacja, b="+b+", ln="+ln);
		
		a=ln--;
		System.out.println("Przyrostkowa dekrementacja, a="+a+", ln="+ln);
		
		b=--ln;
		System.out.println("Przedrostkowa dekrementacja, b="+b+", ln="+ln);
		
	}
	
}