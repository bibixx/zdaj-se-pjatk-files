class Main{
	
	public static void main (String[] args){
		
		int a;
		
		// a = 2.1;
		// b��dny zapis, wymagana jawna konwersja z double na int w celu wykazania zgody na mo�liw� utrat� danych
		
		// a = 2.1-0.1;
		// b��dny zapis, wymagana jawna konwersja z double na int w celu wykazania zgody na mo�liw� utrat� danych
		
		a = (int)2.1;
		// dokonana jawna konwersja z double na int
		System.out.println(a);		
		
	}
	
}