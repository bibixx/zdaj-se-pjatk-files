class Fruit{
	
	private String name;
	private double pricePerKG;
	private double quantity;
	
	public Fruit(String n, double c, double q){
		name=n;
		pricePerKG=c;
		quantity=q;
	}
	
	public String getName(){
		return name;
	}
	
	public double getFinalPrice(){
		return pricePerKG*quantity;
	}
	
	public double getQuantity(){
		return quantity;
	}
	
}



class Main{
	
	public static void main (String[] args){
		
		Fruit A = new Fruit ("jablka", 2.50, 3);
		Fruit B = new Fruit ("winogrona", 6, 0.5);
		
		double bill=A.getFinalPrice()+B.getFinalPrice();
		
		System.out.println("Rachunek: "+bill);
		
		System.out.println("Kupiono:");
		System.out.println(A.getName()+" w ilosci "+A.getQuantity()+"kg, za cene "+A.getFinalPrice()+"zl, co jest rowne okolo "+((int)((A.getFinalPrice()/bill)*100))+"% wartosci zakupow");
		System.out.println(B.getName()+" w ilosci "+B.getQuantity()+"kg, za cene "+B.getFinalPrice()+"zl, co jest rowne okolo "+(100-(int)((A.getFinalPrice()/bill)*100))+"% wartosci zakupow");
		
	}
	
}