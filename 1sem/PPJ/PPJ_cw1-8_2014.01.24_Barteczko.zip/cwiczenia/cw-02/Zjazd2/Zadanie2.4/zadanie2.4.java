class Main{
	
	public static void main (String[] args){
		
		System.out.println("Litera na pozycji o 5 wiekszej niz \"a\": "+(char)('a'+5));
		
		for(char a='a'; a<('z'+1); a++){
			System.out.println(a+"="+(int)a);
		}
		
		System.out.println("\nPolskie znaki:");
		System.out.println("�="+(int)'�');
		System.out.println("�="+(int)'�');
		System.out.println("�="+(int)'�');
		System.out.println("�="+(int)'�');
		System.out.println("�="+(int)'�');
		System.out.println("�="+(int)'�');
		System.out.println("�="+(int)'�');
		System.out.println("�="+(int)'�');
		System.out.println("�="+(int)'�');
		System.out.println("�="+(int)'�');
		System.out.println("�="+(int)'�');
		System.out.println("�="+(int)'�');
		System.out.println("�="+(int)'�');
		System.out.println("�="+(int)'�');
		System.out.println("�="+(int)'�');
		System.out.println("�="+(int)'�');
		System.out.println("�="+(int)'�');
		System.out.println("�="+(int)'�');
				
	}
	
}