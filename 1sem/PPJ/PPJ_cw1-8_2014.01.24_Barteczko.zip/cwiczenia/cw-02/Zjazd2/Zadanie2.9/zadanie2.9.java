import javax.swing.JOptionPane;

class Main{
	
	public static void main(String[] args){
		
		char A='A';
		int n=1;
		String S="";
		
		while(A<='Z'){
			S=S+n+" ... "+A+"\n";
			A+=2;
			n+=2;
		}
		
		JOptionPane.showMessageDialog(null,S);
		
		
		
	}
	
}