class Main{
	
	public static void main(String[] args){
		
		int s; //space in one container
		int n; //number of blocks
		
		s=4;
		n=20;
		
		if((n%s)>0){
			System.out.println("Uzyto "+((n/s)+1)+" pojemnikow, w czym w ostatnim jest "+(n%s)+" klockow.");
		}
		else{
			System.out.println("Uzyto "+(n/s)+" pojemnikow, w czym w ostatnim jest "+s+" klockow.");
		}

	}
	
}