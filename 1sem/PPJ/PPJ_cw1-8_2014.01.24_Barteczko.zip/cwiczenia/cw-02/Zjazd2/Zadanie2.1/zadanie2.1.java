class Main{
	
	public static void main (String[] args){
		
		System.out.println("imie i nazwisko,\nadres,\ne-mail");
				
	}	
	
}