import java.util.*;

class Main{
	
	public static void main (String[] args){
		
		Scanner scan = new Scanner(System.in);
		System.out.print("Podaj liczbe calkowita: ");
		int x = scan.nextInt();
		System.out.println("x = "+x);
		
	}
	
}