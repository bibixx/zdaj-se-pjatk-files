class Main{
	
	public static void main (String[] args){
		
		int x = Integer.parseInt(args[0]);
		System.out.println("x = "+x);
		
	}
	
}