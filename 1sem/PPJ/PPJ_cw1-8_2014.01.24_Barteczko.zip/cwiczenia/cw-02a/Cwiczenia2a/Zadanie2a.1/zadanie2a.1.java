import java.util.*;

class Main{
	
	public static void main (String[] args){
		
		Scanner scan = new Scanner(System.in);
		scan.useLocale(new Locale ("en"));
		System.out.print("Wprowadz pierwsza liczbe: ");
		double a = scan.nextDouble();
		System.out.print("Wprowadz druga liczbe: ");
		double b = scan.nextDouble();
		System.out.println("Liczby w odwrotnej kolejnosci: "+b+", "+a);		
		
	}
	
}