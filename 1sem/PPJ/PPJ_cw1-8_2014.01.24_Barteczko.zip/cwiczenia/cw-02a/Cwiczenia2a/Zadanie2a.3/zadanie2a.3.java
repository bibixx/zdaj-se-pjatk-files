import java.util.*;

class Main{
	
	public static void main(String[] args){
		
		Scanner scan = new Scanner(System.in);
		System.out.print("Podaj dwie liczby calkowite oddzielone spacja: ");
		int x = scan.nextInt();
		int y = scan.nextInt();
		System.out.println("x + y = "+(x+y));
		System.out.println("x - y = "+(x-y));
		System.out.println("x * y = "+(x*y));
		System.out.println("x % y = "+(x%y));

	}
	
}