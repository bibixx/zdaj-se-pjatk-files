class Compare{
	
	static int getMin (int a, int b, int c, int d, int e){
		int y;
		y = a;
		if(y>b) y=b;
		if(y>c) y=c;
		if(y>d) y=d;
		if(y>e) y=e;
		return y;
		
	}
	
	static int getMax (int a, int b, int c, int d, int e){
		int max;
		max = a;
		if(max<b) max=b;
		if(max<c) max=c;
		if(max<d) max=d;
		if(max<e) max=e;
		return max;
	}
	
	static int getNumOfPositive(int a, int b, int c, int d, int e){
		int y=0;
		if(0<a) y++;
		if(0<b) y++;
		if(0<c) y++;
		if(0<d) y++;
		if(0<e) y++;
		return y;
	}
	
}

class Main{
	
	public static void main(String[] args){
		
		int x = Integer.parseInt(args[0]);
		int y = Integer.parseInt(args[1]);
		int z = Integer.parseInt(args[2]);
		int v = Integer.parseInt(args[3]);
		int q = Integer.parseInt(args[4]);
		System.out.println("Max = "+Compare.getMax(x,y,z,v,q));
		System.out.println("Min = "+Compare.getMin(x,y,z,v,q));
		System.out.println("Liczba dodatnich: "+Compare.getNumOfPositive(x,y,z,v,q));

	}
	
}