class Compare{
	
	static int getMin (int a, int b, int c){
		int y;
		y = a;
		if(y>b) y=b;
		if(y>c) y=c;
		return y;
		
	}
	
}

class Main{
	
	public static void main(String[] args){

		int x = Integer.parseInt(args[0]);
		int y = Integer.parseInt(args[1]);
		int z = Integer.parseInt(args[2]);
		System.out.println("Max = "+Math.max(x,Math.max(y,z)));
		System.out.println("Min = "+Compare.getMin(x,y,z));

	}
	
}