import java.util.*;

class Compare{
	
	static int getMin (int a, int b, int c){
		int y;
		y = a;
		if(y>b) y=b;
		if(y>c) y=c;
		return y;
		
	}
	
}

class Main{
	
	public static void main(String[] args){
		
		Scanner scan = new Scanner(System.in);
		System.out.print("Podaj trzy liczby calkowite oddzielone spacja: ");
		int x = scan.nextInt();
		int y = scan.nextInt();
		int z = scan.nextInt();
		System.out.println("Max = "+Math.max(x,Math.max(y,z)));
		System.out.println("Min = "+Compare.getMin(x,y,z));

	}
	
}